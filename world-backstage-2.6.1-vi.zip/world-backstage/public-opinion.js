const WB_PUBLIC_SIGNAL_BIAS = 0x2d;

const NEWS_PUBLICITY = new Set(['public']);
const OPINION_PUBLICITY = new Set(['trace', 'public']);
const VALID_CONFIDENCE = new Set(['high', 'medium']);
const VALID_CLAIM_STATUS = new Set(['fact', 'mixed', 'rumor']);
const VALID_SOURCE_TYPE = new Set(['official', 'unofficial']);

function asArray(value) {
    return Array.isArray(value) ? value : [];
}

function asText(value, maximum = 600) {
    return String(value ?? '').trim().slice(0, maximum);
}

function clampInteger(value, fallback = 1, minimum = 0, maximum = 9) {
    const numeric = Number.parseInt(value, 10);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.min(maximum, Math.max(minimum, numeric));
}

function uniqueStrings(value, maximum = 6) {
    return [...new Set(asArray(value)
        .map(item => asText(item, 60))
        .filter(Boolean))]
        .slice(0, maximum);
}

function uniqueBy(items, keyFor) {
    const seen = new Set();
    return items.filter(item => {
        const key = keyFor(item);
        if (!key || seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function normalizeSourceType(value, fallback = 'unofficial') {
    const normalized = asText(value, 20).toLowerCase();
    return VALID_SOURCE_TYPE.has(normalized) ? normalized : fallback;
}

export function emptyPublicOpinionCache({
    generatedAt = '',
    sourceRevision = -1,
    sourceWorldMinute = -1,
    sourceEventSignature = '',
} = {}) {
    return {
        generatedAt: asText(generatedAt, 40),
        sourceRevision: clampInteger(sourceRevision, -1, -1, Number.MAX_SAFE_INTEGER),
        sourceWorldMinute: clampInteger(sourceWorldMinute, -1, -1, Number.MAX_SAFE_INTEGER),
        sourceEventSignature: asText(sourceEventSignature, 240),
        forumSourceSignature: asText(sourceEventSignature, 240),
        newsSourceSignature: '',
        lastForumWorldMinute: clampInteger(sourceWorldMinute, -1, -1, Number.MAX_SAFE_INTEGER),
        lastNewsWorldMinute: clampInteger(sourceWorldMinute, -1, -1, Number.MAX_SAFE_INTEGER),
        news: [],
        forums: [],
    };
}

export function eligiblePublicOpinionEvents(state) {
    return asArray(state?.events)
        .filter(event => OPINION_PUBLICITY.has(String(event?.publicity || 'private')))
        .filter(event => String(event?.id || '').trim())
        .sort((a, b) => Number(b?.updatedAt || b?.resolvedAt || 0) - Number(a?.updatedAt || a?.resolvedAt || 0))
        .slice(0, 24)
        .map(event => {
            const publicity = asText(event.publicity || 'private', 20);
            const publicHint = asText(event.publicTrace ?? event.public_trace, 360);
            if (publicity === 'trace') {
                const place = asText(event.place, 140);
                return {
                    id: asText(event.id, 120),
                    title: 'Dấu hiệu công khai chưa được xác thực',
                    place,
                    summary: '',
                    result: '',
                    status: asText(event.status, 30),
                    publicity,
                    visibility: asText(event.visibility, 20),
                    public_hint: publicHint || `${place ? `${place} và vùng lân cận ` : 'Đâu đó '}xuất hiện dấu hiệu chưa được xác thực nhưng đã có thể bị bên ngoài nhận ra.`,
                    public_headline: '',
                    public_summary: '',
                    public_result: '',
                    created_at: Number(event?.createdAt ?? -1),
                    updated_at: Number(event?.updatedAt ?? -1),
                    resolved_at: Number(event?.resolvedAt ?? -1),
                    clock_mode: asText(event?.clockMode, 30),
                    due_at: Number(event?.dueAt ?? -1),
                };
            }
            return {
                id: asText(event.id, 120),
                title: asText(event.title, 140),
                place: asText(event.place, 140),
                summary: '',
                result: '',
                status: asText(event.status, 30),
                publicity,
                visibility: asText(event.visibility, 20),
                public_hint: publicHint,
                public_headline: asText(event.publicHeadline ?? event.public_headline, 180),
                public_summary: asText(event.publicSummary ?? event.public_summary, 520),
                public_result: asText(event.publicResult ?? event.public_result, 520),
                created_at: Number(event?.createdAt ?? -1),
                updated_at: Number(event?.updatedAt ?? -1),
                resolved_at: Number(event?.resolvedAt ?? -1),
                clock_mode: asText(event?.clockMode, 30),
                due_at: Number(event?.dueAt ?? -1),
            };
        });
}

function publicSignalHash(value) {
    const text = String(value || '');
    let hash = (0x811c9dc5 ^ WB_PUBLIC_SIGNAL_BIAS) >>> 0;
    for (let index = 0; index < text.length; index += 1) {
        hash ^= text.charCodeAt(index);
        hash = Math.imul(hash, 0x01000193) >>> 0;
    }
    return hash.toString(16).padStart(8, '0');
}

// 只把“社会真正能看到的公开面”计入舆情来源签名。这里故意不复用
// eligiblePublicOpinionEvents：后者会按幕后 updatedAt 排序并截前 24 条，事件一多时
// 仅仅内部更新时间变化就可能把第 24/25 条换位，制造假的“公开来源变化”。
function publicOpinionSurfaceDescriptor(state, { newsOnly = false } = {}) {
    return asArray(state?.events)
        .filter(event => OPINION_PUBLICITY.has(String(event?.publicity || 'private')))
        .filter(event => String(event?.id || '').trim())
        .map(event => {
            const publicity = asText(event.publicity || 'private', 20);
            const place = asText(event.place, 140);
            const publicHint = asText(event.publicTrace ?? event.public_trace, 360);
            if (publicity === 'trace') {
                return {
                    id: asText(event.id, 120),
                    publicity: 'trace',
                    place,
                    public_hint: publicHint || `${place ? `${place} và vùng lân cận ` : 'Đâu đó '}xuất hiện dấu hiệu chưa được xác thực nhưng đã có thể bị bên ngoài nhận ra.`,
                };
            }
            return {
                id: asText(event.id, 120),
                publicity: 'public',
                place,
                public_hint: publicHint,
                public_headline: asText(event.publicHeadline ?? event.public_headline, 180),
                public_summary: asText(event.publicSummary ?? event.public_summary, 520),
                public_result: asText(event.publicResult ?? event.public_result, 520),
            };
        })
        .filter(event => !newsOnly || event.publicity === 'public')
        .sort((a, b) => String(a.id || '').localeCompare(String(b.id || '')));
}

export function publicOpinionSourceSignature(state) {
    return publicSignalHash(JSON.stringify(publicOpinionSurfaceDescriptor(state)));
}

export function publicOpinionNewsSourceSignature(state) {
    return publicSignalHash(JSON.stringify(publicOpinionSurfaceDescriptor(state, { newsOnly: true })));
}

export function planPublicOpinionRefresh(state, rawCache = {}, {
    force = false,
    forumIntervalMinutes = 180,
    newsIntervalMinutes = 360,
} = {}) {
    const candidates = eligiblePublicOpinionEvents(state);
    const cache = normalizePublicOpinionCache(rawCache || {});
    const worldMinute = Number(state?.clock?.absoluteMinute ?? -1);
    const sourceEventSignature = publicOpinionSourceSignature(state);
    const newsSourceSignature = publicOpinionNewsSourceSignature(state);
    const previousForumSignature = String(cache.forumSourceSignature || cache.sourceEventSignature || '');
    const previousNewsSignature = String(cache.newsSourceSignature || '');
    const forumSourceChanged = Boolean(candidates.length && sourceEventSignature !== previousForumSignature);
    const hasPublic = candidates.some(event => event.publicity === 'public');
    const hasTrace = candidates.some(event => event.publicity === 'trace');
    const newsSourceChanged = Boolean(hasPublic && newsSourceSignature !== previousNewsSignature);
    const sourceChanged = forumSourceChanged || newsSourceChanged;
    const fallbackMinute = Number(cache.sourceWorldMinute ?? -1);
    const lastForumWorldMinute = Number(cache.lastForumWorldMinute ?? fallbackMinute);
    const lastNewsWorldMinute = Number(cache.lastNewsWorldMinute ?? fallbackMinute);
    const forumElapsed = worldMinute >= 0 && lastForumWorldMinute >= 0
        ? Math.max(0, worldMinute - lastForumWorldMinute)
        : Number.POSITIVE_INFINITY;
    const newsElapsed = worldMinute >= 0 && lastNewsWorldMinute >= 0
        ? Math.max(0, worldMinute - lastNewsWorldMinute)
        : Number.POSITIVE_INFINITY;
    const forumDueByTime = Boolean(candidates.length && worldMinute >= 0 && forumElapsed >= Math.max(1, Number(forumIntervalMinutes) || 180));
    const newsDueByTime = Boolean(hasPublic && worldMinute >= 0 && newsElapsed >= Math.max(1, Number(newsIntervalMinutes) || 360));

    const allowForums = Boolean(candidates.length && (
        force
        || forumSourceChanged
        || forumDueByTime
    ));
    const allowNews = Boolean(hasPublic && (
        force
        || newsSourceChanged
        || newsDueByTime
    ));
    const due = Boolean(candidates.length && (allowForums || allowNews));

    let reason = 'idle';
    if (force && candidates.length) reason = 'manual-force';
    else if (sourceChanged) reason = 'public-source-changed';
    else if (newsDueByTime && forumDueByTime) reason = 'time-evolution-news-and-forums';
    else if (newsDueByTime) reason = 'time-evolution-news';
    else if (forumDueByTime) reason = 'time-evolution-forums';
    else if (!candidates.length) reason = 'no-public-candidates';

    return {
        due,
        reason,
        sourceChanged,
        forumSourceChanged,
        newsSourceChanged,
        sourceEventSignature,
        forumSourceSignature: sourceEventSignature,
        newsSourceSignature,
        worldMinute,
        candidates,
        hasPublic,
        hasTrace,
        allowForums,
        allowNews,
        forumElapsed,
        newsElapsed,
        nextForumAt: worldMinute >= 0
            ? Math.max(worldMinute, (lastForumWorldMinute >= 0 ? lastForumWorldMinute : worldMinute) + Math.max(1, Number(forumIntervalMinutes) || 180))
            : -1,
        nextNewsAt: worldMinute >= 0 && hasPublic
            ? Math.max(worldMinute, (lastNewsWorldMinute >= 0 ? lastNewsWorldMinute : worldMinute) + Math.max(1, Number(newsIntervalMinutes) || 360))
            : -1,
    };
}

function publicEventSourceType(event) {
    const text = [
        event?.public_hint,
        event?.public_headline,
        event?.public_summary,
        event?.public_result,
        event?.summary,
        event?.result,
    ].filter(Boolean).join(' ');
    return /公告|通报|官方|政府|机构|委员会|公司发布|声明|通知|公示|新闻发布|气象部门|交通部门|警方|消防|医院|学校|主办方|品牌方|供电|铁路|机场|thông báo|công bố|chính thức|chính phủ|cơ quan|ủy ban|uỷ ban|tuyên bố|thông cáo|họp báo|khí tượng|sở giao thông|cảnh sát|công an|cứu hỏa|cứu hoả|phòng cháy|bệnh viện|trường học|ban tổ chức|nhãn hàng|thương hiệu|điện lực|đường sắt|sân bay/i.test(text)
        ? 'official'
        : 'unofficial';
}

function publicEventTemporalState(event, worldMinute = 0) {
    const status = String(event?.status || '');
    if (['resolved', 'cancelled', 'missed'].includes(status)) return 'historical';
    const now = Number(worldMinute || 0);
    const dueAt = Number(event?.due_at);
    if (status === 'waiting') return 'upcoming';
    if (event?.clock_mode === 'scheduled' && Number.isFinite(dueAt) && dueAt > now) return 'upcoming';
    return 'current';
}

export function worldNewsFromPublicEvents(state, { maximum = 12 } = {}) {
    const worldMinute = Number(state?.clock?.absoluteMinute ?? -1);
    return eligiblePublicOpinionEvents(state)
        .filter(event => NEWS_PUBLICITY.has(String(event?.publicity || '')))
        .slice(0, Math.max(1, Number(maximum) || 12))
        .map(event => {
            const temporalState = publicEventTemporalState(event, worldMinute);
            const publicHint = asText(event.public_hint, 360);
            const terminalResult = temporalState === 'historical'
                ? asText(event.public_result, 520)
                : '';
            const publicSummary = terminalResult
                || asText(event.public_summary, 520)
                || publicHint;
            if (!publicSummary) return null;

            const fallbackHeadline = publicSummary
                .split(/[。！？!?\n]/u)
                .map(part => part.trim())
                .find(Boolean)
                ?.slice(0, 46) || 'Động thái thế giới công khai';
            const headline = asText(event.public_headline, 160) || fallbackHeadline;
            const sourceType = publicEventSourceType(event);
            const eventMinute = [
                Number(event?.updated_at),
                Number(event?.resolved_at),
                Number(event?.created_at),
            ].find(value => Number.isFinite(value) && value >= 0);

            return {
                id: `world_news_${event.id}`,
                category: 'Tin tức thế giới',
                headline,
                summary: publicSummary,
                source: sourceType === 'official' ? 'Thông tin cơ quan công khai' : 'Thông tin thế giới công khai',
                sourceType,
                audienceTags: [],
                scope: asText(event.place, 80) || 'Lan truyền công khai',
                relatedEventId: asText(event.id, 120),
                confidence: 'high',
                heat: 1,
                worldSynced: true,
                eventStatus: asText(event.status, 30),
                temporalState,
                worldMinute: clampInteger(
                    eventMinute,
                    worldMinute,
                    -1,
                    Number.MAX_SAFE_INTEGER,
                ),
            };
        })
        .filter(Boolean);
}

export function mergeWorldNewsIntoPublicOpinion(state, rawCache = {}) {
    const cache = normalizePublicOpinionCache(rawCache || {});
    const synced = worldNewsFromPublicEvents(state, { maximum: 18 });
    const existingByEvent = new Map(
        cache.news
            .filter(item => item.relatedEventId)
            .map(item => [String(item.relatedEventId), item]),
    );
    const currentIds = new Set();
    const currentNews = synced.map(worldItem => {
        const existing = existingByEvent.get(worldItem.relatedEventId);
        currentIds.add(worldItem.relatedEventId);
        return {
            ...worldItem,
            ...(existing || {}),
            id: existing?.id || worldItem.id,
            relatedEventId: worldItem.relatedEventId,
            worldSynced: true,
            // 这个 helper 只补世界事件的来源/状态元数据。已经经过舆情调度器生成的
            // headline/summary 是该传播节点自己的表述，不能再被事件最初的公开摘要覆盖。
            source: existing?.source || worldItem.source,
            audienceTags: existing?.audienceTags || worldItem.audienceTags,
            scope: existing?.scope || worldItem.scope,
            eventStatus: worldItem.eventStatus,
            temporalState: worldItem.temporalState,
            publishedAt: existing?.publishedAt || worldItem.publishedAt || '',
            updatedAt: existing?.updatedAt || worldItem.updatedAt || '',
            worldMinute: Math.max(
                Number(existing?.worldMinute ?? -1),
                Number(worldItem.worldMinute ?? -1),
            ),
        };
    });

    const historicalNews = cache.news.filter(item => (
        !item.relatedEventId || !currentIds.has(String(item.relatedEventId))
    ));

    return {
        ...cache,
        news: uniqueBy(
            [...currentNews, ...historicalNews]
                .sort(compareOpinionRecency),
            item => item.relatedEventId
                ? `event:${item.relatedEventId}`
                : `${item.headline}\u0000${item.summary}`,
        ).slice(0, 18),
        forums: cache.forums.slice(0, 12),
    };
}

function opinionItemChanged(previous, next, fields) {
    if (!previous) return true;
    return fields.some(field => String(previous?.[field] ?? '') !== String(next?.[field] ?? ''));
}

function opinionWallClockValue(item) {
    const timestamp = Date.parse(item?.updatedAt || item?.publishedAt || '');
    return Number.isFinite(timestamp) ? timestamp : -1;
}

function compareOpinionRecency(a, b) {
    // 舆情新旧以主世界时间为第一排序轴；现实生成时间只在同一世界时刻内做次级排序。
    const worldDifference = Number(b?.worldMinute ?? -1) - Number(a?.worldMinute ?? -1);
    if (worldDifference) return worldDifference;
    const wallDifference = opinionWallClockValue(b) - opinionWallClockValue(a);
    if (wallDifference) return wallDifference;
    return String(b?.id || '').localeCompare(String(a?.id || ''));
}

export function mergePublicOpinionStream(previousRaw, nextRaw, {
    maximumNews = 18,
    maximumForums = 12,
} = {}) {
    const previous = normalizePublicOpinionCache(previousRaw || {});
    const next = normalizePublicOpinionCache(nextRaw || {});
    const generatedAt = next.generatedAt || new Date().toISOString();

    const previousNewsByEvent = new Map(
        previous.news
            .filter(item => item.relatedEventId)
            .map(item => [String(item.relatedEventId), item]),
    );
    const nextNewsEventIds = new Set();
    const freshNews = next.news.map(item => {
        const previousItem = item.relatedEventId
            ? previousNewsByEvent.get(String(item.relatedEventId))
            : null;
        if (item.relatedEventId) nextNewsEventIds.add(String(item.relatedEventId));

        const changed = opinionItemChanged(previousItem, item, [
            'headline', 'summary', 'source', 'category', 'scope',
        ]);
        return {
            ...previousItem,
            ...item,
            id: previousItem?.id || item.id,
            publishedWorldMinute: previousItem?.publishedWorldMinute ?? previousItem?.worldMinute ?? item.publishedWorldMinute ?? item.worldMinute,
            publishedAt: previousItem?.publishedAt || item.publishedAt || generatedAt,
            updatedAt: changed
                ? (item.updatedAt || generatedAt)
                : (previousItem?.updatedAt || item.updatedAt || generatedAt),
            worldMinute: changed
                ? Number(item.worldMinute ?? next.sourceWorldMinute ?? -1)
                : Number(previousItem?.worldMinute ?? item.worldMinute ?? -1),
        };
    });

    const retainedNews = previous.news.filter(item => (
        !item.relatedEventId || !nextNewsEventIds.has(String(item.relatedEventId))
    ));

    const consumedForums = new Set();
    const freshForums = next.forums.map(item => {
        const sameSource = previousItem => previousItem.relatedEventId === item.relatedEventId
            && previousItem.board === item.board && !consumedForums.has(previousItem.id);
        const previousItem = previous.forums.find(candidate => sameSource(candidate) && candidate.id === item.id)
            || previous.forums.find(candidate => sameSource(candidate) && candidate.title === item.title);
        if (previousItem) consumedForums.add(previousItem.id);
        const replies = uniqueBy([...(previousItem?.replies || []), ...(item.replies || [])],
            reply => `${reply.author}\u0000${reply.text}`).slice(-8);
        const changed = opinionItemChanged(previousItem, item, ['title', 'summary', 'claimStatus', 'heat'])
            || JSON.stringify(previousItem?.replies || []) !== JSON.stringify(replies);
        return {
            ...previousItem, ...item,
            id: previousItem?.id || item.id,
            replies,
            publishedAt: previousItem?.publishedAt || item.publishedAt || generatedAt,
            publishedWorldMinute: previousItem?.publishedWorldMinute ?? previousItem?.worldMinute ?? item.publishedWorldMinute ?? item.worldMinute,
            updatedAt: changed ? (item.updatedAt || generatedAt) : (previousItem?.updatedAt || item.updatedAt || generatedAt),
            worldMinute: changed ? Number(item.worldMinute ?? next.sourceWorldMinute ?? -1) : Number(previousItem?.worldMinute ?? item.worldMinute ?? -1),
        };
    });
    const retainedForums = previous.forums.filter(item => !consumedForums.has(item.id));

    const news = uniqueBy(
        [...freshNews, ...retainedNews]
            .sort(compareOpinionRecency),
        item => item.relatedEventId
            ? `event:${item.relatedEventId}`
            : `${item.headline}\u0000${item.summary}`,
    ).slice(0, Math.max(1, Number(maximumNews) || 18));

    const forums = uniqueBy(
        [...freshForums, ...retainedForums]
            .sort(compareOpinionRecency),
        item => `${item.relatedEventId}\u0000${item.board}\u0000${item.title}`,
    ).slice(0, Math.max(1, Number(maximumForums) || 12));

    return {
        ...next,
        news,
        forums,
    };
}

export function buildPublicOpinionPrompt(state, {
    clockLabel = '',
    previousCache = null,
    elapsedMinutes = null,
    forumElapsedMinutes = elapsedMinutes,
    newsElapsedMinutes = elapsedMinutes,
    allowNews = true,
    allowForums = true,
    reason = '',
    customInstruction = '',
} = {}) {
    const events = eligiblePublicOpinionEvents(state);
    const previous = normalizePublicOpinionCache(previousCache || {});
    const wantedIds = new Set(events.map(event => String(event.id || '')));
    const compactPrevious = {
        news: previous.news
            .filter(item => wantedIds.has(String(item.relatedEventId || '')))
            .slice(0, 8)
            .map(item => ({
                id: item.id,
                headline: item.headline,
                summary: item.summary,
                source_type: item.sourceType,
                scope: item.scope,
                related_event_id: item.relatedEventId,
                heat: item.heat,
            })),
        forums: previous.forums
            .filter(item => wantedIds.has(String(item.relatedEventId || '')))
            .slice(0, 8)
            .map(item => ({
                id: item.id,
                replies: item.replies,
                board: item.board,
                title: item.title,
                summary: item.summary,
                claim_status: item.claimStatus,
                scope: item.scope,
                related_event_id: item.relatedEventId,
                heat: item.heat,
            })),
    };
    const context = {
        world_name: asText(state?.world?.name || 'Thế giới chính', 80),
        world_time: asText(clockLabel, 100),
        elapsed_forum_world_minutes: Math.max(0, Number(forumElapsedMinutes) || 0),
        elapsed_news_world_minutes: Math.max(0, Number(newsElapsedMinutes) || 0),
        update_reason: asText(reason, 80),
        allow_news: Boolean(allowNews),
        allow_forums: Boolean(allowForums),
        user_world_focus: asText(customInstruction, 1000),
        previous_snapshot: compactPrevious,
        public_event_candidates: events,
    };

    return [
        'Bạn là bộ quan sát Dư luận thế giới của “世界背面”. Bạn chỉ tạo ảnh chụp tin tức và diễn đàn chỉ đọc, không sửa trạng thái thế giới, nhận thức nhân vật, sự kiện, ký ức, thời gian hay chính văn. Sẽ không ghi ngược vào nhận thức nhân vật, cũng sẽ không kích hoạt biến đổi thế giới mới. Viết nội dung bằng tiếng Việt.',
        'Chỉ được dựa vào public_event_candidates bên dưới. Không được dùng bất kỳ sự thật hậu trường nào không được cung cấp, không được viết hành động riêng tư hay bí mật nhân vật thành tin công khai.',
        'Ứng viên publicity=trace không phải “sự thật tin tức đã công khai”, mà chỉ là chút dấu hiệu bề mặt bên ngoài có thể nhận ra: chỉ được dựa vào public_hint và place để tạo thảo luận diễn đàn không chính thức; không được dùng tiêu đề thật, summary/result, nguyên nhân ẩn hay thông tin nhân vật hậu trường của sự kiện đó, cũng không được tạo tin tức.',
        'Chỉ ứng viên publicity=public mới được phép tạo tin tức, và chỉ được dùng thông tin đã công khai trong public_headline / public_summary / public_hint / place. title, summary, result nội bộ của sự kiện có thể chứa chi tiết hậu trường, cấm sao chép thẳng vào tin tức.',
        'Không được hư cấu sự kiện chính sử mới. Bạn đang “kiểm tra khi tới giờ”, không phải lần nào cũng bắt buộc tạo ra thay đổi: dù public_event_candidates không rỗng, nếu trong khoảng thời gian thế giới này không tự nhiên hình thành biến đổi mới về đưa tin hay thảo luận, cũng có thể trả về news / forums rỗng.',
        'previous_snapshot là dư luận công khai đã tồn tại từ lượt trước. Diễn đàn và tin tức có elapsed_*_world_minutes độc lập riêng; hãy dựa vào thời gian trôi qua tương ứng để phán đoán lan rộng, hạ nhiệt, phân hóa, đảo chiều hay đưa tin tiếp, đừng dùng thời gian trôi qua của tin tức để đẩy diễn đàn đi xa hơn, và ngược lại. Đừng vì nhận được một yêu cầu kiểm tra mà đổi cách diễn đạt để tạo “thay đổi”.',
        'Tuân thủ nghiêm ngặt allow_news / allow_forums. Loại nào là false thì bắt buộc trả về mảng rỗng. allow_news=true cũng không có nghĩa nhất định phải ra tin tức: khi không có sự thật công khai mới có thể chỉ đưa tin tiếp diễn hoặc không viết gì; allow_forums=true cũng có thể trả về mảng rỗng khi thảo luận không có biến đổi tự nhiên.',
        'Tin tức và diễn đàn là “kênh lan truyền”, source_type mới biểu thị cấp độ nguồn tin: official = chính thức/cơ quan/kênh có thẩm quyền, unofficial = nhân chứng, tiết lộ ẩn danh, truyền thông dân gian, diễn đàn, tin đồn hành lang. Tin chính thức cũng có thể dè dặt lời lẽ, công bố có chọn lọc; tin không chính thức cũng có thể tình cờ là thật. Cấp độ nguồn không đồng nghĩa với sự thật của thế giới.',
        'Tin tức thiên về truyền đạt sự thật: chỉ đưa tin những nội dung có giá trị lan truyền công cộng; nguyên nhân chưa xác nhận thì đừng tự ý kết luận. Sự kiện thế giới chỉ cung cấp ứng viên sự thật công khai, tin tức sẽ không bị hệ thống ép tạo ra vượt qua ngưỡng thời gian của lượt này; tin tức bạn tạo cũng không được thay đổi hay thêm sự thật của sự kiện. Cùng một related_event_id là cùng một dòng tin tiếp diễn, khi có đủ thời gian thế giới và tiến triển công khai thì có thể viết tin tiếp theo, đừng tách cùng một sự kiện thành các tin song song trùng lặp nhau. Diễn đàn thiên về phản ứng của quần chúng: cho phép suy đoán, hiểu lầm, chế meme và tin đồn, nhưng phải phân biệt rõ fact / mixed / rumor qua claim_status, và không được ghi ngược tin đồn thành sự thật.',
        'user_world_focus là trọng tâm suy diễn thế giới do người dùng thiết lập. Nó có thể quyết định thứ tự ưu tiên chọn đề tài và góc độ đưa tin trong các ứng viên, nhưng không phải nguồn sự thật: nếu trong ứng viên không có sự kiện công khai tương ứng, không được hư cấu tin tức để chiều theo nó.',
        'Đừng nhầm visibility=direct/known hoặc gần gũi hơn với nhân vật trước mắt là đáng đưa tin hơn. publicity mới quyết định có thể lan truyền hay không. Khi ứng viên bao phủ nhiều địa điểm, ngành nghề hoặc dòng sự kiện, nếu dung lượng cho phép thì phân tán đề tài, tránh để tin tức và diễn đàn dồn hết vào cùng một dòng cốt truyện hiện tại; nhưng không được bịa sự thật ngoài ứng viên vì sự đa dạng.',
        'Khi tiếp nối cùng một chủ đề diễn đàn trong previous_snapshot thì phải giữ id của bài đó, có thể cập nhật nội dung và bổ sung trả lời; chủ đề khác là bài mới, không được dùng lại id cũ. Đừng xuất lặp lại các trả lời đã có.',
        'Mỗi tin đưa ra audience_tags: chỉ ghi “những kiểu người nào có thể quan tâm tin này hơn”, ví dụ cư dân địa phương, người trong ngành, thành viên một tổ chức nào đó, phóng viên, sinh viên… Đó chỉ là nhãn đối tượng, không có nghĩa bất kỳ NPC cụ thể nào đã thấy hay tin tin đó, cũng không cần đọc toàn bộ World Info.',
        'scope dùng một câu rất ngắn tóm tắt phạm vi lan truyền, ví dụ “giới cư dân địa phương” “nội bộ ngành” “công khai toàn thành phố” “lan truyền ẩn danh trong phạm vi nhỏ”.',
        'related_event_id phải lấy từ id có sẵn trong public_event_candidates. Không được hư cấu ID sự kiện mới.',
        'Tối đa tạo 3 tin tức, 4 chủ đề diễn đàn; mỗi chủ đề diễn đàn tối đa 4 trả lời tiêu biểu. Cho phép cả hai mảng đều rỗng; chỉ cần có xuất nội dung thì related_event_id phải lấy từ ứng viên.',
        'Chỉ xuất JSON, không Markdown, không code block, không giải thích.',
        JSON.stringify({
            output_schema: {
                news: [{
                    id: 'Tin tiếp diễn có thể giữ id cũ, mục mới để trống',
                    category: 'Thành phố / Xã hội / Kinh doanh / Thông báo / Khác',
                    headline: 'Tiêu đề',
                    summary: 'Bản tin ngắn, 1-3 câu',
                    source: 'Tên truyền thông, cơ quan, tổ chức hoặc nguồn thông tin công khai, có thể là tên gọi chung',
                    source_type: 'official | unofficial',
                    audience_tags: ['Nhóm người có thể quan tâm, 1-5 nhóm'],
                    scope: 'Phạm vi lan truyền, câu ngắn',
                    related_event_id: 'Phải lấy từ dữ liệu đầu vào',
                    confidence: 'high | medium',
                    heat: '1-3',
                }],
                forums: [{
                    id: 'Bài tiếp nối phải giữ id của previous_snapshot, bài mới để trống',
                    board: 'Tên chuyên mục',
                    title: 'Tiêu đề bài viết',
                    summary: 'Tóm tắt của chủ thớt hoặc chủ đề',
                    source_type: 'official | unofficial (diễn đàn thường là unofficial, khi tài khoản chính thức đăng thì có thể là official)',
                    audience_tags: ['Nhóm người có thể quan tâm, 1-5 nhóm'],
                    scope: 'Phạm vi lan truyền, câu ngắn',
                    related_event_id: 'Phải lấy từ dữ liệu đầu vào',
                    claim_status: 'fact | mixed | rumor',
                    heat: '1-5',
                    replies: [{ author: 'Biệt danh ẩn danh', text: 'Phản hồi tiêu biểu' }],
                }],
            },
            context,
        }, null, 2),
    ].join('\n\n');
}

export function normalizePublicOpinionPayload(payload, {
    validEventIds = [],
    eventVisibilityById = {},
    eventPublicityById = {},
    sourceRevision = -1,
    sourceWorldMinute = -1,
    sourceEventSignature = '',
    forumSourceSignature = sourceEventSignature,
    newsSourceSignature = '',
    generatedAt = new Date().toISOString(),
    lastForumWorldMinute = sourceWorldMinute,
    lastNewsWorldMinute = sourceWorldMinute,
    maximumNews = 3,
    maximumForums = 4,
    maximumReplies = 4,
} = {}) {
    const allowedIds = new Set(asArray(validEventIds).map(item => String(item || '')).filter(Boolean));
    const visibilityFor = id => String(eventVisibilityById?.[id] || '');
    const hasPublicity = id => Object.hasOwn(eventPublicityById || {}, id);
    const publicityFor = id => String(eventPublicityById?.[id] || '');
    const news = uniqueBy(
        asArray(payload?.news).map((item, index) => {
            const relatedEventId = asText(item?.related_event_id ?? item?.relatedEventId, 120);
            if (!allowedIds.has(relatedEventId)) return null;
            if (hasPublicity(relatedEventId) && publicityFor(relatedEventId) !== 'public') return null;
            const headline = asText(item?.headline ?? item?.title, 160);
            const summary = asText(item?.summary, 700);
            if (!headline || !summary) return null;
            const confidenceRaw = asText(item?.confidence, 20).toLowerCase();
            return {
                id: asText(item?.id, 160) || `news_${relatedEventId}`,
                category: asText(item?.category, 40) || 'Tin tức thế giới',
                headline,
                summary,
                source: asText(item?.source, 100) || 'Thông tin công khai',
                sourceType: normalizeSourceType(item?.source_type ?? item?.sourceType, 'official'),
                audienceTags: uniqueStrings(item?.audience_tags ?? item?.audienceTags, 5),
                scope: asText(item?.scope, 80),
                relatedEventId,
                confidence: VALID_CONFIDENCE.has(confidenceRaw) ? confidenceRaw : 'medium',
                heat: clampInteger(item?.heat, 1, 1, 3),
                worldSynced: Boolean(item?.worldSynced ?? item?.world_synced),
                eventStatus: asText(item?.eventStatus ?? item?.event_status, 30),
                temporalState: asText(item?.temporalState ?? item?.temporal_state, 20),
                publishedWorldMinute: clampInteger(item?.publishedWorldMinute ?? item?.published_world_minute, item?.worldMinute ?? sourceWorldMinute, -1, Number.MAX_SAFE_INTEGER),
                publishedAt: asText(item?.publishedAt ?? item?.published_at, 40) || asText(generatedAt, 40),
                updatedAt: asText(item?.updatedAt ?? item?.updated_at, 40) || asText(generatedAt, 40),
                worldMinute: clampInteger(
                    item?.worldMinute ?? item?.world_minute,
                    sourceWorldMinute,
                    -1,
                    Number.MAX_SAFE_INTEGER,
                ),
            };
        }).filter(Boolean).slice(0, Math.max(1, Number(maximumNews) || 3)),
        item => `${item.relatedEventId}\u0000${item.headline}`,
    );

    const forums = uniqueBy(
        asArray(payload?.forums).map((item, index) => {
            const relatedEventId = asText(item?.related_event_id ?? item?.relatedEventId, 120);
            if (!allowedIds.has(relatedEventId)) return null;
            const eventVisibility = visibilityFor(relatedEventId);
            const eventPublicity = publicityFor(relatedEventId);
            const title = asText(item?.title, 180);
            const summary = asText(item?.summary, 700);
            if (!title || !summary) return null;
            const claimRaw = asText(item?.claim_status ?? item?.claimStatus, 20).toLowerCase();
            const replies = asArray(item?.replies).map((reply, replyIndex) => {
                const text = asText(reply?.text ?? reply?.content, 360);
                if (!text) return null;
                return {
                    id: `reply_${publicSignalHash(`${asText(reply?.author ?? reply?.name, 60)}|${text}`)}`,
                    author: asText(reply?.author ?? reply?.name, 60) || `Ẩn danh ${replyIndex + 1}`,
                    text,
                };
            }).filter(Boolean).slice(-Math.min(8, Math.max(1, Number(maximumReplies) || 4)));
            return {
                id: asText(item?.id, 160) || `forum_${relatedEventId}_${publicSignalHash(`${asText(item?.board, 60)}|${title}`)}`,
                board: asText(item?.board, 60) || 'Tán gẫu',
                title,
                summary,
                sourceType: hasPublicity(relatedEventId) && eventPublicity === 'trace'
                    ? 'unofficial'
                    : normalizeSourceType(item?.source_type ?? item?.sourceType, 'unofficial'),
                audienceTags: uniqueStrings(item?.audience_tags ?? item?.audienceTags, 5),
                scope: asText(item?.scope, 80),
                relatedEventId,
                claimStatus: hasPublicity(relatedEventId) && eventPublicity === 'trace'
                    ? (claimRaw === 'rumor' ? 'rumor' : 'mixed')
                    : (VALID_CLAIM_STATUS.has(claimRaw) ? claimRaw : 'mixed'),
                heat: clampInteger(item?.heat, 1, 1, 5),
                replies,
                publishedWorldMinute: clampInteger(item?.publishedWorldMinute ?? item?.published_world_minute, item?.worldMinute ?? sourceWorldMinute, -1, Number.MAX_SAFE_INTEGER),
                publishedAt: asText(item?.publishedAt ?? item?.published_at, 40) || asText(generatedAt, 40),
                updatedAt: asText(item?.updatedAt ?? item?.updated_at, 40) || asText(generatedAt, 40),
                worldMinute: clampInteger(
                    item?.worldMinute ?? item?.world_minute,
                    sourceWorldMinute,
                    -1,
                    Number.MAX_SAFE_INTEGER,
                ),
            };
        }).filter(Boolean).slice(0, Math.max(1, Number(maximumForums) || 4)),
        item => `${item.relatedEventId}\u0000${item.title}`,
    );

    return {
        generatedAt: asText(generatedAt, 40),
        sourceRevision: clampInteger(sourceRevision, -1, -1, Number.MAX_SAFE_INTEGER),
        sourceWorldMinute: clampInteger(sourceWorldMinute, -1, -1, Number.MAX_SAFE_INTEGER),
        sourceEventSignature: asText(sourceEventSignature, 240),
        forumSourceSignature: asText(forumSourceSignature, 240),
        newsSourceSignature: asText(newsSourceSignature, 240),
        lastForumWorldMinute: clampInteger(lastForumWorldMinute, sourceWorldMinute, -1, Number.MAX_SAFE_INTEGER),
        lastNewsWorldMinute: clampInteger(lastNewsWorldMinute, sourceWorldMinute, -1, Number.MAX_SAFE_INTEGER),
        news,
        forums,
    };
}

export function normalizePublicOpinionCache(raw) {
    const sourceRevision = clampInteger(raw?.sourceRevision, -1, -1, Number.MAX_SAFE_INTEGER);
    const sourceWorldMinute = clampInteger(raw?.sourceWorldMinute, -1, -1, Number.MAX_SAFE_INTEGER);
    const validEventIds = [
        ...asArray(raw?.news).map(item => item?.relatedEventId),
        ...asArray(raw?.forums).map(item => item?.relatedEventId),
    ].filter(Boolean);
    return normalizePublicOpinionPayload(raw, {
        validEventIds,
        sourceRevision,
        sourceWorldMinute,
        sourceEventSignature: raw?.sourceEventSignature || '',
        forumSourceSignature: raw?.forumSourceSignature || raw?.sourceEventSignature || '',
        newsSourceSignature: raw?.newsSourceSignature || '',
        generatedAt: raw?.generatedAt || '',
        lastForumWorldMinute: raw?.lastForumWorldMinute ?? sourceWorldMinute,
        lastNewsWorldMinute: raw?.lastNewsWorldMinute ?? sourceWorldMinute,
        maximumNews: 18,
        maximumForums: 12,
        maximumReplies: 8,
    });
}


export function emptyPublicOpinionSandbox({ generatedAt = '' } = {}) {
    return {
        generatedAt: asText(generatedAt, 40),
        nonCanon: true,
        news: [],
        forums: [],
    };
}

export function buildPublicOpinionSandboxPrompt(state, { clockLabel = '' } = {}) {
    const context = {
        world_name: asText(state?.world?.name || 'Thế giới chính', 80),
        world_time: asText(clockLabel, 100),
        world_flavor: asText(state?.world?.detail || state?.world?.title || '', 700),
        world_background: asText(state?.world?.background || '', 1800),
    };
    return [
        'Bạn là bộ tạo dư luận dạo chơi của “世界背面”. Đây là sandbox giải trí thuần túy: có thể tạo tin tức đời thường, bài tán dóc trên diễn đàn, quảng cáo vặt, chuyện phiếm trong thành phố, bài hot kỳ quặc và những mảnh vụn cuộc sống hoàn toàn không liên quan đến mạch chính và các sự kiện hiện có. Viết nội dung bằng tiếng Việt.',
        'Mọi nội dung đều phải được đánh dấu là ảnh chụp giải trí non-canon: chúng không phải sự thật thế giới, không ghi vào sự kiện, ký ức, nhận thức nhân vật hay nhân quả của chính văn, cũng không được ám chỉ mạch chính thật đã xảy ra điều gì.',
        'Có thể tham khảo world_name / world_time / world_flavor / world_background để giữ khí chất và quy tắc nền của thế giới, nhưng không được lén dùng hay viết tiếp mạch chính hiện tại, bí mật ẩn giấu, chuyện riêng của nhân vật. Cố gắng viết đời sống xã hội bình thường, để thế giới này trông như thật sự có người đang sống.',
        'Nội dung có thể nhẹ nhàng, buồn cười, vụn vặt, thà giống như đang thật sự dạo quanh cộng đồng, cũng đừng tin nào cũng tạo ra chuyện lớn.',
        'Nhất định phải tạo nội dung để dạo chơi: ít nhất 1 tin nhẹ và 2 chủ đề diễn đàn, tối đa 2 tin nhẹ, 4 chủ đề diễn đàn; mỗi diễn đàn tối đa 4 trả lời tiêu biểu. Chỉ xuất JSON.',
        JSON.stringify({
            output_schema: {
                news: [{ category: 'Đời sống / Địa phương / Chuyện lạ / Kinh doanh / Khác', headline: '', summary: '', source: '', heat: 1 }],
                forums: [{ board: 'Tán gẫu', title: '', summary: '', heat: 1, replies: [{ author: '', text: '' }] }],
            },
            context,
        }, null, 2),
    ].join('\n\n');
}

export function normalizePublicOpinionSandboxPayload(payload, { generatedAt = new Date().toISOString() } = {}) {
    const news = uniqueBy(
        asArray(payload?.news).map((item, index) => {
            const headline = asText(item?.headline ?? item?.title, 160);
            const summary = asText(item?.summary, 700);
            if (!headline || !summary) return null;
            return {
                id: `sandbox_news_${index}`,
                category: asText(item?.category, 40) || 'Tin dạo chơi',
                headline,
                summary,
                source: asText(item?.source, 100) || 'Thông tin công khai thường ngày trong thế giới',
                sourceType: 'unofficial',
                audienceTags: [],
                scope: 'Hộp cát giải trí',
                relatedEventId: '',
                confidence: 'medium',
                heat: clampInteger(item?.heat, 1, 1, 3),
                nonCanon: true,
            };
        }).filter(Boolean).slice(0, 2),
        item => item.headline,
    );
    const forums = uniqueBy(
        asArray(payload?.forums).map((item, index) => {
            const title = asText(item?.title, 180);
            const summary = asText(item?.summary, 700);
            if (!title || !summary) return null;
            const replies = asArray(item?.replies).map((reply, replyIndex) => {
                const text = asText(reply?.text ?? reply?.content, 360);
                if (!text) return null;
                return { id: `sandbox_reply_${index}_${replyIndex}`, author: asText(reply?.author ?? reply?.name, 60) || `Ẩn danh ${replyIndex + 1}`, text };
            }).filter(Boolean).slice(0, 4);
            return {
                id: `sandbox_forum_${index}`,
                board: asText(item?.board, 60) || 'Tán gẫu',
                title,
                summary,
                sourceType: 'unofficial',
                audienceTags: [],
                scope: 'Hộp cát giải trí',
                relatedEventId: '',
                claimStatus: 'rumor',
                heat: clampInteger(item?.heat, 1, 1, 5),
                replies,
                nonCanon: true,
            };
        }).filter(Boolean).slice(0, 4),
        item => item.title,
    );
    return { generatedAt: asText(generatedAt, 40), nonCanon: true, news, forums };
}

export function normalizePublicOpinionSandbox(raw) {
    return normalizePublicOpinionSandboxPayload(raw || {}, { generatedAt: raw?.generatedAt || '' });
}
