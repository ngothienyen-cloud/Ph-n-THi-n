# Sửa lỗi nhập nhân vật từ World Info (sổ thế giới)

Tên nhân vật và tiêu đề mục được xử lý riêng. Những mục như「林舟－外貌」(Lâm Chu – Ngoại hình),「林舟－经历」(Lâm Chu – Trải nghiệm) mà từ khóa đều xác định rõ là「林舟」, khi nhập theo quy tắc sẽ được ghép thành một người; các khối nhân vật trùng tên lặp lại trong cùng một mục sẽ giữ lại phần tư liệu bổ sung phía sau. Khi các nguồn khác nhau chỉ đơn thuần trùng tên, phần AI duyệt sẽ mặc định không đánh dấu chọn; người dùng có thể tạo riêng, bổ sung vào một thẻ có sẵn được chỉ định, hoặc gộp với bản nháp cùng tên ở phía trên.

Tại「Cài đặt nhân vật → Nhập nhân vật từ World Info → Chọn thủ công nâng cao」, sau khi quét và đánh dấu các mục, có thể chọn nhập theo quy tắc hoặc「Để AI sắp xếp rồi nhập」. AI dùng cấu hình kết nối và đầu ra của mô-đun nhân vật, sắp xếp văn bản gốc của nguồn theo từng đoạn, kết quả sẽ vào bước duyệt trước; chỉ sau khi xác nhận mới được ghi vào. Độ trùng khớp với văn bản gốc chỉ kiểm tra xuất xứ câu chữ, việc nhân vật thuộc về ai vẫn cần người xác nhận. Các đoạn không vượt qua kiểm tra đối chiếu văn bản gốc sẽ được liệt kê trong báo cáo, các ô có độ trùng khớp thấp mặc định không được ghi vào.

Thân phận, ngoại hình, nhân cách, bối cảnh và quan hệ, thói quen nói năng, giới hạn hành vi không còn bị lưu theo giới hạn cũ 360～900 chữ. Thêm mục mới「Năng lực và giới hạn」, có thể điền hiệu quả, phạm vi, điều kiện kích hoạt, cái giá phải trả, điểm yếu. Toàn bộ văn bản nguồn và nhiều thông tin nguồn được lưu kèm theo thẻ; quá trình suy diễn thông thường không được viết lại các tư liệu của tác giả này. Nhập lại chỉ điền vào các ô trống, hoặc tiếp tục gộp các ô đã nhập nhưng chưa được sửa thủ công; nội dung tác giả tự điền được giữ nguyên.

Độ dài lưu trữ tách biệt với ngân sách mô hình: tư liệu dài không bị cắt khỏi bản lưu; khi gửi cho mô hình suy diễn/quan sát vẫn dùng ngân sách độ dài riêng, tư liệu quá dài sẽ giữ phần đầu và phần cuối và được đánh dấu là trích đoạn, tránh việc các giới hạn ở cuối phần năng lực bị bỏ mất. Phần nội dung ở giữa không được hiển thị vẫn có thể xem trong thẻ nhân vật, nhưng không đảm bảo mỗi lượt mô hình đều đọc được.

Hủy sắp xếp, đổi World Info, đổi chat đều khiến tác vụ hoặc bản nháp đang duyệt bị vô hiệu, kết quả đến muộn không thể ghi vào chat hiện tại. Các đợt bị lỗi trong quá trình AI sắp xếp sẽ được giữ lại trong báo cáo, những bản nháp khác đã tạo ra vẫn có thể xác nhận từng mục.

## Kiểm chứng

- `npm test`: các bài kiểm thử sẵn có, hồi quy đối chiếu văn bản gốc của PR #9, cùng các bài kiểm thử hành vi cho thẻ dài, phân đoạn cùng tên, XML lặp lại, nguồn đầy đủ, gộp khi duyệt và bảo vệ tư liệu của tác giả.
- `npm run check`: chạy kiểm tra cú pháp các mô-đun.
- `tests/worldbook-import-browser-smoke.mjs`: trang SillyTavern 1.18.0 thật được cô lập, chuyển tiếp qua Custom thật tới một dịch vụ phản hồi có thể kiểm soát chạy cục bộ, kiểm thử nhập theo quy tắc, chia khối, không ghi khi chưa xác nhận, gộp, chặn ảo giác (hallucination), sửa và lưu thẻ dài, tải lại toàn trang, nhập lại, hủy, đổi sổ, sự kiện đổi chat và độ rộng 390/320.
- `.lab/runtime-smoke.mjs` sẽ chạy script này sau các bước kiểm tra Tavern thật vốn có; báo cáo và ảnh chụp màn hình được tải lên cùng Lab artifact.

Khung nhập và duyệt bằng AI được chuyển từ PR #9 có sẵn (`abc068f85a2a6a26ddba188d3e7fdcbb4e5df279`) và căn chỉnh theo nhánh chính hiện tại; lần này bổ sung đầy đủ việc lưu trọn vẹn tư liệu, ô năng lực, gộp nguồn, hủy và cô lập theo chat/World Info. Bài kiểm thử phản hồi có thể kiểm soát chứng minh luồng gọi, đối chiếu và lưu trữ, không thay thế việc kiểm tra chất lượng sắp xếp của các mô hình trực tuyến cụ thể.
