# Lớp thích ứng liên lạc theo thế giới quan

“Liên lạc” của 世界背面 là một lối vào để quan sát, không có nghĩa là trong thế giới tồn tại phần mềm nhắn tin tức thời hiện đại.

Lớp này dùng quy tắc mang tính xác định, dựa trên trạng thái thế giới hiện tại, bối cảnh nhân vật, sự kiện gần đây và sự thật dài hạn để xác định hệ sinh thái liên lạc, rồi chèn các ràng buộc trước khi gửi yêu cầu xã giao hậu trường. Nó không gọi thêm mô hình.

## Quy tắc cốt lõi

- `accepted / pending / friend_request / remove_friend / posts / group` được giữ làm tên giao thức dữ liệu để tương thích, không được coi là sự thật trong thế giới.
- Thế giới cổ đại/công nghệ thấp mặc định dùng các phương tiện hợp lý sẵn có như thư từ, lời nhắn miệng, sứ giả, trạm dịch; không được vì giao diện có “tin nhắn” mà cho đến nơi ngay lập tức.
- Thế giới phép thuật chỉ được dùng các phương tiện liên lạc từ xa như thuật truyền tin, pha lê liên lạc, linh thú đưa thư… khi thiết lập hỗ trợ rõ ràng; bản thân việc “có tồn tại phép thuật” không phải là bằng chứng cho năng lực liên lạc.
- Thế giới khoa học viễn tưởng dùng các thiết bị đầu cuối, máy liên lạc, mạng tinh tế… đã được xác nhận, và tuân theo khoảng cách, mạng lưới và quy tắc của thế giới.
- Khi không có bằng chứng rõ ràng thì không mặc định có điện thoại, internet, liên lạc bằng phép thuật hay công nghệ tương lai.
- Hậu trường biết một tin nhắn không có nghĩa là nhân vật đã nhận được; `saw` bắt buộc phải qua bước đánh giá điều kiện gửi tới thực tế.
- Liên lạc có độ trễ có thể được xử lý tự nhiên bởi nhịp xã giao tần suất thấp sau khi thời gian thế giới tiến lên.
- Bài đăng công khai chỉ là khái niệm tương thích cho “chủ động lan truyền công khai/bán công khai”; khi không tồn tại kênh công khai hợp lý thì cho phép không có bài nào.

Thuật ngữ và thích ứng hình ảnh của UI sẽ để dành cho một đợt tái cấu trúc riêng sau này; lớp này chỉ đảm bảo logic thế giới đúng trước.
