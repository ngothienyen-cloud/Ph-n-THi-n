# Hướng dẫn sử dụng 世界背面

Tài liệu này tương ứng với `main` hiện tại. Nó hướng tới việc sử dụng thực tế, không làm nhiệm vụ ghi chép từng phiên bản; thay đổi theo phiên bản xin xem [CHANGELOG.md](../CHANGELOG.md).

> **世界背面 duy trì trạng thái thế giới, phần truyện chính lo kể câu chuyện trước mắt.**

---

## 1. Cài đặt

### Cài đặt từ GitHub

Trong trang quản lý extension của SillyTavern, chọn “Install extension” (Cài đặt extension), điền:

```text
https://github.com/h675786161-prog/world-backstage
```

Sau khi cài, làm mới trang và bật “世界背面”.

### Cài đặt thủ công

Đặt thư mục `world-backstage` trong gói phát hành vào:

```text
SillyTavern/data/<你的用户目录>/extensions/world-backstage/
```

(`<你的用户目录>` = thư mục người dùng của bạn.)

Trong thư mục cuối cùng phải thấy trực tiếp `manifest.json`, `index.js` và `style.css`.

---

## 2. Lần đầu mở

Bấm vào quả cầu thế giới ở góc dưới bên phải trang.

Lần đầu, nên chỉ làm bốn việc:

1. Cấu hình kết nối.
2. Hiệu chỉnh thời gian thế giới chính.
3. Xác nhận đã bật chèn trạng thái vào phần truyện chính.
4. Nếu đã chat rất nhiều tầng, hãy tạo hồ sơ ký ức ban đầu trước.

Cứ để luồng cơ bản chạy ổn đã, rồi hãy đụng tới cài đặt nâng cao. Nhiều nút bấm không làm thế giới thông minh hơn, chỉ khiến con người sinh ra ảo giác kinh điển “hình như mình quên bật cái gì đó”.

---

## 3. Chọn cách kết nối

世界背面 hỗ trợ ba cách kết nối thông dụng.

### Theo Tavern hiện tại

Dùng thẳng kết nối mà SillyTavern đang dùng. Phù hợp cho cấu hình đơn giản nhất.

### Cấu hình đã lưu trong Tavern

Tham chiếu tới cấu hình đã lưu trong Connection Manager của SillyTavern. Plugin chỉ ghi lại ID của cấu hình, không sao chép Key, URL và cấu hình mô hình.

Phù hợp khi:

- Muốn dùng mô hình khác nhau cho phần truyện chính và 世界背面;
- Đã quản lý nhiều bộ kết nối trong Tavern;
- Không muốn điền lại thông tin API.

### API độc lập

Tự điền địa chỉ API tương thích, API Key và mô hình.

Nên bấm “Kiểm tra kết nối” trước. Địa chỉ API cần điền đúng tới tầng phiên bản theo yêu cầu của nhà cung cấp, ví dụ `/v1`; đừng đoán đường dẫn chỉ vì nó trông giống OpenAI.

Cấu hình API độc lập được lưu trong cài đặt extension trên máy, không bị nhét vào file xuất trạng thái thế giới.

---

## 4. Thời gian thế giới chính

Thời gian thế giới chính là trục thời gian chuẩn của 世界背面.

Bản thân số lượt chat không tự động bằng lượng thời gian đã trôi qua trong thế giới. Sự kiện, hành động của nhân vật và các thay đổi dài hạn đều nên được tính toán xoay quanh đồng hồ thế giới chính.

Các cách tính giờ thường gặp:

| Cách | Công dụng |
| --- | --- |
| Trôi tự nhiên | Đi đường, sửa chữa, lên men, chờ giao hàng |
| Giờ công hữu hiệu | Nghiên cứu, huấn luyện, chế tạo, thi công |
| Giờ đã hẹn | Hẹn hò, chuyến xe, hạn chót, nghi lễ |
| Chờ điều kiện | Chờ hồi âm, chờ vật liệu, chờ tin tình báo, chờ điều kiện thành lập |

Khi reroll (swipe lại), hệ thống sẽ bắt đầu lại từ snapshot hợp lệ của nhánh tương ứng, không được lén mang theo thời gian mà nhánh bị bỏ đã đẩy tới.

---

## 5. Nhân vật

Trang nhân vật ghi lại trạng thái của các nhân vật trong thế giới, không phải một thẻ nhân vật thứ hai.

Nội dung thường gặp gồm:

- Địa điểm hiện tại;
- Đang làm gì;
- Ý định ngắn hạn;
- Thông tin đã biết;
- Quan hệ với sự kiện, địa điểm và nhân vật khác;
- Lát cắt góc nhìn thứ nhất ở hậu trường.

“Xem TA đang làm gì” chỉ tạo ra quan sát tức thời về nhân vật hiện tại, không nên đẩy thời gian thế giới tiến lên, cũng không nên sửa đổi sự thật về nhân vật.

Hậu trường thế giới có thể biết rất nhiều chuyện, nhưng nhân vật vẫn chỉ biết những phần mà họ có lý do để biết.

---

## 6. Mạch ngầm và Tiếng vọng

**Mạch ngầm** dùng cho những sự kiện vẫn đang phát triển.  
**Tiếng vọng** dùng cho những sự kiện đã kết thúc, để lại kết quả hoặc ảnh hưởng về sau.

Cùng một việc chưa kết thúc thì nên tiếp tục đẩy tiến trên sự kiện gốc, đừng vì tiêu đề đổi vài chữ mà nhân bản ra một tuyến thế giới mới.

Thế giới thay đổi phải có nguyên nhân. Tin tức được công bố, diễn đàn bàn tán hay một ai đó biết một chuyện, cũng không có nghĩa là các nhân vật khác tự động biết hết.

---

## 7. Trí nhớ dài hạn và tự động ẩn

### 7.1 Hệ thống ký ức lưu những gì

Trí nhớ dài hạn không chỉ là một bản tổng kết chung.

Luồng xử lý hiện tại duy trì:

- **L0 từng tầng**: tóm tắt chính xác tương ứng với mỗi tầng nội dung của user / assistant;
- **Trải nghiệm liên tục**: diễn biến cốt truyện liên tiếp đã xảy ra trong một khoảng thời gian;
- **Tóm tắt giai đoạn**: chỉ mục nén cho phạm vi dài hơn;
- **Sự thật dài hạn**: những sự thật vẫn còn hiệu lực, cần tiếp tục đúng về sau;
- **Chi tiết cài cắm và manh mối**: những thông tin chưa được giải quyết hoặc vẫn còn giá trị về sau.

L0 từng tầng rất quan trọng, vì “một bản tổng kết nào đó sau này nhớ đại khái” không thể thay thế “tầng 4 đã nói rõ ám hiệu là gì”.

### 7.2 Cốt truyện cũ được đọc lại thế nào

Khi phần truyện chính cần thông tin từ sớm, 世界背面 sẽ tìm nội dung liên quan trong ký ức.

Hiện tại đặc biệt chú ý tới:

- Hồi ức phần mở đầu như “lúc đầu”, “lần đầu gặp”, “mở đầu”;
- Ám hiệu, khẩu lệnh, mật khẩu;
- Đồ vật đã bàn giao;
- Nhịp gõ cửa;
- Các giao ước rõ ràng;
- Thứ tự hành động: ai làm gì trước, sau đó lại làm gì.

Ký ức chính xác của các tầng cũ liên quan được ưu tiên cao hơn những bản tóm tắt giai đoạn quá chung chung.

Khi tắt chèn trí nhớ dài hạn, những ký ức cốt truyện này sẽ không tiếp tục được nhét vào prompt của phần truyện chính.

### 7.3 Thế nào là “lưu trữ hoàn tất”

Một tầng cũ muốn đủ điều kiện để tự động ẩn thì ít nhất phải có ký ức từng tầng tương ứng không rỗng bao phủ.

Con trỏ sắp xếp đã đi qua không có nghĩa là tầng đó đã được ghi nhớ an toàn. Những tầng thiếu L0 sẽ tiếp tục được giữ trong ngữ cảnh.

### 7.4 Bật tự động ẩn

Lối vào nằm trong **phần cài đặt của mô-đun ký ức**, công tắc có tên:

> Tự động ẩn các tầng đã lưu trữ

Mặc định nó tắt.

Trước khi bật cần:

- Bật hệ thống ký ức;
- Bật chèn trí nhớ dài hạn.

Quy tắc hoạt động:

- Chỉ những tầng cũ đã có L0 bao phủ đáng tin cậy mới đủ điều kiện ẩn;
- **5 tầng** đã lưu trữ gần nhất luôn được giữ lại;
- Mọi tầng chưa lưu trữ đều được giữ lại;
- Các tầng cũ thiếu L0 tiếp tục được giữ lại;
- Việc ẩn chỉ ảnh hưởng tới ngữ cảnh của mô hình, không xóa lịch sử chat.

### 7.5 Quan hệ với /hide của SillyTavern

世界背面 dùng cơ chế ẩn gốc của SillyTavern.

Nó sẽ ghi dấu quyền sở hữu riêng lên những tầng do nó tự động ẩn, nên khi khôi phục chỉ xử lý những nội dung mà chính nó đã ẩn.

Những tin nhắn bạn tự `/hide` thủ công sẽ không bị nó tự ý bỏ ẩn.

### 7.6 Cách khôi phục

Trong cài đặt ký ức, bấm:

> Tắt và khôi phục các tầng do 世界背面 tự động ẩn

Ngoài ra, khi tắt bất kỳ mục nào dưới đây, 世界背面 cũng sẽ khôi phục các tầng do nó tự động ẩn:

- Tự động ẩn;
- Hệ thống ký ức;
- Chèn trí nhớ dài hạn;
- Chính 世界背面.

### 7.7 Đưa đoạn chat dài cũ vào hệ thống

Khi đã có đoạn chat rất dài, hãy chạy “Tạo hồ sơ ký ức ban đầu” trước.

Quá trình sắp xếp lịch sử sẽ đọc nhánh hiện tại theo từng đợt. Mỗi đợt thành công sẽ lưu tiến độ; nếu lỗi hoặc bị gián đoạn có thể tiếp tục từ điểm dừng gần nhất.

Quy trình khuyến nghị:

1. Tạo hồ sơ ký ức ban đầu;
2. Xác nhận ký ức từng tầng đã bao phủ đoạn chat cũ;
3. Dùng bình thường một thời gian;
4. Rồi mới bật tự động ẩn.

Làm vậy là chắc chắn nhất. Đem 200 tầng nội dung giấu sạch một lượt rồi cầu nguyện mô hình nhờ tia vũ trụ mà nhớ ra, đó là một tôn giáo khác.

---

## 8. Chèn vào phần truyện chính

Phần truyện chính thường chỉ cần nhận phần dữ liệu hậu trường liên quan tới tình huống hiện tại.

Nguồn thường gặp gồm:

- Hiện tại;
- Nhân vật;
- Mạch ngầm;
- Tiếng vọng;
- Ký ức;
- Dư luận.

“Tồn tại ở hậu trường” và “cần được chèn vào lúc này” là hai chuyện khác nhau.

Một ký ức không xuất hiện trong prompt hiện tại không có nghĩa là nó đã biến mất khỏi thế giới. Những sự thật hậu trường mà nhân vật không có lý do để biết cũng không nên bị nhét thẳng cho nhân vật chỉ vì plugin biết.

---

## 9. Liên lạc và dư luận

Tính năng liên lạc dùng lại các nhân vật thật của 世界背面, không dựng một bộ thiết lập danh bạ thứ hai.

Việc nhân vật có trả lời hay không, biết những gì, chịu nói gì, vẫn tiếp tục bị ràng buộc bởi nhận thức, quan hệ, hoàn cảnh và tính cách của nhân vật.

Dư luận cũng tuân theo chuỗi lan truyền:

1. Trong thế giới trước hết phải có sự kiện thật hoặc thông tin công khai;
2. Lan truyền qua các con đường như tin tức, thông báo, nhân chứng, kênh công việc, trò chuyện…;
3. Các nhân vật liên quan mới có thể nhận được phiên bản thông tin tương ứng;
4. Sau khi nhận tin, nhân vật mới nảy sinh phản ứng và hành động tiếp theo của riêng mình.

Một bài đăng sẽ không tự động viết lại sự thật.

---

## 10. Reroll, sửa và xóa tin nhắn

### Reroll

Swipe mới bắt đầu lại từ trạng thái hợp lệ trước khi tin nhắn đó được suy diễn.

Khi chuyển về swipe cũ, snapshot thế giới tương ứng với nhánh đó sẽ được khôi phục.

### Sửa tin nhắn cũ

Sau khi sửa một tầng nội dung sớm hơn, các snapshot phía sau sẽ được coi là có thể đã lỗi thời. 世界背面 nên quay về trạng thái hợp lệ trước điểm sửa, rồi tính toán lại về sau.

### Xóa tin nhắn

Sau khi xóa tin nhắn, khôi phục về snapshot hợp lệ mới nhất vẫn còn tồn tại trong đoạn chat.

---

## 11. Dữ liệu và sao lưu

Vị trí dữ liệu quan trọng:

- Trạng thái thế giới hiện tại: metadata của chat;
- Snapshot nhánh của AI swipe: `extra` của tin nhắn tương ứng;
- Trí nhớ dài hạn và tiến độ sắp xếp: metadata / trạng thái nhánh riêng của đoạn chat hiện tại;
- Cấu hình API độc lập: cài đặt extension SillyTavern trên máy.

Nên xuất bản sao lưu trước các thao tác sau:

- Quay ngược quy mô lớn trên đoạn chat cũ;
- Sửa nhiều nhân vật và sự kiện;
- Chuyển sang thiết bị khác;
- Thử nghiệm các thao tác bảo trì có rủi ro cao.

---

## 12. Câu hỏi thường gặp

### Công tắc tự động ẩn bị xám

Trước tiên hãy xác nhận đã bật chèn trí nhớ dài hạn.

### Đã bật tự động ẩn mà một số tầng rất cũ vẫn còn

Hãy kiểm tra xem chúng có thiếu L0 từng tầng không. Khi thiếu ký ức bao phủ, việc tiếp tục giữ lại là hành vi đúng như dự kiến.

### Tắt tự động ẩn rồi, sao vẫn còn tin nhắn bị ẩn

Nếu những tin nhắn đó vốn do bạn tự `/hide` thủ công, 世界背面 sẽ không khôi phục giúp bạn.

### Ám hiệu từ sớm rõ ràng đã được sắp xếp, mà mô hình vẫn trả lời sai

Trước tiên hãy xem ký ức chính xác tương ứng có được đưa vào phần chèn hiện tại không. Kể cả khi ký ức đã vào prompt, mô hình vẫn có thể trả lời sai do lấy mẫu (sampling), giới hạn kiến thức hoặc khả năng tuân thủ.

Plugin có thể nâng cao khả năng nhớ lại, nhưng không thể biến một mô hình xác suất thành cơ sở dữ liệu.

### Chat dài có bắt buộc phải bật tự động ẩn không

Không. Đây là tính năng tùy chọn, mặc định tắt.

Bạn có thể chỉ dùng tính năng đọc lại trí nhớ dài hạn mà không ẩn bất kỳ nội dung gốc nào.

### Tự động ẩn có xóa chat không

Không. Nó chỉ dùng cơ chế ẩn của SillyTavern để đưa một số tầng cũ ra khỏi ngữ cảnh của mô hình.

---

## 13. Cấu hình khuyến nghị

Thẻ nhân vật thông thường có thể bắt đầu với bộ cấu hình khá thận trọng:

- Hệ thống ký ức: bật;
- Chèn trí nhớ dài hạn: bật;
- Tự động ẩn: tạm tắt;
- Tự động suy diễn: cân bằng;
- Ngân sách nhân vật hậu trường: mặc định 4;
- Chat cũ: tạo hồ sơ ký ức ban đầu trước.

Sau khi xác nhận ký ức bao phủ ổn định, mới bật tự động ẩn.

---

## 14. Thứ tự xử lý sự cố

Khi gặp vấn đề, trước hết hãy phân rõ nó nằm ở tầng nào:

1. Plugin đã được tải chưa;
2. SillyTavern có khởi động bình thường không;
3. API có gọi thành công không;
4. Ký ức có thực sự được ghi vào không;
5. Tầng cũ tương ứng có L0 không;
6. Trong phần chèn có xuất hiện ký ức mục tiêu không;
7. Mô hình nhận được thông tin rồi có dùng đúng không.

“Mô hình trả lời sai” không thể suy thẳng ra “ký ức chưa được lưu”. Con người cũng có thể nhìn đáp án mà vẫn làm sai bài, máy móc chỉ là công nghiệp hóa truyền thống này thôi.

---

## 15. Phát triển và kiểm chứng

Kiểm tra mã:

```bash
npm run check
npm test
```

Kiểm chứng trên SillyTavern thật sử dụng:

```text
h675786161-prog/sillytavern-lab
```

Tài liệu liên quan:

- [Danh sách kiểm thử](TEST-CHECKLIST.md)
- [Tài liệu kiến trúc](ARCHITECTURE.md)
- [Nhật ký cập nhật](../CHANGELOG.md)
