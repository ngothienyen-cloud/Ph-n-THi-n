# Hướng dẫn điện thoại đi kèm

世界背面 2.5.9 đi kèm điện thoại mini 0.3.0-alpha.28: https://github.com/Lenore-111/yellowmi-24-pro-max-plus

Sau khi cài đặt hoặc cập nhật thủ công cả hai extension, hãy làm mới trang, khởi tạo 世界背面 trong đoạn chat gốc, rồi chuyển cài đặt điện thoại sang chế độ 世界背面. Cả hai bên đều đã tắt tự động cập nhật, vui lòng cập nhật đồng bộ theo cặp.

Điện thoại có thể chấp nhận hoặc từ chối lời mời kết bạn, tạo chat riêng mới, gửi tin nhắn riêng và tin nhắn nhóm, đánh dấu đã đọc, tạo nhóm, cũng như thích và bình luận trên bảng tin bạn bè (Moments). 世界背面 là nơi có thẩm quyền ghi và lưu trạng thái xã giao ở chế độ thế giới; nếu lưu thất bại sẽ báo lỗi, chỉ khi xác nhận thành công mới thông báo cho điện thoại.

Bài đăng riêng tư, sự kiện riêng tư và tâm lý hậu trường của nhân vật không được hiển thị qua giao diện công khai của điện thoại. Sau khi đổi chat hoặc đổi nhánh, các thao tác cũ không thể ghi vào thế giới hiện tại; điện thoại cũng sẽ kiểm tra nhân vật, danh tính người chơi và chế độ điện thoại, rồi loại bỏ các kết quả xác nhận cũ.

Gọi điện và tin nhắn SMS ở chế độ thế giới tạm thời chưa hỗ trợ gọi hay gửi/nhận. Tương tác với nhân vật ở chế độ điện thoại độc lập được lưu trong bản ghi riêng, không sửa đổi trạng thái của 世界背面.

Bản cập nhật giữ nguyên cấu trúc của các khóa trạng thái chat, thông báo và bản ghi xã giao hiện có. Hãy sao lưu chat trước khi cập nhật; nếu gặp vấn đề, giữ lại dữ liệu gốc và phiên bản của cả hai extension; khi khôi phục, dùng phiên bản đi kèm trước đó cùng bản sao lưu chat cần thiết, không yêu cầu xóa chat.
