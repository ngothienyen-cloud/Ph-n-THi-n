const SKILLS = [
    { id: 'list_skills', name: 'Danh sách kỹ năng', kind: 'query', category: 'Quản gia', risk: 'low' },
    { id: 'status_overview', name: 'Tổng quan trạng thái thế giới', kind: 'query', category: 'Tra cứu', risk: 'low' },
    { id: 'list_people', name: 'Danh sách nhân vật', kind: 'query', category: 'Tra cứu', risk: 'low' },
    { id: 'person_status', name: 'Tra trạng thái nhân vật', kind: 'query', category: 'Tra cứu', risk: 'low' },
    { id: 'recent_events', name: 'Tra Mạch ngầm gần đây', kind: 'query', category: 'Tra cứu', risk: 'low' },
    { id: 'memory_status', name: 'Kiểm kê trạng thái ký ức', kind: 'query', category: 'Tra cứu', risk: 'low' },
    { id: 'settings_overview', name: 'Tổng quan cài đặt', kind: 'query', category: 'Tra cứu', risk: 'low' },
    { id: 'social_overview', name: 'Kiểm kê liên lạc & bạn bè', kind: 'query', category: 'Tra cứu', risk: 'low' },
    { id: 'social_person_status', name: 'Tra cứu quan hệ liên lạc của nhân vật', kind: 'query', category: 'Tra cứu', risk: 'low' },
    { id: 'setting_guide', name: 'Hướng dẫn cài đặt', kind: 'query', category: 'Quản gia', risk: 'low' },
    { id: 'diagnose_world', name: 'Chẩn đoán suy diễn thế giới', kind: 'query', category: 'Chẩn đoán', risk: 'low' },
    { id: 'diagnose_person', name: 'Chẩn đoán nhân vật đứng yên', kind: 'query', category: 'Chẩn đoán', risk: 'low' },
    { id: 'search_lingqi_chat', name: 'Tìm trong trò chuyện với 玲\u4e03', kind: 'query', category: 'Sắp xếp', risk: 'low' },
    { id: 'update_setting', name: 'Làm hộ cài đặt an toàn', kind: 'action', category: 'Điều khiển', risk: 'medium' },
    { id: 'set_person_simulation', name: 'Công tắc suy diễn nhân vật', kind: 'action', category: 'Điều khiển', risk: 'medium' },
    { id: 'cancel_simulation', name: 'Dừng suy diễn hiện tại', kind: 'action', category: 'Điều khiển', risk: 'medium' },
    { id: 'cancel_background_tasks', name: 'Dừng tác vụ nền', kind: 'action', category: 'Điều khiển', risk: 'medium' },
    { id: 'check_world_state', name: 'Kiểm tra sự thật thế giới', kind: 'action', category: 'Chẩn đoán', risk: 'medium' },
    { id: 'organize_memory', name: 'Sắp xếp ký ức dài hạn', kind: 'action', category: 'Sắp xếp', risk: 'medium' },
    { id: 'simulate_latest', name: 'Suy diễn chính văn mới nhất', kind: 'action', category: 'Điều khiển', risk: 'medium', confirmation: true },
    { id: 'refresh_public_world', name: 'Tuần tra thế giới công cộng', kind: 'action', category: 'Điều khiển', risk: 'medium', confirmation: true },
    { id: 'prioritize_person', name: 'Ưu tiên nhân vật lượt sau', kind: 'action', category: 'Điều khiển', risk: 'medium' },
    { id: 'catch_up_person', name: 'Bù tính tình hình nhân vật', kind: 'action', category: 'Điều khiển', risk: 'medium', confirmation: true },
    { id: 'social_send_message', name: 'Gửi hộ tin nhắn liên lạc', kind: 'action', category: 'Liên lạc', risk: 'high', confirmation: true },
    { id: 'social_accept_request', name: 'Chấp nhận lời mời kết bạn', kind: 'action', category: 'Liên lạc', risk: 'high', confirmation: true },
    { id: 'social_refuse_request', name: 'Từ chối lời mời kết bạn', kind: 'action', category: 'Liên lạc', risk: 'high', confirmation: true },
    { id: 'social_remove_friend', name: 'Xóa bạn liên lạc', kind: 'action', category: 'Liên lạc', risk: 'high', confirmation: true },
    { id: 'social_refresh_moments', name: 'Làm mới Khoảnh khắc', kind: 'action', category: 'Liên lạc', risk: 'medium', confirmation: true },
    { id: 'delete_lingqi_chat', name: 'Xóa trò chuyện với 玲\u4e03', kind: 'action', category: 'Sắp xếp', risk: 'high', confirmation: true },
];

export const LINGQI_SKILL_REGISTRY = Object.freeze(
    SKILLS.map(skill => Object.freeze({ confirmation: false, ...skill })),
);

export const LINGQI_ACTION_TYPES = new Set(
    LINGQI_SKILL_REGISTRY.filter(skill => skill.kind === 'action').map(skill => skill.id),
);

export const LINGQI_SETTING_GUIDES = Object.freeze([
    {
        id: 'world-engine',
        title: 'Động cơ thế giới',
        keywords: ['Động cơ thế giới', 'công tắc tổng suy diễn thế giới', 'bật thế giới', 'Suy diễn thế giới'],
        path: 'Ổ nhỏ của 玲七 → Cài đặt chung → Thường dùng → Bật động cơ thế giới',
        keys: ['worldSimulationEnabled'],
        meaning: 'Quyết định 世界背面 có tiếp tục kết toán nhân vật, Mạch ngầm và trạng thái thế giới hay không. Tắt sẽ không xóa dữ liệu đã có.',
        choices: ['Bật: thế giới tiếp tục vận hành, có thể suy diễn thủ công hoặc tự động', 'Tắt: dừng các lượt suy diễn thế giới mới, trạng thái đã có được giữ nguyên'],
        recommendation: 'Bình thường nên bật; chỉ tắt khi kiểm thử, gỡ lỗi hoặc muốn tạm đóng băng thế giới nền.',
        delegable: true,
    },
    {
        id: 'auto-simulation',
        title: 'Tự động chạy',
        keywords: ['Tự động chạy', 'tự động suy diễn', 'suy diễn mỗi lượt'],
        path: 'Ổ nhỏ của 玲七 → Cài đặt chung → Thường dùng → Tự động chạy',
        keys: ['worldAutoEnabled'],
        meaning: 'Quyết định có tự động sắp xếp suy diễn thế giới khi có chính văn mới hay không; tắt rồi vẫn có thể tự bấm “Suy diễn thế giới”.',
        choices: ['Bật: tự động xếp hàng suy diễn sau chính văn mới', 'Tắt: chỉ suy diễn khi bạn tự yêu cầu'],
        recommendation: 'Muốn đỡ bận tâm thì bật; khi chỉnh prompt, kiểm soát chi phí API hoặc kiểm tra từng lượt thì tắt.',
        delegable: true,
    },
    {
        id: 'prompt-injection',
        title: 'Chèn vào chính văn',
        keywords: ['Chèn vào chính văn', 'công tắc tổng chèn', 'đưa hậu trường cho chính văn', 'hé lộ vào chính văn'],
        path: 'Ổ nhỏ của 玲七 → Cài đặt chung → Chèn vào chính văn',
        keys: ['worldPromptInjection'],
        meaning: 'Chỉ quyết định dữ liệu hậu trường có được đưa cho model chính văn xem hay không, không quyết định module nền có tiếp tục chạy hay không.',
        choices: ['Bật công tắc tổng: sau đó chọn riêng từng mục thời gian, nhân vật, Mạch ngầm, Tiếng vọng, sự thật, ký ức, dư luận', 'Tắt công tắc tổng: phần nền vẫn lưu và chạy như thường, nhưng không đưa gì cho chính văn'],
        recommendation: 'Thường bật công tắc tổng, rồi tắt từng mục theo nhu cầu; đừng tắt chèn chỉ để dừng suy diễn.',
        delegable: true,
    },
    {
        id: 'time-injection',
        title: 'Chèn thời gian thế giới',
        keywords: ['Chèn thời gian thế giới', 'chèn thời gian', 'Điểm neo tối thiểu', 'thời gian đầy đủ', 'chính văn báo giờ'],
        path: 'Ổ nhỏ của 玲七 → Cài đặt chung → Chèn vào chính văn → Thời gian thế giới',
        keys: ['injectionTimeMode'],
        meaning: 'Quyết định model chính văn được thấy bao nhiêu thông tin thời gian thế giới.',
        choices: ['Đầy đủ: ngày, buổi và giờ cụ thể đều được đưa cho chính văn', 'Điểm neo tối thiểu: chỉ giữ thông tin cần thiết để duy trì tính liên tục của thời gian', 'Tắt: hoàn toàn không đưa thời gian, nguy cơ thời gian lùi lại hoặc nhảy loạn cao hơn'],
        recommendation: 'Đa số game văn bản nên dùng “Điểm neo tối thiểu”; khi cần lịch trình, đếm ngược hoặc dòng thời gian chính xác thì chọn “Đầy đủ”.',
        delegable: true,
    },
    {
        id: 'people-injection',
        title: 'Chèn trạng thái nhân vật',
        keywords: ['chèn nhân vật', 'Chèn trạng thái nhân vật', 'chèn trạng thái nhân vật'],
        path: 'Ổ nhỏ của 玲七 → Cài đặt chung → Chèn vào chính văn → 「Nhân vật」· Trạng thái hiện tại',
        keys: ['injectionPeople'],
        meaning: 'Quyết định vị trí, hành động và ý định hiện tại của nhân vật có được đưa cho chính văn hay không; tắt không có nghĩa là nhân vật ngừng sống ở hậu trường.',
        choices: ['Bật: chính văn dễ tiếp nối trạng thái hiện tại của nhân vật hơn', 'Tắt: nhân vật vẫn có thể được suy diễn nền, nhưng model chính văn không thấy trạng thái này'],
        recommendation: 'Thường nên bật; chỉ tắt khi muốn chính văn hoàn toàn không tham khảo trạng thái nhân vật nền.',
        delegable: true,
    },
    {
        id: 'event-injection',
        title: 'Chèn Mạch ngầm & Tiếng vọng',
        keywords: ['chèn Mạch ngầm', 'chèn sự kiện', 'chèn tiếng vọng', 'Chèn sự thật thế giới'],
        path: 'Ổ nhỏ của 玲七 → Cài đặt chung → Chèn vào chính văn → 「Mạch ngầm」/「Tiếng vọng」/Sự thật thế giới',
        keys: ['injectionEvents', 'injectionEchoes', 'injectionFacts'],
        meaning: 'Lần lượt điều khiển việc sự kiện đang diễn ra, hậu quả đã kết toán và sự thật thế giới có thẩm quyền có được đưa cho chính văn hay không.',
        choices: ['Mạch ngầm: cho chính văn biết những thay đổi đang hình thành ngoài ống kính', 'Tiếng vọng: cho chính văn tiếp nối những hậu quả đã xảy ra', 'Sự thật thế giới: ngăn chính văn mâu thuẫn với các sự thật đã xác lập'],
        recommendation: 'Sự thật thế giới và Tiếng vọng nên giữ bật; Mạch ngầm có thể quyết định tùy mức độ bạn muốn hé lộ sớm.',
        delegable: true,
    },
    {
        id: 'memory',
        title: 'ký ức dài hạn',
        keywords: ['Hệ thống ký ức', 'ký ức dài hạn', 'chèn ký ức', 'tự động sắp xếp ký ức', 'Sắp xếp ký ức'],
        path: 'Ổ nhỏ của 玲七 → Cài đặt chat hiện tại → Ký ức dài hạn; công tắc chèn nằm ở “Cài đặt chung → Chèn vào chính văn → Ký ức dài hạn”',
        keys: ['memorySystemEnabled', 'injectionMemory', 'memoryAutoIndexInterval'],
        meaning: '“Hệ thống ký ức” quyết định có tiếp tục sắp xếp và lưu hay không; “Chèn ký ức” chỉ quyết định có đưa cho chính văn hay không; “Khoảng cách sắp xếp” quyết định bao lâu tự động dọn dẹp một lần.',
        choices: ['Bật hệ thống + bật chèn: tiếp tục sắp xếp và cũng đưa cho chính văn', 'Bật hệ thống + tắt chèn: tiếp tục sắp xếp, nhưng tạm thời chính văn không thấy', 'Tắt hệ thống: không sắp xếp ký ức mới nữa, ký ức cũ vẫn được giữ'],
        recommendation: 'Thường giữ hệ thống bật; khoảng cách sắp xếp 10 lượt hợp với đa số cuộc chat, truyện dài có thể dùng 5 lượt, muốn hoàn toàn thủ công thì chọn 0.',
        delegable: true,
    },
    {
        id: 'public-opinion',
        title: 'Dư luận & tin tức',
        keywords: ['Dư luận', 'tin tức', 'diễn đàn', 'Tự động dư luận', 'Chèn dư luận'],
        path: 'Thanh bên 世界背面 → Dư luận; công tắc chèn nằm ở “Cài đặt chung → Chèn vào chính văn → Tin tức & diễn đàn”',
        keys: ['publicOpinionAutoEnabled', 'injectionPublicOpinion'],
        meaning: 'Tự động dư luận quyết định có tự làm mới tiếng nói công chúng hay không; chèn dư luận chỉ quyết định những nội dung này có được đưa cho chính văn hay không.',
        choices: ['Bật tự động: tự cập nhật khi thỏa điều kiện thời gian thế giới và sự kiện công cộng', 'Tắt tự động: chỉ làm mới khi bạn tự bấm “Đi tuần một vòng”', 'Tắt chèn: tin tức vẫn có thể được tạo, nhưng sẽ không chủ động vào ngữ cảnh chính văn'],
        recommendation: 'Muốn thế giới có âm thanh nền thì bật tự động dư luận; khi cần kiểm soát chi phí API thì tắt tự động, giữ lại tuần tra thủ công.',
        delegable: true,
    },
    {
        id: 'player-recording',
        title: 'Ghi nhận nhân vật người chơi',
        keywords: ['Ghi nhận nhân vật người chơi', 'nhân vật người chơi', 'ghi nhận user', 'ghi nhận tôi'],
        path: 'Thanh bên 世界背面 → Nhân vật → Cài đặt suy diễn nhân vật → Ghi nhận nhân vật người chơi',
        keys: ['recordPlayerCharacter'],
        meaning: 'Chỉ ghi lại vị trí, hành động và trạng thái khách quan của người chơi đã xảy ra rõ ràng trong chính văn, không đọc hay viết thay nội tâm của người chơi.',
        choices: ['Bật: trạng thái khách quan của người chơi vào mục Nhân vật', 'Tắt: người chơi không được ghi nhận như một nhân vật nền'],
        recommendation: 'Bật khi cần tính liên tục chặt chẽ về vị trí và hành động; tắt khi không muốn plugin duy trì trạng thái người chơi.',
        delegable: true,
    },
    {
        id: 'social-life',
        title: 'Liên lạc & chủ động liên lạc',
        keywords: ['Liên lạc', 'bạn bè', 'chủ động liên lạc', 'tin nhắn chủ động', 'lời mời kết bạn', 'Khoảnh khắc', 'trò chuyện ảnh hưởng chính văn'],
        path: 'Thanh bên 世界背面 → Liên lạc → Danh bạ; công tắc chính văn cũng có thể tìm ở “Cài đặt chung → Chèn vào chính văn → Chat gần đây”',
        keys: ['socialAutoEnabled', 'injectionSocial'],
        meaning: '“Nhân vật chủ động liên lạc” quyết định nhân vật có, theo thiết lập nhân vật, thỉnh thoảng gửi tin nhắn, lời mời, bài đăng hoặc kết thúc quan hệ hay không; “Liên lạc ảnh hưởng chính văn” chỉ quyết định chat có được đưa cho chính văn dưới dạng bản ghi chưa kết toán hay không.',
        choices: ['Bật chủ động liên lạc: nhân vật có động cơ thật thì có thể hành động, không có động cơ thì vẫn giữ im lặng', 'Tắt chủ động liên lạc: chỉ giữ thao tác chủ động của user và các bản ghi đã có', 'Tắt tham khảo chính văn: chat hoàn toàn ở lại tầng liên lạc, không vào ngữ cảnh chính văn'],
        recommendation: 'Muốn có cảm giác đời sống thì bật chủ động liên lạc; trò chuyện ảnh hưởng chính văn vẫn mặc định tắt, khi cần chính văn tiếp nối giọng điệu hay kế hoạch trong chat thì mới bật riêng.',
        delegable: true,
    },
    {
        id: 'background-people',
        title: 'Tăng cường suy diễn nhân vật nền',
        keywords: ['tăng cường nhân vật nền', 'suy diễn nhân vật nền', 'suy diễn npc', 'nhân vật ngoài ống kính'],
        path: 'Thanh bên 世界背面 → Nhân vật → Cài đặt suy diễn nhân vật → Tăng cường suy diễn nhân vật nền',
        keys: ['enhancedBackgroundSimulation'],
        meaning: 'Cho nhiều nhân vật ngoài ống kính hơn tham gia kết toán theo thời gian thế giới; không phải mỗi lượt gửi riêng một request API cho từng người.',
        choices: ['Bật: nhân vật ngoài ống kính năng động hơn, trạng thái bao phủ rộng hơn', 'Tắt: kết toán dè dặt hơn theo mức liên quan và điều kiện đến hạn'],
        recommendation: 'Bật khi có nhiều nhân vật mà muốn thế giới sống động hơn; khi coi trọng ổn định và chi phí hơn thì tắt trước.',
        delegable: true,
    },
    {
        id: 'connection',
        title: 'Kết nối & model',
        keywords: ['api', 'API', 'kết nối', 'Model', 'trung chuyển', 'kết nối Tavern', 'phân luồng theo module'],
        path: 'Ổ nhỏ của 玲七 → Cài đặt chung → Kết nối & model',
        keys: [],
        meaning: 'Trước tiên chọn theo Tavern, cấu hình Tavern hay API độc lập, sau đó chọn kết nối mặc định hoặc phân luồng riêng cho suy diễn thế giới, quan sát nhân vật, ký ức và dư luận.',
        choices: ['Không cần API độc lập: theo kết nối hiện tại của Tavern', 'Cần model cố định: chọn cấu hình Tavern', 'Cần URL / Key độc lập: lưu API độc lập, rồi phân bổ trong “Phân luồng API theo module”'],
        recommendation: 'Khi chưa chắc thì cứ theo Tavern trước; chỉ khi cần chia việc cho các model, hạn mức riêng hoặc năng lực ngữ cảnh khác nhau mới phân luồng. API Key không giao cho 玲七 điền hộ qua trò chuyện.',
        delegable: false,
    },
    {
        id: 'generation-limit',
        title: 'Token & thời gian chờ',
        keywords: ['token', 'giới hạn đầu ra', 'giới hạn sinh', 'quá thời gian', 'thời gian chờ', 'timeout'],
        path: 'Ổ nhỏ của 玲七 → Cài đặt chung → Nâng cao & bảo trì → Giới hạn sinh',
        keys: ['maxOutputTokens', 'generationTimeoutMs'],
        meaning: 'Giá trị toàn cục bằng 0 nghĩa là tự động; module để riêng 0 nghĩa là kế thừa toàn cục. Token là giới hạn đầu ra, không phải bắt buộc viết đầy.',
        choices: ['Tự động: để plugin chọn theo loại tác vụ', 'Tùy chỉnh toàn cục: tăng hoặc giới hạn đồng loạt', 'Cài riêng theo module: chỉ chỉnh suy diễn thế giới, quan sát nhân vật, ký ức hoặc dư luận'],
        recommendation: 'Thường cứ dùng tự động trước; khi JSON của suy diễn thế giới bị cắt cụt thì ưu tiên tăng Token của module “Suy diễn thế giới”, còn khi upstream chậm nhưng vẫn đang sinh thì mới tăng thời gian chờ.',
        delegable: false,
    },
    {
        id: 'appearance',
        title: 'Cỡ chữ giao diện & bóng nổi',
        keywords: ['Cỡ chữ giao diện', 'phông chữ', 'cỡ chữ', 'bóng nổi', 'bám mép', 'Sáng/tối giao diện', 'chủ đề'],
        path: 'Ổ nhỏ của 玲七 → Cài đặt chung → Thường dùng → Giao diện',
        keys: ['uiScale', 'orbEnabled', 'orbEdgeHide', 'theme'],
        meaning: 'Điều khiển cỡ chữ, sáng/tối và hiển thị bóng nổi của riêng 世界背面, không thay đổi phông chữ chính văn của SillyTavern.',
        choices: ['Cỡ chữ: Gọn / Tiêu chuẩn / Chữ lớn', 'Sáng/tối: Tự động / Ban ngày / Ban đêm', 'Bóng nổi có thể ẩn, cũng có thể bật thu gọn sát mép'],
        recommendation: 'Ưu tiên dùng “Tiêu chuẩn”; khi dùng điện thoại hoặc đọc vất vả thì dùng “Chữ lớn”. Sau khi ẩn bóng nổi có thể mở lại từ cài đặt tiện ích mở rộng của Tavern.',
        delegable: false,
    },
]);

export function findLingqiSettingGuide(userText = '') {
    const raw = normalize(userText).toLocaleLowerCase();
    if (!raw || !/(?:怎么(?:设|设置|调|开|关|用)|如何(?:设|设置|开启|关闭|使用)|在哪(?:里)?(?:设|设置|开|关|找)|入口|调哪个|选哪个|什么意思|该不该开|要不要开|làm sao\s*(?:để\s*)?(?:đặt|cài|chỉnh|bật|tắt|dùng)|cách\s*(?:đặt|cài|chỉnh|bật|tắt|dùng|sử dụng)|(?:đặt|cài|chỉnh|bật|tắt|tìm)[^?？]{0,12}ở đâu|lối vào|chỉnh cái nào|chọn cái nào|nghĩa là gì|có nên bật|có cần bật|có nên mở)/iu.test(raw)) return null;
    const scored = LINGQI_SETTING_GUIDES
        .map(guide => ({
            guide,
            score: guide.keywords.reduce((total, keyword) => (
                raw.includes(String(keyword).toLocaleLowerCase()) ? total + Math.max(2, keyword.length) : total
            ), 0),
        }))
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score || b.guide.title.length - a.guide.title.length);
    if (!scored.length) return null;
    return scored[0].guide;
}

function normalize(value = '') {
    return String(value || '').trim();
}

function mentionedPersonName(userText, people = []) {
    const raw = normalize(userText).toLocaleLowerCase();
    const matches = (Array.isArray(people) ? people : [])
        .map(person => String(person?.name || '').trim())
        .filter(name => name && raw.includes(name.toLocaleLowerCase()))
        .sort((a, b) => b.length - a.length);
    if (!matches.length) return '';
    const longest = matches[0];
    return matches.filter(name => name.length === longest.length).length === 1 ? longest : '';
}

export function parseLingqiLocalQueryRequest(userText = '', people = []) {
    const raw = normalize(userText);
    if (!raw) return null;

    if (/(?:你会什么|你能做什么|有什么技能|技能清单|管家能力|能帮我做什么|bạn biết làm gì|bạn làm được gì|bạn có (?:những\s*)?(?:kỹ năng|kĩ năng) gì|danh sách kỹ năng|năng lực quản gia|(?:có thể\s*)?giúp (?:tôi|mình) (?:làm\s*)?(?:được\s*)?gì)/iu.test(raw)) {
        return { type: 'list_skills' };
    }

    const personName = mentionedPersonName(raw, people);
    if (personName && /(?:是不是|是否|还算|现在是).{0,5}(?:好友|通讯好友)|(?:好友|通讯关系).{0,6}(?:什么状态|怎么样|还在吗)|(?:có phải|có còn|còn là|bây giờ là|hiện là|vẫn là).{0,8}(?:bạn bè|bạn liên lạc)|(?:quan hệ bạn bè|quan hệ liên lạc|kết bạn).{0,10}(?:thế nào|ra sao|trạng thái gì|còn không)/iu.test(raw)) {
        return { type: 'social_person_status', personName };
    }
    if (
        personName
        && /(?:为什么|怎么).{0,12}(?:没动|不动|没推演|没更新|这么久)|(?:这么久|最近).{0,8}(?:没动|不动|没推演|没更新)|(?:tại sao|vì sao|sao).{0,16}(?:không động|chưa động|không suy diễn|chưa suy diễn|không cập nhật|chưa cập nhật|lâu vậy|lâu thế)|(?:lâu (?:vậy|thế|rồi)|gần đây|dạo này).{0,10}(?:không động|chưa động|không suy diễn|chưa suy diễn|không cập nhật|chưa cập nhật)/iu.test(raw)
    ) {
        return { type: 'diagnose_person', personName };
    }
    if (
        personName
        && /(?:现在|目前|最近).{0,12}(?:在哪|哪里|做什么|干什么|怎么样|状态|近况)|(?:在哪|哪里|做什么|干什么|怎么样|状态|近况).{0,4}(?:呢|？|\?)*$|(?:bây giờ|hiện giờ|hiện tại|gần đây|dạo này).{0,16}(?:ở đâu|đang làm gì|làm gì|thế nào|ra sao|trạng thái|tình hình)|(?:ở đâu|đang làm gì|làm gì|thế nào|ra sao|trạng thái|tình hình)\s*(?:vậy|thế|rồi|nhỉ)?\s*(?:？|\?)*$/iu.test(raw)
    ) {
        return { type: 'person_status', personName };
    }

    if (/(?:为什么|怎么).{0,12}(?:没推演|不推演|没运行|没跑|失败|报错)|(?:后台|世界推演).{0,8}(?:卡住|正常吗|怎么了|有问题)|(?:tại sao|vì sao|sao).{0,16}(?:không suy diễn|chưa suy diễn|không chạy|chưa chạy|thất bại|báo lỗi)|(?:tác vụ nền|nền|suy diễn thế giới).{0,10}(?:bị kẹt|kẹt|bình thường không|làm sao vậy|sao vậy|có vấn đề)/iu.test(raw)) {
        return { type: 'diagnose_world' };
    }
    const settingGuide = findLingqiSettingGuide(raw);
    if (settingGuide) return { type: 'setting_guide', guideId: settingGuide.id };
    if (/(?:世界背面|后台|世界).{0,8}(?:什么情况|怎么样|状态总览|汇报)|(?:状态总览|汇报一下|管家汇报)|(?:世界背面|nền|thế giới).{0,10}(?:tình hình|thế nào|ra sao|tổng quan trạng thái|báo cáo)|(?:tổng quan trạng thái|báo cáo (?:một chút|đi|tình hình)|quản gia báo cáo)/iu.test(raw)) {
        return { type: 'status_overview' };
    }
    if (/(?:有哪些|列出|看看|查看).{0,6}(?:人物|角色)|(?:人物|角色)(?:清单|列表|有谁)|(?:có những ai|liệt kê|xem|kiểm tra).{0,8}nhân vật|nhân vật\s*(?:có những ai|gồm những ai|gồm ai)|danh sách nhân vật/iu.test(raw)) {
        return { type: 'list_people' };
    }
    if (/(?:最近|当前|现在).{0,8}(?:发生了什么|有什么暗流|有哪些暗流|有什么事件|有哪些事件)|(?:暗流|事件)(?:清单|列表|近况)|(?:gần đây|hiện tại|bây giờ|hiện giờ).{0,10}(?:có chuyện gì|xảy ra (?:chuyện\s*)?gì|có (?:những\s*)?(?:mạch ngầm|mạch ngầm|sự kiện)\s*(?:gì|nào))|(?:danh sách|tình hình)\s*(?:các\s*)?(?:mạch ngầm|mạch ngầm|sự kiện)|(?:mạch ngầm|mạch ngầm|sự kiện)\s*gần đây/iu.test(raw)) {
        return { type: 'recent_events' };
    }
    if (/(?:记忆).{0,8}(?:什么情况|状态|多少|整理到哪|记住了什么)|(?:盘点|看看|查看).{0,6}(?:长期)?记忆|ký ức.{0,10}(?:tình hình|trạng thái|bao nhiêu|sắp xếp đến đâu|nhớ được gì)|(?:kiểm kê|xem|kiểm tra).{0,8}ký ức/iu.test(raw)) {
        return { type: 'memory_status' };
    }
    if (/(?:设置|开关).{0,8}(?:概览|总览|有哪些|什么状态|现在怎样)|(?:看看|查看).{0,6}(?:设置|开关)|(?:cài đặt|thiết lập|công tắc).{0,10}(?:tổng quan|có những gì|trạng thái|thế nào)|(?:xem|kiểm tra).{0,8}(?:cài đặt|thiết lập|công tắc)/iu.test(raw)) {
        return { type: 'settings_overview' };
    }
    if (/(?:通讯|好友|好友申请|朋友圈).{0,8}(?:概览|总览|什么情况|多少|未读|盘点)|(?:看看|查看).{0,6}(?:通讯录|好友申请|未读消息)|(?:liên lạc|bạn bè|lời mời kết bạn|khoảnh khắc).{0,10}(?:tổng quan|tình hình|bao nhiêu|chưa đọc|kiểm kê)|(?:xem|kiểm tra).{0,8}(?:danh bạ|lời mời kết bạn|tin nhắn chưa đọc)/iu.test(raw)) {
        return { type: 'social_overview' };
    }

    const search = raw.match(/(?:找(?:一下|找)?|搜索|翻翻|查查|tìm lại|tìm kiếm|tìm xem|tìm đoạn|lục lại|tra lại).{0,8}(?:我们|玲七|\s*chúng ta|\s*mình)?(?:之前|以前|\s*trước đây|\s*trước đó|\s*đã)?(?:聊过|说过|提到过|提过|\s*(?:nói|trò chuyện|nhắc|kể|bàn)(?:\s*(?:về|đến|tới|qua))?)?(?:的)?[“「『"]?([^”」』"，。！？!]{2,80})[”」』"]?(?:那段|的地方|在哪|记录)?/iu)
        || raw.match(/(?:我们|你和我|chúng ta|tôi với bạn|tôi và bạn|bạn với tôi).{0,6}(?:聊过|说过|提到过|提过|(?:nói|trò chuyện|nhắc|bàn|kể)\s*(?:về|đến|tới|qua)?)[“「『"]?([^”」』"，。！？!?]{2,80})[”」』"]?(?:吗|没有|么|？|\?|\s*(?:chưa|không|nhỉ|à)\s*[？?]?)/iu);
    if (search) {
        const query = String(search[1] || '')
            .replace(/^(?:关于|有关|về\s+|liên quan (?:đến|tới)\s+)/iu, '')
            .replace(/(?:的聊天|这件事|这个话题|\s+(?:chưa|không|nhỉ|à|chuyện này|chủ đề này|việc này))$/iu, '')
            .trim();
        if (query.length >= 2) return { type: 'search_lingqi_chat', query };
    }

    return null;
}

export function buildLingqiSkillMenuText() {
    return [
        'Giờ mình làm được những việc này:',
        '· Tra cứu: tổng quan thế giới, vị trí/hành động nhân vật, Mạch ngầm gần đây, trạng thái ký ức và cài đặt',
        '· Chẩn đoán: vì sao chưa suy diễn, nền có bị kẹt không, vì sao ai đó lâu rồi không động đậy',
        '· Điều khiển: suy diễn chính văn mới nhất, tuần tra thế giới công cộng, bật/tắt các cài đặt an toàn, dừng tác vụ nền',
        '· Nhân vật: bật/tắt suy diễn nền, xếp ưu tiên ở lượt sau, cập nhật tình hình gần đây một lần',
        '· Liên lạc: xem bạn bè/lời mời/tin chưa đọc, sau khi xác nhận thì gửi tin nhắn hộ, xử lý lời mời, xóa bạn hoặc làm mới Khoảnh khắc',
        '· Sắp xếp: tìm hoặc xóa trò chuyện với 玲七, sắp xếp ký ức dài hạn, kiểm tra sự thật thế giới',
        'Sửa sự thật cốt lõi của nhân vật, xóa ký ức dài hạn, đặt lại thế giới và sửa API thì mình sẽ không làm ngay chỉ vì một câu nói.',
    ].join('\n');
}
