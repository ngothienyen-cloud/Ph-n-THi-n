const MAX_CONVERSATIONS = 80;
const MAX_MESSAGES = 400;
const MAX_CONNECTIONS = 240;
const MAX_MOMENTS = 180;
const MAX_NOTICES = 40;
const MAX_MOMENT_IMAGES = 6;
const MAX_IMAGE_URL_CHARS = 6_000_000;

function text(value, maximum = 1200) {
    return String(value ?? '').trim().slice(0, maximum);
}

function makeId(prefix = 'social') {
    const random = globalThis.crypto?.randomUUID?.()
        || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
    return `${prefix}-${random}`;
}

function normalizedMessage(raw = {}) {
    const senderId = text(raw.senderId, 120);
    const body = text(raw.text, 1600);
    if (!senderId || !body) return null;
    return {
        id: text(raw.id, 160) || makeId('social-message'),
        senderId,
        senderName: text(raw.senderName, 120) || (senderId === 'user' ? 'Bạn' : 'Nhân vật không rõ'),
        text: body,
        worldMinute: Math.max(0, Number(raw.worldMinute) || 0),
        createdAt: text(raw.createdAt, 80) || new Date().toISOString(),
    };
}

function normalizedRouting(raw = {}, memberIds = []) {
    const members = new Set(memberIds);
    return {
        at: text(raw.at, 80),
        evaluations: (Array.isArray(raw.evaluations) ? raw.evaluations : [])
            .map(item => ({
                personId: text(item?.personId ?? item?.person_id, 120),
                saw: Boolean(item?.saw),
                knows: Boolean(item?.knows),
                willing: Boolean(item?.willing),
                outcome: item?.outcome === 'speak' ? 'speak' : 'silent',
                reason: text(item?.reason, 220),
            }))
            .filter(item => members.has(item.personId)),
    };
}

function normalizedConversation(raw = {}, validPersonIds = null) {
    const type = raw.type === 'group' ? 'group' : 'direct';
    const memberIds = [...new Set(
        (Array.isArray(raw.memberIds) ? raw.memberIds : [])
            .map(id => text(id, 120))
            .filter(id => id && (!validPersonIds || validPersonIds.has(id))),
    )].slice(0, type === 'direct' ? 1 : 24);
    if (!memberIds.length) return null;
    const rawMessages = (Array.isArray(raw.rawMessages) ? raw.rawMessages : [])
        .map(normalizedMessage)
        .filter(Boolean)
        .slice(-MAX_MESSAGES);
    const requestedSettlementId = text(
        raw.narrativeSettledThroughMessageId ?? raw.narrative_settled_through_message_id,
        160,
    );
    return {
        id: text(raw.id, 160) || makeId(type),
        type,
        title: text(raw.title, 120) || 'Hội thoại chưa đặt tên',
        memberIds,
        rawMessages,
        narrativeSettledThroughMessageId: rawMessages.some(message => message.id === requestedSettlementId)
            ? requestedSettlementId
            : '',
        lastRouting: normalizedRouting(raw.lastRouting, memberIds),
        lastError: text(raw.lastError, 500),
        createdAt: text(raw.createdAt, 80) || new Date().toISOString(),
        updatedAt: text(raw.updatedAt, 80) || new Date().toISOString(),
    };
}

export function pendingSocialConversations(social, state = {}) {
    const normalized = normalizeSocialState(social, state?.people || []);
    const accepted = new Set(normalized.connections
        .filter(item => item.status === 'accepted')
        .map(item => item.personId));
    const peopleById = new Map((state?.people || []).map(person => [String(person?.id || ''), person]));
    return normalized.conversations
        .filter(conversation => conversation.type === 'group' || accepted.has(conversation.memberIds[0]))
        .map(conversation => {
            const settledIndex = conversation.rawMessages.findIndex(message => (
                message.id === conversation.narrativeSettledThroughMessageId
            ));
            return {
                conversationId: conversation.id,
                title: conversation.title,
                members: conversation.memberIds.map(id => peopleById.get(id)?.name).filter(Boolean),
                messages: conversation.rawMessages.slice(settledIndex + 1),
            };
        })
        .filter(conversation => conversation.messages.length)
        .sort((a, b) => {
            const aTime = a.messages.at(-1)?.createdAt || '';
            const bTime = b.messages.at(-1)?.createdAt || '';
            return String(bTime).localeCompare(String(aTime));
        });
}

export function settleSocialConversations(social, state, settlements, narrativeText = '') {
    const normalized = normalizeSocialState(social, state?.people || []);
    const narrative = String(narrativeText || '');
    for (const raw of Array.isArray(settlements) ? settlements : []) {
        const conversationId = text(raw?.conversation_id ?? raw?.conversationId, 160);
        const throughMessageId = text(raw?.through_message_id ?? raw?.throughMessageId, 160);
        const evidence = text(raw?.evidence, 500);
        if (!conversationId || !throughMessageId || !evidence || !narrative.includes(evidence)) continue;
        const conversation = normalized.conversations.find(item => item.id === conversationId);
        if (!conversation) continue;
        const targetIndex = conversation.rawMessages.findIndex(message => message.id === throughMessageId);
        const currentIndex = conversation.rawMessages.findIndex(message => (
            message.id === conversation.narrativeSettledThroughMessageId
        ));
        if (targetIndex > currentIndex) conversation.narrativeSettledThroughMessageId = throughMessageId;
    }
    return normalized;
}

function normalizedConnection(raw = {}, validPersonIds = null) {
    const personId = text(raw.personId ?? raw.person_id, 120);
    if (!personId || (validPersonIds && !validPersonIds.has(personId))) return null;
    const status = ['accepted', 'pending', 'declined', 'suggested', 'incoming', 'removed'].includes(raw.status)
        ? raw.status
        : 'suggested';
    return {
        personId,
        status,
        source: text(raw.source, 60) || 'world',
        evidence: text(raw.evidence, 360),
        requestMessage: text(raw.requestMessage ?? raw.request_message, 300),
        decisionReason: text(raw.decisionReason ?? raw.decision_reason, 360),
        decisionReply: text(raw.decisionReply ?? raw.decision_reply, 300),
        requestedAt: text(raw.requestedAt ?? raw.requested_at, 80),
        respondedAt: text(raw.respondedAt ?? raw.responded_at, 80),
        updatedAt: text(raw.updatedAt ?? raw.updated_at, 80) || new Date().toISOString(),
    };
}

function normalizedMoment(raw = {}, validPersonIds = null) {
    const personId = text(raw.personId ?? raw.person_id, 120);
    const body = text(raw.text, 1200);
    if (!personId || !body || (validPersonIds && !validPersonIds.has(personId))) return null;
    const rawImage = text(raw.imageUrl ?? raw.image_url, MAX_IMAGE_URL_CHARS);
    const imageUrl = /^(?:https?:\/\/|data:image\/)/i.test(rawImage) ? rawImage : '';
    return {
        id: text(raw.id, 160) || makeId('moment'),
        personId,
        text: body,
        visibility: raw.visibility === 'private' ? 'private' : 'friends',
        worldMinute: Math.max(0, Number(raw.worldMinute ?? raw.world_minute) || 0),
        wantsImage: Boolean(raw.wantsImage ?? raw.wants_image),
        imagePrompt: text(raw.imagePrompt ?? raw.image_prompt, 1200),
        imageUrl,
        imageError: text(raw.imageError ?? raw.image_error, 360),
        likedByUser: Boolean(raw.likedByUser ?? raw.liked_by_user),
        likes: Math.max(0, Math.min(9999, Number(raw.likes) || 0)),
        comments: (Array.isArray(raw.comments) ? raw.comments : []).map(comment => ({
            id: text(comment?.id, 160),
            authorId: text(comment?.authorId, 120),
            authorName: text(comment?.authorName, 80),
            text: text(comment?.text, 500),
            createdAt: text(comment?.createdAt, 80),
        })).filter(comment => comment.id && comment.text).slice(-50),
        createdAt: text(raw.createdAt ?? raw.created_at, 80) || new Date().toISOString(),
    };
}

function normalizedNotice(raw = {}, validPersonIds = null) {
    const kind = ['message', 'friend_request', 'friend_removed', 'moment'].includes(raw.kind)
        ? raw.kind
        : 'message';
    const personId = text(raw.personId ?? raw.person_id, 120);
    if (!personId || (validPersonIds && !validPersonIds.has(personId))) return null;
    return {
        id: text(raw.id, 160) || makeId('social-notice'),
        kind,
        personId,
        conversationId: text(raw.conversationId ?? raw.conversation_id, 160),
        text: text(raw.text, 500),
        createdAt: text(raw.createdAt ?? raw.created_at, 80) || new Date().toISOString(),
        readAt: text(raw.readAt ?? raw.read_at, 80),
    };
}

export function emptySocialState() {
    return {
        schemaVersion: 2,
        activeConversationId: '',
        conversations: [],
        connections: [],
        moments: [],
        notices: [],
        momentsUpdatedAt: '',
        momentsUpdatedWorldMinute: -1,
        lastPulseMessageId: -1,
        lastPulseWorldMinute: -1,
        lastPulseRelationSignature: '',
    };
}

export function normalizeSocialState(raw, people = []) {
    const validPersonIds = new Set(
        (Array.isArray(people) ? people : [])
            .filter(person => !person?.isUser)
            .map(person => text(person?.id, 120))
            .filter(Boolean),
    );
    const source = raw && typeof raw === 'object' ? raw : emptySocialState();
    const conversations = (Array.isArray(source.conversations) ? source.conversations : [])
        .map(item => normalizedConversation(item, validPersonIds))
        .filter(Boolean)
        .slice(-MAX_CONVERSATIONS);
    const activeConversationId = conversations.some(item => item.id === source.activeConversationId)
        ? source.activeConversationId
        : (conversations[0]?.id || '');
    const connectionMap = new Map();
    for (const rawConnection of Array.isArray(source.connections) ? source.connections : []) {
        const connection = normalizedConnection(rawConnection, validPersonIds);
        if (connection) connectionMap.set(connection.personId, connection);
    }
    // Existing direct/group conversations predate the friendship graph. Preserve
    // them as accepted real contacts instead of breaking users' current chats.
    for (const conversation of conversations) {
        for (const personId of conversation.memberIds) {
            const existing = connectionMap.get(personId);
            if (existing) continue;
            connectionMap.set(personId, {
                ...normalizedConnection({ personId }, validPersonIds),
                status: 'accepted',
                source: 'legacy-conversation',
                evidence: 'Đã có cuộc trò chuyện',
            });
        }
    }
    const connections = [...connectionMap.values()].slice(-MAX_CONNECTIONS);
    const acceptedIds = new Set(connections.filter(item => item.status === 'accepted').map(item => item.personId));
    const moments = (Array.isArray(source.moments) ? source.moments : [])
        .map(item => normalizedMoment(item, validPersonIds))
        .filter(item => item && acceptedIds.has(item.personId))
        .slice(-MAX_MOMENTS);
    const imageMoments = moments.filter(item => item.imageUrl);
    for (const oldMoment of imageMoments.slice(0, Math.max(0, imageMoments.length - MAX_MOMENT_IMAGES))) {
        oldMoment.imageUrl = '';
    }
    const notices = (Array.isArray(source.notices) ? source.notices : [])
        .map(item => normalizedNotice(item, validPersonIds))
        .filter(Boolean)
        .slice(-MAX_NOTICES);
    return {
        schemaVersion: 2,
        activeConversationId,
        conversations,
        connections,
        moments,
        notices,
        momentsUpdatedAt: text(source.momentsUpdatedAt ?? source.moments_updated_at, 80),
        momentsUpdatedWorldMinute: Number.isFinite(Number(source.momentsUpdatedWorldMinute ?? source.moments_updated_world_minute))
            ? Math.max(-1, Number(source.momentsUpdatedWorldMinute ?? source.moments_updated_world_minute))
            : -1,
        lastPulseMessageId: Number.isFinite(Number(source.lastPulseMessageId ?? source.last_pulse_message_id))
            ? Math.max(-1, Number(source.lastPulseMessageId ?? source.last_pulse_message_id))
            : -1,
        lastPulseWorldMinute: Number.isFinite(Number(source.lastPulseWorldMinute ?? source.last_pulse_world_minute))
            ? Math.max(-1, Number(source.lastPulseWorldMinute ?? source.last_pulse_world_minute))
            : -1,
        lastPulseRelationSignature: text(source.lastPulseRelationSignature ?? source.last_pulse_relation_signature, 160),
    };
}

export function acceptedSocialPersonIds(social, people = []) {
    return new Set(normalizeSocialState(social, people).connections
        .filter(item => item.status === 'accepted')
        .map(item => item.personId));
}

function relationEvidenceFor(person, userPerson, state, userName = '', recentNarrative = '') {
    const personId = text(person?.id, 120);
    const personName = text(person?.name, 120);
    const userId = text(userPerson?.id, 120);
    const playerName = text(userName || userPerson?.name, 120);
    const relationWords = /同事|同僚|上司|下属|主管|经理|员工|助理|秘书|搭档|队友|朋友|好友|同学|室友|家人|亲属|恋人|伴侣|夫妻|师生|导师|学生|客户|经纪人|合作伙伴|đồng nghiệp|cấp trên|cấp dưới|quản lý|nhân viên|trợ lý|thư ký|cộng sự|đồng đội|bạn bè|bạn thân|bạn học|bạn cùng lớp|bạn cùng phòng|gia đình|người thân|người yêu|bạn đời|vợ chồng|thầy trò|người hướng dẫn|học sinh|sinh viên|khách hàng|người đại diện|đối tác/;
    const workWords = /上班|工作|值班|办公|公司|单位|部门|岗位|工位|店里|学校|医院|片场|剧组|项目|会议|出勤|đi làm|làm việc|công việc|trực ca|văn phòng|công ty|cơ quan|phòng ban|bộ phận|vị trí công tác|chỗ làm|cửa hàng|trường học|bệnh viện|phim trường|đoàn phim|dự án|cuộc họp|chấm công/;
    const personProfile = [
        person?.identityAnchor,
        person?.backgroundProfile,
        person?.worldbookRaw,
        person?.trace,
        person?.action,
        person?.intent,
        person?.location,
    ].map(value => text(value, 2200)).join('\n');
    const userProfile = [
        userPerson?.identityAnchor,
        userPerson?.backgroundProfile,
        userPerson?.worldbookRaw,
        userPerson?.trace,
        userPerson?.action,
        userPerson?.intent,
        userPerson?.location,
    ].map(value => text(value, 2200)).join('\n');
    const profileNamesRelation = relationWords.test(personProfile)
        && (playerName && personProfile.includes(playerName));
    const reverseProfileRelation = relationWords.test(userProfile)
        && personName && userProfile.includes(personName);
    if (profileNamesRelation || reverseProfileRelation) {
        return { status: 'accepted', evidence: 'Thiết lập nhân vật có quan hệ ngoài đời thực hoặc phương thức liên lạc rõ ràng' };
    }

    const narrative = text(recentNarrative, 18000);
    const completedContact = /(?:交换|互换|互留|留下|留了|给了|记下|存下|保存|添加|互加|加上|通过了?)(?:彼此|双方|对方|了|上|好|一下|一下子|的)?(?:联系方式|微信|qq|QQ|号码|手机号|电话|通讯号|联系人|好友)|(?:扫码|扫了码|扫二维码|扫描二维码|加了微信|加上微信|加了QQ|加上QQ|互加好友|互加微信|互加QQ|通讯录里(?:有|多了))|(?:trao đổi|để lại|đã cho|ghi lại|lưu lại|đã lưu|đã thêm|thêm)\s*(?:cho nhau|với nhau|của nhau|lẫn nhau)?\s*(?:thông tin liên lạc|cách liên lạc|số điện thoại|số liên lạc|danh bạ|wechat|WeChat|zalo|Zalo|qq|QQ)|(?:quét mã|quét QR|quét qr|đã kết bạn|kết bạn với nhau|thêm bạn bè|trong danh bạ (?:đã có|có thêm))/u;
    const notCompleted = /(?:还没|没有|没能|未能|尚未|并未|拒绝|婉拒|暂不|以后再|改天再|等.+再|如果.+(?:再|才)?|想(?:要)?|打算|准备|试图|询问|请求).{0,24}(?:交换|添加|互加|联系方式|微信|qq|QQ|号码|电话|好友)|(?:chưa|không|không thể|chưa thể|từ chối|khước từ|tạm không|để sau|hôm khác|nếu|muốn|định|dự định|chuẩn bị|thử|hỏi|xin|nhờ).{0,24}(?:trao đổi|thêm|kết bạn|bạn bè|thông tin liên lạc|cách liên lạc|số điện thoại|số liên lạc|danh bạ|wechat|WeChat|zalo|Zalo|qq|QQ)/u;
    if (personName && narrative.includes(personName)) {
        const segments = narrative
            .replace(/([。！？!?；;])/gu, '$1\n')
            .split(/\n+/u)
            .map(segment => segment.trim())
            .filter(Boolean);
        const personIndexes = segments
            .map((segment, index) => segment.includes(personName) ? index : -1)
            .filter(index => index >= 0);
        const contactIndexes = segments
            .map((segment, index) => completedContact.test(segment) && !notCompleted.test(segment) ? index : -1)
            .filter(index => index >= 0);
        const nearbyCompleted = contactIndexes.some(contactIndex => (
            personIndexes.some(personIndex => Math.abs(personIndex - contactIndex) <= 1)
        ));
        if (nearbyCompleted) {
            return { status: 'accepted', evidence: 'Chính văn đã ghi rõ là hai bên đã hoàn tất trao đổi phương thức liên lạc' };
        }
    }

    const relationRecords = [
        ...(Array.isArray(state?.storyMemory?.facts) ? state.storyMemory.facts : []),
        ...(Array.isArray(state?.storyMemory?.summaries) ? state.storyMemory.summaries : []),
    ];
    for (const record of relationRecords.slice(-160)) {
        const recordText = JSON.stringify(record);
        const hasPerson = recordText.includes(personId) || (personName && recordText.includes(personName));
        const hasUser = (userId && recordText.includes(userId)) || (playerName && recordText.includes(playerName));
        if (hasPerson && hasUser && relationWords.test(recordText)) {
            return { status: 'accepted', evidence: 'Sự thật dài hạn có ghi lại quan hệ ngoài đời thực của hai bên' };
        }
    }

    const userAtWork = workWords.test(userProfile);
    let sharedEvent = false;
    for (const event of (Array.isArray(state?.events) ? state.events : []).slice(-80)) {
        const eventText = JSON.stringify(event);
        const hasPerson = eventText.includes(personId) || (personName && eventText.includes(personName));
        const hasUser = (userId && eventText.includes(userId)) || (playerName && eventText.includes(playerName));
        if (!hasPerson || !hasUser) continue;
        sharedEvent = true;
        if (workWords.test(eventText) && (userAtWork || relationWords.test(personProfile + eventText))) {
            return { status: 'accepted', evidence: 'Hai bên có cơ sở liên lạc trong quan hệ công việc đã xảy ra' };
        }
    }

    if (userAtWork && workWords.test(personProfile)) {
        const workMarkerPattern = /[\p{L}\p{N}·]{2,24}(?:公司|集团|部门|科室|单位|学校|学院|医院|诊所|剧组|片场|项目组|工作室|事务所|门店)|(?:[Cc]ông ty|[Tt]ập đoàn|[Bb]ộ phận|[Pp]hòng ban|[Tt]rường|[Hh]ọc viện|[Bb]ệnh viện|[Pp]hòng khám|[Đđ]oàn phim|[Pp]him trường|[Ss]tudio|[Vv]ăn phòng|[Cc]ửa hàng)\s+\p{Lu}[\p{L}\p{N}·]*(?:\s+\p{Lu}[\p{L}\p{N}·]*){0,4}/gu;
        const userMarkers = new Set(userProfile.match(workMarkerPattern) || []);
        const sharedMarker = (personProfile.match(workMarkerPattern) || []).find(marker => userMarkers.has(marker));
        if (sharedMarker) return { status: 'accepted', evidence: `Hai bên cùng thuộc phạm vi liên lạc công việc đã xác nhận: ${sharedMarker}` };
    }
    if (sharedEvent) return { status: 'suggested', evidence: 'Hai bên từng cùng xuất hiện trong sự kiện đã xảy ra' };
    return null;
}

export function reconcileSocialRelationships(social, state, { userName = '', recentNarrative = '' } = {}) {
    const people = Array.isArray(state?.people) ? state.people : [];
    const normalized = normalizeSocialState(social, people);
    const userPerson = people.find(person => person?.isUser) || null;
    const byPerson = new Map(normalized.connections.map(item => [item.personId, item]));
    for (const person of people.filter(item => !item?.isUser)) {
        const inference = relationEvidenceFor(person, userPerson, state, userName, recentNarrative);
        if (!inference) continue;
        const existing = byPerson.get(String(person.id || ''));
        if (existing?.status === 'accepted') continue;
        if (
            ['pending', 'declined', 'incoming', 'removed'].includes(existing?.status)
            && !inference.evidence.startsWith('Chính văn đã ghi rõ')
        ) continue;
        const next = normalizedConnection({
            ...existing,
            personId: person.id,
            status: inference.status,
            source: 'world-relation',
            evidence: inference.evidence,
        }, new Set(people.map(item => String(item?.id || ''))));
        if (next) byPerson.set(next.personId, next);
    }
    normalized.connections = [...byPerson.values()].slice(-MAX_CONNECTIONS);
    return normalized;
}

export function searchSocialPeople(social, state, query) {
    const people = Array.isArray(state?.people) ? state.people : [];
    const normalized = normalizeSocialState(social, people);
    const needle = text(query, 80).toLocaleLowerCase();
    if (needle.length < 2) return [];
    const byPerson = new Map(normalized.connections.map(item => [item.personId, item]));
    return people
        .filter(person => !person?.isUser)
        .filter(person => {
            const haystack = `${text(person.name, 120)}\n${text(person.identityAnchor, 220)}`.toLocaleLowerCase();
            return haystack.includes(needle);
        })
        .slice(0, 12)
        .map(person => ({
            person,
            connection: byPerson.get(String(person.id || '')) || null,
        }));
}

export function buildFriendRequestPrompt(social, state, personId, {
    userName = 'Bạn',
    requestMessage = '',
} = {}) {
    const people = Array.isArray(state?.people) ? state.people : [];
    const normalized = normalizeSocialState(social, people);
    const person = people.find(item => String(item?.id || '') === text(personId, 120) && !item?.isUser);
    if (!person) throw new Error('Không tìm thấy nhân vật này');
    const existing = normalized.connections.find(item => item.personId === String(person.id));
    if (existing?.status === 'accepted') throw new Error('Hai bạn đã là bạn liên lạc rồi');
    if (existing?.status === 'pending') throw new Error('Lời mời kết bạn vẫn đang chờ xử lý');
    if (existing?.status === 'incoming') throw new Error('Đối phương đã gửi lời mời kết bạn cho bạn');
    const profile = {
        id: person.id,
        name: person.name,
        identity_anchor: text(person.identityAnchor, 500),
        personality_anchor: text(person.personalityAnchor, 600),
        background_profile: text(person.backgroundProfile, 900),
        behavior_boundaries: text(person.behaviorBoundaries, 500),
        location: text(person.location, 180),
        action: text(person.action, 260),
        intent: text(person.intent, 260),
        emotional_state: text(person.emotionalState, 220),
        knowledge: personKnowledge(person, state),
    };
    return [
        'Bạn đang phán đoán một nhân vật cụ thể có chấp nhận lời mời kết bạn liên lạc hay không. Không được chiều theo người dùng, cũng không được ép đồng ý để đẩy tính năng.',
        '玲七 là quản gia mèo nhỏ chuyển lời mời thay cho người dùng hiện tại, chỉ phụ trách chuyển, không cung cấp sự thật mới, cũng không đồng ý thay nhân vật này.',
        'Chỉ phán đoán dựa trên nhận thức, quan hệ, hoàn cảnh, rủi ro và ranh giới hành vi của chính nhân vật đó. Khi nhân vật không quen người gửi lời mời, đang đề phòng, thân phận bất tiện hoặc không có lý do, có thể từ chối hoặc tạm thời không xử lý.',
        'decision chỉ được là accepted, declined, pending. pending nghĩa là tạm thời không xử lý, không có nghĩa là đồng ý. reason là lý do ngắn gọn từ góc nhìn nhân vật, reply là một câu người gửi lời mời có thể thấy; nhân vật có thể không viết reply. reason và reply viết bằng tiếng Việt.',
        'Trả về JSON nghiêm ngặt: {"decision":"accepted|declined|pending","reason":"căn cứ phán định nội bộ","reply":"câu trả lời hiển thị"}',
        `Người gửi lời mời: ${text(userName, 120) || 'Bạn'}. Lời nhắn xác minh: ${text(requestMessage, 300) || '(không điền)'}`,
        `Bằng chứng quan hệ hiện có: ${text(existing?.evidence, 360) || 'không có ghi nhận rõ ràng'}`,
        `Hồ sơ nhân vật: ${JSON.stringify(profile)}`,
    ].join('\n');
}

export function applyFriendDecisionPayload(social, state, personId, payload, {
    requestMessage = '',
} = {}) {
    const people = Array.isArray(state?.people) ? state.people : [];
    const normalized = normalizeSocialState(social, people);
    const id = text(personId, 120);
    if (!people.some(person => String(person?.id || '') === id && !person?.isUser)) throw new Error('Không tìm thấy nhân vật này');
    const decision = ['accepted', 'declined', 'pending'].includes(payload?.decision)
        ? payload.decision
        : 'pending';
    const now = new Date().toISOString();
    const next = normalizedConnection({
        personId: id,
        status: decision,
        source: 'friend-request',
        evidence: 'Người dùng gửi lời mời qua tìm kiếm liên lạc',
        requestMessage,
        decisionReason: text(payload?.reason, 360),
        decisionReply: text(payload?.reply, 300),
        requestedAt: now,
        respondedAt: decision === 'pending' ? '' : now,
        updatedAt: now,
    }, new Set(people.map(person => String(person?.id || ''))));
    normalized.connections = normalized.connections.filter(item => item.personId !== id);
    normalized.connections.unshift(next);
    return {
        social: normalized,
        decision,
        reply: next.decisionReply,
        reason: next.decisionReason,
    };
}

export function buildMomentsPrompt(social, state, { userName = 'Bạn' } = {}) {
    const people = Array.isArray(state?.people) ? state.people : [];
    const normalized = normalizeSocialState(social, people);
    const accepted = new Set(normalized.connections.filter(item => item.status === 'accepted').map(item => item.personId));
    const profiles = people
        .filter(person => accepted.has(String(person?.id || '')) && !person?.isUser)
        .slice(0, 24)
        .map(person => ({
            id: person.id,
            name: person.name,
            personality_anchor: text(person.personalityAnchor, 500),
            speaking_style: text(person.speakingStyle, 320),
            behavior_boundaries: text(person.behaviorBoundaries, 420),
            location: text(person.location, 160),
            action: text(person.action, 240),
            intent: text(person.intent, 240),
            emotional_state: text(person.emotionalState, 180),
            knowledge: personKnowledge(person, state),
            last_post: normalized.moments.filter(moment => moment.personId === String(person.id)).at(-1)?.text || '',
        }));
    if (!profiles.length) throw new Error('Chưa có bạn liên lạc nào có thể xem Khoảnh khắc');
    return [
        'Bạn đang tạo các bài đăng tự nhiên ứng viên cho “世界背面·Khoảnh khắc”. Đây là nội dung xã hội do nhân vật chủ động đăng, không phải lời dẫn, cũng không phải sự thật chính thức của thế giới. Viết bằng tiếng Việt.',
        '玲七 chỉ thu nhận thay người dùng hiện tại những mảnh đời thường được công khai cho bạn bè này, không vì thế mà biết chuyện riêng nhân vật không đăng.',
        'Phán đoán từng người xem lúc này họ có động cơ đăng Khoảnh khắc hay không. Khi bận rộn, thận trọng, không có gì để đăng, thân phận nhạy cảm hoặc không thích đăng bài thì bắt buộc không đăng; lần này cho phép không có bài nào. Tối đa ba bài, cấm ai cũng lần lượt đăng cho có.',
        'Chỉ được dùng knowledge, vị trí hiện tại, hành động và cảm xúc của chính nhân vật; không được tiết lộ bí mật, thông tin toàn cục ở hậu trường hay hình ảnh mà họ không thể chụp được.',
        'Văn phong phải giống chính người đó ngoài đời, đừng viết báo cáo tổng kết. wants_image chỉ là true khi họ thực sự sẽ đăng kèm ảnh và hiện tại có thể chụp/có bức ảnh đó. image_prompt chỉ mô tả hình ảnh họ sẽ đăng, không chứa nội dung nhân vật không biết.',
        'visibility hiện chỉ được là friends. Trả về JSON nghiêm ngặt: {"posts":[{"person_id":"...","text":"...","visibility":"friends","wants_image":true,"image_prompt":"..."}]}',
        `Người xem: ${text(userName, 120) || 'Bạn'}. Phút thế giới: ${Math.max(0, Number(state?.clock?.absoluteMinute) || 0)}。`,
        `Hồ sơ bạn bè: ${JSON.stringify(profiles)}`,
    ].join('\n');
}

export function applyMomentsPayload(social, state, payload) {
    const people = Array.isArray(state?.people) ? state.people : [];
    const normalized = normalizeSocialState(social, people);
    const accepted = new Set(normalized.connections.filter(item => item.status === 'accepted').map(item => item.personId));
    const recentKeys = new Set(normalized.moments.slice(-60).map(item => `${item.personId}\n${item.text}`));
    const worldMinute = Math.max(0, Number(state?.clock?.absoluteMinute) || 0);
    const posts = (Array.isArray(payload?.posts) ? payload.posts : [])
        .map(item => normalizedMoment({
            id: makeId('moment'),
            personId: item?.person_id ?? item?.personId,
            text: item?.text,
            visibility: item?.visibility,
            worldMinute,
            wantsImage: item?.wants_image ?? item?.wantsImage,
            imagePrompt: item?.image_prompt ?? item?.imagePrompt,
        }, new Set(people.map(person => String(person?.id || '')))))
        .filter(item => item && accepted.has(item.personId))
        .filter(item => !recentKeys.has(`${item.personId}\n${item.text}`))
        .slice(0, 3);
    normalized.moments.push(...posts);
    normalized.moments = normalized.moments.slice(-MAX_MOMENTS);
    normalized.momentsUpdatedAt = new Date().toISOString();
    normalized.momentsUpdatedWorldMinute = worldMinute;
    return { social: normalized, posts };
}

export function attachMomentImage(social, state, momentId, { imageUrl = '', error = '' } = {}) {
    const normalized = normalizeSocialState(social, state?.people || []);
    const moment = normalized.moments.find(item => item.id === text(momentId, 160));
    if (!moment) return normalized;
    const candidate = text(imageUrl, MAX_IMAGE_URL_CHARS);
    moment.imageUrl = /^(?:https?:\/\/|data:image\/)/i.test(candidate) ? candidate : '';
    moment.imageError = text(error, 360);
    return normalized;
}

export function toggleMomentLike(social, state, momentId) {
    const normalized = normalizeSocialState(social, state?.people || []);
    const moment = normalized.moments.find(item => item.id === text(momentId, 160));
    if (!moment) return normalized;
    moment.likedByUser = !moment.likedByUser;
    moment.likes = Math.max(0, moment.likes + (moment.likedByUser ? 1 : -1));
    return normalized;
}

export function respondIncomingFriendRequest(social, state, personId, accept) {
    const people = Array.isArray(state?.people) ? state.people : [];
    const normalized = normalizeSocialState(social, people);
    const id = text(personId, 120);
    const connection = normalized.connections.find(item => item.personId === id);
    if (!connection || connection.status !== 'incoming') throw new Error('Lời mời kết bạn này không còn tồn tại');
    connection.status = accept ? 'accepted' : 'declined';
    connection.source = 'incoming-request';
    connection.respondedAt = new Date().toISOString();
    connection.updatedAt = connection.respondedAt;
    connection.decisionReply = accept ? 'Bạn đã chấp nhận lời mời kết bạn của đối phương' : 'Bạn đã từ chối lời mời kết bạn của đối phương';
    const readAt = new Date().toISOString();
    normalized.notices.forEach(notice => {
        if (notice.kind === 'friend_request' && notice.personId === id && !notice.readAt) notice.readAt = readAt;
    });
    return normalized;
}

export function removeSocialFriend(social, state, personId, {
    source = 'user-removed',
    reason = 'Người dùng chủ động xóa bạn',
} = {}) {
    const people = Array.isArray(state?.people) ? state.people : [];
    const normalized = normalizeSocialState(social, people);
    const id = text(personId, 120);
    const connection = normalized.connections.find(item => item.personId === id);
    if (!connection || connection.status !== 'accepted') throw new Error('Đối phương không còn trong danh sách bạn bè');
    const now = new Date().toISOString();
    connection.status = 'removed';
    connection.source = text(source, 60) || 'user-removed';
    connection.decisionReason = text(reason, 360) || 'Người dùng chủ động xóa bạn';
    connection.decisionReply = '';
    connection.respondedAt = now;
    connection.updatedAt = now;
    const direct = normalized.conversations.find(item => item.type === 'direct' && item.memberIds[0] === id);
    if (direct && normalized.activeConversationId === direct.id) normalized.activeConversationId = '';
    return normalized;
}

export function markSocialNoticeRead(social, state, noticeId = '') {
    const normalized = normalizeSocialState(social, state?.people || []);
    const id = text(noticeId, 160);
    const now = new Date().toISOString();
    normalized.notices.forEach(notice => {
        if ((!id || notice.id === id) && !notice.readAt) notice.readAt = now;
    });
    return normalized;
}

export function buildSocialPulsePrompt(social, state, { userName = 'Bạn' } = {}) {
    const people = Array.isArray(state?.people) ? state.people : [];
    const normalized = normalizeSocialState(social, people);
    const byId = new Map(people.map(person => [String(person?.id || ''), person]));
    const candidates = normalized.connections
        .filter(item => ['accepted', 'suggested'].includes(item.status))
        .map(connection => ({ connection, person: byId.get(connection.personId) }))
        .filter(item => item.person && !item.person.isUser)
        .slice(0, 24)
        .map(({ connection, person }) => ({
            id: person.id,
            name: person.name,
            relation_status: connection.status,
            relation_evidence: connection.evidence,
            personality_anchor: text(person.personalityAnchor, 500),
            speaking_style: text(person.speakingStyle, 320),
            behavior_boundaries: text(person.behaviorBoundaries, 420),
            location: text(person.location, 160),
            action: text(person.action, 240),
            intent: text(person.intent, 240),
            emotional_state: text(person.emotionalState, 180),
            knowledge: personKnowledge(person, state),
            recent_messages: normalized.conversations
                .find(conversation => conversation.type === 'direct' && conversation.memberIds[0] === String(person.id))
                ?.rawMessages.slice(-6).map(message => ({ sender: message.senderId, text: message.text })) || [],
        }));
    if (!candidates.length) return '';
    return [
        'Bạn đang thực hiện một lần “nhịp xã hội đời thường” tần suất thấp. Nhân vật không phải nhân viên chăm sóc khách hàng, không được ép hành động để làm giao diện sôi động. Cho phép mọi mảng đều rỗng. Tổng số hành động tối đa hai. Văn bản viết bằng tiếng Việt.',
        '玲七 là quản gia mèo nhỏ trông tin nhắn, chuyển lời thay người dùng hiện tại, không phải đài phát thanh biết tuốt; việc chuyển lời của cô bé không được bù đắp thông tin nhân vật chưa biết.',
        'Bạn bè accepted chỉ được chủ động gửi message khi trong hoàn cảnh hiện tại có động cơ liên lạc cụ thể; không được lặp lại tin nhắn trước, cũng không được tự dưng biết sự thật mới.',
        'Nhân vật suggested chỉ được chủ động gửi friend_request khi bằng chứng quan hệ đủ để họ có kênh biết được phương thức liên lạc, và bản thân họ muốn. Người lạ không thể tự dưng tìm ra người dùng.',
        'Bạn bè accepted cũng có thể remove_friend, nhưng phải có ranh giới rõ ràng phù hợp thiết lập nhân vật, quan hệ xấu đi, rủi ro hoặc lý do thực tế; cấm xóa bạn ngẫu nhiên vì kịch tính.',
        'Bạn bè accepted có thể đăng post, nhưng phải giống Khoảnh khắc thật, tuân thủ kiến thức và quyền riêng tư của chính họ; bận rộn, thận trọng hoặc không có gì thì không đăng.',
        'Trả về JSON nghiêm ngặt: {"messages":[{"person_id":"...","text":"...","reason":"..."}],"friend_requests":[{"person_id":"...","message":"...","reason":"..."}],"remove_friends":[{"person_id":"...","reason":"...","farewell":"lời tạm biệt (không bắt buộc)"}],"posts":[{"person_id":"...","text":"...","visibility":"friends","wants_image":false,"image_prompt":""}]}',
        `Người dùng: ${text(userName, 120) || 'Bạn'}. Phút thế giới: ${Math.max(0, Number(state?.clock?.absoluteMinute) || 0)}。`,
        `Nhân vật ứng viên: ${JSON.stringify(candidates)}`,
    ].join('\n');
}

export function applySocialPulsePayload(social, state, payload) {
    const people = Array.isArray(state?.people) ? state.people : [];
    let normalized = normalizeSocialState(social, people);
    const peopleById = new Map(people.map(person => [String(person?.id || ''), person]));
    const connectionsById = new Map(normalized.connections.map(item => [item.personId, item]));
    const worldMinute = Math.max(0, Number(state?.clock?.absoluteMinute) || 0);
    let remaining = 2;
    let messageCount = 0;
    let requestCount = 0;
    let removalCount = 0;

    for (const raw of (Array.isArray(payload?.messages) ? payload.messages : [])) {
        if (remaining <= 0) break;
        const personId = text(raw?.person_id ?? raw?.personId, 120);
        const body = text(raw?.text, 1600);
        const person = peopleById.get(personId);
        if (!person || !body || connectionsById.get(personId)?.status !== 'accepted') continue;
        let conversation = normalized.conversations.find(item => item.type === 'direct' && item.memberIds[0] === personId);
        if (!conversation) {
            conversation = normalizedConversation({
                id: `direct-${personId}`,
                type: 'direct',
                title: person.name,
                memberIds: [personId],
            });
            normalized.conversations.unshift(conversation);
        }
        const last = conversation.rawMessages.at(-1);
        if (last?.senderId === personId && last?.text === body) continue;
        conversation.rawMessages.push(normalizedMessage({
            senderId: personId,
            senderName: person.name,
            text: body,
            worldMinute,
        }));
        conversation.rawMessages = conversation.rawMessages.slice(-MAX_MESSAGES);
        conversation.updatedAt = new Date().toISOString();
        normalized.notices.push(normalizedNotice({
            kind: 'message',
            personId,
            conversationId: conversation.id,
            text: body,
        }, new Set(peopleById.keys())));
        messageCount += 1;
        remaining -= 1;
    }

    for (const raw of (Array.isArray(payload?.friend_requests) ? payload.friend_requests : [])) {
        if (remaining <= 0) break;
        const personId = text(raw?.person_id ?? raw?.personId, 120);
        const connection = connectionsById.get(personId);
        if (!connection || connection.status !== 'suggested' || !peopleById.has(personId)) continue;
        connection.status = 'incoming';
        connection.source = 'proactive-request';
        connection.requestMessage = text(raw?.message, 300);
        connection.decisionReason = text(raw?.reason, 360);
        connection.requestedAt = new Date().toISOString();
        connection.updatedAt = connection.requestedAt;
        normalized.notices.push(normalizedNotice({
            kind: 'friend_request',
            personId,
            text: connection.requestMessage || `${peopleById.get(personId)?.name || 'Một nhân vật'} muốn kết bạn với bạn`,
        }, new Set(peopleById.keys())));
        requestCount += 1;
        remaining -= 1;
    }

    for (const raw of (Array.isArray(payload?.remove_friends) ? payload.remove_friends : [])) {
        if (remaining <= 0) break;
        const personId = text(raw?.person_id ?? raw?.personId, 120);
        const connection = connectionsById.get(personId);
        if (!connection || connection.status !== 'accepted' || !peopleById.has(personId)) continue;
        connection.status = 'removed';
        connection.source = 'character-boundary';
        connection.decisionReason = text(raw?.reason, 360);
        connection.decisionReply = text(raw?.farewell, 300);
        connection.respondedAt = new Date().toISOString();
        connection.updatedAt = connection.respondedAt;
        const direct = normalized.conversations.find(item => item.type === 'direct' && item.memberIds[0] === personId);
        if (direct && normalized.activeConversationId === direct.id) normalized.activeConversationId = '';
        normalized.notices.push(normalizedNotice({
            kind: 'friend_removed',
            personId,
            text: connection.decisionReply || connection.decisionReason || 'Đối phương đã kết thúc quan hệ bạn bè',
        }, new Set(peopleById.keys())));
        removalCount += 1;
        remaining -= 1;
    }

    let momentCount = 0;
    if (remaining > 0 && Array.isArray(payload?.posts) && payload.posts.length) {
        const applied = applyMomentsPayload(normalized, state, { posts: payload.posts.slice(0, remaining) });
        normalized = applied.social;
        momentCount = applied.posts.length;
    }
    normalized.notices = normalized.notices.filter(Boolean).slice(-MAX_NOTICES);
    return { social: normalized, messageCount, requestCount, removalCount, momentCount };
}

export function openDirectConversation(social, person, people = []) {
    const normalized = normalizeSocialState(social, people);
    const personId = text(person?.id, 120);
    if (!personId || person?.isUser) throw new Error('Nhân vật này không thể tham gia hội thoại xã hội');
    if (!normalized.connections.some(item => item.personId === personId && item.status === 'accepted')) {
        throw new Error('Đối phương chưa phải bạn liên lạc của bạn');
    }
    let conversation = normalized.conversations.find(item => (
        item.type === 'direct' && item.memberIds[0] === personId
    ));
    if (!conversation) {
        conversation = normalizedConversation({
            id: `direct-${personId}`,
            type: 'direct',
            title: text(person.name, 120) || 'Nhân vật không rõ',
            memberIds: [personId],
        });
        normalized.conversations.unshift(conversation);
    } else {
        conversation.title = text(person.name, 120) || conversation.title;
    }
    normalized.activeConversationId = conversation.id;
    return normalized;
}

export function createGroupConversation(social, { title = '', memberIds = [] } = {}, people = []) {
    const normalized = normalizeSocialState(social, people);
    const peopleById = new Map((Array.isArray(people) ? people : []).map(person => [String(person?.id || ''), person]));
    const accepted = new Set(normalized.connections.filter(item => item.status === 'accepted').map(item => item.personId));
    const members = [...new Set(memberIds.map(id => text(id, 120)))]
        .filter(id => id && accepted.has(id) && peopleById.has(id) && !peopleById.get(id)?.isUser)
        .slice(0, 24);
    if (members.length < 2) throw new Error('Tạo nhóm cần chọn ít nhất hai nhân vật');
    const fallbackTitle = members.slice(0, 3).map(id => peopleById.get(id)?.name).filter(Boolean).join('、');
    const conversation = normalizedConversation({
        id: makeId('group'),
        type: 'group',
        title: text(title, 120) || fallbackTitle || 'Nhóm chat mới',
        memberIds: members,
    });
    normalized.conversations.unshift(conversation);
    normalized.activeConversationId = conversation.id;
    return normalized;
}

export function selectSocialConversation(social, conversationId, people = []) {
    const normalized = normalizeSocialState(social, people);
    const id = text(conversationId, 160);
    const accepted = new Set(normalized.connections.filter(item => item.status === 'accepted').map(item => item.personId));
    const conversation = normalized.conversations.find(item => item.id === id);
    const available = conversation && (
        conversation.type === 'group'
        || accepted.has(conversation.memberIds[0])
    );
    if (available) normalized.activeConversationId = id;
    return normalized;
}

export function appendUserSocialMessage(social, conversationId, body, worldMinute = 0, people = []) {
    const normalized = normalizeSocialState(social, people);
    const conversation = normalized.conversations.find(item => item.id === text(conversationId, 160));
    const content = text(body, 1600);
    if (!conversation) throw new Error('Không tìm thấy cuộc trò chuyện này');
    if (!content) throw new Error('Vui lòng nhập nội dung cần gửi trước');
    if (conversation.type === 'direct') {
        const connection = normalized.connections.find(item => item.personId === conversation.memberIds[0]);
        if (connection?.status !== 'accepted') throw new Error('Hai bạn không còn là bạn liên lạc, không thể tiếp tục chat riêng');
    }
    conversation.rawMessages.push(normalizedMessage({
        id: makeId('social-message'),
        senderId: 'user',
        senderName: 'Bạn',
        text: content,
        worldMinute,
    }));
    conversation.rawMessages = conversation.rawMessages.slice(-MAX_MESSAGES);
    conversation.lastError = '';
    conversation.updatedAt = new Date().toISOString();
    normalized.activeConversationId = conversation.id;
    return normalized;
}

function personKnowledge(person, state) {
    const knownEventIds = new Set(Array.isArray(person?.knownEventIds) ? person.knownEventIds.map(String) : []);
    const knownClueIds = new Set(Array.isArray(person?.knownClueIds) ? person.knownClueIds.map(String) : []);
    return {
        events: (Array.isArray(state?.events) ? state.events : [])
            .filter(event => knownEventIds.has(String(event?.id || '')))
            .slice(-12)
            .map(event => ({
                id: event.id,
                title: text(event.title, 160),
                description: text(event.description, 500),
                state: text(event.state, 80),
            })),
        clues: (Array.isArray(state?.storyMemory?.clues) ? state.storyMemory.clues : [])
            .filter(clue => knownClueIds.has(String(clue?.id || '')))
            .slice(-12)
            .map(clue => ({ id: clue.id, text: text(clue.text ?? clue.value, 420) })),
        beliefs: (Array.isArray(person?.knownFactBeliefs) ? person.knownFactBeliefs : []).slice(-16),
    };
}

export function buildSocialReplyPrompt(social, state, conversationId, { userName = 'Bạn' } = {}) {
    const normalized = normalizeSocialState(social, state?.people || []);
    const conversation = normalized.conversations.find(item => item.id === text(conversationId, 160));
    if (!conversation) throw new Error('Không tìm thấy hội thoại cần tạo trả lời');
    const peopleById = new Map((state?.people || []).map(person => [String(person?.id || ''), person]));
    const members = conversation.memberIds.map(id => peopleById.get(id)).filter(Boolean);
    const participantProfiles = members.map(person => ({
        id: person.id,
        name: person.name,
        identity_anchor: text(person.identityAnchor, 500),
        personality_anchor: text(person.personalityAnchor, 600),
        background_profile: text(person.backgroundProfile, 900),
        speaking_style: text(person.speakingStyle, 360),
        behavior_boundaries: text(person.behaviorBoundaries, 500),
        location: text(person.location, 180),
        action: text(person.action, 260),
        intent: text(person.intent, 260),
        emotional_state: text(person.emotionalState, 220),
        knowledge: personKnowledge(person, state),
    }));
    const history = conversation.rawMessages.slice(-24).map(message => ({
        sender_id: message.senderId,
        sender_name: message.senderId === 'user' ? text(userName, 120) || 'Bạn' : message.senderName,
        text: message.text,
        world_minute: message.worldMinute,
    }));
    return [
        'Bạn đang thực hiện định tuyến trả lời “世界背面·Mạng xã hội tích hợp”. Đây là một lớp ghi chép xã hội độc lập, không phải chính văn, cũng sẽ không tự động trở thành sự thật chính thức của thế giới. Tin nhắn trả lời viết bằng tiếng Việt.',
        '玲七 chỉ phụ trách đưa lời của người dùng hiện tại tới nơi, rồi mang về những lời đối phương muốn nói; cô bé không trả lời thay nhân vật, cũng sẽ không nhét kiến thức hậu trường cho nhân vật.',
        'Bắt buộc tuân thủ nghiêm ngặt:',
        '1. Chỉ thành viên hội thoại mới được trả lời; không được thêm người qua đường, lời dẫn hay thông báo hệ thống.',
        '2. Với từng thành viên, lần lượt phán đoán saw (có thấy tin nhắn này không), knows (có đủ kiến thức để trả lời không), willing (có muốn trả lời không). Chỉ cần một cái là false thì giữ im lặng.',
        '3. Cho phép không ai trả lời; trong nhóm chat không được vì cho đủ mặt mà để mọi người lần lượt nói, tối đa ba người trả lời. Chat riêng tối đa một người trả lời.',
        '4. Chỉ được dùng knowledge của chính nhân vật đó và lịch sử hội thoại. Sự thật thế giới không có trong knowledge của họ thì không được vì bạn thấy hồ sơ của người khác mà để họ biết.',
        '5. Câu trả lời phải tiếp nối nhân cách, cách dùng từ, nhịp điệu và ranh giới của nhân vật cụ thể; đừng biến nhãn tính cách thành văn phong chung chung.',
        '6. Không được tuyên bố cuộc chat đã thay đổi hiện thực thế giới; lời hứa, quyết định, gặp mặt… chỉ là nội dung hội thoại, trừ khi sau đó được quy trình thế giới chính thức kết toán.',
        'Chỉ trả về JSON nghiêm ngặt, không dùng Markdown:',
        '{"routing":[{"person_id":"...","saw":true,"knows":true,"willing":true,"outcome":"speak|silent","reason":"lý do ngắn gọn"}],"replies":[{"person_id":"...","text":"lời nhân vật gửi"}]}',
        `Loại hội thoại: ${conversation.type === 'group' ? 'Nhóm chat' : 'Chat riêng'}. Phút thế giới: ${Math.max(0, Number(state?.clock?.absoluteMinute) || 0)}。`,
        `Hồ sơ thành viên: ${JSON.stringify(participantProfiles)}`,
        `Bản ghi gốc của hội thoại: ${JSON.stringify(history)}`,
    ].join('\n');
}

export function applySocialReplyPayload(social, conversationId, payload, state) {
    const normalized = normalizeSocialState(social, state?.people || []);
    const conversation = normalized.conversations.find(item => item.id === text(conversationId, 160));
    if (!conversation) throw new Error('Không tìm thấy cuộc trò chuyện này');
    const peopleById = new Map((state?.people || []).map(person => [String(person?.id || ''), person]));
    const allowed = new Set(conversation.memberIds);
    const routing = (Array.isArray(payload?.routing) ? payload.routing : [])
        .map(item => ({
            personId: text(item?.person_id ?? item?.personId, 120),
            saw: Boolean(item?.saw),
            knows: Boolean(item?.knows),
            willing: Boolean(item?.willing),
            outcome: item?.outcome === 'speak' ? 'speak' : 'silent',
            reason: text(item?.reason, 220),
        }))
        .filter(item => allowed.has(item.personId));
    const routingById = new Map(routing.map(item => [item.personId, item]));
    const replyLimit = conversation.type === 'group' ? 3 : 1;
    const seenReplyIds = new Set();
    const replies = (Array.isArray(payload?.replies) ? payload.replies : [])
        .map(item => ({ personId: text(item?.person_id ?? item?.personId, 120), text: text(item?.text, 1600) }))
        .filter(item => {
            const route = routingById.get(item.personId);
            if (!item.text || !allowed.has(item.personId) || seenReplyIds.has(item.personId)) return false;
            if (!route || !route.saw || !route.knows || !route.willing || route.outcome !== 'speak') return false;
            seenReplyIds.add(item.personId);
            return true;
        })
        .slice(0, replyLimit);
    const worldMinute = Math.max(0, Number(state?.clock?.absoluteMinute) || 0);
    for (const reply of replies) {
        const person = peopleById.get(reply.personId);
        if (!person) continue;
        conversation.rawMessages.push(normalizedMessage({
            id: makeId('social-message'),
            senderId: reply.personId,
            senderName: person.name,
            text: reply.text,
            worldMinute,
        }));
    }
    conversation.rawMessages = conversation.rawMessages.slice(-MAX_MESSAGES);
    conversation.lastRouting = { at: new Date().toISOString(), evaluations: routing };
    conversation.lastError = '';
    conversation.updatedAt = new Date().toISOString();
    normalized.activeConversationId = conversation.id;
    return { social: normalized, replyCount: replies.length };
}

export function setSocialConversationError(social, conversationId, error, people = []) {
    const normalized = normalizeSocialState(social, people);
    const conversation = normalized.conversations.find(item => item.id === text(conversationId, 160));
    if (conversation) conversation.lastError = text(error?.message || error, 500);
    return normalized;
}
