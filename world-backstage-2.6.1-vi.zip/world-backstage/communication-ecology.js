const PATCH_KEY = Symbol.for('world_backstage.communication_ecology.v1');
const MODULE_ID = 'world_backstage';
const STATE_KEY = 'world_backstage_v1';

const SOCIAL_MARKERS = [
    '世界背面·Mạng xã hội tích hợp',
    'lời mời kết bạn liên lạc',
    'lời mời kết bạn',
    '世界背面·Khoảnh khắc',
    'nhịp xã hội đời thường',
    'friend_requests',
    'remove_friends',
    '世界背面·内置社交',
    '通讯好友申请',
    '好友申请',
    '世界背面·朋友圈',
    '生活社交脉冲',
];

const SCORE_RULES = Object.freeze({
    modern: [
        [/手机|智能机|电话|短信|微信|QQ|聊天软件|即时通讯|社交平台|社交媒体|互联网|网络账号|邮箱|电子邮件|APP|直播|视频通话|điện thoại|smartphone|tin nhắn|wechat|zalo|messenger|ứng dụng chat|ứng dụng nhắn tin|nhắn tin|nền tảng mạng xã hội|mạng xã hội|internet|tài khoản mạng|email|hộp thư|thư điện tử|livestream|phát trực tiếp|gọi video/giu, 6],
        [/现代|都市|公司|办公室|大学|高中|医院|警局|商场|地铁|出租车|网吧|电脑|摄影棚|经纪公司|hiện đại|đô thị|thành phố|công ty|văn phòng|đại học|trường cấp ba|bệnh viện|đồn cảnh sát|sở cảnh sát|trung tâm thương mại|tàu điện ngầm|taxi|quán net|máy tính|trường quay|studio/giu, 1],
    ],
    historical: [
        [/古代|王朝|朝廷|皇帝|皇后|太后|王爷|公主|驸马|宫廷|王府|县衙|驿站|驿传|飞鸽|书信|家书|拜帖|名帖|信使|口信|传话|奏折|邸报|cổ đại|vương triều|triều đình|hoàng đế|hoàng hậu|thái hậu|vương gia|công chúa|phò mã|cung đình|vương phủ|huyện nha|nha môn|dịch trạm|trạm dịch|bồ câu đưa thư|thư nhà|bái thiếp|danh thiếp bái phỏng|sứ giả|tín sứ|người đưa tin|truyền lời|tấu chương|tấu sớ|để báo/giu, 5],
        [/江湖|门派|掌门|少侠|侠客|客栈|镖局|科举|官府|太守|知府|县令|侍卫|内侍|宫女|giang hồ|môn phái|chưởng môn|thiếu hiệp|hiệp khách|khách điếm|tiêu cục|khoa cử|quan phủ|thái thú|tri phủ|huyện lệnh|thị vệ|nội thị|thái giám|cung nữ/giu, 2],
    ],
    scifi: [
        [/星际|星舰|宇宙航行|太空站|殖民星|跃迁|曲率|量子通讯|光脑|终端|全息通讯|通讯器|舰载频道|神经接口|赛博|网络空间|星网|liên sao|giữa các vì sao|tinh hạm|du hành vũ trụ|trạm không gian|trạm vũ trụ|hành tinh thuộc địa|bước nhảy không gian|nhảy không gian|warp|liên lạc lượng tử|quang não|thiết bị đầu cuối|liên lạc toàn ảnh|hologram|máy liên lạc|kênh của hạm|giao diện thần kinh|cyber|không gian mạng|tinh võng|mạng liên sao/giu, 6],
        [/飞船|舰桥|机甲|人工智能|仿生人|殖民地|轨道站|phi thuyền|tàu vũ trụ|đài chỉ huy|mecha|cơ giáp|trí tuệ nhân tạo|người máy sinh học|android|thuộc địa|trạm quỹ đạo/giu, 2],
    ],
    lowtech: [
        [/原始社会|史前|荒岛|孤岛求生|与世隔绝|无通讯|无法通讯|通讯中断|断网|失联|无线电静默|荒野求生|xã hội nguyên thủy|tiền sử|đảo hoang|sinh tồn trên đảo|cô lập với thế giới|biệt lập với thế giới|không có liên lạc|không thể liên lạc|liên lạc bị gián đoạn|gián đoạn liên lạc|mất kết nối mạng|mất sóng|mất liên lạc|im lặng vô tuyến|sinh tồn nơi hoang dã/giu, 7],
    ],
    supernatural: [
        [/魔法|魔力|法术|巫术|术式|灵力|灵气|修仙|仙门|神术|异能|超能力|咒术|魔导|炼金|使魔|精灵|妖怪|神明|phép thuật|ma thuật|ma pháp|ma lực|pháp thuật|vu thuật|phù thủy|thuật thức|linh lực|linh khí|tu tiên|tiên môn|thần thuật|dị năng|siêu năng lực|chú thuật|ma đạo|giả kim|luyện kim|sứ ma|tinh linh|yêu quái|thần linh/giu, 2],
        [/传讯术|传音|传音入密|神识传音|念话|心灵感应|通讯魔法|通讯水晶|魔法水晶|传讯水晶|灵符传讯|符箓传讯|飞剑传书|使魔传信|魔法信件|thuật truyền tin|truyền tin thuật|truyền âm|truyền âm nhập mật|thần thức truyền âm|niệm thoại|thần giao cách cảm|phép liên lạc|ma pháp liên lạc|pha lê liên lạc|thủy tinh liên lạc|pha lê ma thuật|thủy tinh ma thuật|pha lê truyền tin|linh phù truyền tin|bùa truyền tin|phù lục truyền tin|phi kiếm truyền thư|sứ ma đưa thư|thư ma thuật|thư phép thuật/giu, 8],
    ],
});

function cleanText(value, maximum = 4000) {
    return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, maximum);
}

function scoreText(source, rules) {
    let score = 0;
    for (const [pattern, weight] of rules) {
        pattern.lastIndex = 0;
        const matches = source.match(pattern);
        if (matches?.length) score += Math.min(4, matches.length) * weight;
    }
    return score;
}

function selectedWorldEvidence(state = {}, store = null) {
    const people = Array.isArray(state?.people) ? state.people : [];
    const events = Array.isArray(state?.events) ? state.events : [];
    const facts = Array.isArray(state?.storyMemory?.facts) ? state.storyMemory.facts : [];
    const summaries = Array.isArray(state?.storyMemory?.summaries) ? state.storyMemory.summaries : [];
    const clues = Array.isArray(state?.storyMemory?.clues) ? state.storyMemory.clues : [];

    const parts = [
        state?.worldBackground,
        state?.worldSetting,
        state?.setting,
        state?.background,
        state?.summary,
        state?.location,
        store?.initialState?.worldBackground,
        store?.initialState?.worldSetting,
        store?.initialState?.setting,
        ...people.slice(0, 48).flatMap(person => [
            person?.identityAnchor,
            person?.backgroundProfile,
            person?.worldbookRaw,
            person?.location,
            person?.action,
            person?.intent,
        ]),
        ...events.slice(-36).map(item => JSON.stringify(item)),
        ...facts.slice(-48).map(item => JSON.stringify(item)),
        ...summaries.slice(-24).map(item => JSON.stringify(item)),
        ...clues.slice(-24).map(item => JSON.stringify(item)),
    ];

    let output = '';
    for (const value of parts) {
        if (value == null) continue;
        const chunk = cleanText(typeof value === 'string' ? value : JSON.stringify(value), 5000);
        if (!chunk) continue;
        output += `${chunk}\n`;
        if (output.length >= 48000) break;
    }
    return output.slice(0, 48000);
}

function technologyProfile(scores) {
    const ordered = [
        ['scifi', scores.scifi],
        ['historical', scores.historical],
        ['modern', scores.modern],
        ['lowtech', scores.lowtech],
    ].sort((a, b) => b[1] - a[1]);
    const [winner, winnerScore] = ordered[0];
    const secondScore = ordered[1][1];

    if (winnerScore <= 1) return { technology: 'unknown', confidence: 'low' };
    if (winnerScore === secondScore && winnerScore < 8) return { technology: 'unknown', confidence: 'low' };
    return {
        technology: winner,
        confidence: winnerScore >= secondScore + 6 || winnerScore >= 12 ? 'high' : 'medium',
    };
}

function labelsFor(technology, supernatural) {
    const base = {
        modern: {
            privateChannel: 'Nhắn tin tức thời, điện thoại, SMS hoặc phương thức liên lạc hiện đại đã được xác nhận trong thế giới',
            publicChannel: 'Nền tảng mạng xã hội, bài đăng công khai hoặc mạng công khai đã được xác nhận trong thế giới',
            contactConcept: 'Thông tin liên lạc / người liên hệ',
            delivery: 'Thường có thể gửi đến tức thì, nhưng vẫn chịu ảnh hưởng của việc ngoại tuyến, bị chặn, mạng và ý muốn của nhân vật',
            realtime: 'usually',
            publicStream: 'usually',
            groupChannel: 'usually',
        },
        historical: {
            privateChannel: 'Thư từ, lời nhắn miệng, sứ giả, trạm dịch, thiếp bái kiến hoặc phương thức hợp lý khác của thời đại',
            publicChannel: 'Các kênh công khai thực sự tồn tại như cáo thị, để báo (công báo triều đình), thiếp thơ, tin tức từ yến tiệc, truyền miệng chốn phố chợ',
            contactConcept: 'Kênh qua lại ổn định / mối quan hệ có thể nhờ người nhắn hộ',
            delivery: 'Mặc định không tức thì; phải tính đến khoảng cách, sứ giả, đường trạm, thân phận và thời gian đưa đến',
            realtime: 'rare',
            publicStream: 'conditional',
            groupChannel: 'conditional',
        },
        scifi: {
            privateChannel: 'Thiết bị đầu cuối, máy liên lạc, kênh nội bộ phi thuyền, mạng liên sao hoặc phương thức liên lạc tương lai đã được xác nhận trong thế giới',
            publicChannel: 'Kênh công cộng, mạng liên sao, phát thanh hoặc mạng thông tin công khai đã được xác nhận trong thế giới',
            contactConcept: 'Quyền liên lạc / nút liên lạc',
            delivery: 'Liên lạc cục bộ có thể tức thì; liên lạc xuyên khu vực, xuyên tinh hệ có bị trễ hay không phải tuân theo quy tắc thế giới',
            realtime: 'conditional',
            publicStream: 'usually',
            groupChannel: 'usually',
        },
        lowtech: {
            privateChannel: 'Nói chuyện trực tiếp, nhờ người nhắn hộ, ký hiệu, mảnh giấy hoặc phương thức kỹ thuật thấp thực sự khả dụng trong môi trường',
            publicChannel: 'Tụ họp, cáo thị, truyền miệng…; không tồn tại thì đừng cố tạo ra',
            contactConcept: 'Mối quan hệ có thể tiếp xúc / có thể nhờ người tìm được',
            delivery: 'Mặc định không tức thì; không có con đường thực tế thì coi như tạm thời không thể gửi đến',
            realtime: 'rare',
            publicStream: 'rare',
            groupChannel: 'rare',
        },
        unknown: {
            privateChannel: 'Chỉ dùng các phương thức liên lạc mà thiết lập thế giới đã chứng minh là tồn tại',
            publicChannel: 'Chỉ dùng các kênh truyền bá công khai mà thiết lập thế giới đã chứng minh là tồn tại',
            contactConcept: 'mối quan hệ có thể liên lạc',
            delivery: 'Không rõ; không được mặc định có điện thoại thông minh, internet, liên lạc bằng phép thuật hay phương tiện nào khác chưa được chứng minh',
            realtime: 'unknown',
            publicStream: 'unknown',
            groupChannel: 'unknown',
        },
    }[technology] || null;

    if (!supernatural) return base;
    return {
        ...base,
        privateChannel: `${base.privateChannel}; nếu thiết lập ghi rõ có truyền tin thuật, truyền âm, sứ ma (familiar), thủy tinh liên lạc…, thì cũng có thể dùng, nhưng tuyệt đối không được chỉ vì “đây là thế giới phép thuật” mà tự tạo ra năng lực liên lạc từ xa`,
        delivery: `${base.delivery}; khoảng cách, thời gian, tiêu hao, quyền hạn và quy tắc chặn của liên lạc siêu nhiên cũng phải tuân theo thiết lập sẵn có`,
    };
}

export function inferCommunicationEcology(state = {}, store = null) {
    const evidence = selectedWorldEvidence(state, store);
    const scores = {
        modern: scoreText(evidence, SCORE_RULES.modern),
        historical: scoreText(evidence, SCORE_RULES.historical),
        scifi: scoreText(evidence, SCORE_RULES.scifi),
        lowtech: scoreText(evidence, SCORE_RULES.lowtech),
        supernatural: scoreText(evidence, SCORE_RULES.supernatural),
    };
    const tech = technologyProfile(scores);
    const supernatural = scores.supernatural >= 4;
    const labels = labelsFor(tech.technology, supernatural);

    return {
        schemaVersion: 1,
        technology: tech.technology,
        supernatural,
        confidence: tech.confidence,
        ...labels,
        scores,
    };
}

function currentStore(context = null) {
    let resolved = context;
    if (!resolved) {
        try {
            resolved = globalThis.SillyTavern?.getContext?.() || null;
        } catch {
            resolved = null;
        }
    }
    return resolved?.chatMetadata?.[STATE_KEY] || null;
}

function currentState(store) {
    return store?.currentState || store?.initialState || {};
}

function pendingPrivateMessages(store, state) {
    const social = store?.social;
    const conversations = Array.isArray(social?.conversations) ? social.conversations : [];
    const people = new Map((Array.isArray(state?.people) ? state.people : []).map(person => [String(person?.id || ''), person]));
    const now = Math.max(0, Number(state?.clock?.absoluteMinute) || 0);
    const pending = [];

    for (const conversation of conversations) {
        if (conversation?.type !== 'direct' || !Array.isArray(conversation.rawMessages)) continue;
        const messages = conversation.rawMessages;
        let lastUserIndex = -1;
        for (let index = messages.length - 1; index >= 0; index -= 1) {
            if (messages[index]?.senderId === 'user') {
                lastUserIndex = index;
                break;
            }
        }
        if (lastUserIndex < 0) continue;
        const hasLaterReply = messages.slice(lastUserIndex + 1).some(message => message?.senderId !== 'user');
        if (hasLaterReply) continue;
        const message = messages[lastUserIndex];
        const personId = String(conversation.memberIds?.[0] || '');
        const person = people.get(personId);
        const sentAt = Math.max(0, Number(message?.worldMinute) || 0);
        pending.push({
            conversation_id: String(conversation.id || ''),
            person_id: personId,
            person_name: cleanText(person?.name, 120),
            person_location: cleanText(person?.location, 180),
            sent_world_minute: sentAt,
            elapsed_world_minutes: Math.max(0, now - sentAt),
            text: cleanText(message?.text, 500),
        });
    }
    return pending.slice(0, 12);
}

export function communicationEcologyInstruction(ecology, { store = null, state = null } = {}) {
    const activeState = state || currentState(store);
    const pending = pendingPrivateMessages(store, activeState);
    const internalFieldNote = [
        'Ghi chú trường tương thích: các trường accepted / pending / friend_request / remove_friend / posts / group… trong dữ liệu social chỉ là tên giao thức nội bộ.',
        'Chúng không chứng minh thế giới này có “lời mời kết bạn, Khoảnh khắc, lượt thích, nhóm chat, điện thoại hay internet”. Trừ khi sự thật thế giới hỗ trợ rõ ràng, văn bản mà nhân vật nhìn thấy cấm bê nguyên các từ sản phẩm hiện đại này.',
        'friend_request nên hiểu là “thử thiết lập kênh liên lạc ổn định”; remove_friend nên hiểu là “ngừng hoặc cắt đứt kênh liên lạc đó”; posts nên hiểu là “nội dung nhân vật chủ động truyền bá công khai hoặc bán công khai”.',
    ].join('\n');

    return [
        '<world_backstage_communication_ecology>',
        'Hệ thống liên lạc phải tuân theo chính thế giới hiện tại, chứ không phải bắt thế giới tuân theo UI của plugin. “Liên lạc” trong chính văn và UI chỉ là lối vào để quan sát.',
        `Suy đoán hệ sinh thái công nghệ hiện tại: ${ecology.technology}${ecology.supernatural ? ' + yếu tố siêu nhiên' : ''} (độ tin cậy: ${ecology.confidence}）。`,
        `Liên lạc riêng tư chỉ được dùng: ${ecology.privateChannel}。`,
        `Truyền bá công khai chỉ được dùng: ${ecology.publicChannel}。`,
        `“Người liên hệ” trong thế giới nên được hiểu là: ${ecology.contactConcept}。`,
        `Quy tắc chuyển đến: ${ecology.delivery}。`,
        internalFieldNote,
        'Cách ly tri thức: nền biết nội dung tin nhắn không có nghĩa là nhân vật đã nhận được. saw phải biểu thị tin nhắn đã thực sự đến nơi qua kênh hợp lý và được nhân vật đó nhìn thấy; knows vẫn chỉ biểu thị nhân vật có tri thức để trả lời hay không.',
        'Nếu phương tiện hiện tại không thể gửi đến tức thì, tin nhắn vừa gửi trong lượt này phải giữ saw=false, không được vì “trải nghiệm trò chuyện” mà trả lời ngay lập tức. Về sau, khi thời gian thế giới trôi đi và điều kiện chuyển đến thực tế được đáp ứng, nhịp xã hội có thể xử lý tự nhiên các hồi âm đến muộn.',
        'Nếu trong thế giới hoàn toàn không có con đường liên lạc từ xa/gián tiếp hợp lý, cho phép lượt này hoàn toàn không có hồi âm, không có bài đăng công khai, không có liên lạc mới; đừng vì muốn tính năng trông sôi động mà phát minh ra công nghệ liên lạc hay phép thuật.',
        pending.length ? `Các tin nhắn riêng tư hiện vẫn đang chờ thực sự chuyển đến/hồi đáp: ${JSON.stringify(pending)}` : 'Hiện không phát hiện tin nhắn riêng tư nào đang chờ hồi đáp.',
        '</world_backstage_communication_ecology>',
    ].join('\n');
}

function isSocialPrompt(value, depth = 0) {
    if (depth > 7 || value == null) return false;
    if (typeof value === 'string') return SOCIAL_MARKERS.some(marker => value.includes(marker));
    if (Array.isArray(value)) return value.some(item => isSocialPrompt(item, depth + 1));
    if (typeof value !== 'object') return false;
    return Object.values(value).some(item => isSocialPrompt(item, depth + 1));
}

function prependInstructionToMessages(messages, instruction) {
    if (!Array.isArray(messages)) return messages;
    const next = messages.map(message => ({ ...message }));
    const systemIndex = next.findIndex(message => String(message?.role || '').toLowerCase() === 'system');
    if (systemIndex >= 0) {
        next[systemIndex] = {
            ...next[systemIndex],
            content: `${instruction}\n\n${String(next[systemIndex]?.content || '')}`,
        };
    } else {
        next.unshift({ role: 'system', content: instruction });
    }
    return next;
}

export function adaptSocialPromptPayload(payload, context = null) {
    if (!payload || typeof payload !== 'object' || !isSocialPrompt(payload?.messages)) return payload;
    const store = currentStore(context);
    if (!store) return payload;
    const state = currentState(store);
    const ecology = inferCommunicationEcology(state, store);
    const instruction = communicationEcologyInstruction(ecology, { store, state });
    store.communicationEcology = {
        ...ecology,
        updatedAt: new Date().toISOString(),
    };
    return {
        ...payload,
        messages: prependInstructionToMessages(payload.messages, instruction),
    };
}

function adaptGenerateRawOptions(options, context) {
    if (!options || !isSocialPrompt(options.prompt)) return options;
    const store = currentStore(context);
    if (!store) return options;
    const state = currentState(store);
    const ecology = inferCommunicationEcology(state, store);
    const instruction = communicationEcologyInstruction(ecology, { store, state });
    store.communicationEcology = {
        ...ecology,
        updatedAt: new Date().toISOString(),
    };
    if (Array.isArray(options.prompt)) {
        return {
            ...options,
            prompt: prependInstructionToMessages(options.prompt, instruction),
        };
    }
    return {
        ...options,
        prompt: `${instruction}\n\n${String(options.prompt || '')}`,
    };
}

function installFetchPolicy() {
    const originalFetch = globalThis.fetch;
    if (typeof originalFetch !== 'function' || originalFetch[PATCH_KEY]) return false;

    const wrappedFetch = async function worldBackstageCommunicationFetch(input, init) {
        if (typeof init?.body !== 'string') return originalFetch.call(this, input, init);
        let payload;
        try {
            payload = JSON.parse(init.body);
        } catch {
            return originalFetch.call(this, input, init);
        }
        if (!isSocialPrompt(payload?.messages)) return originalFetch.call(this, input, init);
        const adapted = adaptSocialPromptPayload(payload);
        if (adapted === payload) return originalFetch.call(this, input, init);
        return originalFetch.call(this, input, {
            ...init,
            body: JSON.stringify(adapted),
        });
    };
    Object.defineProperty(wrappedFetch, PATCH_KEY, { value: true, enumerable: false });
    globalThis.fetch = wrappedFetch;
    return true;
}

function installGenerateRawPolicy() {
    const tavern = globalThis.SillyTavern;
    const originalGetContext = tavern?.getContext;
    if (typeof originalGetContext !== 'function' || originalGetContext[PATCH_KEY]) return false;
    const cache = new WeakMap();

    const wrappedGetContext = function worldBackstageCommunicationGetContext(...args) {
        const context = originalGetContext.apply(this, args);
        const raw = context?.generateRaw;
        if (!context || typeof raw !== 'function' || raw[PATCH_KEY]) return context;
        let wrapped = cache.get(raw);
        if (!wrapped) {
            wrapped = function worldBackstageCommunicationGenerateRaw(options = {}) {
                return raw.call(context, adaptGenerateRawOptions(options, context));
            };
            Object.defineProperty(wrapped, PATCH_KEY, { value: true, enumerable: false });
            cache.set(raw, wrapped);
        }
        try {
            context.generateRaw = wrapped;
            return context;
        } catch {
            return new Proxy(context, {
                get(target, property, receiver) {
                    if (property === 'generateRaw') return wrapped;
                    return Reflect.get(target, property, receiver);
                },
            });
        }
    };
    Object.defineProperty(wrappedGetContext, PATCH_KEY, { value: true, enumerable: false });
    tavern.getContext = wrappedGetContext;
    return true;
}

function install() {
    installFetchPolicy();
    if (installGenerateRawPolicy()) return;
    let attempts = 0;
    const timer = globalThis.setInterval(() => {
        attempts += 1;
        if (installGenerateRawPolicy() || attempts >= 40) globalThis.clearInterval(timer);
    }, 250);
}

if (globalThis.SillyTavern || globalThis.document) install();
