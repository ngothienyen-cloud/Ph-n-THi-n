import './storage-guard.js';
import './mobile-character-search-scroll.js';
import './mobile-ui-polish.js';
import './ui-hotfix.js';
import './token-budget-policy.js';
import './communication-ecology.js';
import './communication-voice-guard.js';
import './observation-scene-overlap.js';
import './settings-persistence-guard.js';
import './social-notice-stability.js?v=3';
import './auto-hide-settings-ui.js?v=1';
import './index.js';
import './phone-bridge-host.js?v=2';
import './phone-feed-host.js?v=3';

void import('./update-manager.js?v=2')
    .then(() => import('./update-session-refresh.js?v=1'))
    .catch(error => {
        console.error('[世界背面] Tải trình quản lý kiểm tra cập nhật thất bại', error);
    });

void import('./social-friend-request-fix.js?v=2').catch(error => {
    console.error('[世界背面] Tải bản sửa trạng thái lời mời kết bạn thất bại', error);
});

void import('./presentation-polish.js?v=251')
    .then(() => Promise.all([
        import('./social-responsive-adapter.js?v=1'),
        import('./settings-responsive-adapter.js?v=1'),
        import('./tablet-responsive-adapter.js?v=1'),
        import('./mobile-news-discussion.js?v=1'),
    ]))
    .then(() => import('./tablet-height-guard.js?v=4'))
    .then(() => import('./tablet-clock-polish.js?v=1'))
    .catch(error => {
        console.error('[世界背面] Tải lớp hiển thị thích ứng thất bại', error);
    });

void import('./orb-motion-randomizer.js?v=8').catch(error => {
    console.error('[世界背面] Tải hiệu ứng sống động của bóng nổi thất bại', error);
});

void import('./community-note.js?v=3').catch(error => {
    console.error('[世界背面] Tải Mảnh giấy nhỏ của mẹ thất bại', error);
});

void import('./community-note-entry-fix.js?v=1').catch(error => {
    console.error('[世界背面] Tải lối vào thường trực của Mảnh giấy nhỏ của mẹ thất bại', error);
});

void import('./lingqi-greeting.js?v=2').catch(error => {
    console.error('[世界背面] Tải lời chào thường trực của 玲七 thất bại', error);
});

void import('./history-parallel-lab-runtime.js?v=2').catch(error => {
    console.error('[世界背面] Tải phòng thí nghiệm lịch sử song song thất bại', error);
});