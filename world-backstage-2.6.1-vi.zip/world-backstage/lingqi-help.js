import { LINGQI_ACTION_TYPES } from './lingqi-skills.js';

const HELP_TOPICS = [
    {
        id: 'world-backstage-concept',
        title: '世界背面 là gì',
        keywords: ['世界背面', 'nền', 'chính văn', 'ống kính', 'chạy', 'không chèn', 'không tồn tại'],
        text: '世界背面 (Thế Giới Phía Sau) chính là trạng thái hậu trường của bản thân thế giới câu chuyện này, còn chính văn chỉ là ống kính hiện tại. Một module không chèn vào chính văn không có nghĩa là nó không tồn tại hay đã ngừng chạy; nhân vật, sự kiện, ký ức, dư luận vẫn tiếp tục được lưu và phát triển.',
    },
    {
        id: 'simulation',
        title: 'Suy diễn thế giới và dừng lại',
        keywords: ['Suy diễn', 'dừng suy diễn', 'tạm dừng', 'tự động suy diễn', 'suy diễn thủ công', 'không suy diễn', 'chưa suy diễn'],
        text: '“Suy diễn thế giới” xử lý các thay đổi trạng thái thế giới sau chính văn; “Dừng suy diễn” chỉ dừng lượt suy diễn thế giới đang chạy. “Dừng mọi tác vụ nền” sẽ dừng luôn cả sắp xếp ký ức, truy hồi lịch sử, dư luận, quan sát, sửa lỗi và các suy diễn thế giới đang xếp hàng. Nếu tác vụ nền như sắp xếp ký ức đang chạy, vẫn có thể bấm “Suy diễn thế giới”, nhưng nó sẽ xếp hàng an toàn trước, đợi tác vụ hiện tại xong rồi mới bắt đầu, không ghi trạng thái thế giới song song. Dừng tác vụ chưa xong sẽ không hoàn tác dữ liệu đã được lưu thành công.',
    },
    {
        id: 'narrative-sync-status',
        title: 'Chính văn mới nhất đã được suy diễn chưa',
        keywords: ['chính văn mới nhất', 'chấm vàng', 'chấm vàng nhỏ', 'chờ suy diễn', 'suy diễn xong', 'xếp hàng', 'bong bóng', 'cửa sổ bật lên'],
        text: 'Chỉ khi tin nhắn hiện tại, nhánh vuốt (swipe), dấu vân tay nội dung chính văn và ảnh chụp đã lưu đều khớp nhau thì chính văn mới nhất mới được coi là đã suy diễn. Thanh trạng thái chính, trang Lúc này, bóng nổi và 玲七 đều đọc cùng một kết quả. Chấm vàng nghĩa là chính văn đang chờ suy diễn, bị lỗi hoặc cần xử lý; chấm nhỏ màu chủ đề chỉ có nghĩa là thế giới có thay đổi mới mà bạn chưa xem.',
    },
    {
        id: 'injection',
        title: 'Chèn vào chính văn',
        keywords: ['chèn', 'Chèn vào chính văn', 'chèn nhân vật', 'chèn sự thật', 'chèn tiếng vọng', 'chèn ký ức', 'Chèn dư luận', 'chèn liên lạc', 'trò chuyện ảnh hưởng chính văn', 'điểm neo thời gian'],
        text: 'Chèn vào chính văn chỉ quyết định những thông tin hậu trường nào được đưa cho model chính văn xem, không điều khiển việc module nền tương ứng có chạy hay không. Khi tắt công tắc tổng, phần nền vẫn tiếp tục lưu và vận hành. Liên lạc mặc định không ảnh hưởng chính văn; khi bật riêng cũng chỉ được dùng làm tham khảo dạng “bản ghi liên lạc chưa kết toán”, các lời hứa, kế hoạch trong chat sẽ không bị coi là đã xảy ra. Chèn thời gian có ba mức “Đầy đủ / Điểm neo tối thiểu / Tắt”; Điểm neo tối thiểu chỉ có nhiệm vụ ngăn thời gian lùi lại hay nhảy loạn mà không có nhân quả.',
    },
    {
        id: 'player-recording',
        title: 'Ghi nhận nhân vật người chơi',
        keywords: ['nhân vật người chơi', 'user', 'ghi nhận người chơi', 'đừng ghi nhận tôi', 'ghi nhận tôi', 'nội tâm người chơi', 'inner_voice'],
        text: 'Khi bật “Ghi nhận nhân vật người chơi”, chỉ lưu vị trí, hành động và trạng thái khách quan của user đã xảy ra rõ ràng trong chính văn; khi tắt, user sẽ không vào mục Nhân vật hay suy diễn nhân vật nền. Dù công tắc thế nào, hành động đã xảy ra trong chính văn vẫn là sự thật của thế giới. Plugin không lưu và cũng không viết thay inner_voice của người chơi.',
    },
    {
        id: 'people',
        title: 'Nhân vật và suy diễn nhân vật nền',
        keywords: ['Nhân vật', 'npc', 'vai', 'không động đậy', 'suy diễn nhân vật', 'nhân vật nền', 'simulationEnabled', 'tăng cường nhân vật nền'],
        text: 'Mục Nhân vật lưu trạng thái hậu trường hiện tại của các nhân vật. Từng nhân vật có thể tắt suy diễn nền riêng; “Tăng cường suy diễn nhân vật nền” dùng để cho nhiều nhân vật ngoài ống kính hơn được kết toán theo thời gian thế giới, không có nghĩa là mỗi lượt đều gửi riêng một request API cho từng người.',
    },
    {
        id: 'currents-echoes',
        title: 'Mạch ngầm & Tiếng vọng',
        keywords: ['Mạch ngầm', 'Tiếng vọng', 'Sự kiện', 'sao lại có tiếng vọng', 'xóa tiếng vọng', 'Biên niên'],
        text: 'Mạch ngầm là các sự kiện nền đang hình thành hoặc đang chờ điều kiện; Tiếng vọng là bản ghi những gì đã xảy ra và để lại hậu quả, dấu vết hoặc kết quả có thể chuyển giao. Khi xóa/sửa lỗi cần phân biệt phần phái sinh chưa xảy ra với lịch sử chính văn đã thật sự xảy ra: phần sau không được để hậu trường lén viết lại.',
    },
    {
        id: 'memory',
        title: 'Ký ức',
        keywords: ['Ký ức', 'sắp xếp ký ức', 'quét lịch sử', 'Truy hồi lịch sử', 'nhớ sai', 'ký ức dài hạn', 'memory'],
        text: 'Hệ thống ký ức sẽ sắp xếp sự thật dài hạn, manh mối và tóm tắt phân tầng. Sắp xếp ký ức thông thường lưu theo từng đợt, lỗi thì tiếp tục từ vị trí thành công lần trước; truy hồi lịch sử đầy đủ của “Tham gia giữa chừng” cũng lưu điểm ngắt an toàn theo từng đợt, nhưng chỉ khi tất cả thành công mới lưu thế giới tạm vào một lần, điểm ngắt không ghi đè thế giới chính thức. Tắt “Chèn ký ức” chỉ là không đưa ký ức cho chính văn, tắt “Hệ thống ký ức” mới dừng tác vụ ký ức. Đầu ra chạm length là giới hạn Token, không phải hết thời gian chờ; nên đặt giới hạn Token “Lịch sử / Ký ức” về 0 (tự động) hoặc tăng lên hợp lý.',
    },
    {
        id: 'public-opinion',
        title: 'Dư luận & tin tức',
        keywords: ['Dư luận', 'tin tức', 'diễn đàn', 'sao không có tin tức', 'tin tức không cập nhật', 'thông tin công cộng', 'public'],
        text: 'Dư luận được thúc đẩy bởi thời gian thế giới và các sự kiện thật sự công khai/lan truyền, không phải cứ mỗi lượt chat là bắt buộc cập nhật. “Đi tuần một vòng và làm mới” của V2.3 sẽ, khi nâng cấp lần đầu, khi thời gian thế giới trôi ít nhất ba giờ hoặc khi trọng tâm thế giới tùy chỉnh thay đổi, kiểm tra luân phiên thế giới công cộng ngoài ống kính trước; cùng một thời điểm thế giới với cùng một trọng tâm sẽ không tuần tra lặp lại. Các ảnh hưởng khách quan như thời tiết, giao thông, thông báo do tin tức tạo ra sẽ được nối lại vào nhận thức nhân vật và chính văn về sau, nhưng người không có kênh tiếp nhận sẽ không tự động biết hết. Tắt chèn dư luận chỉ là không đưa vào chính văn, không có nghĩa là dư luận ngừng chạy.',
    },
    {
        id: 'worldbook',
        title: 'Nhập nhân vật từ World Info',
        keywords: ['World Info', 'nhập nhân vật', 'mvu', 'biến', 'nhập một chạm', 'nhận diện nhân vật'],
        text: 'Nhập nhân vật từ World Info mặc định có thể nhận diện nhân vật thông minh bằng một cú bấm, sẽ bỏ qua các mục kỹ thuật như MVU, biến, script, JSONPatch, regex; khi nhân vật và thế lực viết chung một mục thì sẽ thử tách nhân vật ra. Các ứng viên chưa chắc chắn sẽ để lại cho phần chọn thủ công nâng cao.',
    },
    {
        id: 'cache-reset',
        title: 'Xóa cache & đặt lại',
        keywords: ['xóa cache', 'cache', 'đặt lại', 'xóa sạch', 'điểm khôi phục', 'thử lại từ đầu', 'dọn dữ liệu'],
        text: '“Dọn cache của chat hiện tại” chỉ dọn cache có thể dựng lại và tác vụ tạm thời, không động vào nhân vật, sự kiện, ký ức, đồng hồ thế giới và API. “Đặt lại dữ liệu chat hiện tại” sẽ đưa 世界背面 của chat hiện tại về trống trơn, đồng thời xóa điểm khôi phục/ảnh chụp nhánh để tránh dữ liệu cũ đội mồ sống dậy; chính văn của chat và cấu hình API sẽ không bị xóa.',
    },
    {
        id: 'fact-correction',
        title: 'Sửa lỗi sự thật',
        keywords: ['sửa lỗi', 'nhớ sai', 'lỗi', 'đã kết hôn', 'ly hôn', 'mâu thuẫn sự thật', 'sai một bước hỏng cả chuỗi', 'kiểm tra trạng thái thế giới'],
        text: 'Thứ tự ưu tiên sự thật đại khái là: người dùng/duy trì thủ công > sự thật nêu rõ trong chính văn > kết quả sự kiện đã kết toán > suy luận AI thông thường. Sự thật ổn định về thân phận/quan hệ không được để suy luận nền lật ngược mà không có nhân quả. “Kiểm tra và sửa trạng thái thế giới” chỉ sửa lỗi nền có bằng chứng rõ ràng, không thể tua ngược chính văn đã thật sự xảy ra.',
    },
    {
        id: 'api',
        title: 'API, 200, 429 và lỗi',
        keywords: ['api', '200', '401', '429', 'unauthorized', 'giới hạn tốc độ', 'API', 'Model', 'trả về rỗng', 'kết nối thất bại', 'báo lỗi'],
        text: 'HTTP 200 chỉ cho thấy tầng truyền tải có thể đã thành công, không đảm bảo model thật sự trả về completion hợp lệ; một số proxy trung gian sẽ dùng 200 để bọc nội dung Unauthorized/error. 429 là bị giới hạn tốc độ, plugin sẽ giữ thời gian chờ hồi thật thay vì coi nó là cache bẩn mà xóa đi. Khi gỡ lỗi nên xem cùng lúc transportStatus, upstreamStatus, errorSummary, model hiện tại và định tuyến tác vụ.',
    },
    {
        id: 'tokens-timeout',
        title: 'Token & quá thời gian',
        keywords: ['token', '16000', '64000', 'giới hạn', 'đầu ra tối đa', 'quá thời gian', 'timeout'],
        text: 'Khi giới hạn Token toàn cục và của module bằng 0 nghĩa là tự động/kế thừa; số dương là giới hạn đầu ra thật sự. Khi module Suy diễn thế giới để 0 để kế thừa toàn cục, lượt đầu sẽ lấy thẳng giá trị toàn cục người dùng đặt làm giới hạn khả dụng, không còn thu nhỏ trước về mức cũ 4.6K / 6.4K; max_tokens chỉ là ceiling, model viết xong vẫn tự dừng. Các tác vụ nhỏ như quan sát nhân vật, lịch sử/ký ức và dư luận vẫn chạy theo ngân sách riêng. Nếu suy diễn thế giới trả về JSON chưa đóng và bị xác định là output-limit, thì nhân vật, sự kiện, ký ức và thời gian thế giới của lượt này đều không được lưu, nên tăng giới hạn Token của Suy diễn thế giới hoặc toàn cục trước rồi thử lại. Plugin cũng không được lén ép giá trị lớn hơn mà người dùng đã điền về mức cũ 16000.',
    },
    {
        id: 'mama',
        title: 'Mẹ ở đâu',
        keywords: ['mẹ', 'tìm mẹ', 'mẹ đâu', 'Mẹ ở đâu', 'cộng đồng cá nhân', 'cộng đồng', '玲', '小玲七的妈妈', 'ai làm ra'],
        text: '玲七 biết mẹ của mình tên là “玲”, chữ ký trên mảnh giấy là “\u5c0f玲七\u7684\u5988\u5988·玲”. Mẹ đang đợi mọi người ở cộng đồng riêng của mẹ; khi người dùng muốn tìm mẹ, báo bug, hỏi cách dùng hoặc ước có tính năng mới, có thể vào thẳng https://discord.gg/3tdTAy2Fr, cũng có thể bấm “Mảnh giấy nhỏ của mẹ” trong trang 玲七 rồi nhấn “Đi tìm mẹ”. Khi được hỏi “mẹ ở đâu/làm sao tìm mẹ” thì phải nói thẳng chuyện này, đừng bịa những câu không có căn cứ kiểu “mẹ ở ngoài màn hình”, “có lẽ mẹ đang bận”, “玲七 không chạm tới mẹ được”, cũng đừng bịa ra địa chỉ ngoài đời thật.',
    },
    {
        id: 'lingqi',
        title: '玲七',
        keywords: ['玲七', 'mèo con', 'mảnh giấy', 'đạo diễn', 'quản gia nhỏ', 'hỏi mèo'],
        text: '玲七 là mèo quản gia nhỏ có sẵn trong plugin: có thể trò chuyện, giải thích plugin, báo cáo tổng quan thế giới, tra cứu nhân vật/Mạch ngầm/ký ức/cài đặt và quan hệ liên lạc, chẩn đoán suy diễn và nhân vật bị đứng yên, tìm kiếm hoặc quản lý lịch sử trò chuyện của chính mình, sau khi xác nhận thì gửi tin nhắn hộ, xử lý lời mời kết bạn, làm mới Khoảnh khắc, cũng có thể dịch “đoạn tiếp theo muốn chơi thế nào” thành giấy nhắn đạo diễn. 玲七 biết người tạo ra mình và 世界背面 là mẹ “玲”, khi cần tìm mẹ có thể vào cộng đồng riêng https://discord.gg/3tdTAy2Fr. Trước khi thật sự gửi, hủy quan hệ hoặc xóa trò chuyện đều sẽ hiện hộp xác nhận trước; xóa trò chuyện với 玲七 mặc định không xóa ký ức dài hạn. Bản thân trò chuyện với 玲七 không phải sự thật của thế giới, phỏng đoán của người dùng sẽ không tự động được ghi vào nhân vật hay trạng thái thế giới.',
    },
];

function normalize(value) {
    return String(value ?? '').trim().toLocaleLowerCase();
}

export function selectLingqiHelpEntries(query, maximum = 6) {
    const text = normalize(query);
    if (!text) return HELP_TOPICS.slice(0, Math.max(1, maximum));
    return HELP_TOPICS
        .map(topic => {
            let score = 0;
            for (const keyword of topic.keywords) {
                const key = normalize(keyword);
                if (!key) continue;
                if (text.includes(key)) score += Math.max(2, Math.min(10, key.length + 1));
            }
            if (text.includes(normalize(topic.title))) score += 12;
            return { topic, score };
        })
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score || a.topic.title.localeCompare(b.topic.title, 'zh-CN'))
        .slice(0, Math.max(1, maximum))
        .map(item => item.topic);
}

export function buildLingqiHelpContext(query, pluginVersion = '') {
    const topics = selectLingqiHelpEntries(query, 6);
    const lines = [
        `Phiên bản plugin hiện tại: ${String(pluginVersion || 'Không rõ')}`,
        'Dưới đây là kiến thức trợ giúp có sẵn của phiên bản hiện tại. Chỉ được coi những mô tả chức năng được viết rõ ở đây là quy tắc plugin đã biết; những gì không được viết đến và cũng không nhìn ra được từ trạng thái hiện tại thì đừng tự bịa thêm thiết lập.',
    ];
    for (const topic of topics) {
        lines.push(`- ${topic.title}：${topic.text}`);
    }
    return lines.join('\n');
}

export function normalizeLingqiButlerActions(value) {
    const source = Array.isArray(value) ? value : [];
    return source
        .slice(0, 8)
        .map(raw => {
            if (!raw || typeof raw !== 'object') return null;
            const type = String(raw.type || '').trim();
            if (!LINGQI_ACTION_TYPES.has(type)) return null;
            if (type === 'update_setting') {
                return {
                    type,
                    setting: String(raw.setting || raw.key || '').trim().slice(0, 80),
                    value: raw.value,
                };
            }
            if (type === 'set_person_simulation') {
                return {
                    type,
                    personId: String(raw.person_id ?? raw.personId ?? '').trim().slice(0, 120),
                    personName: String(raw.person_name ?? raw.personName ?? '').trim().slice(0, 100),
                    enabled: Boolean(raw.enabled),
                };
            }
            if (['prioritize_person', 'catch_up_person'].includes(type)) {
                return {
                    type,
                    personId: String(raw.person_id ?? raw.personId ?? '').trim().slice(0, 120),
                    personName: String(raw.person_name ?? raw.personName ?? '').trim().slice(0, 100),
                    enabled: type === 'prioritize_person' ? raw.enabled !== false : true,
                };
            }
            if (['social_send_message', 'social_accept_request', 'social_refuse_request', 'social_remove_friend'].includes(type)) {
                return {
                    type,
                    personId: String(raw.person_id ?? raw.personId ?? '').trim().slice(0, 120),
                    personName: String(raw.person_name ?? raw.personName ?? '').trim().slice(0, 100),
                    text: type === 'social_send_message'
                        ? String(raw.text ?? raw.message ?? '').trim().slice(0, 1600)
                        : '',
                };
            }
            if (type === 'delete_lingqi_chat') {
                const requestedMode = String(raw.mode || '').trim().toLowerCase();
                const mode = [
                    'all',
                    'recent',
                    'between',
                    'before',
                    'after',
                    'day',
                    'topic',
                ].includes(requestedMode) ? requestedMode : 'topic';
                return {
                    type,
                    mode,
                    count: Math.min(800, Math.max(1, Number.parseInt(raw.count, 10) || 1)),
                    startQuery: String(raw.start_query ?? raw.startQuery ?? '').trim().slice(0, 240),
                    endQuery: String(raw.end_query ?? raw.endQuery ?? '').trim().slice(0, 240),
                    query: String(raw.query ?? raw.topic ?? '').trim().slice(0, 240),
                    day: ['today', 'yesterday', 'day_before_yesterday'].includes(String(raw.day || '').trim().toLowerCase())
                        ? String(raw.day || '').trim().toLowerCase()
                        : '',
                };
            }
            return { type };
        })
        .filter(Boolean);
}

export const LINGQI_BUTLER_TOOL_HELP = [
    'Các hành động rủi ro thấp có thể làm hộ chỉ gồm những việc sau:',
    '1. update_setting: sửa các công tắc/giá trị liệt kê có thể đảo ngược trên bảng điều khiển. setting chỉ được là: worldSimulationEnabled / worldPromptInjection / injectionTimeMode / injectionWorldBackground / injectionPeople / injectionEvents / injectionEchoes / injectionFacts / injectionMemory / injectionPublicOpinion / injectionSocial / socialAutoEnabled / memorySystemEnabled / worldAutoEnabled / publicOpinionAutoEnabled / recordPlayerCharacter / enhancedBackgroundSimulation. Không được đụng vào API Key, URL, model, sự thật cốt lõi của nhân vật, xóa/đặt lại.',
    '2. set_person_simulation: bật/tắt suy diễn nền của một nhân vật cụ thể. Bắt buộc phải đưa person_id hoặc tên chính xác; không tìm thấy/trùng tên thì đừng đoán.',
    '3. cancel_simulation: chỉ dừng lượt suy diễn thế giới hiện tại.',
    '4. cancel_background_tasks: dừng mọi tác vụ nền chưa hoàn thành.',
    '5. check_world_state: khi người dùng yêu cầu rõ ràng kiểm tra/sửa lỗi sự thật, gọi quy trình sửa lỗi sự thật hiện có.',
    '6. organize_memory: khi người dùng yêu cầu rõ ràng “sắp xếp ký ức/sắp xếp lại ký ức chút”, khởi động việc sắp xếp ký ức dài hạn hiện có; đây không phải “dựng lại lịch sử thế giới”, đừng nhập nhằng hai việc này.',
    '7. simulate_latest: chỉ dùng khi người dùng yêu cầu rõ ràng suy diễn chính văn mới nhất; khi đã theo kịp thì không được ép chạy lại. Sẽ gọi suy diễn thế giới, plugin bắt buộc phải xác nhận với người dùng trước.',
    '8. refresh_public_world: chỉ dùng khi người dùng yêu cầu rõ ràng “đi tuần một vòng/làm mới dư luận thế giới”; dùng lại cơ chế tuần tra thế giới công cộng hiện có, quy tắc ba giờ và khử trùng lặp cùng thời điểm. Sẽ gọi model nền, plugin bắt buộc phải xác nhận với người dùng trước.',
    '9. prioritize_person: cho một nhân vật cụ thể được ưu tiên trong lượt kết toán nền tiếp theo; không gọi API ngay. Bắt buộc phải đưa person_id hoặc tên chính xác, không tìm thấy/trùng tên thì đừng đoán.',
    '10. catch_up_person: cập nhật ngay tình hình gần đây một lần cho một nhân vật cụ thể, dùng lại cơ chế suy diễn bù nhân vật hiện có. Sẽ gọi model nền, plugin bắt buộc phải xác nhận với người dùng trước.',
    '11. delete_lingqi_chat: chỉ quản lý “lịch sử trò chuyện giữa 玲七 và chính người dùng”, không xóa chính văn của thế giới, không xóa trạng thái thế giới, không xóa nhân vật/sự kiện, và mặc định cũng không động vào ký ức dài hạn 玲七 đã hình thành. Chỉ dùng khi người dùng yêu cầu rõ ràng xóa trò chuyện với 玲七; hỗ trợ mode=all / recent / between / before / after / day / topic. between dùng start_query + end_query; before/after dùng query; topic dùng query; recent dùng count; day dùng today / yesterday / day_before_yesterday. Plugin sẽ định vị bản ghi thực tế ở máy cục bộ trước rồi hiện phạm vi xóa, số tin và xem trước tin đầu/cuối, người dùng xác nhận thêm lần nữa thì mới thật sự xóa. Không tìm thấy hoặc có điểm mơ hồ rõ ràng thì đừng đoán.',
    '12. social_send_message: dùng khi người dùng yêu cầu rõ ràng gửi một nội dung chữ cụ thể cho một bạn liên lạc hiện có; bắt buộc phải đưa nhân vật chính xác và text, plugin sẽ xem trước và xác nhận rồi mới gửi.',
    '13. social_accept_request / social_refuse_request: chỉ xử lý lời mời kết bạn chủ động đang thật sự tồn tại; bắt buộc phải đưa nhân vật chính xác, plugin sẽ xác nhận.',
    '14. social_remove_friend: xóa một bạn liên lạc hiện có; chỉ hủy quan hệ và giữ lại lịch sử/nhóm chat chung, plugin sẽ xác nhận, không được nói rằng lịch sử trò chuyện cũng đã bị xóa.',
    '15. social_refresh_moments: dùng khi người dùng yêu cầu rõ ràng xem Khoảnh khắc mới; sẽ gọi model nền, nếu bật tạo ảnh thì có thể phát sinh thêm một lần phí tạo ảnh, plugin sẽ xác nhận.',
    'Các hành động này do plugin thực hiện cục bộ. reply đừng tuyên bố trước là “đã sửa thành công”; có thể nói “để mình làm/mình đi xem thử”, kết quả thành công thật sự sẽ được plugin bổ sung vào sau câu trả lời.',
].join('\n');

export const LINGQI_SAFE_SETTING_KEYS = Object.freeze({
    worldSimulationEnabled: 'boolean',
    worldPromptInjection: 'boolean',
    injectionTimeMode: 'enum:full,anchor,off',
    injectionWorldBackground: 'boolean',
    injectionPeople: 'boolean',
    injectionEvents: 'boolean',
    injectionEchoes: 'boolean',
    injectionFacts: 'boolean',
    injectionMemory: 'boolean',
    injectionPublicOpinion: 'boolean',
    injectionSocial: 'boolean',
    socialAutoEnabled: 'boolean',
    memorySystemEnabled: 'boolean',
    worldAutoEnabled: 'boolean',
    publicOpinionAutoEnabled: 'boolean',
    recordPlayerCharacter: 'boolean',
    enhancedBackgroundSimulation: 'boolean',
});

export function isKnownLingqiHelpQuestion(query) {
    return selectLingqiHelpEntries(query, 1).length > 0;
}
