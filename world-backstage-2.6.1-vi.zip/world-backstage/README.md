# 世界背面

> **Bản dịch tiếng Việt không chính thức** của 世界背面 / World Backstage 2.6.1, dựa trên phiên bản gốc của tác giả **玲** (Trung Quốc). Dự án gốc: https://github.com/h675786161-prog/world-backstage — mọi bản quyền thuộc về tác giả. Bản dịch được thực hiện và chia sẻ phi thương mại trong cộng đồng SillyTavern Việt Nam với sự cho phép của tác giả; giữ nguyên tên tác giả, tên dự án, liên kết gốc và các dấu tác giả/watermark. Muốn đăng lại ở nền tảng khác, chỉnh sửa thêm chức năng hoặc phát hành dưới hình thức khác, cần hỏi lại tác giả.

> **Ngoài ống kính, thế giới vẫn tiếp diễn.**

**World Backstage / 世界背面 (Thế Giới Phía Sau)** là một extension quản lý trạng thái thế giới và tính liên tục dài hạn, được thiết kế cho SillyTavern.  
Phần truyện chính lo thể hiện câu chuyện ngay trước mắt, còn 世界背面 lo duy trì thời gian, nhân vật, sự kiện, nhận thức, ký ức và nhân quả vẫn đang tồn tại bên ngoài ống kính.

Phiên bản hiện tại: 2.6.1.
`main` đã hợp nhất bản cập nhật ngày 2026-09-25 gồm **đọc lại trí nhớ dài hạn** và **tự động ẩn các tầng đã lưu trữ**. Tự động ẩn mặc định tắt.

[📖 Hướng dẫn sử dụng](docs/USER-GUIDE.md) · [🧾 Nhật ký cập nhật](CHANGELOG.md) · [🧪 Danh sách kiểm thử](docs/TEST-CHECKLIST.md) · [🧱 Tài liệu kiến trúc](docs/ARCHITECTURE.md)

Liên kết điện thoại: đi kèm điện thoại mini 0.3.0-alpha.28, hỗ trợ lời mời kết bạn, nhắn tin riêng, nhắn tin nhóm, đánh dấu đã đọc và thao tác trên bảng tin bạn bè (Moments); gọi điện và tin nhắn SMS ở chế độ thế giới tạm thời chưa hỗ trợ gọi hay gửi/nhận. Xem [hướng dẫn điện thoại đi kèm](docs/PHONE-PAIRING.md).

---

## Nó làm gì

世界背面 duy trì **chính trạng thái của thế giới**, chứ không phải chỉ chèn thêm vài câu prompt kiểu “hãy nhớ những gì ở trên” cho mô hình.

- **Thời gian thế giới chính**: quản lý thống nhất thời gian hiện tại của thế giới và tiến độ các sự kiện.
- **Trạng thái nhân vật**: ghi lại vị trí, hành động, ý định, giới hạn nhận thức và trạng thái hậu trường.
- **Mạch ngầm và Tiếng vọng**: giúp sự kiện có nguyên nhân, diễn biến, kết quả và ảnh hưởng về sau.
- **Trí nhớ dài hạn**: sắp xếp đoạn chat dài thành tóm tắt từng tầng, trải nghiệm liên tục, sự thật dài hạn và các chi tiết cài cắm (foreshadowing).
- **Đọc lại cốt truyện**: khi cần nhớ lại các giao ước, ám hiệu, vật bàn giao hay thứ tự hành động từ sớm, ưu tiên tìm lại ký ức của đúng các tầng cũ tương ứng.
- **Tự động ẩn tầng cũ**: chỉ khi đã có ký ức từng tầng bao phủ thì mới ẩn phần nội dung cũ hơn khỏi ngữ cảnh của mô hình; lịch sử chat vẫn được giữ nguyên.
- **Dư luận và lan truyền trong thế giới**: tin tức, diễn đàn, tin nhắn và con đường nhân vật biết được thông tin đều tuân theo chuỗi lan truyền thực tế.
- **Liên lạc và quản gia 玲七**: dùng lại những nhân vật và trạng thái thật sự tồn tại trong thế giới, không dựng thêm một bộ dữ liệu thứ hai mâu thuẫn lẫn nhau.

Tóm lại một câu:

> **Phần truyện chính là ống kính, 世界背面 là thế giới vẫn tồn tại bên ngoài ống kính.**

---

## Cài đặt

### Cài đặt từ GitHub

1. Mở trang quản lý extension của SillyTavern.
2. Chọn “Install extension” (Cài đặt extension).
3. Dán:

```text
https://github.com/h675786161-prog/world-backstage
```

4. Sau khi cài xong, tải lại SillyTavern.
5. Bật “世界背面” trong phần cài đặt extension, hoặc bấm vào quả cầu thế giới ở góc dưới bên phải trang.

Sau này có thể tiếp tục cập nhật từ trang quản lý extension của SillyTavern.

### Cài đặt thủ công

Tải file ZIP từ GitHub Releases, giải nén vào:

```text
SillyTavern/data/<你的用户目录>/extensions/world-backstage/
```

(`<你的用户目录>` = thư mục người dùng của bạn.)

Thư mục cuối cùng phải trực tiếp chứa:

```text
world-backstage/manifest.json
world-backstage/index.js
world-backstage/style.css
```

Nếu thấy `world-backstage/world-backstage/manifest.json` thì nghĩa là bạn đã lồng thừa một lớp thư mục.

---

## Lần đầu sử dụng

Nên làm theo thứ tự sau:

1. Mở quả cầu thế giới ở góc dưới bên phải.
2. Chọn cách kết nối: theo Tavern hiện tại, cấu hình đã lưu trong Tavern, hoặc API độc lập.
3. Hiệu chỉnh lịch và thời gian của thế giới chính.
4. Với đoạn chat dài cũ, trước tiên hãy chạy một lần “Tạo hồ sơ ký ức ban đầu”.
5. Giữ bật tính năng chèn trí nhớ dài hạn.
6. Chat bình thường, để 世界背面 dần dần sắp xếp nội dung và duy trì trạng thái thế giới.
7. Sau khi xác nhận trí nhớ đã ổn định, mới quyết định có bật “Tự động ẩn các tầng đã lưu trữ” hay không.

Các bước đầy đủ và giải thích từng công tắc xem tại **[Hướng dẫn sử dụng](docs/USER-GUIDE.md)**.

---

## Trí nhớ dài hạn và tự động ẩn

Phần này là trọng tâm sau đợt hợp nhất ngày 2026-09-25.

### Đọc lại trí nhớ dài hạn

世界背面 sẽ tạo tóm tắt L0 cho từng tầng nội dung của user / assistant, rồi tổng hợp tiếp lên thành trải nghiệm liên tục và tóm tắt theo giai đoạn.

Khi phần truyện chính cần thông tin cũ, hệ thống sẽ ưu tiên gọi lại đúng các tầng liên quan. Những nội dung như mở đầu, lần gặp đầu tiên, ám hiệu, mật khẩu, đồ vật bàn giao, nhịp gõ cửa, thứ tự hành động trước sau… sẽ được cố gắng tìm lại từ đúng ký ức gốc tương ứng, thay vì chỉ dựa vào một bản tổng kết lớn chung chung.

### Tự động ẩn các tầng đã lưu trữ

Công tắc này mặc định tắt.

Khi bật:

- Chỉ ẩn những nội dung cũ đã được ký ức từng tầng bao phủ một cách đáng tin cậy;
- Luôn giữ lại **5 tầng** đã lưu trữ gần nhất;
- Mọi tầng chưa được lưu trữ hoặc thiếu L0 vẫn tiếp tục hiển thị;
- Dùng cơ chế ẩn gốc của SillyTavern, chỉ loại khỏi ngữ cảnh của mô hình, không xóa chat;
- Nội dung người dùng tự `/hide` thủ công sẽ không bị 世界背面 khôi phục;
- Khi tắt tự động ẩn, hệ thống ký ức, chèn trí nhớ dài hạn hoặc tắt chính 世界背面, các tầng do 世界背面 tự ẩn sẽ được khôi phục.

Hành vi chi tiết, cách khôi phục và xử lý sự cố xem tại **[Hướng dẫn sử dụng → Trí nhớ dài hạn và tự động ẩn](docs/USER-GUIDE.md#7-trí-nhớ-dài-hạn-và-tự-động-ẩn)**.

---

## Dữ liệu và an toàn

- Trạng thái thế giới được lưu trong metadata của đoạn chat hiện tại.
- Snapshot nhánh của mỗi AI swipe được lưu trong `extra` của tin nhắn tương ứng.
- Tóm tắt liên tục, sự thật dài hạn, trải nghiệm theo giai đoạn, chi tiết cài cắm và tiến độ sắp xếp được lưu theo đoạn chat hiện tại.
- Cấu hình API độc lập được lưu trong cài đặt extension SillyTavern trên máy, không nằm trong file xuất trạng thái thế giới.
- Đầu ra của mô hình chỉ được coi là ứng viên; lỗi, phản hồi rỗng và bị cắt cụt sẽ không khiến trạng thái thế giới tiến lên vô cớ.
- Tự động ẩn không xóa tin nhắn; sau khi tắt có thể khôi phục các tầng do 世界背面 tự động ẩn.

Nên xuất một bản sao lưu trạng thái thế giới trước khi thay đổi lớn cài đặt, quay ngược dài hạn hoặc chuyển thiết bị.

---

## Kiểm chứng

Dự án dùng môi trường SillyTavern thật để chạy kiểm thử hồi quy trên trình duyệt; hạ tầng thử nghiệm nằm ở:

```text
h675786161-prog/sillytavern-lab
```

Đợt kiểm chứng trước khi hợp nhất ngày 2026-09-25 bao gồm:

- Smoke test tự động ẩn trên SillyTavern thật với 121 tầng;
- Các tầng thiếu L0 vẫn hiển thị;
- Vùng đệm 5 tầng gần nhất;
- Bảo vệ nội dung ẩn thủ công và tự động khôi phục;
- Đọc lại ký ức trong RP dài với nhiều thẻ nhân vật;
- Hồi quy về ám hiệu chính xác, bàn giao, nhịp gõ cửa và thứ tự hành động;
- `npm test` và `npm run check`.

Những bài kiểm thử này dùng để kiểm chứng luồng xử lý của plugin và cơ chế đọc lại, không có nghĩa là mọi mô hình đều trả lời đúng 100% trong mọi tình huống RP tự do.

---

## Phát triển

Cần Node.js 20 hoặc mới hơn:

```bash
npm run check
npm test
```

Quy ước phát triển và nghiệm thu trên máy thật xem tại [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) và [docs/TEST-CHECKLIST.md](docs/TEST-CHECKLIST.md).

Lịch sử phiên bản và chi tiết được gom hết vào [CHANGELOG.md](CHANGELOG.md), README không còn gánh hơn bảy trăm dòng khảo cổ nữa. Văn minh nhân loại đã có lịch sử Git rồi, không cần biến cả trang chủ thành mặt cắt địa tầng.
