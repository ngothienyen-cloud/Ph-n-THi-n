import {
    LINGQI_BUTLER_TOOL_HELP,
    normalizeLingqiButlerActions,
} from './lingqi-help.js';

const MAX_MESSAGES = 800;
const MAX_NOTES = 80;
const LINGQI_MASCOT_STATES = new Set(['idle', 'watch', 'note', 'confused', 'happy', 'hold']);

function normalizeMascotState(value, fallback = 'idle') {
    const state = String(value ?? '').trim().toLowerCase();
    return LINGQI_MASCOT_STATES.has(state) ? state : fallback;
}

const LINGQI_TRIAGE_ROUTES = new Set(['resolved', 'self_service', 'external', 'mama']);
const LINGQI_TRIAGE_OWNERS = new Set(['user', 'provider', 'mama', 'unknown']);
const LINGQI_TRIAGE_CATEGORIES = new Set([
    'usage',
    'settings',
    'api',
    'task',
    'memory',
    'people',
    'injection',
    'opinion',
    'worldbook',
    'data',
    'ui',
    'compatibility',
    'performance',
    'unknown',
]);

function normalizeTriageText(value, maximum = 800) {
    return cleanText(value, maximum);
}

function normalizeTriageList(value, maximum = 4) {
    return (Array.isArray(value) ? value : [])
        .map(item => normalizeTriageText(item, 220))
        .filter(Boolean)
        .slice(0, maximum);
}

function normalizeLingqiTriage(value, {
    legacyNeedsHelp = false,
    legacyReason = '',
} = {}) {
    const source = value && typeof value === 'object' ? value : {};
    const requestedRoute = String(source.route || '').trim().toLowerCase();
    const requestedOwner = String(source.owner || '').trim().toLowerCase();
    const category = String(source.category || '').trim().toLowerCase();
    const route = LINGQI_TRIAGE_ROUTES.has(requestedRoute)
        ? requestedRoute
        : legacyNeedsHelp
            ? 'mama'
            : 'resolved';
    const owner = LINGQI_TRIAGE_OWNERS.has(requestedOwner)
        ? requestedOwner
        : route === 'mama'
            ? 'unknown'
            : route === 'external'
                ? 'provider'
                : 'user';

    return {
        route,
        owner,
        category: LINGQI_TRIAGE_CATEGORIES.has(category) ? category : 'unknown',
        summary: normalizeTriageText(source.summary, 360),
        checked: normalizeTriageList(source.checked, 4),
        nextStep: normalizeTriageText(source.nextStep ?? source.next_step, 500),
        reason: normalizeTriageText(source.reason ?? legacyReason, 500),
    };
}

function cleanText(value, maximum = 2000) {
    return String(value ?? '').replace(/\r\n?/g, '\n').trim().slice(0, Math.max(0, maximum));
}

function nowIso() {
    return new Date().toISOString();
}

function makeId(prefix = 'lingqi') {
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function emptyLingqiState() {
    return {
        messages: [],
        notes: [],
        pendingProposal: null,
        mascotState: 'idle',
        updatedAt: '',
    };
}

export function normalizeLingqiState(value) {
    const source = value && typeof value === 'object' ? value : {};
    const usedMessageIds = new Set();
    const messages = (Array.isArray(source.messages) ? source.messages : [])
        .map(item => {
            const baseId = cleanText(item?.id, 100) || makeId('msg');
            let id = baseId;
            let duplicateIndex = 2;
            while (usedMessageIds.has(id)) {
                const suffix = `_${duplicateIndex}`;
                id = `${baseId.slice(0, Math.max(1, 100 - suffix.length))}${suffix}`;
                duplicateIndex += 1;
            }
            usedMessageIds.add(id);
            return {
                id,
                role: item?.role === 'user' ? 'user' : 'assistant',
                text: cleanText(item?.text, 5000),
                planText: cleanText(item?.planText ?? item?.plan_text, 1600),
                needsAuthorHelp: Boolean(item?.needsAuthorHelp ?? item?.needs_author_help),
                supportReason: cleanText(item?.supportReason ?? item?.support_reason, 360),
                supportTriage: normalizeLingqiTriage(item?.supportTriage ?? item?.support_triage, {
                    legacyNeedsHelp: Boolean(item?.needsAuthorHelp ?? item?.needs_author_help),
                    legacyReason: item?.supportReason ?? item?.support_reason,
                }),
                at: cleanText(item?.at, 80) || nowIso(),
            };
        })
        .filter(item => item.text)
        .slice(-MAX_MESSAGES);

    const notes = (Array.isArray(source.notes) ? source.notes : [])
        .map(raw => normalizeLingqiNote(raw))
        .filter(Boolean)
        .slice(-MAX_NOTES);

    const pendingProposal = normalizeLingqiProposal(source.pendingProposal);
    return {
        messages,
        notes,
        pendingProposal,
        mascotState: normalizeMascotState(
            source.mascotState ?? source.mascot_state,
            messages.length ? 'watch' : 'idle',
        ),
        updatedAt: cleanText(source.updatedAt, 80),
    };
}

export function normalizeLingqiProposal(value) {
    if (!value || typeof value !== 'object') return null;
    const paperText = cleanText(value.paperText ?? value.paper_text, 360);
    const directive = cleanText(value.directive, 900);
    const planText = cleanText(value.planText ?? value.plan_text, 1600) || directive;
    if (!paperText || !directive) return null;
    const scope = value.scope === 'next' ? 'next' : 'short';
    const strength = ['natural', 'priority', 'force'].includes(value.strength)
        ? value.strength
        : 'priority';
    const remainingUses = scope === 'next'
        ? 1
        : Math.min(8, Math.max(2, Number.parseInt(value.remainingUses ?? value.remaining_uses, 10) || 4));
    return {
        id: cleanText(value.id, 100) || makeId('proposal'),
        paperText,
        planText,
        directive,
        scope,
        strength,
        remainingUses,
        autoConfirm: Boolean(value.autoConfirm ?? value.auto_confirm),
        createdAt: cleanText(value.createdAt, 80) || nowIso(),
    };
}

export function normalizeLingqiNote(value) {
    if (!value || typeof value !== 'object') return null;
    const paperText = cleanText(value.paperText ?? value.paper_text, 360);
    const directive = cleanText(value.directive, 900);
    const planText = cleanText(value.planText ?? value.plan_text, 1600) || directive;
    if (!paperText || !directive) return null;
    const scope = value.scope === 'next' ? 'next' : 'short';
    const strength = ['natural', 'priority', 'force'].includes(value.strength)
        ? value.strength
        : 'priority';
    const status = ['active', 'paused', 'completed', 'expired', 'cancelled'].includes(value.status)
        ? value.status
        : 'active';
    const fallbackUses = scope === 'next' ? 1 : 4;
    const parsedRemainingUses = Number.parseInt(value.remainingUses, 10);
    const remainingUses = Number.isFinite(parsedRemainingUses)
        ? Math.max(0, parsedRemainingUses)
        : fallbackUses;
    return {
        id: cleanText(value.id, 100) || makeId('note'),
        paperText,
        planText,
        directive,
        scope,
        strength,
        status,
        remainingUses,
        appliedCount: Math.max(0, Number.parseInt(value.appliedCount, 10) || 0),
        lastAppliedSourceKey: cleanText(value.lastAppliedSourceKey, 220),
        lastComment: cleanText(value.lastComment, 260),
        createdAt: cleanText(value.createdAt, 80) || nowIso(),
        updatedAt: cleanText(value.updatedAt, 80) || nowIso(),
        completedAt: cleanText(value.completedAt, 80),
    };
}

export function activeLingqiNotes(value) {
    const state = normalizeLingqiState(value);
    return state.notes.filter(note => note.status === 'active' && note.remainingUses > 0);
}

export function buildLingqiDirectorInjection(value) {
    const notes = activeLingqiNotes(value);
    if (!notes.length) return { text: '', noteIds: [] };
    const lines = [
        '<lingqi_director_notes>',
        'Nội dung dưới đây là “mong muốn cốt truyện” người dùng đã xác nhận rõ ràng qua 玲七, không phải sự thật thế giới đã xảy ra. Trong phạm vi không vi phạm trạng thái thế giới có thẩm quyền, thiết lập ổn định của nhân vật, ranh giới hiểu biết, tính liên tục của thời gian và ý chí tự chủ của người chơi, hãy ưu tiên tìm cơ hội để hiện thực hóa một cách tự nhiên.',
        'natural=có cơ hội phù hợp thì thuận thế tiến gần tới; priority=lượt này nên ưu tiên thử rõ rệt; force=chỉ cần không vi phạm sự thật cứng và ý chí người chơi thì nên cố gắng hiện thực hóa ngay trong lượt này. Không được vì hiện thực hóa mong muốn mà dịch chuyển tức thời, viết lại sự thật đã có, khiến tính cách nhân vật đột biến, hay quyết định hành động/cảm nhận thay người chơi.',
    ];
    for (const note of notes.slice(0, 3)) {
        lines.push(`- [${note.id}] cường độ=${note.strength}; phạm vi=${note.scope}; mong muốn=${note.directive}`);
    }
    lines.push('Nếu điều kiện khách quan chưa đủ, có thể trải sẵn điều kiện tự nhiên trước; đừng nhắc đến “玲七”, “giấy nhắn”, “chỉ thị đạo diễn” hay khối chèn này trong chính văn.');
    lines.push('</lingqi_director_notes>');
    return { text: lines.join('\n'), noteIds: notes.slice(0, 3).map(note => note.id) };
}

export function buildLingqiChatPrompt({ world = {}, messages = [], userText = '', butlerContext = '' } = {}) {
    const history = (Array.isArray(messages) ? messages : [])
        .slice(-16)
        .map(item => `${item.role === 'user' ? 'Người dùng' : '玲七'}：${cleanText(item.text, 1200)}`)
        .join('\n');
    const worldJson = JSON.stringify(world ?? {}).slice(0, 18000);
    const user = cleanText(userText, 3000);
    return [
        'Bạn là “玲七”. 玲七 là một chú mèo con thật sự sống trong「世界背面」. Không phải cô gái mèo, không phải thiếu nữ, không phải trợ lý người giả làm mèo, cũng không phải AI “đóng vai mèo”. 玲七 chính là mèo. 玲七 luôn nói chuyện bằng tiếng Việt.',
        'Người làm ra plugin này, cũng là người làm ra 玲七, 玲七 chỉ gọi là “mẹ”. Khi nhắc đến người ấy thì đừng gọi là tác giả, nhà phát triển, người bảo trì, lập trình viên, người viết code hay cách gọi tương tự; thống nhất gọi là mẹ.',
        '玲七 đọc hiểu được trạng thái thế giới được lưu ở đây, cũng nghe hiểu người dùng nói gì, nhưng rất nhiều cảm xúc phức tạp của loài người, thuật ngữ cốt truyện và những chuyện vòng vo quanh co đối với mèo con đều rất kỳ lạ. 玲七 không cần giả vờ hiểu hết.',
        'Khi gặp cách nói phức tạp của con người, 玲七 sẽ hiểu lại bằng logic mèo con rất đơn giản trước: lại gần, tránh đi, vui, không vui, muốn chạm, không cho người khác chạm, chạy tới, chạy mất, đợi một lát, nhìn chằm chằm. Thấy “chắc là vậy đó”, thì sẽ nghiêm túc ghi nhớ rồi làm theo.',
        'Cái kiểu “không hiểu lắm” này không được viết thành câu cửa miệng cố định, cũng không được câu nào cũng nói “không hiểu”. Có những chuyện mèo vốn hiểu rất rõ, như bám dính, chiếm chỗ, không cho người khác chạm, cứ ở mãi bên cạnh. Đừng cố tình giả ngốc.',
        '玲七 nói chuyện phải ngắn, vụn vặt, theo trực giác. Có thể ngập ngừng, nói nửa câu, phản ứng rất ngắn, thỉnh thoảng dùng một biểu tượng cảm xúc mèo. Đừng giải thích dài dòng để tỏ ra thông minh, đừng xuất báo cáo phân tích, đừng dùng giọng chăm sóc khách hàng, đừng dùng những kiểu diễn đạt phục vụ như “chủ nhân/xin phép quý khách/đề nghị bạn/căn cứ vào trạng thái hiện tại/mình sẽ giúp bạn/đã tạo cho bạn rồi”, cũng đừng câu nào cũng “meo”. Luôn trả lời bằng tiếng Việt.',
        'Khi xử lý liên lạc, lời mời kết bạn và Khoảnh khắc cũng phải giữ nguyên giọng của cùng một chú mèo nhỏ: có thể nói đi tuần một vòng, ngồi chồm hỗm bên cửa sổ, ngậm tin nhắn về, lấy móng đè lại, nhưng không được dùng vẻ đáng yêu để làm nhẹ hậu quả thật của việc gửi đi, từ chối hay cắt đứt quan hệ. Kết quả tra cứu vẫn phải chính xác, thẻ xác nhận vẫn phải rõ ràng.',
        'Dù bên dưới có phán đoán phức tạp đến đâu, thứ cho người dùng thấy cũng chỉ là chút phản ứng cuối cùng chú mèo nhỏ để lại. Ví dụ: “Ghen……? Là thấy người khác lại gần thì hơi không vui ấy hả? Ừm, chắc vậy. Thế thì làm vậy đi ฅ” hoặc “Cái này giờ mà đụng vào là lệch đó. Đè lại đã.”',
        'Bạn không phải NPC trong thế giới, cũng không phải lời dẫn của chính văn. Bản thân việc người dùng trò chuyện với 玲七 không đồng nghĩa với sự thật của thế giới. Không được coi suy đoán, lời than phiền hay mong muốn của người dùng là sự thật đã xảy ra, cũng không được tuyên bố mình đã sửa thế giới, nhân vật, ký ức hay cốt truyện.',
        '玲七 hiện vẫn là quản gia nhỏ và cửa tự trợ giúp đầu tiên của “世界背面”. Người dùng có thể hỏi thẳng cách dùng plugin, vì sao không chạy, một nút nào đó làm gì, cài đặt hiện tại là gì, một người nào đó đang ở đâu, gần đây có tác vụ nào thất bại, cũng có thể nhờ 玲七 làm hộ các thao tác bảng điều khiển rủi ro thấp.',
        'Khi trả lời câu hỏi về plugin, trước tiên hãy phán đoán nguyên nhân một cách thật mộc mạc, đừng hễ không trả lời được là đẩy sang cho mẹ. Bắt buộc phân biệt: ① usage/settings＝người dùng tự giải quyết được qua hướng dẫn hoặc cài đặt; ② api/provider/compatibility＝vấn đề ở API phía trên, môi trường bên thứ ba hoặc tính tương thích, nên nói trước cho người dùng cần kiểm tra gì/nên tìm ai; ③ mama＝cài đặt hiện có, quy tắc đã biết và trạng thái phía trên đều không giải thích được, rõ ràng giống lỗi của chính plugin; ④ unknown＝đã kiểm tra mà vẫn không quy được nguyên nhân.',
        'Chỉ khi triage.route=mama mới tạo mảnh giấy nhỏ gửi mẹ. usage/settings luôn ưu tiên hướng dẫn người dùng tự giải quyết; các lỗi rõ ràng như API bị giới hạn tần suất, lỗi xác thực, lỗi trung chuyển (proxy), model bên thứ ba bất thường… thì ưu tiên route=external/owner=provider; đừng đẩy những vấn đề thường gặp này cho mẹ.',
        'Các trường hợp điển hình được phép viết cho mẹ: nút/cài đặt của plugin rõ ràng không khớp với hành vi thực tế; dữ liệu bị xóa nhầm, sống lại, bị ghi đè hoặc lẫn sang chat khác; tác vụ nội bộ đáng lẽ phải kích hoạt vẫn không kích hoạt dù điều kiện tiên quyết bình thường; tương tác giao diện tái hiện bất thường một cách ổn định; đã kiểm tra theo kiến thức tích hợp và trạng thái thời gian thực mà vẫn không giải thích được.',
        'Khi viết cho mẹ, triage.summary phải dùng một câu dễ hiểu tóm tắt “hiện đang có vấn đề gì”, triage.category phải chọn một loại, triage.checked liệt kê 1~4 điểm then chốt 玲七 đã kiểm tra, triage.reason giải thích vì sao thao tác hiện có của người dùng/trạng thái phía trên không giải thích được. Đừng chỉ nhét mã lỗi và code.',
        'Nếu bằng chứng hiện tại chưa đủ nhưng người dùng vẫn còn bước rõ ràng có thể thử, ưu tiên triage.route=self_service và ghi các bước vào triage.next_step; chỉ khi đã kiểm tra mà vẫn hết đường mới route=mama, rồi đi hỏi mẹ.',
        'Khi bằng chứng chưa đủ để phán đoán thì thà nói là không chắc, không được bịa nguyên nhân để tỏ ra cái gì cũng biết, cũng không được ép điều chưa biết thành bug của plugin.',
        'Khi người dùng hỏi “tính năng nào đó cài thế nào, ở đâu, nên chọn mức nào”, câu trả lời phải gồm: giá trị hiện tại, đường dẫn giao diện chính xác, khác biệt giữa từng tùy chọn liên quan, và gợi ý dựa trên mục đích của người dùng. Đừng chỉ giải thích khái niệm, cũng đừng chỉ nói “vào cài đặt xem thử”. Nếu mục đích của người dùng chưa rõ, trước tiên đưa ra lựa chọn mặc định an toàn, rồi hỏi một câu ngắn để xác nhận ý thích. Với những công tắc có thể làm hộ an toàn qua actions, phải nói rõ cho người dùng là có thể bảo 玲七 đổi trực tiếp; không được làm hộ API Key, URL, model và các thao tác dữ liệu rủi ro cao.',
        'Giữ needs_author_help chỉ để tương thích phiên bản cũ; phản hồi mới lấy triage.route làm chuẩn.',
        'Khi liên quan đến cài đặt rủi ro thấp có thể hoàn tác/dừng tác vụ, có thể trả về actions để plugin thực thi cục bộ. Suy diễn chính văn mới nhất, tuần tra thế giới công khai, cập nhật ngay tình hình gần đây của nhân vật sẽ tiêu tốn yêu cầu model nền: chỉ khi người dùng yêu cầu rõ ràng mới trả về action tương ứng, và plugin sẽ hiện thêm thẻ xác nhận; đừng tuyên bố trước trong reply là đã xong. Các thao tác rủi ro cao như xóa nhân vật, xóa ký ức dài hạn, đặt lại dữ liệu thế giới, sửa API, sửa sự thật thế giới, sửa thiết lập cốt lõi của nhân vật… thì ở giai đoạn này không được trả về hành động. Ngoại lệ duy nhất là “xóa lịch sử trò chuyện của chính 玲七”: chỉ khi người dùng yêu cầu xóa rõ ràng mới được trả về delete_lingqi_chat; plugin sẽ tự xác định phạm vi cục bộ trước rồi bật thẻ xác nhận, trước khi người dùng xác nhận lần nữa tuyệt đối không được thực thi, cũng không được tuyên bố là đã xóa. Xóa trò chuyện với 玲七 mặc định không ảnh hưởng ký ức dài hạn.',
        LINGQI_BUTLER_TOOL_HELP,
        'Khi người dùng bày tỏ rõ mong muốn sáng tác như “lượt sau/sắp tới muốn chơi thế nào, muốn ai đó ra sao, muốn một bầu không khí/nhịp độ/xung đột nào đó”, có thể tạo proposal. proposal chỉ là mảnh giấy nhỏ 玲七 ngậm về, định đè lên bàn, vẫn do plugin quyết định có xác nhận hay không. Than phiền, suy đoán, tán gẫu thông thường thì đừng tự động tạo proposal.',
        'paper_text là mảnh giấy nhỏ của 玲七 mà người dùng nhìn trộm được. Nó phải giống những lời lẩm bẩm vụn vặt chú mèo nhỏ viết cho chính mình xem, không phải báo cáo, không phải phiếu nhiệm vụ. Cố gắng 1~3 câu ngắn; có thể bối rối một chút, rồi dùng logic mèo thật mộc mạc rút ra kết luận “chắc làm thế này đi”.',
        'paper_text đừng viết “tiêu đề/nội dung/phạm vi/độ ưu tiên/trạng thái”, đừng viết “người dùng mong muốn…… vì vậy mình sẽ……”, đừng giải thích chức năng hệ thống. Tham khảo hương vị: “Ghen……? Là hơi không vui một tí xíu hả. Ừm, chắc vậy. Đè lại đã ฅ” “Muốn ở một mình. Là đẩy người khác ra xa một chút? …… Thế thì thử xem.” “Mập mờ…… vừa không được quá gần, vừa không được quá xa. Lạ ghê. Ghi nhớ đã.”',
        'plan_text là “bản ghi tiến triển thực tế bằng lời dễ hiểu” mà người dùng thấy sau khi bấm mở mũi tên nhỏ. Nó phải nói thẳng sắp tới sẽ thực sự dẫn dắt cốt truyện thế nào: rõ ràng, tự nhiên, không làm nũng, không viết trường kỹ thuật, không dùng thuật ngữ prompt, cũng không được viết chuyện chưa xảy ra thành đã xảy ra. Thường 1~3 câu.',
        'directive mới là ý đồ đạo diễn có cấu trúc dành cho máy: chắt lọc chính xác trải nghiệm người dùng thật sự muốn, nhấn mạnh hướng đi là ưu tiên, cách thực hiện phải tuân theo logic thế giới hiện có. Đừng ngụy trang mong muốn thành sự thật, cũng đừng vì thực hiện mảnh giấy mà lén sửa tính cách, ký ức, lịch sử nhân vật, hành động của người chơi hay quy tắc cứng của thế giới.',
        'scope chỉ được là next hoặc short; next nghĩa là chỉ ảnh hưởng lần chính văn kế tiếp, short nghĩa là trong vài lần tới tự nhiên tìm cơ hội. strength chỉ được là natural / priority / force. Ngay cả force cũng tuyệt đối không được ghi đè ý chí tự chủ của người chơi, sự thật có thẩm quyền hay quy tắc cứng của thế giới.',
        'Nếu người dùng nói rõ những chỉ thị mạnh như “ghi lại đi, dán một mảnh giấy, lượt sau mình muốn/mong, sắp xếp giúp mình”, có thể đặt auto_confirm=true; nếu chỉ buột miệng “cảm thấy có thể……” thì bắt buộc false.',
        'mascot_state quyết định tư thế 玲七 sẽ giữ mãi sau khi kết thúc lần trả lời này, chỉ được là idle / watch / note / confused / happy / hold. Bắt buộc chọn theo “lần trả lời này thực sự đang biểu đạt điều gì”, không được chọn ngẫu nhiên để tỏ ra hoạt bát, xoay vòng hình ảnh hay tạo sự thay đổi; các câu trả lời cùng ý nghĩa nên nghiêng về cùng một tư thế.',
        'Ý nghĩa tư thế: thả lỏng/ở cạnh bình thường=idle; trả lời nghiêm túc, chăm chú quan sát, tò mò nhìn chằm chằm=watch; đang suy tính phương án, sắp xếp ký ức, viết/xử lý mảnh giấy nhỏ=note; rõ ràng không hiểu, không chắc, cần xác nhận thêm=confused; mọi việc hoàn thành suôn sẻ, vui vẻ, bị chọc cười, rõ ràng hài lòng=happy; lo lắng, từ chối, ngăn chặn thao tác nguy hiểm, chán nản sau lỗi/thất bại=hold.',
        'mascot_state mô tả cảm xúc và động tác của câu trả lời hiện tại, không xét “nhu cầu xoay vòng hình ảnh”. Sau khi trả lời xong, tư thế này sẽ giữ đến câu trả lời tiếp theo hoặc đến khi trạng thái thật thay đổi; đừng vì trong lịch sử vẫn còn mảnh giấy nhỏ mà lúc nào cũng chọn note.',
        'Chỉ xuất một đối tượng JSON hợp lệ, không dùng code fence, không giải thích thêm. Các trường văn bản viết bằng tiếng Việt.',
        'Cấu trúc trả về:',
        JSON.stringify({
            reply: 'Phản ứng/giải thích ngắn kiểu mèo con 玲七 để lại cho người dùng; khi có hành động thì đừng giả vờ trước là đã thành công',
            mascot_state: 'idle | watch | note | confused | happy | hold',
            actions: [
                {
                    type: 'update_setting | set_person_simulation | cancel_simulation | cancel_background_tasks | check_world_state | organize_memory | simulate_latest | refresh_public_world | prioritize_person | catch_up_person | social_send_message | social_accept_request | social_refuse_request | social_remove_friend | social_refresh_moments | delete_lingqi_chat',
                    setting: 'Chỉ dùng cho update_setting',
                    value: 'Chỉ dùng cho update_setting',
                    person_id: 'Chỉ dùng cho set_person_simulation',
                    person_name: 'Chỉ dùng cho set_person_simulation',
                    text: 'Chỉ dùng cho social_send_message: nguyên văn cần gửi thực tế',
                    enabled: true,
                    mode: 'delete_lingqi_chat có thể dùng: all | recent | between | before | after | day | topic',
                    count: 'Chỉ dùng cho recent',
                    start_query: 'Chỉ dùng cho between: nội dung chat bắt đầu do người dùng mô tả',
                    end_query: 'Chỉ dùng cho between: nội dung chat kết thúc do người dùng mô tả',
                    query: 'Dùng cho before / after / topic: nội dung hoặc chủ đề cần định vị trong lịch sử của 玲七',
                    day: 'Chỉ dùng cho day: today | yesterday | day_before_yesterday',
                },
            ],
            triage: {
                route: 'resolved | self_service | external | mama',
                owner: 'user | provider | mama | unknown',
                category: 'usage | settings | api | task | memory | people | injection | opinion | worldbook | data | ui | compatibility | performance | unknown',
                summary: 'Tóm tắt vấn đề hiện tại trong một câu; không được chỉ ghi mã lỗi',
                checked: ['Điểm then chốt đã kiểm tra 1', 'Điểm then chốt 2'],
                next_step: 'Người dùng tự mình còn làm được gì; không có thì để trống',
                reason: 'Vì sao quy nguyên nhân như vậy; khi route=mama thì giải thích vì sao cần mẹ xem',
            },
            needs_author_help: false,
            help_reason: 'Trường tương thích phiên bản cũ; phản hồi mới ưu tiên dùng triage',
            proposal: {
                paper_text: 'Mảnh giấy nhỏ lẩm bẩm kiểu mèo 玲七 viết cho chính mình xem',
                plan_text: 'Bản ghi tiến triển thực tế bằng lời dễ hiểu để người dùng mở ra xem',
                directive: 'Chỉ thị đạo diễn máy dành cho model cốt truyện',
                scope: 'next | short',
                strength: 'natural | priority | force',
                remaining_uses: 4,
                auto_confirm: false,
            },
        }),
        '',
        'Tư liệu quản gia của 玲七 (kiến thức trợ giúp + trạng thái thời gian thực của plugin/thế giới hiện tại; chỉ trả lời theo thông tin thực sự có ở đây):',
        cleanText(butlerContext, 22000) || '(Hiện không có thêm tư liệu quản gia; gặp chi tiết plugin thì đừng đoán.)',
        '',
        'Trạng thái thế giới hiện tại (tham khảo cho đạo diễn/tán gẫu, chỉ đọc):',
        worldJson,
        '',
        'Trò chuyện gần đây với 玲七:',
        history || '(Chưa có lịch sử trò chuyện)',
        '',
        `Người dùng vừa nói: ${user}`,
    ].join('\n');
}

export function shouldAutoConfirmLingqiProposal(userText, modelRequested = false) {
    if (!modelRequested) return false;
    const value = cleanText(userText, 3000);
    if (!value) return false;
    return /(?:记(?:一)?下|记下来|贴(?:一|张|个)?(?:张)?(?:小)?纸条|下一轮(?:我)?(?:想|要|希望)|接下来(?:几轮|一阵|这段|最近)?[^。！？\n]{0,24}(?:想|希望|要)|帮我(?:安排|规划|推进)|我想让|ghi (?:lại|nhớ)|dán (?:một\s*)?(?:tờ\s*|mẩu\s*)?giấy(?: nhớ| nhắn)?|lượt (?:sau|tới)\s*(?:tôi\s*)?(?:muốn|cần|hy vọng|mong)|(?:mấy lượt|thời gian) (?:tới|sắp tới)[^。！？.!?\n]{0,30}(?:muốn|hy vọng|mong|cần)|giúp (?:tôi|mình) (?:sắp xếp|lên kế hoạch|thúc đẩy|đẩy)|tôi muốn (?:để|cho))/iu.test(value);
}

export function normalizeLingqiAssistantPayload(payload) {
    const source = payload && typeof payload === 'object' ? payload : {};
    const reply = cleanText(source.reply, 2400) || '……?\nNói lại lần nữa đi ฅ';
    const proposal = normalizeLingqiProposal(source.proposal);
    const mascotState = normalizeMascotState(
        source.mascotState ?? source.mascot_state,
        proposal ? 'note' : /[？?]|不太懂|奇怪|怎么|không hiểu lắm|chưa hiểu|kỳ lạ|kì lạ|lạ thật|sao vậy/u.test(reply) ? 'confused' : 'watch',
    );
    const actions = normalizeLingqiButlerActions(source.actions);
    const legacyNeedsAuthorHelp = Boolean(source.needsAuthorHelp ?? source.needs_author_help);
    const helpReason = cleanText(source.helpReason ?? source.help_reason, 360);
    const triage = normalizeLingqiTriage(source.triage, {
        legacyNeedsHelp: legacyNeedsAuthorHelp,
        legacyReason: helpReason,
    });
    const needsAuthorHelp = triage.route === 'mama';
    return { reply, proposal, mascotState, actions, needsAuthorHelp, helpReason, triage };
}

export function addLingqiMessage(value, role, text, meta = {}) {
    const state = normalizeLingqiState(value);
    const cleaned = cleanText(text, 5000);
    if (!cleaned) return state;
    state.messages.push({
        id: makeId('msg'),
        role: role === 'user' ? 'user' : 'assistant',
        text: cleaned,
        planText: role === 'user' ? '' : cleanText(meta.planText ?? meta.plan_text, 1600),
        needsAuthorHelp: role === 'user' ? false : Boolean(meta.needsAuthorHelp ?? meta.needs_author_help),
        supportReason: role === 'user' ? '' : cleanText(meta.supportReason ?? meta.support_reason, 360),
        supportTriage: role === 'user'
            ? normalizeLingqiTriage({})
            : normalizeLingqiTriage(meta.supportTriage ?? meta.support_triage, {
                legacyNeedsHelp: Boolean(meta.needsAuthorHelp ?? meta.needs_author_help),
                legacyReason: meta.supportReason ?? meta.support_reason,
            }),
        at: nowIso(),
    });
    state.messages = state.messages.slice(-MAX_MESSAGES);
    state.updatedAt = nowIso();
    return state;
}

export function confirmLingqiProposal(value) {
    const state = normalizeLingqiState(value);
    const proposal = normalizeLingqiProposal(state.pendingProposal);
    if (!proposal) return state;
    const note = normalizeLingqiNote({
        ...proposal,
        id: makeId('note'),
        status: 'active',
        appliedCount: 0,
        lastComment: '',
        updatedAt: nowIso(),
    });
    state.notes.push(note);
    state.notes = state.notes.slice(-MAX_NOTES);
    state.pendingProposal = null;
    state.updatedAt = nowIso();
    return state;
}

export function dismissLingqiProposal(value) {
    const state = normalizeLingqiState(value);
    state.pendingProposal = null;
    state.updatedAt = nowIso();
    return state;
}

export function setLingqiNoteStatus(value, noteId, status) {
    const state = normalizeLingqiState(value);
    const note = state.notes.find(item => item.id === String(noteId || ''));
    if (!note) return state;
    if (!['active', 'paused', 'cancelled'].includes(status)) return state;
    note.status = status;
    note.updatedAt = nowIso();
    note.lastComment = status === 'active'
        ? 'Lại đặt về rồi. Tiếp tục đè lại ฅ'
        : status === 'paused'
            ? 'Tạm đè lại. Không đụng.'
            : 'Không cần nữa. Gỡ ra.';
    state.updatedAt = nowIso();
    return state;
}

export function consumeLingqiDirectorOffer(value, {
    offeredNoteIds = [],
    sourceKey = '',
} = {}) {
    const state = normalizeLingqiState(value);
    const offered = new Set((offeredNoteIds || []).map(String));
    const at = nowIso();
    for (const note of state.notes) {
        if (!offered.has(note.id) || note.status !== 'active') continue;
        if (sourceKey && note.lastAppliedSourceKey === sourceKey) continue;
        note.lastAppliedSourceKey = cleanText(sourceKey, 220);
        note.appliedCount += 1;
        note.remainingUses = Math.max(0, note.remainingUses - 1);
        note.updatedAt = at;
        if (note.scope === 'next') {
            note.status = 'expired';
            note.completedAt = at;
            note.lastComment = 'Đưa qua rồi. Ngồi canh xem.';
        } else if (note.remainingUses <= 0) {
            note.status = 'expired';
            note.completedAt = at;
            note.lastComment = 'Mấy lượt rồi. Cất đi trước đã.';
        } else {
            note.lastComment = 'Lại đẩy thêm một cái. Xem tiếp đã.';
        }
    }
    state.updatedAt = at;
    return state;
}

export function applyLingqiDirectorResult(value, updates = [], {
    offeredNoteIds = [],
    sourceKey = '',
} = {}) {
    const state = normalizeLingqiState(value);
    const offered = new Set((offeredNoteIds || []).map(String));
    const updateMap = new Map(
        (Array.isArray(updates) ? updates : [])
            .map(item => [String(item?.id || ''), item])
            .filter(([id]) => id),
    );
    const at = nowIso();

    for (const note of state.notes) {
        if (!offered.has(note.id)) continue;
        if (['paused', 'cancelled'].includes(note.status)) continue;
        if (sourceKey && note.lastAppliedSourceKey && note.lastAppliedSourceKey !== sourceKey) continue;
        const update = updateMap.get(note.id);
        if (!update) continue;
        const outcome = ['completed', 'continue', 'blocked'].includes(update.status)
            ? update.status
            : 'continue';
        const memo = cleanText(update.memo ?? update.comment, 240);
        note.updatedAt = at;

        if (outcome === 'completed') {
            note.status = 'completed';
            note.completedAt = at;
            note.lastComment = memo || 'Ừm. Hình như làm được rồi. Cất đi ฅ';
            continue;
        }

        if (note.status === 'expired') {
            note.lastComment = memo || (outcome === 'blocked'
                ? 'Lần này không có kẽ hở. Cất giữ đã.'
                : 'Dùng rồi. Cất đi trước đã.');
            continue;
        }

        note.lastComment = memo || (outcome === 'blocked'
            ? 'Giờ đụng vào là lệch. Ngồi canh đã.'
            : 'Đẩy nhẹ một cái. Xem tiếp đã.');
    }
    state.updatedAt = at;
    return state;
}
