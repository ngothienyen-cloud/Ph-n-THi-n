function normalizeSearchText(value = '') {
    return String(value || '')
        .toLocaleLowerCase()
        .replace(/[“”‘’「」『』【】《》〈〉（）()\[\]{}]/gu, '')
        .replace(/[，。！？!?、；;：:\s…—_-]+/gu, '')
        .trim();
}

export function cleanLingqiChatAnchor(value = '') {
    return String(value || '')
        .trim()
        .replace(/^[“”‘’「」『』\s]+|[“”‘’「」『』\s]+$/gu, '')
        .replace(/^(?:(?:câu|đoạn|lần|chỗ|lúc|khi)\s*)?(?:mà\s*)?(?:tôi|mình)?\s*(?:đã\s*)?(?:nói|hỏi|nhắc(?:\s*(?:đến|tới))?|kể|trò chuyện|chat)\s*(?:với\s*(?:bạn|em|玲七)\s*)?(?:về\s*)?|^(?:我)?(?:(?:跟|和)你)?(?:说过|说|问过|问|提过|提到|聊过|聊|讲过|讲)(?:你)?(?:的)?/iu, '')
        .replace(/(?:那(?:句|段|次|里|时候)|这里|那里|的时候|开始|为止|\s*(?:lúc đó|khi đó|hồi đó|đó|ấy|ở đây|ở đó|trở đi))$/iu, '')
        .trim();
}

function messageMatches(message, query = '') {
    const haystack = normalizeSearchText(message?.text || '');
    const needle = normalizeSearchText(cleanLingqiChatAnchor(query));
    if (!haystack || !needle) return false;
    if (haystack.includes(needle) || (needle.length >= 6 && needle.includes(haystack))) return true;
    const chunks = String(cleanLingqiChatAnchor(query) || '')
        .split(/[，。！？!?、；;：:\s]+/u)
        .map(part => normalizeSearchText(part))
        .filter(part => part.length >= 2);
    if (!chunks.length) return false;
    const matched = chunks.filter(part => haystack.includes(part));
    return matched.length >= Math.min(2, chunks.length) && matched.join('').length >= Math.min(6, needle.length);
}

export function findLingqiChatMatches(messagesValue = [], query = '', maximum = 8) {
    const messages = Array.isArray(messagesValue) ? messagesValue : [];
    const limit = Math.min(20, Math.max(1, Number.parseInt(maximum, 10) || 8));
    const matches = messages
        .map((message, index) => messageMatches(message, query) ? { message, index } : null)
        .filter(Boolean);
    return matches.slice(-limit).map(({ message, index }) => ({
        id: String(message?.id || ''),
        index,
        role: message?.role === 'user' ? 'user' : 'assistant',
        text: String(message?.text || '').trim(),
        at: String(message?.at || ''),
    }));
}

function preview(message) {
    const role = message?.role === 'user' ? 'Bạn' : '玲七';
    const text = String(message?.text || '').replace(/\s+/gu, ' ').trim();
    return `${role}：${text.length > 76 ? `${text.slice(0, 76)}…` : text}`;
}

function localDayKey(value) {
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) return '';
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export function lingqiChatSnapshotSignature(messages = []) {
    let hash = 2166136261;
    for (const message of Array.isArray(messages) ? messages : []) {
        const value = `${message?.id || ''}\u001f${message?.role || ''}\u001f${message?.at || ''}\u001f${message?.text || ''}\u001e`;
        for (let index = 0; index < value.length; index += 1) {
            hash ^= value.charCodeAt(index);
            hash = Math.imul(hash, 16777619);
        }
    }
    return `${Array.isArray(messages) ? messages.length : 0}:${(hash >>> 0).toString(36)}`;
}

export function resolveLingqiChatDeletionPlan(messagesValue = [], action = {}, totalMessageCount = null) {
    const messages = Array.isArray(messagesValue) ? messagesValue : [];
    const mode = String(action.mode || '').trim().toLowerCase();
    if (!messages.length) {
        return { ok: false, message: 'Ở đây không còn trò chuyện nào cũ hơn với 玲七 để xóa nữa rồi～' };
    }

    let startIndex = 0;
    let endIndex = messages.length - 1;
    const deleteAll = mode === 'all';
    const singleMatches = query => messages
        .map((message, index) => messageMatches(message, query) ? index : -1)
        .filter(index => index >= 0);

    if (mode === 'recent') {
        const count = Math.min(messages.length, Math.max(1, Number.parseInt(action.count, 10) || 1));
        startIndex = Math.max(0, messages.length - count);
    } else if (mode === 'between') {
        const starts = singleMatches(action.startQuery);
        const ends = singleMatches(action.endQuery);
        if (!starts.length || !ends.length) {
            return {
                ok: false,
                message: `Mình chưa nhận đúng${!starts.length ? 'phần đầu' : 'phần cuối'} cho chắc…… đổi sang một câu mô tả gần với nguyên văn lúc đó hơn cho mình nhé.`,
            };
        }
        if (starts.length > 1 || ends.length > 1) {
            return { ok: false, message: 'Phần đầu hoặc phần cuối xuất hiện trong lịch sử nhiều hơn một lần, mình sợ bắt nhầm đoạn. Nói câu đó đầy đủ hơn chút nhé～' };
        }
        if (ends[0] < starts[0]) {
            return { ok: false, message: 'Phần cuối mình tìm được lại chạy lên trước phần đầu mất rồi…… nói phạm vi này cụ thể hơn chút nhé.' };
        }
        startIndex = starts[0];
        endIndex = ends[0];
    } else if (mode === 'before' || mode === 'after') {
        const matches = singleMatches(action.query);
        if (!matches.length) return { ok: false, message: 'Mình không tìm thấy vị trí bạn nói trong cuộc trò chuyện…… cho mình thêm chút nguyên văn nhé.' };
        if (matches.length > 1) return { ok: false, message: 'Vị trí này xuất hiện nhiều hơn một lần, mình sợ xóa nhầm. Cho mình một câu nguyên văn đầy đủ hơn nhé～' };
        if (mode === 'before') {
            endIndex = Math.max(0, matches[0] - 1);
            if (matches[0] === 0) return { ok: false, message: 'Nó đã là tin sớm nhất rồi, phía trước không còn trò chuyện nào để xóa.' };
        } else {
            startIndex = Math.min(messages.length - 1, matches[0] + 1);
            if (matches[0] === messages.length - 1) return { ok: false, message: 'Nó đã là bản ghi cũ mới nhất rồi, phía sau không còn trò chuyện nào mới hơn để xóa.' };
        }
    } else if (mode === 'day') {
        const offset = action.day === 'yesterday' ? -1 : action.day === 'day_before_yesterday' ? -2 : 0;
        const target = new Date();
        target.setDate(target.getDate() + offset);
        const key = localDayKey(target);
        const indices = messages
            .map((message, index) => localDayKey(message.at) === key ? index : -1)
            .filter(index => index >= 0);
        if (!indices.length) return { ok: false, message: 'Ngày đó ở đây không có lịch sử trò chuyện với 玲七.' };
        startIndex = indices[0];
        endIndex = indices.at(-1);
    } else if (mode === 'topic') {
        const matches = singleMatches(action.query);
        if (!matches.length) return { ok: false, message: 'Mình lục lọi một hồi mà không tìm thấy đoạn trò chuyện bạn nói…… thử từ khóa cụ thể hơn nhé?' };
        const groups = [];
        for (const index of matches) {
            const last = groups.at(-1);
            if (!last || index - last.at(-1) > 6) groups.push([index]);
            else last.push(index);
        }
        if (groups.length > 1) {
            return { ok: false, message: `Mình tìm thấy ${groups.length} đoạn đều giống nội dung bạn nói…… sợ bắt nhầm. Cho mình thêm một từ đã nói lúc đó nhé.` };
        }
        startIndex = groups[0][0];
        endIndex = groups[0].at(-1);
        if (messages[startIndex]?.role === 'assistant' && startIndex > 0 && messages[startIndex - 1]?.role === 'user') startIndex -= 1;
        if (messages[endIndex]?.role === 'user' && endIndex < messages.length - 1 && messages[endIndex + 1]?.role === 'assistant') endIndex += 1;
    } else if (mode !== 'all') {
        return { ok: false, message: 'Phạm vi xóa này mình nghe chưa hiểu…… nói “tất cả”, “mấy tin gần đây” hoặc “từ câu nào đến câu nào” đều được.' };
    }

    const selected = messages.slice(startIndex, endIndex + 1);
    if (!selected.length) return { ok: false, message: 'Trong phạm vi này không có trò chuyện nào có thể xóa.' };
    return {
        ok: true,
        action: {
            ...action,
            resolvedMessageIds: selected.map(message => message.id),
            deleteAll,
            resolvedCount: deleteAll
                ? Math.max(selected.length, Number(totalMessageCount) || 0)
                : selected.length,
        },
        title: deleteAll ? 'Xóa sạch lịch sử trò chuyện với 玲七?' : `Xóa ${selected.length} tin nhắn trò chuyện này?`,
        detail: deleteAll
            ? 'Sẽ xóa sạch toàn bộ lịch sử trò chuyện giữa 玲七 và bạn trong chat hiện tại. Ký ức dài hạn của 玲七, trạng thái thế giới và giấy nhắn đều không bị xóa theo.'
            : 'Chỉ xóa đoạn trò chuyện với 玲七 bên dưới. Ký ức dài hạn của 玲七, trạng thái thế giới và giấy nhắn đều không bị xóa theo.',
        confirmLabel: deleteAll ? 'Xóa hết' : 'Xóa đoạn này',
        previewLines: [
            `Từ: ${preview(selected[0])}`,
            selected.length > 1 ? `Đến: ${preview(selected.at(-1))}` : '',
        ].filter(Boolean),
        caution: 'Xóa lịch sử trò chuyện ≠ xóa ký ức dài hạn',
    };
}

export function parseLingqiLocalChatDeleteRequest(userText = '') {
    const raw = String(userText || '').trim();
    if (!/(?:聊天记录|聊天|trò chuyện|chat|tin nhắn)/iu.test(raw) || !/(?:删掉|删除|清掉|清除|清空|xóa|xoá|dọn sạch|làm trống)/iu.test(raw)) return null;

    if (
        /(?:清空)(?:一下|掉)?(?:我们|我和你|和玲七|玲七)?(?:的)?(?:全部|所有)?(?:聊天记录|聊天)|(?:xóa|xoá|dọn|làm)\s*(?:sạch|trống)\s*(?:hết\s*)?(?:(?:toàn bộ|tất cả)\s*)?(?:các\s*)?(?:lịch sử trò chuyện|lịch sử chat|đoạn chat|cuộc trò chuyện|tin nhắn|trò chuyện|chat)/iu.test(raw)
        || /(?:删掉|删除|清掉|清除)(?:一下)?(?:我们|我和你|和玲七|玲七)?(?:的)?(?:全部|所有)(?:的)?(?:聊天记录|聊天)|(?:xóa|xoá)(?:\s*bỏ)?\s*(?:hết|toàn bộ|tất cả)\s*(?:các\s*|những\s*)?(?:lịch sử trò chuyện|lịch sử chat|đoạn chat|cuộc trò chuyện|tin nhắn|trò chuyện|chat)/iu.test(raw)
        || /(?:把)?(?:我们|我和你|和玲七|玲七)?(?:的)?(?:全部|所有)(?:的)?(?:聊天记录|聊天)(?:都)?(?:删掉|删除|清掉|清除)|(?:toàn bộ|tất cả)\s*(?:các\s*|những\s*)?(?:lịch sử trò chuyện|lịch sử chat|đoạn chat|cuộc trò chuyện|tin nhắn|trò chuyện|chat)(?:\s*(?:của chúng ta|giữa chúng ta|với 玲七))?\s*(?:đều\s*)?(?:xóa|xoá)/iu.test(raw)
        || /^(?:玲七[，,]?\s*)?(?:帮我)?\s*(?:删掉|删除|清掉|清除)\s*(?:聊天记录|聊天)\s*[吧。！!]*$|^(?:玲七\s*(?:ơi\s*)?[，,]?\s*)?(?:giúp tôi|hãy|làm ơn)?\s*(?:xóa|xoá)(?:\s*bỏ)?\s*(?:lịch sử trò chuyện|lịch sử chat|đoạn chat|cuộc trò chuyện|tin nhắn|trò chuyện|chat)(?:\s*(?:của chúng ta|giữa chúng ta|với 玲七))?\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu.test(raw)
    ) return { type: 'delete_lingqi_chat', mode: 'all' };

    const recent = raw.match(/(?:最近|刚才(?:的)?|(?:xóa|xoá)(?:\s*bỏ)?(?=[^,，。.!！]*(?:gần nhất|gần đây|vừa rồi|vừa xong|mới nhất|cuối cùng)))\s*(\d{1,3})\s*(条|轮|tin nhắn|tin|câu|lượt)(?:玲七)?(?:聊天记录|聊天)?/iu);
    if (recent) {
        const count = Math.min(800, Math.max(1, Number.parseInt(recent[1], 10) || 1) * (recent[2] === '轮' ? 2 : 1));
        return { type: 'delete_lingqi_chat', mode: 'recent', count };
    }

    const dayMap = [
        { re: /前天(?:的)?(?:玲七)?(?:聊天记录|聊天)|(?:lịch sử trò chuyện|lịch sử chat|đoạn chat|cuộc trò chuyện|tin nhắn|trò chuyện|chat)(?:\s*(?:với\s*)?玲七)?\s*(?:của\s*|từ\s*|trong\s*)?(?:ngày\s*)?hôm kia/iu, day: 'day_before_yesterday' },
        { re: /昨天(?:的)?(?:玲七)?(?:聊天记录|聊天)|(?:lịch sử trò chuyện|lịch sử chat|đoạn chat|cuộc trò chuyện|tin nhắn|trò chuyện|chat)(?:\s*(?:với\s*)?玲七)?\s*(?:của\s*|từ\s*|trong\s*)?(?:ngày\s*)?hôm qua/iu, day: 'yesterday' },
        { re: /今天(?:的)?(?:玲七)?(?:聊天记录|聊天)|(?:lịch sử trò chuyện|lịch sử chat|đoạn chat|cuộc trò chuyện|tin nhắn|trò chuyện|chat)(?:\s*(?:với\s*)?玲七)?\s*(?:của\s*|từ\s*|trong\s*)?(?:ngày\s*)?hôm nay/iu, day: 'today' },
    ];
    for (const item of dayMap) {
        if (item.re.test(raw)) return { type: 'delete_lingqi_chat', mode: 'day', day: item.day };
    }

    let between = raw.match(/^(?:玲七[，,]?\s*|(?:玲七\s*(?:ơi\s*)?[，,]?\s*)?)?(?:帮我|giúp tôi|hãy|làm ơn)?\s*(?:把|đoạn|phần)?\s*(?:从|từ)\s*(.{1,160}?)\s*(?:到|至|đến|tới)\s*(.{1,160}?)(?:之间|这一段|这段)?(?:的)?(?:聊天记录|聊天)?\s*(?:都)?(?:删掉|删除|清掉|清除|(?:thì\s*)?(?:đều\s*)?(?:xóa|xoá)(?:\s*(?:hết|sạch))?)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu);
    if (!between) {
        between = raw.match(/^(?:玲七[，,]?\s*|(?:玲七\s*(?:ơi\s*)?[，,]?\s*)?)?(?:帮我|giúp tôi|hãy|làm ơn)?\s*(?:删掉|删除|清掉|清除|(?:xóa|xoá)(?:\s*bỏ)?)\s*(?:(?:các\s*|những\s*)?(?:lịch sử trò chuyện|lịch sử chat|đoạn chat|cuộc trò chuyện|tin nhắn|trò chuyện|chat)\s*)?(?:从\s*|từ\s*)?(.{1,160}?)\s*(?:到|至|đến|tới)\s*(.{1,160}?)(?:之间|这一段|这段)?(?:的)?(?:聊天记录|聊天)?\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu);
    }
    if (between) {
        return {
            type: 'delete_lingqi_chat',
            mode: 'between',
            startQuery: cleanLingqiChatAnchor(between[1]),
            endQuery: cleanLingqiChatAnchor(between[2]),
        };
    }

    const sided = raw.match(/^(?:玲七[，,]?\s*|(?:玲七\s*(?:ơi\s*)?[，,]?\s*)?)?(?:帮我|giúp tôi|hãy|làm ơn)?\s*(?:把|từ)?\s*(.{1,180}?)\s*(之前|以前|之后|以后|trở về trước|về trước|trở về sau|về sau|trở đi)(?:的)?(?:聊天记录|聊天|\s*(?:các\s*|những\s*)?(?:lịch sử trò chuyện|lịch sử chat|đoạn chat|cuộc trò chuyện|tin nhắn|trò chuyện|chat))\s*(?:都)?(?:删掉|删除|清掉|清除|(?:thì\s*)?(?:đều\s*)?(?:xóa|xoá)(?:\s*(?:hết|sạch))?)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu)
        || raw.match(/^(?:玲七[，,]?\s*|(?:玲七\s*(?:ơi\s*)?[，,]?\s*)?)?(?:帮我|giúp tôi|hãy|làm ơn)?\s*(?:删掉|删除|清掉|清除|(?:xóa|xoá)(?:\s*bỏ)?)\s*(?:(?:các\s*|những\s*)?(?:lịch sử trò chuyện|lịch sử chat|đoạn chat|cuộc trò chuyện|tin nhắn|trò chuyện|chat)\s*)?(?:từ\s*)?(.{1,180}?)\s*(之前|以前|之后|以后|trở về trước|về trước|trở về sau|về sau|trở đi)(?:的)?(?:聊天记录|聊天|(?<=(?:trở về trước|về trước|trở về sau|về sau|trở đi)))\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu);
    if (sided) {
        return {
            type: 'delete_lingqi_chat',
            mode: /之前|以前|trước/u.test(sided[2]) ? 'before' : 'after',
            query: cleanLingqiChatAnchor(sided[1]),
        };
    }

    const topic = raw.match(/(?:把|(?:đoạn|phần)(?:\s*(?:chat|trò chuyện|tin nhắn))?\s*(?:mà\s*|khi\s*|lúc\s*)?)?(?:我们|我和你|和玲七|\s*chúng ta\s*|\s*tôi (?:với|và) bạn\s*|\s*mình\s*)?(?:之前|刚才|那次|đã\s*|vừa\s*|lúc nãy\s*)?(?:聊过|聊|说过|说|讨论过|讨论|(?:nói chuyện|nói|trò chuyện|bàn|chat|kể)(?:\s*(?:về|đến|tới))?|nhắc\s*(?:đến|tới))(?:的|过)?\s*([^，。！？!]{2,80}?)(?:那一段|那段|这段|(?<=(?:đoạn|phần)\s.*))(?:的)?(?:聊天记录|聊天)?(?:都)?(?:删掉|删除|清掉|清除|\s*(?:thì\s*)?(?:đều\s*)?(?:xóa|xoá))/iu)
        || raw.match(/(?:删掉|删除|清掉|清除|(?:xóa|xoá)(?:\s*bỏ)?\s*(?:đoạn|phần)(?:\s*(?:chat|trò chuyện|tin nhắn))?\s*(?:mà\s*|khi\s*|lúc\s*)?)(?:我们|我和你|和玲七|\s*chúng ta\s*|\s*tôi (?:với|và) bạn\s*|\s*mình\s*)?(?:之前|刚才|那次|đã\s*|vừa\s*|lúc nãy\s*)?(?:聊过|聊|说过|讨论过|(?:nói chuyện|nói|trò chuyện|bàn|chat|kể)(?:\s*(?:về|đến|tới))?|nhắc\s*(?:đến|tới))(?:的|过)?\s*([^，。！？!]{2,80}?)(?:那一段|那段|这段|(?<=(?:đoạn|phần)\s.*)(?=\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$))(?:的)?(?:聊天记录|聊天)?/iu);
    if (topic) return { type: 'delete_lingqi_chat', mode: 'topic', query: cleanLingqiChatAnchor(topic[1]) };

    return null;
}
