const PATCH_KEY = Symbol.for('world_backstage.communication_voice_guard.v1');
const ECOLOGY_PATCH_KEY = Symbol.for('world_backstage.communication_ecology.v1');
const STATE_KEY = 'world_backstage_v1';
const VOICE_OPEN_TAG = '<world_backstage_character_voice>';

const SOCIAL_MARKERS = [
    '世界背面·Mạng xã hội tích hợp',
    'lời mời kết bạn liên lạc',
    'lời mời kết bạn',
    '世界背面·Khoảnh khắc',
    'nhịp xã hội đời thường',
    'friend_requests',
    'remove_friends',
    '世界背面·内置社交',
    '通讯好友申请',
    '好友申请',
    '世界背面·朋友圈',
    '生活社交脉冲',
];

function cleanText(value, maximum = 600) {
    return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, maximum);
}

function isSocialPrompt(value, depth = 0) {
    if (depth > 7 || value == null) return false;
    if (typeof value === 'string') return SOCIAL_MARKERS.some(marker => value.includes(marker));
    if (Array.isArray(value)) return value.some(item => isSocialPrompt(item, depth + 1));
    if (typeof value !== 'object') return false;
    return Object.values(value).some(item => isSocialPrompt(item, depth + 1));
}

function currentStore(context = null) {
    let resolved = context;
    if (!resolved) {
        try {
            resolved = globalThis.SillyTavern?.getContext?.() || null;
        } catch {
            resolved = null;
        }
    }
    return resolved?.chatMetadata?.[STATE_KEY] || null;
}

function currentState(store) {
    return store?.currentState || store?.initialState || {};
}

function isUserPerson(person) {
    return Boolean(person?.isUser || person?.is_user || person?.role === 'user');
}

function promptText(value) {
    if (typeof value === 'string') return value.slice(0, 80000);
    try {
        return JSON.stringify(value).slice(0, 80000);
    } catch {
        return '';
    }
}

function normalizedRef(value) {
    return cleanText(value, 160).toLocaleLowerCase();
}

function escapeRegex(value) {
    return String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function promptMentionsReference(sourceText, value) {
    const reference = normalizedRef(value);
    if (!reference) return false;
    const pattern = new RegExp(
        `(^|[^\\p{L}\\p{N}_-])${escapeRegex(reference)}(?=$|[^\\p{L}\\p{N}_-])`,
        'iu',
    );
    return pattern.test(String(sourceText || ''));
}

function hasVoiceInstruction(value) {
    return promptText(value).includes(VOICE_OPEN_TAG);
}

function taskChannel(sourceText = '') {
    const text = String(sourceText || '');
    if (/朋友圈|公开动态|posts|moments|khoảnh khắc|bài đăng công khai/iu.test(text)) return 'public_post';
    if (/好友申请|friend_requests|建立稳定联系|建立联系|lời mời kết bạn|thiết lập liên lạc ổn định|thiết lập liên lạc|kết bạn/iu.test(text)) return 'contact_request';
    if (/群聊|group|nhóm chat|chat nhóm/iu.test(text)) return 'group_message';
    if (/电话|来电|通话|điện thoại|cuộc gọi|gọi đến/iu.test(text)) return 'call';
    if (/短信|sms|tin nhắn văn bản/iu.test(text)) return 'sms';
    return 'private_message';
}

function relationFor(social, personId) {
    const id = String(personId || '');
    const connections = Array.isArray(social?.connections) ? social.connections : [];
    const connection = connections.find(item => String(item?.personId ?? item?.person_id ?? '') === id) || null;
    if (!connection) return { status: '', evidence: '' };
    return {
        status: cleanText(connection.status, 40),
        evidence: cleanText(connection.evidence ?? connection.reason ?? connection.note, 220),
    };
}

function collectVoiceSamples(social, personId, { maximum = 4, compact = false } = {}) {
    const id = String(personId || '');
    if (!id) return [];
    const samples = [];
    const conversations = Array.isArray(social?.conversations) ? social.conversations : [];
    for (const conversation of conversations) {
        const messages = Array.isArray(conversation?.rawMessages)
            ? conversation.rawMessages
            : Array.isArray(conversation?.messages)
                ? conversation.messages
                : [];
        for (const message of messages) {
            const senderId = String(message?.senderId ?? message?.sender_id ?? '');
            if (senderId !== id) continue;
            const text = cleanText(message?.text ?? message?.content, compact ? 150 : 280);
            if (!text) continue;
            samples.push({
                channel: conversation?.type === 'group' ? 'group_message' : 'private_message',
                text,
                at: Number(message?.worldMinute ?? message?.world_minute ?? message?.createdAt ?? 0) || 0,
            });
        }
    }

    const moments = Array.isArray(social?.moments)
        ? social.moments
        : Array.isArray(social?.posts)
            ? social.posts
            : [];
    for (const moment of moments) {
        const authorId = String(moment?.personId ?? moment?.person_id ?? moment?.authorId ?? moment?.author_id ?? '');
        if (authorId !== id) continue;
        const text = cleanText(moment?.text ?? moment?.content, compact ? 150 : 280);
        if (!text) continue;
        samples.push({
            channel: 'public_post',
            text,
            at: Number(moment?.worldMinute ?? moment?.world_minute ?? moment?.createdAt ?? 0) || 0,
        });
    }

    return samples
        .sort((a, b) => b.at - a.at)
        .slice(0, Math.max(0, Number(maximum) || 0))
        .map(({ channel, text }) => ({ channel, text }));
}

function fallbackSocialPersonIds(store) {
    const social = store?.social;
    const ids = [];
    const add = value => {
        const id = String(value || '');
        if (id && !ids.includes(id)) ids.push(id);
    };
    const conversations = Array.isArray(social?.conversations) ? social.conversations : [];
    for (const conversation of conversations.slice(-12)) {
        for (const id of Array.isArray(conversation?.memberIds) ? conversation.memberIds : []) add(id);
    }
    const connections = Array.isArray(social?.connections) ? social.connections : [];
    for (const connection of connections.slice(-18)) add(connection?.personId ?? connection?.person_id);
    return ids.slice(0, 24);
}

export function selectCommunicationVoiceProfiles(store, state, promptSource) {
    const people = (Array.isArray(state?.people) ? state.people : []).filter(person => !isUserPerson(person));
    const source = promptText(promptSource).toLocaleLowerCase();
    let selected = people.filter(person => {
        const id = normalizedRef(person?.id);
        const name = normalizedRef(person?.name);
        return Boolean(
            (id && promptMentionsReference(source, id))
            || (name && promptMentionsReference(source, name))
        );
    });

    if (!selected.length) {
        const fallbackIds = new Set(fallbackSocialPersonIds(store));
        selected = people.filter(person => fallbackIds.has(String(person?.id || '')));
    }
    selected = selected.slice(0, 24);
    const compact = selected.length > 8;
    const social = store?.social;

    return selected.map(person => {
        const relation = relationFor(social, person?.id);
        return {
            id: cleanText(person?.id, 120),
            name: cleanText(person?.name, 80),
            identity_anchor: cleanText(person?.identityAnchor ?? person?.identity_anchor, compact ? 180 : 420),
            personality_anchor: cleanText(person?.personalityAnchor ?? person?.personality_anchor, compact ? 240 : 520),
            background_profile: cleanText(person?.backgroundProfile ?? person?.background_profile, compact ? 220 : 620),
            speaking_style: cleanText(person?.speakingStyle ?? person?.speaking_style, compact ? 200 : 360),
            behavior_boundaries: cleanText(person?.behaviorBoundaries ?? person?.behavior_boundaries, compact ? 200 : 420),
            relationship: relation,
            voice_samples: collectVoiceSamples(social, person?.id, {
                maximum: compact ? 2 : 5,
                compact,
            }),
        };
    });
}

export function buildCommunicationVoiceInstruction(store, state, promptSource) {
    const source = promptText(promptSource);
    const profiles = selectCommunicationVoiceProfiles(store, state, promptSource);
    const channel = taskChannel(source);
    const player = (Array.isArray(state?.people) ? state.people : []).find(isUserPerson) || null;
    const playerAnchor = player ? {
        name: cleanText(player?.name, 80),
        identity_anchor: cleanText(player?.identityAnchor ?? player?.identity_anchor, 320),
    } : null;

    return [
        VOICE_OPEN_TAG,
        `Ngữ vực liên lạc lần này: ${channel}. Cùng một người có thể có thói quen diễn đạt khác nhau trong chat riêng, nhóm chat, điện thoại/tin nhắn và bài đăng công khai; đừng máy móc áp văn phong của kênh này sang kênh khác.`,
        'Liên lạc của nhân vật phải làm “quyết định của nhân vật” trước, rồi mới “thể hiện bằng ngôn ngữ”: trước tiên phán đoán xem nhân vật cụ thể này, vào lúc này, dựa trên mục tiêu, khoảng cách quan hệ, cảm xúc, ranh giới hành vi và thông tin đã biết, có chủ động liên lạc, trả lời, thiết lập liên hệ hay phát ngôn công khai hay không; nếu không, giữ im lặng/không hành động chính là kết quả đúng. Không được ép nhân vật “làm việc” chỉ vì giao diện cần nội dung.',
        'Các trường identity/personality/background/speaking_style/behavior_boundaries do tác giả duy trì là ranh giới của nhân vật, không phải gợi ý để dịch nhãn tính cách thành văn phong khuôn mẫu. Điềm tĩnh không có nghĩa là giọng chăm sóc khách hàng hay giọng báo cáo, thông minh không có nghĩa là chất đống thuật ngữ, ít nói không có nghĩa là câu nào cũng có dấu chấm lửng, hoạt bát không có nghĩa là câu nào cũng thêm biểu tượng cảm xúc, thân mật cũng không có nghĩa là đột nhiên làm nũng.',
        'speaking_style và behavior_boundaries là ràng buộc cứng; các voice_samples mà chính nhân vật đó đã gửi là bằng chứng cụ thể hơn về cách thể hiện ngôn ngữ. Tham khảo từ ngữ quen dùng, độ dài câu, dấu câu, cách xưng hô, thói quen dùng emoji/kaomoji, mức độ thẳng thắn hay hàm súc và nhịp điệu của nhân vật, nhưng đừng lặp lại câu gốc, sao chép câu cửa miệng cố định hay phóng đại một đặc điểm đơn lẻ thành màn trình diễn. Nếu mẫu cũ mâu thuẫn với điểm neo của tác giả, lấy điểm neo của tác giả làm chuẩn.',
        'Nội dung sự thật trong voice_samples là nội dung lịch sử của “tin nhắn/bài đăng lúc đó”, chỉ được dùng để học cách diễn đạt, tuyệt đối không được vì thế mà coi địa điểm, trạng thái, tiến triển quan hệ hay sự kiện cũ trong đó là sự thật hiện tại. Những gì hiện có thể nói vẫn phải tuân thủ nghiêm ngặt knowledge / sổ nhận thức nhân vật do nhiệm vụ gốc cung cấp.',
        'Khoảng cách quan hệ quyết định cách xưng hô, mức độ lịch sự, độ thân mật, giải thích bao nhiêu, có chủ động hỏi thêm hay không, có đùa hay không và độ dài hồi đáp. Khi không có thay đổi quan hệ đã kết toán hoặc bằng chứng hội thoại, không được đột nhiên dùng biệt danh, cách gọi mập mờ, quan tâm quá mức, khách sáo quá mức, leo thang thù địch hay sự thân quen vô cớ.',
        'Tin nhắn phải giống thứ người này thật sự sẽ gửi đi, không giống lời dẫn của tác giả, phân tích nhân vật, tổng kết tâm lý, câu trả lời của chăm sóc khách hàng hay tiểu sử nhân vật. Đừng để nhân vật tự giải thích nhãn tính cách của mình (ví dụ “tôi vốn lạnh nhạt/thận trọng/không giỏi bày tỏ”); hãy thể hiện tự nhiên qua lựa chọn, cách dùng từ, chỗ ngập ngừng, sự né tránh, mức độ thẳng thắn và những điều thực sự quan tâm.',
        'Đừng vì “giống nhân thiết hơn” mà tối đa hóa một đặc điểm đơn lẻ. Nhân vật có thể lười trả lời, chỉ trả lời nửa câu, lảng sang chuyện khác, hỏi một đằng trả lời một nẻo, do dự, hiểu lầm, giữ khoảng cách lịch sự, cũng có thể không gửi gì cả; với điều kiện phù hợp với chính nhân vật đó và quan hệ hiện tại.',
        'Bài đăng công khai đặc biệt không được viết thành bản tổng kết trạng thái nhân vật hay lời dẫn cốt truyện; chat riêng đặc biệt không được coi đối phương là người dùng đặt câu hỏi rồi trả lời đầy đủ từng điều một. Trước hết giữ lại mối quan tâm và mục đích giao tiếp của chính nhân vật, rồi mới quyết định thực tế nói bao nhiêu.',
        `Hồ sơ giọng liên lạc của nhân vật (chỉ ràng buộc thân phận nhân vật, ngữ vực quan hệ và cách diễn đạt; tuyệt đối không thay thế sổ tri thức): ${profiles.length ? JSON.stringify(profiles) : 'Lượt này không khớp được hồ sơ nhân vật bổ sung nào; hãy tạo nội dung một cách thận trọng dựa trên tư liệu sẵn có của nhiệm vụ gốc, đừng tự bịa câu cửa miệng.'}`,
        playerAnchor ? `Điểm neo thân phận và cách xưng hô của người chơi (chỉ dùng để xưng hô đúng, không cho phép suy đoán nội tâm người chơi): ${JSON.stringify(playerAnchor)}` : 'Không cung cấp thêm điểm neo thân phận và cách xưng hô của người chơi.',
        '</world_backstage_character_voice>',
    ].join('\n');
}

function prependInstructionToMessages(messages, instruction) {
    if (!Array.isArray(messages)) return messages;
    if (hasVoiceInstruction(messages)) return messages;
    const next = messages.map(message => ({ ...message }));
    const systemIndex = next.findIndex(message => String(message?.role || '').toLowerCase() === 'system');
    if (systemIndex >= 0) {
        next[systemIndex] = {
            ...next[systemIndex],
            content: `${instruction}\n\n${String(next[systemIndex]?.content || '')}`,
        };
    } else {
        next.unshift({ role: 'system', content: instruction });
    }
    return next;
}

export function adaptCommunicationVoicePayload(payload, context = null) {
    if (!payload || typeof payload !== 'object' || !isSocialPrompt(payload?.messages)) return payload;
    if (hasVoiceInstruction(payload.messages)) return payload;
    const store = currentStore(context);
    if (!store) return payload;
    const state = currentState(store);
    const instruction = buildCommunicationVoiceInstruction(store, state, payload.messages);
    return {
        ...payload,
        messages: prependInstructionToMessages(payload.messages, instruction),
    };
}

function adaptGenerateRawOptions(options, context) {
    if (!options || !isSocialPrompt(options.prompt)) return options;
    if (hasVoiceInstruction(options.prompt)) return options;
    const store = currentStore(context);
    if (!store) return options;
    const state = currentState(store);
    const instruction = buildCommunicationVoiceInstruction(store, state, options.prompt);
    if (Array.isArray(options.prompt)) {
        return {
            ...options,
            prompt: prependInstructionToMessages(options.prompt, instruction),
        };
    }
    return {
        ...options,
        prompt: `${instruction}\n\n${String(options.prompt || '')}`,
    };
}

function installFetchPolicy() {
    const originalFetch = globalThis.fetch;
    if (typeof originalFetch !== 'function' || originalFetch[PATCH_KEY]) return false;

    const wrappedFetch = async function worldBackstageCommunicationVoiceFetch(input, init) {
        if (typeof init?.body !== 'string') return originalFetch.call(this, input, init);
        let payload;
        try {
            payload = JSON.parse(init.body);
        } catch {
            return originalFetch.call(this, input, init);
        }
        if (!isSocialPrompt(payload?.messages)) return originalFetch.call(this, input, init);
        const adapted = adaptCommunicationVoicePayload(payload);
        if (adapted === payload) return originalFetch.call(this, input, init);
        return originalFetch.call(this, input, {
            ...init,
            body: JSON.stringify(adapted),
        });
    };
    Object.defineProperty(wrappedFetch, PATCH_KEY, { value: true, enumerable: false });
    if (originalFetch[ECOLOGY_PATCH_KEY]) {
        Object.defineProperty(wrappedFetch, ECOLOGY_PATCH_KEY, { value: true, enumerable: false });
    }
    globalThis.fetch = wrappedFetch;
    return true;
}

function installGenerateRawPolicy() {
    const tavern = globalThis.SillyTavern;
    const originalGetContext = tavern?.getContext;
    if (typeof originalGetContext !== 'function' || originalGetContext[PATCH_KEY]) return false;
    const cache = new WeakMap();

    const wrappedGetContext = function worldBackstageCommunicationVoiceGetContext(...args) {
        const context = originalGetContext.apply(this, args);
        const raw = context?.generateRaw;
        if (!context || typeof raw !== 'function' || raw[PATCH_KEY]) return context;
        let wrapped = cache.get(raw);
        if (!wrapped) {
            wrapped = function worldBackstageCommunicationVoiceGenerateRaw(options = {}) {
                return raw.call(context, adaptGenerateRawOptions(options, context));
            };
            Object.defineProperty(wrapped, PATCH_KEY, { value: true, enumerable: false });
            if (raw[ECOLOGY_PATCH_KEY]) {
                Object.defineProperty(wrapped, ECOLOGY_PATCH_KEY, { value: true, enumerable: false });
            }
            cache.set(raw, wrapped);
        }
        try {
            context.generateRaw = wrapped;
            return context;
        } catch {
            return new Proxy(context, {
                get(target, property, receiver) {
                    if (property === 'generateRaw') return wrapped;
                    return Reflect.get(target, property, receiver);
                },
            });
        }
    };
    Object.defineProperty(wrappedGetContext, PATCH_KEY, { value: true, enumerable: false });
    tavern.getContext = wrappedGetContext;
    return true;
}

function install() {
    installFetchPolicy();
    if (installGenerateRawPolicy()) return;
    let attempts = 0;
    const timer = globalThis.setInterval(() => {
        attempts += 1;
        if (installGenerateRawPolicy() || attempts >= 40) globalThis.clearInterval(timer);
    }, 250);
}

if (globalThis.SillyTavern || globalThis.document) install();