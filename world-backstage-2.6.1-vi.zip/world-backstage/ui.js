import { LINGQI_MASCOT_DATA_URLS } from './lingqi-assets.js';
import {
    eventProgress,
    formatDuration,
    formatWorldCalendar,
    formatWorldClockFactLabel,
    formatWorldMinute,
    isActiveEvent,
    isTerminalEvent,
} from './core.js';
import { filterWorldbookEntries, isWorldbookEntryManuallySelectable } from './worldbook.js';

const WB_PANEL_STABILITY_HINT = 'fold:7/2';

const VIEWS = [
    { id: 'now', label: 'Lúc này', eyebrow: 'NOW' },
    { id: 'lingqi', label: '玲七', eyebrow: 'LINGQI' },
    { id: 'social', label: 'Liên lạc', eyebrow: 'SOCIAL' },
    { id: 'people', label: 'Nhân vật', eyebrow: 'PEOPLE' },
    { id: 'currents', label: 'Mạch ngầm', eyebrow: 'CURRENTS' },
    { id: 'echoes', label: 'Tiếng vọng', eyebrow: 'ECHOES' },
    { id: 'opinion', label: 'Dư luận', eyebrow: 'PUBLIC' },
    { id: 'memory', label: 'Ký ức', eyebrow: 'MEMORY' },
    { id: 'archive', label: 'Biên niên', eyebrow: 'ARCHIVE' },
];

const TOAST_FACES = {
    success: '(｡•̀ᴗ-)✧',
    busy: '( •̀ ω •́ )',
    info: '( •ᴗ• )',
    normal: '( •ᴗ• )',
    warning: '(・_・;)',
    error: '(；′⌒`)',
};

const TOAST_LABELS = {
    success: 'Xong rồi',
    busy: 'Đang cố gắng',
    info: 'Mẹo nhỏ',
    normal: 'Mẹo nhỏ',
    warning: 'Đợi chút',
    error: 'Có lỗi rồi',
};

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function escapeAttr(value) {
    return escapeHtml(value).replaceAll('`', '&#096;');
}


function foldOpenAttr(openFolds, key, defaultOpen = false) {
    const isOpen = openFolds instanceof Set ? openFolds.has(key) : defaultOpen;
    return isOpen ? 'open' : '';
}

function renderFoldToolbar(prefix) {
    return `
        <div class="wb-fold-toolbar" aria-label="Điều khiển thu gọn">
            <button type="button" data-wb-action="expand-folds" data-fold-prefix="${escapeAttr(prefix)}">Mở rộng tất cả</button>
            <button type="button" data-wb-action="collapse-folds" data-fold-prefix="${escapeAttr(prefix)}">Thu gọn tất cả</button>
        </div>
    `;
}

function compactText(value, maximum = 64) {
    const text = String(value || '').replace(/\s+/g, ' ').trim();
    if (text.length <= maximum) return text;
    return `${text.slice(0, Math.max(1, maximum - 1)).trimEnd()}…`;
}

function normalizeGroupLabel(value, fallback = 'Khác') {
    const label = String(value || '').trim();
    return label || fallback;
}

function groupItems(items, getGroup) {
    const groups = new Map();
    for (const item of items) {
        const descriptor = getGroup(item);
        const rawLabel = typeof descriptor === 'object' && descriptor
            ? descriptor.label
            : descriptor;
        const label = normalizeGroupLabel(rawLabel);
        const rawKey = typeof descriptor === 'object' && descriptor
            ? descriptor.key
            : label;
        const key = normalizeGroupLabel(rawKey, label).toLocaleLowerCase();
        if (!groups.has(key)) groups.set(key, { key, label, items: [] });
        groups.get(key).items.push(item);
    }
    return [...groups.values()];
}
function formatLocalTimestamp(value) {
    const date = new Date(String(value || ''));
    if (!Number.isFinite(date.getTime())) return 'Không rõ thời gian';
    return date.toLocaleString('zh-CN', {
        month: 'numeric',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
    });
}

function estimatedClockProgress(state) {
    const resolution = state.lastTimeResolution;
    return resolution?.method === 'model-elapsed'
        && state.clock?.source === 'world-clock'
        && Number(resolution.afterMinute) === Number(state.clock.absoluteMinute)
        ? Math.max(0, Number(resolution.afterMinute) - Number(resolution.beforeMinute)) || 0
        : 0;
}

function worldClockLabel(state) {
    const progress = estimatedClockProgress(state);
    return formatWorldClockFactLabel(state)
        + (progress > 0 ? ` · Lượt này ước tính theo hành động, đã đẩy thời gian khoảng ${formatDuration(progress)}` : '');
}


function pluginReleaseStage(version = '') {
    const text = String(version || '');
    if (/-rc\./i.test(text)) return 'Bản RC';
    if (/-alpha|-beta|dev\./i.test(text)) return 'Bản thử nghiệm';
    return 'Bản chính thức';
}

function pluginDisplayVersion(version = '') {
    const text = String(version || '');
    if (/^2\.5\.\d+$/i.test(text)) return 'Bản Mèo Con V2.5';
    if (/^2\.4\.\d+(?:-|$)/i.test(text)) return 'Bản Mèo Con V2.4';
    if (/^2\.3\.0-alpha\.\d+$/i.test(text)) return 'Bản Mèo Con V2.3 · Bản trải nghiệm';
    if (/^2\.2\.\d+$/i.test(text)) return 'Bản Mèo Con V2.2';
    return `${pluginReleaseStage(text)} ${text || '1.1.0'}`;
}

function themeFor(state, settings) {
    if (settings.theme === 'day' || settings.theme === 'night') return settings.theme;
    const hour = formatWorldMinute(state.clock.absoluteMinute).hour;
    return hour >= 6 && hour < 18 ? 'day' : 'night';
}

function eventStatusLabel(event) {
    return {
        active: 'Đang phát triển',
        waiting: 'Chờ điều kiện',
        ready: 'Đến hạn, chờ xác nhận',
        resolved: 'Đã kết thúc',
        cancelled: 'Đã hủy',
        missed: 'Đã lỡ mất',
    }[event.status] || event.status;
}

function visibilityLabel(value) {
    return {
        hidden: 'Nhân vật chưa thể biết',
        trace: 'Có thể nhận ra qua dấu vết',
        known: 'Có thể biết qua tin tức',
        direct: 'Có thể trực tiếp cảm nhận',
    }[value] || 'Nhân vật chưa thể biết';
}

function deliveryLabel(event) {
    if (event.status === 'ready') return 'Đến giờ chờ nền xác nhận';
    return {
        none: 'Chỉ có hiệu lực ở hậu trường',
        pending: 'Chờ hé lộ tự nhiên',
        delivered: 'Đã được chính văn tiếp nhận',
        expired: 'Chưa hé lộ, chuyển vào Biên niên',
    }[event.delivery?.state] || 'Chỉ có hiệu lực ở hậu trường';
}

function clockModeLabel(value) {
    return {
        duration: 'Trôi tự nhiên',
        active: 'Giờ làm hiệu quả',
        scheduled: 'Thời gian định trước',
        condition: 'Chờ điều kiện',
    }[value] || 'Trôi tự nhiên';
}

function renderBrandMark() {
    return `
        <span class="wb-brand-mark" aria-hidden="true">
            <i class="wb-orbit wb-orbit-a"></i>
            <i class="wb-orbit wb-orbit-b"></i>
            <i class="wb-brand-core"></i>
        </span>
    `;
}

function renderEmpty(label, detail = '') {
    return `
        <div class="wb-empty">
            <span class="wb-empty-eye"></span>
            <strong>${escapeHtml(label)}</strong>
            ${detail ? `<p>${escapeHtml(detail)}</p>` : ''}
        </div>
    `;
}

function renderPersonAvatar(person, size = '') {
    const glyph = person?.monogram || person?.name?.slice(0, 1) || '·';
    const avatar = String(person?.avatarDataUrl || '');
    const image = /^data:image\/(?:png|jpeg|webp|gif);base64,/i.test(avatar)
        ? `<img src="${escapeAttr(avatar)}" alt="" loading="lazy">`
        : escapeHtml(glyph);
    return `
        <span class="wb-person-avatar ${size}">
            ${image}
            <i></i>
        </span>
    `;
}

async function readPersonAvatarFile(file) {
    if (!file) return '';
    if (!String(file.type || '').startsWith('image/')) throw new Error('File này hình như không phải ảnh đâu～');
    if (Number(file.size || 0) > 8 * 1024 * 1024) throw new Error('Ảnh đại diện to quá～ Chọn ảnh dưới 8MB trước nhé.');

    const source = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('Không đọc được ảnh đại diện, đổi ảnh khác thử xem～'));
        reader.readAsDataURL(file);
    });
    const image = await new Promise((resolve, reject) => {
        const node = new Image();
        node.onload = () => resolve(node);
        node.onerror = () => reject(new Error('Trình duyệt không nhận ra ảnh này, có thể đổi sang PNG / JPG / WebP thử xem～'));
        node.src = source;
    });

    const side = Math.max(1, Math.min(image.naturalWidth || image.width, image.naturalHeight || image.height));
    const sx = Math.max(0, ((image.naturalWidth || image.width) - side) / 2);
    const sy = Math.max(0, ((image.naturalHeight || image.height) - side) / 2);
    const canvas = document.createElement('canvas');
    canvas.width = 160;
    canvas.height = 160;
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) throw new Error('Trình duyệt hiện tại không xử lý được ảnh đại diện.');
    context.drawImage(image, sx, sy, side, side, 0, 0, 160, 160);
    let result = canvas.toDataURL('image/webp', 0.78);
    if (!result.startsWith('data:image/webp')) result = canvas.toDataURL('image/jpeg', 0.78);
    if (result.length > 180000) result = canvas.toDataURL('image/jpeg', 0.62);
    if (result.length > 180000) throw new Error('Ảnh đại diện nén rồi vẫn hơi to～ Đổi ảnh đơn giản hơn thử xem nhé.');
    return result;
}

export function renderInnerVoice(person, worldMinute, compact = false) {
    if (!person.innerVoice) return '';
    return `
        <blockquote class="wb-inner-voice ${compact ? 'is-compact' : ''}">
            <p>“${escapeHtml(person.innerVoice)}”</p>
        </blockquote>
    `;
}

function renderPersonRow(person, observerMode, worldMinute) {
    return `
        <article class="wb-person-row" role="button" tabindex="0"
            data-wb-action="select-person" data-person-id="${escapeAttr(person.id)}">
            ${renderPersonAvatar(person)}
            <span class="wb-person-row-main">
                <span class="wb-person-name-line">
                    <strong>${escapeHtml(person.name)}</strong>
                    <small>${escapeHtml(person.location)}</small>
                </span>
                <span class="wb-person-action">${escapeHtml(person.action)}</span>
                ${observerMode === 'backstage' ? renderInnerVoice(person, worldMinute, true) : ''}
            </span>
            <span class="wb-row-arrow">↗</span>
        </article>
    `;
}

export function renderPersonCard(person, observerMode, worldMinute, openFolds = new Set()) {
    const foldKey = `people:${person.id}`;
    return `
        <details class="wb-fold wb-person-card" data-fold-key="${escapeAttr(foldKey)}"
            ${foldOpenAttr(openFolds, foldKey)}>
            <summary class="wb-person-card-summary">
                <span class="wb-person-summary-main">
                    ${renderPersonAvatar(person, 'is-large')}
                    <span class="wb-person-summary-copy">
                        <span class="wb-person-summary-heading">
                            <strong>${escapeHtml(person.name)}</strong>
                            <small>${escapeHtml(person.location)}</small>
                        </span>
                        <span class="wb-person-summary-action">${escapeHtml(compactText(person.action, 72) || 'Tạm thời chưa có hành động mới.')}</span>
                    </span>
                </span>
                <span class="wb-fold-meta">
                    <span class="wb-person-sim-state ${person.simulationEnabled === false ? 'is-sleeping' : ''}">
                        ${person.simulationEnabled === false ? 'Ngủ ở hậu trường' : 'Hoạt động ở hậu trường'}
                    </span>
                    <i class="wb-fold-chevron" aria-hidden="true"></i>
                </span>
            </summary>
            <div class="wb-fold-body wb-person-card-body">
                <span class="wb-person-thread is-current-action">
                    <small>Đang làm</small>
                    <strong>${escapeHtml(person.action || 'Tạm thời chưa có hành động mới.')}</strong>
                </span>
                <span class="wb-person-thread">
                    <small>Ý định ngắn hạn</small>
                    <strong>${escapeHtml(person.intent || 'Tạm chưa có ý định ngắn hạn rõ ràng.')}</strong>
                </span>
                ${person.longTermGoal ? `
                    <span class="wb-person-thread is-long-term">
                        <small>Mục tiêu dài hạn</small>
                        <strong>${escapeHtml(person.longTermGoal)}</strong>
                    </span>
                ` : ''}
                ${observerMode === 'backstage'
                    ? renderInnerVoice(person, worldMinute)
                    : '<span class="wb-known-boundary">Độc thoại hậu trường đã ẩn</span>'}
                <div class="wb-person-card-actions">
                    <button class="wb-card-action-button is-primary" type="button"
                        data-wb-action="select-person" data-person-id="${escapeAttr(person.id)}">Xem chi tiết nhân vật</button>
                    <button class="wb-card-action-button is-terminal" type="button"
                        data-wb-action="open-terminal-person" data-person-id="${escapeAttr(person.id)}">Liên lạc với TA</button>
                    <button class="wb-card-action-button is-edit" type="button" data-wb-action="open-person-editor"
                        data-person-id="${escapeAttr(person.id)}" data-person-name="${escapeAttr(person.name)}">Sửa</button>
                </div>
            </div>
        </details>
    `;
}

function renderProgress(event, state, wide = false) {
    const progress = eventProgress(event, state.clock.absoluteMinute);
    const started = formatWorldCalendar(state, event.startedAt);
    const due = Number.isFinite(Number(event.dueAt))
        ? formatWorldCalendar(state, event.dueAt)
        : null;
    const remaining = progress.remaining === null
        ? progress.phase
        : progress.remaining === 0
            ? eventStatusLabel(event)
            : `Còn lại ${formatDuration(progress.remaining)}`;

    if (progress.percent === null) {
        return `
            <div class="wb-condition-progress">
                <span>${escapeHtml(clockModeLabel(event.clockMode))}</span>
                <strong>${escapeHtml(progress.phase)}</strong>
            </div>
        `;
    }

    return `
        <div class="wb-time-progress ${wide ? 'is-wide' : ''}">
            ${wide ? `
                <div class="wb-time-progress-copy">
                    <span>${escapeHtml(started.stamp)}</span>
                    <strong>${escapeHtml(clockModeLabel(event.clockMode))}</strong>
                    <span>${due ? escapeHtml(due.stamp) : 'Thời gian hoàn thành chờ xác nhận'}</span>
                </div>
            ` : ''}
            <span class="wb-time-track">
                <i style="width:${progress.percent}%"></i>
                <b style="left:${progress.percent}%"></b>
            </span>
            <span class="wb-time-foot">
                <small>${escapeHtml(progress.phase)}</small>
                <strong>${escapeHtml(remaining)}</strong>
            </span>
        </div>
    `;
}

function renderEventCard(event, state, wide = false, openFolds = new Set()) {
    if (!wide) {
        return `
            <article class="wb-event-card">
                <div class="wb-event-topline">
                    <span class="wb-phase phase-${escapeAttr(event.status)}">${escapeHtml(eventStatusLabel(event))}</span>
                    <span>${escapeHtml(event.place)}</span>
                </div>
                <h3>${escapeHtml(event.title)}</h3>
                <p>${escapeHtml(event.summary || event.consequence || 'Sự kiện vẫn đang hình thành.')}</p>
                ${renderProgress(event, state, false)}
                <div class="wb-route">
                    <i></i>
                    ${escapeHtml(visibilityLabel(event.visibility))}
                </div>
                <div class="wb-event-card-actions">
                    <button class="wb-card-action-button is-terminal" type="button" data-wb-action="open-terminal-event"
                        data-event-id="${escapeAttr(event.id)}">Xem mọi người đang nói gì</button>
                    <button class="wb-card-action-button is-primary wb-event-delivery-toggle ${event.delivery?.manualQueued ? 'is-queued' : ''}"
                        type="button" data-wb-action="toggle-event-delivery"
                        data-event-id="${escapeAttr(event.id)}"
                        ${event.visibility === 'hidden' ? 'disabled' : ''}>
                        ${event.delivery?.manualQueued ? '✓ Hé lộ ở lượt sau' : 'Hé lộ ở lượt sau'}
                    </button>
                </div>
            </article>
        `;
    }

    const progress = eventProgress(event, state.clock.absoluteMinute);
    const remaining = progress.remaining === null
        ? progress.phase
        : progress.remaining === 0
            ? eventStatusLabel(event)
            : `Còn lại ${formatDuration(progress.remaining)}`;
    const foldKey = `currents:${event.id}`;
    return `
        <details class="wb-fold wb-event-card is-wide" data-fold-key="${escapeAttr(foldKey)}"
            ${foldOpenAttr(openFolds, foldKey)}>
            <summary class="wb-event-summary">
                <span class="wb-event-summary-copy">
                    <span class="wb-event-topline">
                        <span class="wb-phase phase-${escapeAttr(event.status)}">${escapeHtml(eventStatusLabel(event))}</span>
                        <span>${escapeHtml(event.place)}</span>
                    </span>
                    <strong>${escapeHtml(event.title)}</strong>
                    <small>${escapeHtml(compactText(event.summary || event.consequence || 'Sự kiện vẫn đang hình thành.', 90))}</small>
                </span>
                <span class="wb-fold-meta">
                    <span class="wb-fold-status">${escapeHtml(remaining)}</span>
                    <i class="wb-fold-chevron" aria-hidden="true"></i>
                </span>
            </summary>
            <div class="wb-fold-body wb-event-card-body">
                <p>${escapeHtml(event.summary || event.consequence || 'Sự kiện vẫn đang hình thành.')}</p>
                ${event.consequence ? `
                    <div class="wb-consequence">
                        <span>Hậu quả có thể xảy ra</span>
                        <strong>${escapeHtml(event.consequence)}</strong>
                    </div>
                ` : ''}
                ${renderProgress(event, state, true)}
                <div class="wb-route">
                    <i></i>
                    ${escapeHtml(visibilityLabel(event.visibility))}
                </div>
                <div class="wb-event-card-actions">
                    <button class="wb-card-action-button is-primary wb-event-delivery-toggle ${event.delivery?.manualQueued ? 'is-queued' : ''}"
                        type="button" data-wb-action="toggle-event-delivery"
                        data-event-id="${escapeAttr(event.id)}"
                        ${event.visibility === 'hidden' ? 'disabled' : ''}>
                        ${event.delivery?.manualQueued ? '✓ Hé lộ ở lượt sau' : 'Hé lộ ở lượt sau'}
                    </button>
                    <button class="wb-card-action-button is-edit" type="button" data-wb-action="open-event-editor"
                        data-event-id="${escapeAttr(event.id)}">Sửa</button>
                    <button class="wb-card-action-button is-danger" type="button" data-wb-action="delete-event"
                        data-event-id="${escapeAttr(event.id)}">Xóa</button>
                </div>
            </div>
        </details>
    `;
}

function echoOutcomeMinute(event) {
    const resolvedAt = Number(event?.resolvedAt);
    const dueAt = Number(event?.dueAt);
    const updatedAt = Number(event?.updatedAt);
    const status = String(event?.status || '');
    const timed = ['duration', 'scheduled'].includes(event?.clockMode);

    if (status === 'ready' && Number.isFinite(dueAt)) return dueAt;
    if (
        ['resolved', 'missed'].includes(status)
        && timed
        && Number.isFinite(dueAt)
        && dueAt >= 0
        && (!Number.isFinite(resolvedAt) || dueAt <= resolvedAt)
    ) {
        return dueAt;
    }
    if (Number.isFinite(resolvedAt)) return resolvedAt;
    if (Number.isFinite(dueAt)) return dueAt;
    return Number.isFinite(updatedAt) ? updatedAt : 0;
}

function renderOutcome(event, state, openFolds = new Set()) {
    const time = formatWorldCalendar(
        state,
        echoOutcomeMinute(event),
    );
    const result = event.result || event.expectedResult || event.consequence || 'Kết quả đang chờ xác nhận.';
    const foldKey = `echoes:${event.id}`;
    return `
        <article class="wb-echo-item">
            <time>${escapeHtml(`${time.shortDate} ${time.time}`)}</time>
            <span class="wb-timeline-node state-${escapeAttr(event.delivery?.state || 'none')}"></span>
            <details class="wb-fold wb-echo-card" data-fold-key="${escapeAttr(foldKey)}"
                ${foldOpenAttr(openFolds, foldKey)}>
                <summary class="wb-echo-summary">
                    <span class="wb-echo-copy">
                        <strong>${escapeHtml(event.title)}</strong>
                        <small>${escapeHtml(compactText(result, 96))}</small>
                    </span>
                    <span class="wb-fold-meta">
                        <span class="wb-record-state">${escapeHtml(deliveryLabel(event))}</span>
                        <i class="wb-fold-chevron" aria-hidden="true"></i>
                    </span>
                </summary>
                <div class="wb-fold-body wb-echo-body">
                    <p>${escapeHtml(result)}</p>
                    <div class="wb-record-actions">
                        <button class="wb-card-action-button is-edit" type="button" data-wb-action="open-record-editor"
                            data-record-kind="echo" data-record-id="${escapeAttr(event.id)}">Sửa</button>
                        <button class="wb-card-action-button is-danger" type="button" data-wb-action="delete-record"
                            data-record-kind="echo" data-record-id="${escapeAttr(event.id)}">Xóa</button>
                    </div>
                </div>
            </details>
        </article>
    `;
}

function renderArchiveEntry(entry, state, recordKind = 'archive', openFolds = new Set()) {
    const time = Number.isFinite(Number(entry.resolvedAt ?? entry.at))
        ? formatWorldCalendar(state, entry.resolvedAt ?? entry.at)
        : null;
    const title = entry.title || 'Bản ghi chưa đặt tên';
    const text = entry.result || entry.text || entry.consequence || entry.route || '';
    const tags = [
        entry.visibility ? visibilityLabel(entry.visibility) : '',
        entry.delivery?.state ? deliveryLabel(entry) : '',
        entry.deliveryState === 'expired' ? 'Chưa hé lộ, chuyển vào Biên niên' : '',
    ].filter(Boolean);
    const foldKey = `archive:${recordKind}:${entry.id}`;

    return `
        <article class="wb-archive-entry">
            <div class="wb-archive-date">
                <strong>${time ? time.date : 'Chưa định ngày'}</strong>
                <span>${time ? time.time : '—'}</span>
            </div>
            <span class="wb-archive-rule"></span>
            <details class="wb-fold wb-archive-copy" data-fold-key="${escapeAttr(foldKey)}"
                ${foldOpenAttr(openFolds, foldKey)}>
                <summary class="wb-archive-summary">
                    <span>
                        <strong>${escapeHtml(title)}</strong>
                        <small>${escapeHtml(compactText(text || 'Chuyện này đã trở thành sự thật thế giới.', 100))}</small>
                    </span>
                    <i class="wb-fold-chevron" aria-hidden="true"></i>
                </summary>
                <div class="wb-fold-body wb-archive-body">
                    <p>${escapeHtml(text || 'Chuyện này đã trở thành sự thật thế giới.')}</p>
                    <div class="wb-archive-tags">${tags.map(tag => `<span>${escapeHtml(tag)}</span>`).join('')}</div>
                    <div class="wb-record-actions">
                        <button class="wb-card-action-button is-edit" type="button" data-wb-action="open-record-editor"
                            data-record-kind="${escapeAttr(recordKind)}" data-record-id="${escapeAttr(entry.id)}">Sửa</button>
                        <button class="wb-card-action-button is-danger" type="button" data-wb-action="delete-record"
                            data-record-kind="${escapeAttr(recordKind)}" data-record-id="${escapeAttr(entry.id)}">Xóa</button>
                    </div>
                </div>
            </details>
        </article>
    `;
}

function syncPhaseLabel(phase) {
    return {
        idle: 'Chờ chính văn',
        queued: 'Đang xếp hàng',
        running: 'Đang suy diễn',
        cancelling: 'Đang dừng',
        success: 'suy diễn xong',
        error: 'Suy diễn thất bại',
        pending: 'Chờ suy diễn',
    }[phase] || 'Chờ chính văn';
}

function renderSyncStrip(syncStatus) {
    const status = syncStatus || {};
    const connection = status.lastConnection || status.connection || {};
    const memoryPhase = status.memory?.phase;
    const memoryTakesFocus = ['running', 'error'].includes(memoryPhase);
    const phase = memoryTakesFocus ? memoryPhase : (status.phase || 'idle');
    const baseDetail = memoryTakesFocus
        ? status.memory?.message || (memoryPhase === 'error' ? 'Sắp xếp ký ức chưa hoàn tất' : 'Đang sắp xếp ký ức dài hạn')
        : status.error || status.message || 'Chưa suy diễn thế giới';
    const waitingTurns = Math.max(0, Number(status.queue?.waitingTurns) || 0);
    const detail = !memoryTakesFocus && waitingTurns > 0 && !String(baseDetail).includes('chờ xử lý')
        ? `${baseDetail} · phía sau còn ${waitingTurns} lượt chờ xử lý`
        : baseDetail;
    const title = memoryTakesFocus
        ? (memoryPhase === 'error' ? 'Sắp xếp ký ức thất bại' : 'Đang sắp xếp ký ức')
        : syncPhaseLabel(phase);
    const connectionText = [
        connection.apiLabel,
        connection.model,
    ].filter(Boolean).join(' · ');
    const summary = !memoryTakesFocus && phase === 'success' ? status.summary : null;
    const changedNames = summary?.peopleNames?.length
        ? `（${summary.peopleNames.map(escapeHtml).join('、')}）`
        : '';
    const eventNames = summary?.eventTitles?.length
        ? `（${summary.eventTitles.map(escapeHtml).join('、')}）`
        : '';
    const summaryHtml = summary ? `
        <details class="wb-sync-summary">
            <summary>Thay đổi lần này</summary>
            <div>
                <span>Thời gian thế giới</span><strong>${summary.elapsedMinutes > 0 ? `+${escapeHtml(formatDuration(summary.elapsedMinutes))}` : 'Chưa tiến triển'}</strong>
                <span>Thay đổi nhân vật</span><strong>${summary.peopleChanged || 0} người ${changedNames}</strong>
                <span>Thay đổi sự kiện</span><strong>Thêm ${summary.eventsAdded || 0} · cập nhật ${summary.eventsUpdated || 0} ${eventNames}</strong>
                <span>Thay đổi ký ức</span><strong>Thêm ${summary.memoryAdded || 0} · cập nhật ${summary.memoryUpdated || 0}</strong>
                <span>Hé lộ vào chính văn</span><strong>${summary.injectionEvents || 0} sự kiện</strong>
            </div>
        </details>
    ` : '';

    return `
        <div class="wb-sync-strip is-${escapeAttr(phase)}" role="${phase === 'error' ? 'alert' : 'status'}">
            <i class="wb-sync-indicator"></i>
            <div class="wb-sync-copy">
                <strong>${escapeHtml(title)}</strong>
                <span>${escapeHtml(detail)}</span>
            </div>
            <span class="wb-sync-connection">${escapeHtml(connectionText || 'Theo API chính hiện tại của Tavern')}</span>
            ${summaryHtml}
        </div>
    `;
}

function coverageLabel(coverage) {
    return `${Math.round(Math.max(0, Math.min(1, Number(coverage) || 0)) * 100)}%`;
}

// 报告显示来源核对、未导入的条目和失败的批次。
function renderWorldbookImportReport(report) {
    if (!report || report.phase === 'idle') return '';
    if (report.running || report.phase === 'running') {
        return `<div class="wb-worldbook-status is-running">${escapeHtml(report.message || 'Đang sắp xếp～')}</div>`;
    }

    // 审校台已经把命中率逐栏位摆出来了，这里就不再重复列一遍。
    const inReview = report.phase === 'review-detail';
    const reviewed = inReview
        ? []
        : (report.people || []).filter(person => person.review?.length || person.lengthFuse);
    const dropped = (report.people || []).flatMap(person => (person.dropped || [])
        .map(item => ({ ...item, name: person.name })));
    const details = [
        ...(report.renamed || []).map(item => `<li class="is-fixed">Đã sửa tên「${escapeHtml(item.from)}」thành <strong>${escapeHtml(item.to)}</strong></li>`),
        ...reviewed.map(person => `<li class="is-review"><strong>${escapeHtml(person.name)}</strong> nên kiểm tra lại: ${
            person.lengthFuse
                ? 'Kết quả sắp xếp còn dài hơn nguyên văn, có thể đã bị viết thêm'
                : escapeHtml(person.review.map(item => `${item.label} ${coverageLabel(item.coverage)}`).join('、'))
        }</li>`),
        ...dropped.slice(0, 12).map(item => `<li class="is-dropped"><strong>${escapeHtml(item.name)}</strong> · ${escapeHtml(item.label)} không tìm thấy trong nguyên văn, đã chặn: <em>${escapeHtml(String(item.text).slice(0, 60))}</em></li>`),
        ...(report.untouched || []).map(item => `<li class="is-untouched">Mục đã chọn「${escapeHtml(item.name)}」không tạo ra nhân vật nào: ${escapeHtml(item.reason)}</li>`),
        ...(report.skipped || []).map(item => `<li class="is-skipped">${escapeHtml(item.name || 'Mục không tên')}：${escapeHtml(item.reason)}</li>`),
        ...(report.failures || []).map(item => `<li class="is-failed">Lô thứ ${item.batch} chạy không thành công (${escapeHtml((item.entries || []).join('、'))}）：${escapeHtml(item.reason)}</li>`),
    ];

    return `
        ${report.message ? `<div class="wb-worldbook-status is-${escapeAttr(report.phase)}">${escapeHtml(report.message)}</div>` : ''}
        ${details.length ? `
            <details class="wb-worldbook-import-report">
                <summary><span>Báo cáo sắp xếp lần này</span><small>${details.length} mục · bấm để mở</small></summary>
                <ul>${details.join('')}</ul>
                <p class="wb-worldbook-import-note">Nội dung bị chặn không mất đâu: mục 「Thiết lập gốc World Info」 trong mỗi thẻ nhân vật vẫn giữ trọn văn bản nguồn.</p>
            </details>
        ` : ''}
    `;
}

const IMPORT_FIELD_LABELS = Object.freeze({
    identityAnchor: 'Điểm neo danh tính',
    appearanceProfile: 'Ngoại hình',
    personalityAnchor: 'Điểm neo tính cách',
    backgroundProfile: 'Bối cảnh & quan hệ',
    abilityProfile: 'Năng lực & giới hạn',
    speakingStyle: 'Thói quen nói chuyện',
    behaviorBoundaries: 'Ranh giới hành vi',
});

// 审校台：整理结果先摆出来，勾选确认后才写进世界。高可信默认勾选，命中率偏低
// 的标黄，明显查不到原文的在上一层就已经被丢弃，根本不会出现在这里。
function renderWorldbookDraftReview(report, draftUi = {}) {
    const people = Array.isArray(report?.people) ? report.people : [];
    if (!people.length) return '';
    const skipped = draftUi.skipped instanceof Set ? draftUi.skipped : new Set();
    const droppedFields = draftUi.droppedFields instanceof Set ? draftUi.droppedFields : new Set();
    const pickedFields = draftUi.pickedFields instanceof Set ? draftUi.pickedFields : new Set();
    const targets = draftUi.targets instanceof Map ? draftUi.targets : new Map();
    const chosen = people.filter(person => !skipped.has(person.reference));

    return `
        <div class="wb-worldbook-draft-review">
            <div class="wb-worldbook-draft-head">
                <strong>Ghi sau khi xác nhận</strong>
                <small>Tổng ${people.length} người · đã chọn ${chosen.length} người. Nhân vật trùng tên khác nguồn hoặc còn mơ hồ mặc định không được chọn; hãy xác nhận vị trí ghi rồi mới tick. Các ô tô vàng cũng cần bạn chủ động xác nhận. Khớp nguyên văn chỉ đối chiếu xuất xứ câu chữ, vui lòng đồng thời xác nhận nhân vật đó thuộc về ai.</small>
            </div>
            ${people.map(person => {
                const personSkipped = skipped.has(person.reference);
                const chosenTarget = String(targets.get(person.reference) || '');
                const reviewFields = new Set((person.review || []).map(item => item.field));
                const coverageOf = field => (person.review || []).find(item => item.field === field)?.coverage;
                return `
                <div class="wb-worldbook-draft-card ${personSkipped ? 'is-skipped' : ''}">
                    <label class="wb-worldbook-draft-person">
                        <input type="checkbox" data-wb-draft-person="${escapeAttr(person.reference)}"
                            ${personSkipped ? '' : 'checked'}>
                        <span>
                            <strong>${escapeHtml(person.name)}</strong>
                            ${chosenTarget === 'new'
                                ? '<em>Tạo riêng</em>'
                                : chosenTarget.startsWith('draft:')
                                    ? '<em>Gộp với bản nháp cùng tên ở trên</em>'
                                    : person.ambiguous && !chosenTarget.startsWith('person:')
                                ? '<em class="is-warn">Bản ghi hiện có còn mơ hồ, hãy chọn nhân vật cần bổ sung hoặc tạo riêng</em>'
                                : person.existing
                                    ? `<em class="is-existing">Cập nhật nhân vật có sẵn「${escapeHtml(person.existingName || person.name)}」</em>`
                                    : '<em>Tạo mới</em>'}
                            ${person.nameConflict ? '<em class="is-warn">Trùng tên nhưng khác nguồn, hãy xác nhận có phải cùng một người không</em>' : ''}
                            ${person.lengthFuse ? '<em class="is-warn">Kết quả sắp xếp dài hơn nguyên văn, nghi bị viết thêm</em>' : ''}
                            <small>Từ: ${escapeHtml((person.sourceNames || []).join('、') || 'Mục không rõ')}</small>
                        </span>
                    </label>
                    <label class="wb-worldbook-draft-target">Vị trí ghi
                        <select data-wb-draft-target="${escapeAttr(person.reference)}">
                            ${[...(person.ambiguous || person.nameConflict ? [] : [{ value: '', label: person.existing ? `Bổ sung vào nhân vật có sẵn「${person.existingName}」` : 'Tạo nhân vật mới' }]),
                                { value: 'new', label: 'Tạo riêng, không gộp với nhân vật khác' },
                                ...(person.candidates || []).map(candidate => ({ value: `person:${candidate.id}`, label: `Bổ sung vào「${candidate.name}」 · ${candidate.source}` })),
                                ...people.slice(0, people.indexOf(person)).filter(other => other.name === person.name).map(other => ({ value: `draft:${other.reference}`, label: `Gộp với「${other.name}」ở trên thành cùng một người` })),
                            ].map(option => `<option value="${escapeAttr(option.value)}" ${String(targets.get(person.reference) || '') === option.value ? 'selected' : ''}>${escapeHtml(option.label)}</option>`).join('')}
                        </select>
                    </label>
                    <div class="wb-worldbook-draft-fields">
                        ${Object.entries(person.values || {}).map(([field, value]) => {
                            const key = `${person.reference}::${field}`;
                            const low = reviewFields.has(field);
                            // 命中率偏低的栏位默认不勾选：这个功能的核心是宁可漏掉
                            // 也不要让模型延伸，所以存疑的内容要人主动确认才写入。
                            const off = personSkipped
                                || droppedFields.has(key)
                                || (low && !pickedFields.has(key));
                            const coverage = coverageOf(field);
                            return `
                            <label class="wb-worldbook-draft-field ${low ? 'is-low' : ''} ${off ? 'is-off' : ''}">
                                <input type="checkbox" data-wb-draft-field="${escapeAttr(key)}"
                                    ${off ? '' : 'checked'} ${personSkipped ? 'disabled' : ''}>
                                <span>
                                    <b>${escapeHtml(IMPORT_FIELD_LABELS[field] || field)}</b>
                                    ${chosenTarget !== 'new' && person.retainedFields?.includes(field) ? '<em>Nội dung tác giả đã điền sẽ được giữ lại; toàn văn nguồn vẫn được lưu.</em>' : ''}
                                    ${low ? `<em>Khớp nguyên văn ${coverageLabel(coverage)}, mặc định không ghi, xác nhận không sai rồi hãy tick</em>` : ''}
                                    <p>${escapeHtml(String(value))}</p>
                                </span>
                            </label>`;
                        }).join('')}
                    </div>
                </div>`;
            }).join('')}
            <div class="wb-worldbook-draft-actions">
                <button type="button" data-wb-action="discard-worldbook-drafts">Bỏ lần sắp xếp này</button>
                <button class="wb-primary-button" type="button" data-wb-action="commit-worldbook-drafts"
                    ${chosen.length ? '' : 'disabled'}>
                    ${chosen.length ? `Xác nhận ghi (${chosen.length} người)` : 'Chưa tick ai cả'}
                </button>
            </div>
        </div>
    `;
}

function renderWorldbookImportActions(worldbook, selectedCount, draftUi = {}) {
    const report = worldbook?.aiImport || null;
    const running = Boolean(report?.running);
    const disabled = !selectedCount || running ? 'disabled' : '';
    const suffix = selectedCount ? `（${selectedCount}）` : '';
    if (report?.phase === 'review') {
        return `
            <div class="wb-worldbook-status is-review">${escapeHtml(report.message || '')}</div>
            ${renderWorldbookDraftReview(report, draftUi)}
            ${renderWorldbookImportReport({ ...report, message: '', phase: 'review-detail' })}
        `;
    }
    return `
        <div class="wb-worldbook-import-actions">
            <button class="wb-worldbook-import-button" type="submit" ${disabled}>
                ${selectedCount ? `Nhập theo quy tắc các nhân vật đã chọn${suffix}` : 'Hãy chọn nhân vật cần nhập'}
            </button>
            <button class="wb-primary-button wb-worldbook-ai-import-button" type="button"
                data-wb-action="ai-import-worldbook" ${disabled}>
                ${running ? 'Đang sắp xếp…' : `Để AI sắp xếp rồi nhập${suffix}`}
            </button>
        </div>
        <p class="wb-worldbook-import-hint">Nhập theo quy tắc không cần mạng, cắt theo từ khóa; AI sắp xếp sẽ xếp lại thiết lập vào đúng ô tương ứng, chỉ chuyển sang chứ không viết thêm, nội dung không tìm thấy trong nguyên văn sẽ bị chặn.</p>
        ${running ? '<button type="button" data-wb-action="discard-worldbook-drafts">Hủy sắp xếp</button>' : ''}
        ${renderWorldbookImportReport(report)}
    `;
}

function renderSettings(state, settings, syncStatus, openGroups = new Set(), openSubgroups = new Set(), apiDraft = null, tagFilterRules = null, tagCandidates = [], worldbookUi = {}, tavernProfiles = [], activeSection = 'common') {
    const clock = formatWorldCalendar(state);
    const clockLabel = worldClockLabel(state);
    const connection = syncStatus?.connection || {};
    const memory = syncStatus?.memory || {};
    const phase = syncStatus?.phase || 'idle';
    const historyRunning = memory.phase === 'running';
    const availableModels = Array.isArray(syncStatus?.availableModels)
        ? syncStatus.availableModels
        : [];
    const modelPull = syncStatus?.modelPull || { phase: 'idle', message: '' };
    const worldbook = syncStatus?.worldbook || { books: [], entries: [], phase: 'idle' };
    const recovery = syncStatus?.recovery || { count: 0, latest: null };
    const latestRecovery = recovery.latest || null;
    const worldbookBooks = Array.isArray(worldbook.books) ? worldbook.books : [];
    const worldbookEntries = Array.isArray(worldbook.entries) ? worldbook.entries : [];
    const worldbookQuery = String(worldbookUi.query || '').slice(0, 120);
    const worldbookOnlyPeople = Boolean(worldbookUi.onlyPeople);
    const worldbookOnlyEnabled = Boolean(worldbookUi.onlyEnabled);
    const worldbookSelectedIds = worldbookUi.selectedIds instanceof Set
        ? worldbookUi.selectedIds
        : new Set(Array.isArray(worldbookUi.selectedIds) ? worldbookUi.selectedIds.map(String) : []);
    const filteredWorldbookEntries = filterWorldbookEntries(worldbookEntries, {
        query: worldbookQuery,
        onlyPeople: worldbookOnlyPeople,
        onlyEnabled: worldbookOnlyEnabled,
    });
    const worldbookSelectedCount = worldbookSelectedIds.size;
    const rules = Array.isArray(tagFilterRules)
        ? tagFilterRules
        : (settings.tagFilterRules || []);
    const hasSavedApiKey = Boolean(settings.customApiKey);
    const apiValues = {
        customApiUrl: apiDraft?.customApiUrl ?? settings.customApiUrl,
        customApiCredential: apiDraft?.customApiCredential ?? '',
        customApiModel: apiDraft?.customApiModel ?? settings.customApiModel,
        customApiTransport: apiDraft?.customApiTransport ?? settings.customApiTransport,
        profileName: apiDraft?.profileName ?? '',
        profileId: apiDraft?.profileId ?? '',
    };
    const apiProfiles = Array.isArray(settings.apiProfiles) ? settings.apiProfiles : [];
    const tavernApiProfiles = Array.isArray(tavernProfiles) ? tavernProfiles : [];
    const apiModuleRoutes = settings.apiModuleRoutes && typeof settings.apiModuleRoutes === 'object'
        ? settings.apiModuleRoutes
        : {};
    const tavernProfileById = id => tavernApiProfiles.find(profile => String(profile.id) === String(id || '')) || null;
    const tavernProfileSelectOptions = (currentId = '') => {
        const current = String(currentId || '');
        const currentExists = Boolean(tavernProfileById(current));
        return [
            `<option value="" ${current ? '' : 'selected'}>Hãy chọn cấu hình đã lưu của Tavern</option>`,
            current && !currentExists
                ? `<option value="${escapeAttr(current)}" selected disabled>Cấu hình cũ không còn tồn tại · ${escapeHtml(current)}</option>`
                : '',
            ...tavernApiProfiles.map(profile => (
                `<option value="${escapeAttr(profile.id)}" ${current === String(profile.id) ? 'selected' : ''}>${escapeHtml(profile.name)} · ${escapeHtml(profile.model || 'Chưa chọn model')}</option>`
            )),
        ].join('');
    };
    const routeOptions = (current = 'default') => {
        const missingTavernId = String(current).startsWith('tavern-profile:')
            ? String(current).slice('tavern-profile:'.length)
            : '';
        const missingTavern = missingTavernId && !tavernProfileById(missingTavernId);
        return [
            `<option value="default" ${current === 'default' ? 'selected' : ''}>Theo kết nối mặc định của 世界背面</option>`,
            `<option value="tavern" ${current === 'tavern' ? 'selected' : ''}>Theo Tavern hiện tại</option>`,
            missingTavern
                ? `<option value="${escapeAttr(current)}" selected disabled>Cấu hình Tavern không còn tồn tại · ${escapeHtml(missingTavernId)}</option>`
                : '',
            tavernApiProfiles.length
                ? `<optgroup label="Cấu hình đã lưu của Tavern">${tavernApiProfiles.map(profile => {
                    const value = `tavern-profile:${profile.id}`;
                    return `<option value="${escapeAttr(value)}" ${current === value ? 'selected' : ''}>${escapeHtml(profile.name)} · ${escapeHtml(profile.model || 'Chưa chọn model')}</option>`;
                }).join('')}</optgroup>`
                : '',
            apiProfiles.length
                ? `<optgroup label="Cấu hình độc lập của 世界背面">${apiProfiles.map(profile => {
                    const value = `profile:${profile.id}`;
                    return `<option value="${escapeAttr(value)}" ${current === value ? 'selected' : ''}>${escapeHtml(profile.name)} · ${escapeHtml(profile.model || 'Chưa chọn model')}</option>`;
                }).join('')}</optgroup>`
                : '',
        ].join('');
    };
    const settingExplanation = (setting, value) => {
        const key = String(value);
        const maps = {
            apiMode: {
                tavern: 'Mình đi theo đường kết nối hiện tại của Tavern～ chat chính đổi model thì bên mình cũng đổi theo. Khỏi phải điền lại lần nữa ฅ',
                'tavern-profile': 'Mình nhớ cái thẻ tên của cấu hình bên Tavern～ Key, địa chỉ và model thật thì vẫn để Tavern tự giữ, mỗi lần dùng mình mới sang đọc.',
                custom: 'Mở riêng cho mình một lối nhỏ～ mình tự chui ra từ bên này, không giẫm lên đường của chat chính.',
            },
            theme: {
                auto: 'Trời sáng thì mình đổi sáng lên một chút, trời tối thì mình rúc vào màu tối～ không cần lúc nào cũng phải sờ công tắc.',
                day: 'Lúc nào cũng sáng trưng. Ừm, đồ đạc bày hết bên chân, nhìn rõ ràng.',
                night: 'Lúc nào cũng tối một chút～ tối ngồi canh nền không chói mắt, mình thích cái này.',
            },
            uiScale: {
                compact: 'Mình gom giấy tờ sát lại bên chân～ liếc một cái thấy được nhiều thứ hơn.',
                comfortable: 'Mình trải ra thế này trước～ duỗi chân thoải mái mà cũng không bị trống một mảng lớn.',
                large: 'Chữ to hơn một chút～ trên màn hình nhỏ không phải nheo mắt nhìn.',
            },
            deliveryDensity: {
                restrained: 'Mình sẽ ít tha đồ ra cạnh ống kính hơn～ nhưng ở nền, ai cần sống vẫn sống như thường.',
                balanced: 'Chuyện quan trọng mình tha ra cạnh ống kính, chuyện không quan trọng thì tạm đè dưới chân mèo. Ừm, vậy là không loạn.',
                active: 'Mình sẽ siêng tha các thay đổi ra cạnh ống kính hơn～ nhưng lúc đang bận thì mình cũng không cố nhào vào đâu.',
            },
            autoSimulationMode: {

                light: 'Mình nằm bò nhìn nhẹ nhàng thôi～ chỉ lo những thay đổi thật sự cần thiết, không chạy lung tung.',
                balanced: 'Mình sẽ ngó qua từng chỗ một～ cái gì cần động thì tự động, không có chuyện gì thì mình không lấy chân khều bừa.',
                deep: 'Mình sẽ ngồi canh lâu hơn, soi kỹ cả người lẫn nhân quả ngoài ống kính～ thế giới phức tạp thì dùng cái này.',
            },
            timePolicy: {
                world: 'Mình canh đồng hồ thế giới～ chính văn nói rõ mấy giờ thì mình mới khều kim qua đó.',
                explicit: 'Thật sự tính ra được thì mình mới chỉnh. Tính không chuẩn à? Vậy mình không đụng.',
                cautious: 'Có thể cho mình đoán một chút xíu～ nhưng không chắc thì mình rụt chân lại.',
                open: 'Mấy chuyện nhìn là biết tốn thời gian như đi đường, chờ đợi, làm việc, mình sẽ tiện tay đẩy đồng hồ lên trước.',
            },
            publicOpinionRevealMode: {
                observe: 'Mình đè hết tiếng gió bên ngoài ở góc này～ bạn đến xem thì mình mới lật ra cho, không tha vào chính văn.',
                relevant: 'Thật sự liên quan đến đoạn cốt truyện trước mắt thì mình mới tha sang một chút～ không liên quan thì mình cứ đè tiếp.',
            },
        };
        return maps[setting]?.[key] || '';
    };
    const historyPercent = memory.total > 0
        ? Math.min(100, Math.round((Number(memory.processed) || 0) / memory.total * 100))
        : 0;
    const themeButton = (id, label) => `
        <button type="button" data-wb-action="setting-button"
            data-setting="theme" data-value="${id}"
            class="${settings.theme === id ? 'is-active' : ''}">${label}</button>
    `;
    const densityButton = (id, label) => `
        <button type="button" data-wb-action="setting-button"
            data-setting="deliveryDensity" data-value="${id}"
            class="${settings.deliveryDensity === id ? 'is-active' : ''}">${label}</button>
    `;
    const settingButton = (setting, current, id, label) => `
        <button type="button" data-wb-action="setting-button"
            data-setting="${setting}" data-value="${id}"
            class="${String(current) === String(id) ? 'is-active' : ''}">${label}</button>
    `;
    const generationLimits = settings.generationModuleLimits && typeof settings.generationModuleLimits === 'object'
        ? settings.generationModuleLimits
        : {};
    const automaticTimeouts = {
        simulation: 180000,
        observation: 120000,
        history: 300000,
        opinion: 150000,
    };
    const generationModuleLabel = {
        simulation: 'Suy diễn thế giới',
        observation: 'Quan sát nhân vật',
        history: 'Lịch sử / Ký ức',
        opinion: 'Dư luận / Dạo chơi',
    };
    const generationLimitFor = key => generationLimits[key] || { maxTokens: 0, timeoutMs: 0 };
    const effectiveGenerationTokenLabel = key => {
        const moduleLimit = generationLimitFor(key);
        const cap = Number(moduleLimit.maxTokens) > 0
            ? Number(moduleLimit.maxTokens)
            : Number(settings.maxOutputTokens) > 0
                ? Number(settings.maxOutputTokens)
                : 0;
        return cap > 0 ? `Tối đa ${Math.round(cap / 100) / 10}K` : 'Ngân sách tự động';
    };
    const effectiveGenerationTimeoutLabel = key => {
        const moduleLimit = generationLimitFor(key);
        const timeoutMs = Number(moduleLimit.timeoutMs) > 0
            ? Number(moduleLimit.timeoutMs)
            : Number(settings.generationTimeoutMs) > 0
                ? Number(settings.generationTimeoutMs)
                : automaticTimeouts[key];
        return `${Math.round(timeoutMs / 1000)}s`;
    };
    const generationModuleRow = key => {
        const moduleLimit = generationLimitFor(key);
        return `
            <div class="wb-generation-module-row">
                <div class="wb-generation-module-copy">
                    <strong>${generationModuleLabel[key]}</strong>
                    <span>Hiện tại: ${effectiveGenerationTokenLabel(key)} · ${effectiveGenerationTimeoutLabel(key)}</span>
                </div>
                <label>Giới hạn Token
                    <input type="number" min="0" step="500"
                        data-wb-generation-limit="maxTokens" data-module="${key}"
                        value="${escapeAttr(moduleLimit.maxTokens || 0)}"
                        title="0 = kế thừa toàn cục">
                    <small>0 = kế thừa</small>
                </label>
                <label>Số giây chờ
                    <input type="number" min="0" max="600" step="15"
                        data-wb-generation-limit="timeoutSeconds" data-module="${key}"
                        value="${escapeAttr(moduleLimit.timeoutMs ? Math.round(moduleLimit.timeoutMs / 1000) : 0)}"
                        title="0 = kế thừa toàn cục">
                    <small>0 = kế thừa</small>
                </label>
            </div>
        `;
    };
    const groupOpen = id => openGroups.has(id) ? 'open' : '';
    const subgroupOpen = id => openSubgroups.has(id) ? 'open' : '';
    const sectionKey = ['common', 'injection', 'connection', 'advanced'].includes(activeSection)
        ? activeSection
        : 'common';
    const sectionButton = (id, label) => `
        <button type="button" data-wb-action="settings-section" data-section="${id}"
            class="${sectionKey === id ? 'is-active' : ''}">${label}</button>
    `;

    return `
        <div class="wb-settings-popover wb-settings-scope-global wb-settings-section-${sectionKey}" role="dialog" aria-modal="true"
            aria-label="Cài đặt chung">
            <div class="wb-settings-sticky-head">
                <div class="wb-popover-heading">
                    <div><span>Ổ nhỏ của 玲七</span><h3>Cài đặt chung</h3></div>
                    <button type="button" data-wb-action="toggle-settings" aria-label="Đóng cài đặt">×</button>
                </div>
                <nav class="wb-settings-tabs" aria-label="Phân loại cài đặt">
                    ${sectionButton('common', 'Thường dùng')}
                    ${sectionButton('injection', 'Chèn vào chính văn')}
                    ${sectionButton('connection', 'Kết nối & model')}
                    ${sectionButton('advanced', 'Nâng cao & bảo trì')}
                </nav>
            </div>

            <section class="wb-settings-section-body wb-settings-common-section">
                <div class="wb-global-flat-block">
                    <div class="wb-flat-section-heading">
                        <div><strong>Giao diện</strong><span>Đây là chỗ mình ở. Ừm… đương nhiên phải trải cho êm một chút.</span></div>
                    </div>
                    <div class="wb-flat-setting-list">
                        <div class="wb-setting-block">
                            <label>Sáng/tối giao diện</label>
                            <div class="wb-option-row">
                                ${themeButton('auto', 'Tự động')}
                                ${themeButton('day', 'Ban ngày')}
                                ${themeButton('night', 'Ban đêm')}
                            </div>
                            <p class="wb-setting-explanation">${escapeHtml(settingExplanation('theme', settings.theme))}</p>
                        </div>
                        <div class="wb-setting-block">
                            <label>Cỡ chữ giao diện</label>
                            <div class="wb-option-row">
                                ${settingButton('uiScale', settings.uiScale, 'compact', 'Gọn')}
                                ${settingButton('uiScale', settings.uiScale, 'comfortable', 'Tiêu chuẩn')}
                                ${settingButton('uiScale', settings.uiScale, 'large', 'Chữ lớn')}
                            </div>
                            <p class="wb-setting-explanation">${escapeHtml(settingExplanation('uiScale', settings.uiScale))}</p>
                        </div>
                    </div>
                </div>

                <div class="wb-global-common-grid">
                    <div class="wb-setting-toggle">
                        <div>
                            <strong>Hiện bóng nổi</strong>
                            <span>Đây là quả bóng nhỏ trước cửa nhà mình. Giấu đi cũng được, mình đâu có biến mất chỉ vì không thấy biển số nhà.</span>
                        </div>
                        <label class="wb-switch">
                            <input type="checkbox" data-wb-setting="orbEnabled"
                                ${settings.orbEnabled !== false ? 'checked' : ''}>
                            <i></i>
                        </label>
                    </div>
                    <div class="wb-setting-toggle">
                        <div>
                            <strong>Thu bóng nổi bám mép</strong>
                            <span>Không giấu hẳn biển số nhà～ hút vào mép màn hình gần nhất, giấu một nửa, lộ một nửa; bấm vào vẫn mở ra được ngay.</span>
                        </div>
                        <label class="wb-switch">
                            <input type="checkbox" data-wb-setting="orbEdgeHide"
                                ${settings.orbEdgeHide ? 'checked' : ''}>
                            <i></i>
                        </label>
                    </div>
                    <div class="wb-setting-toggle">
                        <div>
                            <strong>Bật Động cơ thế giới</strong>
                            <span>Tắt đi thì mình nằm im～ những gì đã xảy ra mình đè giữ cẩn thận, không ăn mất đâu.</span>
                        </div>
                        <label class="wb-switch">
                            <input type="checkbox" data-wb-setting="worldSimulationEnabled"
                                ${settings.worldSimulationEnabled ? 'checked' : ''}>
                            <i></i>
                        </label>
                    </div>
                    <div class="wb-setting-toggle">
                        <div>
                            <strong>Tự động chạy</strong>
                            <span>Bật thì mình tự thức dậy đi tuần～ tắt thì mình chờ bạn chọc. Không lén chạy lung tung đâu.</span>
                        </div>
                        <label class="wb-switch">
                            <input type="checkbox" data-wb-setting="worldAutoEnabled"
                                ${settings.worldAutoEnabled ? 'checked' : ''}>
                            <i></i>
                        </label>
                    </div>
                </div>
                <div class="wb-setting-toggle">
    <div>
        <strong>Liên lạc tự hoạt động</strong>
        <span>Tắt đi thì nhân vật sẽ không tự nhắn tin, gửi lời mời kết bạn, xóa bạn hay đăng Khoảnh khắc; danh bạ hiện có và các cuộc chat thủ công của bạn vẫn được giữ.</span>
    </div>
    <label class="wb-switch">
        <input type="checkbox" data-wb-setting="socialAutoEnabled"
            ${settings.socialAutoEnabled !== false ? 'checked' : ''}>
        <i></i>
    </label>
</div>
<div class="wb-settings-common-hint">
                    <strong>Đồ hay dùng mình để sẵn bên chân. Mấy thứ khác mình cất vào trong rồi.</strong>
                    <span>Nhân vật, Mạch ngầm, Ký ức, Dư luận đều có ổ riêng; cái nào cần tha cho chính văn xem thì cứ vào 「Chèn vào chính văn」 báo mình một chỗ.</span>
                </div>
            </section>

            <section class="wb-settings-section-body wb-settings-injection-section">
                <div class="wb-injection-intro">
                    <div>
                        <span>玲七 tha gì ra cạnh ống kính · không chèn ≠ không chạy</span>
                        <strong>Chúng vẫn đang sống ở phía sau. Bạn chỉ cần bảo mình: cái nào tha ra cạnh ống kính, cái nào tạm đè dưới chân mèo.</strong>
                    </div>
                    <label class="wb-switch wb-injection-master">
                        <input type="checkbox" data-wb-setting="worldPromptInjection"
                            ${settings.worldPromptInjection ? 'checked' : ''}>
                        <i></i>
                    </label>
                </div>

                <div class="wb-injection-source-list ${settings.worldPromptInjection ? '' : 'is-master-off'}">
                    <article class="wb-injection-source is-time">
                        <div class="wb-injection-source-copy">
                            <small class="wb-injection-source-board">Từ thanh bên 「Lúc này」</small>
                            <strong>Thời gian thế giới</strong>
                            <span>Đồng hồ mình vẫn ôm, không làm mất đâu. Ở đây chỉ quyết định có đưa thời gian cho chính văn hay không.</span>
                        </div>
                        <div class="wb-time-mode-picker" role="group" aria-label="Cách chèn thời gian thế giới">
                            <button type="button" data-wb-action="setting-button" data-setting="injectionTimeMode" data-value="full"
                                class="${settings.injectionTimeMode === 'full' ? 'is-active' : ''}">
                                <strong>Đầy đủ</strong><small>Ngày + buổi + giờ cụ thể</small>
                            </button>
                            <button type="button" data-wb-action="setting-button" data-setting="injectionTimeMode" data-value="anchor"
                                class="${settings.injectionTimeMode === 'anchor' ? 'is-active' : ''}">
                                <strong>Điểm neo tối thiểu</strong><small>Chỉ giữ thời gian cần cho tính liên tục</small>
                            </button>
                            <button type="button" data-wb-action="setting-button" data-setting="injectionTimeMode" data-value="off"
                                class="${settings.injectionTimeMode === 'off' ? 'is-active' : ''}">
                                <strong>Tắt</strong><small>Không đưa thời gian cho chính văn</small>
                            </button>
                        </div>
                    </article>
                    <article class="wb-injection-source">
                        <div class="wb-injection-source-copy"><small class="wb-injection-source-board">Từ thanh bên 「Lúc này」</small><strong>Bối cảnh thế giới</strong><span>Đây là nền móng của thế giới, mình sẽ đè cho vững, không để ai lấy móng cào bậy.</span></div>
                        <label class="wb-switch"><input type="checkbox" data-wb-setting="injectionWorldBackground" ${settings.injectionWorldBackground !== false ? 'checked' : ''}><i></i></label>
                    </article>
                    <article class="wb-injection-source">
                        <div class="wb-injection-source-copy"><small class="wb-injection-source-board">Từ thanh bên 「Nhân vật」</small><strong>Trạng thái hiện tại</strong><span>${settings.worldSimulationEnabled ? 'Họ vẫn sẽ sống ngày thường ở phía sau, mình ngồi canh thay bạn.' : 'Động cơ thế giới đang nghỉ, họ tạm dừng ở trạng thái hiện tại.'}</span></div>
                        <label class="wb-switch"><input type="checkbox" data-wb-setting="injectionPeople" ${settings.injectionPeople !== false ? 'checked' : ''}><i></i></label>
                    </article>
                    <article class="wb-injection-source">
                        <div class="wb-injection-source-copy"><small class="wb-injection-source-board">Từ thanh bên 「Mạch ngầm」</small><strong>Sự kiện đang diễn ra và môi trường thế giới</strong><span>${settings.worldSimulationEnabled ? 'Chuyện ngoài ống kính vẫn tiếp tục tiến lên, mình ngồi bên cạnh trông chừng.' : 'Động cơ thế giới đang nghỉ, Mạch ngầm tạm dừng ở đây.'}</span></div>
                        <label class="wb-switch"><input type="checkbox" data-wb-setting="injectionEvents" ${settings.injectionEvents !== false ? 'checked' : ''}><i></i></label>
                    </article>
                    <article class="wb-injection-source">
                        <div class="wb-injection-source-copy"><small class="wb-injection-source-board">Từ thanh bên 「Tiếng vọng」</small><strong>Hậu quả đã kết toán</strong><span>Hậu quả đã xảy ra mình sẽ đè giữ, không để nó lặng lẽ lăn mất.</span></div>
                        <label class="wb-switch"><input type="checkbox" data-wb-setting="injectionEchoes" ${settings.injectionEchoes !== false ? 'checked' : ''}><i></i></label>
                    </article>
                    <article class="wb-injection-source">
                        <div class="wb-injection-source-copy"><small class="wb-injection-source-board">Từ thanh bên 「Lúc này」</small><strong>Sự thật thế giới</strong><span>Đây là những sự thật đã thành lập, mình phải dùng để đối chiếu, không được tiện tay khều loạn.</span></div>
                        <label class="wb-switch"><input type="checkbox" data-wb-setting="injectionFacts" ${settings.injectionFacts !== false ? 'checked' : ''}><i></i></label>
                    </article>
                    <article class="wb-injection-source">
                        <div class="wb-injection-source-copy"><small class="wb-injection-source-board">Từ thanh bên 「Ký ức」</small><strong>Ký ức dài hạn</strong><span>${settings.memorySystemEnabled ? 'Ký ức mình sẽ cất từng tấm một cẩn thận, nhét vào đúng hộp của nó.' : 'Hệ thống ký ức đang nghỉ, ký ức cũ vẫn còn, mình không làm mất đâu.'}</span></div>
                        <label class="wb-switch"><input type="checkbox" data-wb-setting="injectionMemory" ${settings.injectionMemory !== false ? 'checked' : ''}><i></i></label>
                    </article>
                    <article class="wb-injection-source">
                        <div class="wb-injection-source-copy"><small class="wb-injection-source-board">Từ thanh bên 「Dư luận」</small><strong>Tin tức và diễn đàn</strong><span>${settings.publicOpinionAutoEnabled ? 'Tiếng động bên ngoài mình vẫn sẽ dỏng tai nghe.' : 'Mình tạm không tự nghe ngóng nữa nha, muốn xem thì vẫn có thể gọi mình đi thủ công.'}</span></div>
                        <label class="wb-switch"><input type="checkbox" data-wb-setting="injectionPublicOpinion" ${settings.injectionPublicOpinion !== false ? 'checked' : ''}><i></i></label>
                    </article>
                    <article class="wb-injection-source">
                        <div class="wb-injection-source-copy"><small class="wb-injection-source-board">Từ thanh bên 「Liên lạc」</small><strong>Chat gần đây</strong><span>Mặc định tắt; bật lên thì cũng chỉ đưa cho chính văn dưới dạng “bản ghi liên lạc chưa kết toán”.</span></div>
                        <label class="wb-switch"><input type="checkbox" data-wb-setting="injectionSocial" ${settings.injectionSocial === true ? 'checked' : ''}><i></i></label>
                    </article>
                </div>

                <div class="wb-injection-behavior">
                    <div class="wb-flat-section-heading"><div><strong>Chiến lược hé lộ</strong><span>Những thứ đã cho phép tha ra, mình nên đứng gần ống kính tới đâu</span></div></div>
                    <div class="wb-setting-block">
                        <label>Mức hé lộ vào chính văn</label>
                        <div class="wb-option-row">
                            ${densityButton('restrained', 'Tiết chế')}
                            ${densityButton('balanced', 'Cân bằng')}
                            ${densityButton('active', 'Sôi nổi')}
                        </div>
                        <p class="wb-setting-explanation">${escapeHtml(settingExplanation('deliveryDensity', settings.deliveryDensity))}</p>
                    </div>
                    <div class="wb-setting-block">
                        <label for="wb-scene-timing-global">Thời điểm hé lộ</label>
                        <select id="wb-scene-timing-global" data-wb-setting="sceneTiming">
                            <option value="strict" ${settings.sceneTiming === 'strict' ? 'selected' : ''}>Nghiêm ngặt: chỉ khi chuyển cảnh hoặc lúc trống</option>
                            <option value="smart" ${settings.sceneTiming === 'smart' ? 'selected' : ''}>Thông minh: lùi lại ở cảnh then chốt</option>
                            <option value="open" ${settings.sceneTiming === 'open' ? 'selected' : ''}>Cởi mở: cho phép thay đổi ngắn, tự nhiên</option>
                        </select>
                    </div>
                </div>
                <p class="wb-injection-bottom-note">Tắt công tắc tổng thì mình đè hết mọi thứ ở sau ống kính. Thế giới vẫn sống như thường, chỉ là mình không tha cái nào ra trước cả.</p>
            </section>

            <details class="wb-settings-group wb-settings-connection-section" data-settings-group="connection" ${sectionKey === 'connection' ? 'open' : groupOpen('connection')}>
                <summary><span>Kết nối</span><small>API và model</small></summary>
                <div class="wb-settings-group-body wb-settings-subgroup-stack">
                    <div class="wb-settings-flat-section">
            <div class="wb-connection-card is-${escapeAttr(phase)}">
                <div>
                    <span>Kết nối suy diễn thế giới</span>
                    <strong>${escapeHtml(connection.apiLabel || 'Theo API chính hiện tại của Tavern')}</strong>
                </div>
                <dl>
                    <dt>Model</dt><dd>${escapeHtml(connection.model || 'Theo model hiện tại của Tavern')}</dd>
                    ${connection.profile ? `<dt>Hồ sơ kết nối</dt><dd>${escapeHtml(connection.profile)}</dd>` : ''}
                    <dt>Phương thức</dt><dd>${escapeHtml(connection.method || 'Suy diễn với ngữ cảnh độc lập')}</dd>
                    <dt>Trạng thái</dt><dd>${escapeHtml(syncPhaseLabel(phase))}</dd>
                </dl>
                ${syncStatus?.error ? `<p>${escapeHtml(syncStatus.error)}</p>` : ''}
                <small>${settings.apiMode === 'custom'
                    ? 'Mình đi lối nhỏ của riêng mình～ bên chat chính không cần nhường đường cho mình.'
                    : settings.apiMode === 'tavern-profile'
                        ? 'Mình chỉ nhớ thẻ tên cấu hình, không chép Key đi. Bên Tavern đổi model hay địa chỉ thì lần sau dùng mình sẽ đọc được cái mới.'
                        : 'Mình đi theo đường hiện tại của Tavern～ không cần vẽ thêm bản đồ thứ hai cho mình.'}</small>
            </div>

            <div class="wb-setting-block">
                <label>Kết nối suy diễn thế giới</label>
                <div class="wb-option-row">
                    ${settingButton('apiMode', settings.apiMode, 'tavern', 'Theo Tavern hiện tại')}
                    ${settingButton('apiMode', settings.apiMode, 'tavern-profile', 'Cấu hình đã lưu của Tavern')}
                    ${settingButton('apiMode', settings.apiMode, 'custom', 'API độc lập')}
                </div>
                <p class="wb-setting-explanation">${escapeHtml(settingExplanation('apiMode', settings.apiMode))}</p>
                ${settings.apiMode === 'tavern-profile' ? `
                    <label class="wb-tavern-profile-picker">Chọn cấu hình Tavern
                        <select data-wb-tavern-profile-select>
                            ${tavernProfileSelectOptions(settings.tavernApiProfileId)}
                        </select>
                    </label>
                    <p>${tavernApiProfiles.length
                        ? 'Ở đây chỉ lưu ID cấu hình～ Key, địa chỉ API, model và Secret vẫn do SillyTavern quản lý. Cấu hình bị sửa thì lần sau mình đọc thẳng giá trị mới; cấu hình bị xóa thì mình sẽ dừng lại báo lỗi, không lén đổi đường.'
                        : 'Mình không đọc được cấu hình kết nối Tavern nào dùng được. Hãy vào Connection Manager của SillyTavern lưu một cấu hình trước, rồi quay lại chọn nó.'}</p>
                ` : ''}
            </div>
                    </div>
                    <details class="wb-settings-subgroup" data-settings-subgroup="connection-custom" ${subgroupOpen('connection-custom')}>
                        <summary><span>Cấu hình API độc lập</span><small>Địa chỉ, Key, model và cách kết nối</small></summary>
                        <div class="wb-settings-subgroup-body">
                <form class="wb-api-form" data-wb-form="api" autocomplete="off">
                    <input type="hidden" name="profileId" value="${escapeAttr(apiValues.profileId)}">
                    <div class="wb-api-draft-heading">
                        <span>${apiValues.profileId ? 'Mình đang sửa cấu hình đã lưu này～ để trống Key thì tiếp tục dùng Key cũ.' : (hasSavedApiKey ? 'API độc lập mặc định mình nhớ rồi nha～ Key cũ sẽ không bày ra cho người khác xem nữa.' : 'Có thể đưa mình một API thử trước～ hay dùng thì lưu thành cấu hình, sau này các module khác cũng dùng thẳng được.')}</span>
                        <button type="button" data-wb-action="reset-api-draft">Xóa và điền lại</button>
                    </div>
                    <label>Địa chỉ API
                        <input name="customApiUrl" type="url" required
                            value="${escapeAttr(apiValues.customApiUrl)}"
                            autocomplete="off" inputmode="url" autocapitalize="none" spellcheck="false"
                            placeholder="https://example.com/v1">
                    </label>
                    <p>Địa chỉ chỉ cần điền tới tầng phiên bản, ví dụ <code>/v1</code>～ phần <code>/chat/completions</code> phía sau mình tự thêm.</p>
                    <label>API Key
                        <span class="wb-api-secret-field">
                            <input class="wb-secret-input" name="customApiCredential" type="text"
                                value="${escapeAttr(apiValues.customApiCredential)}"
                                placeholder="${hasSavedApiKey ? 'Để trống thì tiếp tục dùng Key đã lưu' : 'Nhập API Key'}"
                                autocomplete="one-time-code" autocapitalize="none" spellcheck="false"
                                data-lpignore="true" data-1p-ignore data-form-type="other"
                                ${hasSavedApiKey ? '' : 'required'}>
                            <button type="button" data-wb-action="toggle-api-key-visibility"
                                aria-pressed="false">Hiện</button>
                        </span>
                    </label>
                    <p>${hasSavedApiKey
                        ? 'Điền Key mới thì mình thay Key cũ; để trống thì mình dùng tiếp Key cũ. Key cũ sẽ không hiện lại trong ô nhập, kẻo điện thoại tự điền bậy.'
                        : 'Key mình chỉ để trong cài đặt tiện ích SillyTavern trên máy này, không nhét vào trạng thái thế giới khi xuất.'}</p>
                    <label>Tên model
                        <input name="customApiModel" required list="wb-custom-model-list"
                            value="${escapeAttr(apiValues.customApiModel)}"
                            autocomplete="off" autocapitalize="none" spellcheck="false"
                            placeholder="gemini-2.5-flash">
                        <datalist id="wb-custom-model-list">
                            ${availableModels.map(model => `<option value="${escapeAttr(model)}"></option>`).join('')}
                        </datalist>
                    </label>
                    ${availableModels.length ? `
                        <label class="wb-api-model-picker">Chọn từ danh sách đã tải
                            <select data-wb-api-model-picker>
                                <option value="">Bấm vào đây để chọn (${availableModels.length} model)</option>
                                ${availableModels.map(model => `<option value="${escapeAttr(model)}" ${model === apiValues.customApiModel ? 'selected' : ''}>${escapeHtml(model)}</option>`).join('')}
                            </select>
                        </label>
                        <p>Chọn từ danh sách sẽ điền vào tên model ở trên; bạn vẫn có thể tự nhập model ngoài danh sách.</p>
                    ` : ''}
                    <label>Cách kết nối
                        <select name="customApiTransport">
                            <option value="proxy" ${apiValues.customApiTransport === 'proxy' ? 'selected' : ''}>
                                Chuyển tiếp qua máy chủ Tavern (khuyên dùng)
                            </option>
                            <option value="direct" ${apiValues.customApiTransport === 'direct' ? 'selected' : ''}>
                                Trình duyệt kết nối trực tiếp
                            </option>
                        </select>
                    </label>
                    <label>Tên cấu hình (tùy chọn)
                        <input name="profileName" maxlength="80"
                            value="${escapeAttr(apiValues.profileName)}"
                            autocomplete="off" placeholder="Ví dụ: Pro chủ lực / Flash trạm miễn phí">
                    </label>
                    <p>Chỉ thử tạm thì không cần đặt tên～ muốn dùng lại sau này thì mình giúp bạn cất thành một cấu hình.</p>
                    <div class="wb-api-actions">
                        <button class="wb-api-action is-primary" type="submit">Lưu làm API độc lập mặc định và áp dụng</button>
                        <button class="wb-api-action is-accent" type="button" data-wb-action="save-api-profile-from-form">${apiValues.profileId ? 'Lưu thay đổi cấu hình' : 'Lưu thành cấu hình'}</button>
                        <button class="wb-api-action" type="button" data-wb-action="test-api">Kiểm tra kết nối</button>
                        <button class="wb-api-action" type="button" data-wb-action="pull-api-models"
                            ${modelPull.phase === 'running' ? 'disabled' : ''}>
                            ${modelPull.phase === 'running' ? 'Đang tải…' : 'Tải danh sách model'}
                        </button>
                    </div>
                    ${modelPull.message ? `<p class="wb-api-model-status is-${escapeAttr(modelPull.phase)}">${escapeHtml(modelPull.message)}</p>` : ''}
                </form>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="connection-image" ${subgroupOpen('connection-image')}>
                        <summary><span>API tạo ảnh cho Khoảnh khắc</span><small>${settings.imageApiEnabled ? 'Đã bật' : 'Mặc định tắt'}</small></summary>
                        <div class="wb-settings-subgroup-body">
                            <form class="wb-api-form wb-image-api-form" data-wb-form="image-api" autocomplete="off">
                                <label class="wb-setting-check">
                                    <input name="imageApiEnabled" type="checkbox" ${settings.imageApiEnabled ? 'checked' : ''}>
                                    <span><strong>Cho phép Khoảnh khắc tạo ảnh minh họa</strong><small>Mỗi lần làm mới tạo tối đa một ảnh; nhân vật không có động cơ đăng ảnh thì sẽ không gọi.</small></span>
                                </label>
                                <label>Địa chỉ API tạo ảnh
                                    <input name="imageApiUrl" type="url" value="${escapeAttr(settings.imageApiUrl || '')}" autocomplete="off" inputmode="url" autocapitalize="none" spellcheck="false" placeholder="https://example.com/v1">
                                </label>
                                <p>Dùng <code>/images/generations</code> tương thích OpenAI; điền tới <code>/v1</code> là được. Hiện do trình duyệt kết nối trực tiếp, API cần cho phép CORS.</p>
                                <label>API Key tạo ảnh
                                    <span class="wb-api-secret-field">
                                        <input class="wb-secret-input" name="imageApiCredential" type="text" value="" placeholder="${settings.imageApiKey ? 'Để trống thì tiếp tục dùng Key đã lưu' : 'Nhập API Key'}" autocomplete="one-time-code" autocapitalize="none" spellcheck="false" data-lpignore="true" data-1p-ignore data-form-type="other">
                                        <button type="button" data-wb-action="toggle-api-key-visibility" aria-pressed="false">Hiện</button>
                                    </span>
                                </label>
                                <label>Model tạo ảnh
                                    <input name="imageApiModel" value="${escapeAttr(settings.imageApiModel || '')}" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="Ví dụ gpt-image-1">
                                </label>
                                <label>Kích thước ảnh
                                    <select name="imageApiSize">
                                        ${['512x512', '768x768', '1024x1024', '1024x1536', '1536x1024'].map(size => `<option value="${size}" ${settings.imageApiSize === size ? 'selected' : ''}>${size}</option>`).join('')}
                                    </select>
                                </label>
                                <div class="wb-api-actions">
                                    <button class="wb-api-action is-primary" type="submit">Lưu API tạo ảnh</button>
                                    <button class="wb-api-action" type="button" data-wb-action="test-image-api">Tạo ảnh thử (sẽ tính phí)</button>
                                </div>
                                <p>Key chỉ lưu trong cài đặt tiện ích trên máy này, không đưa vào trạng thái thế giới; tắt công tắc sẽ không xóa ảnh Khoảnh khắc đã tạo.</p>
                            </form>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="connection-profiles" ${subgroupOpen('connection-profiles')}>
                        <summary><span>Cấu hình tự lưu của 世界背面</span><small>${apiProfiles.length ? `${apiProfiles.length} cấu hình` : 'Chưa lưu cấu hình nào'}</small></summary>
                        <div class="wb-settings-subgroup-body">
                            ${apiProfiles.length ? `
                                <div class="wb-api-profile-list">
                                    ${apiProfiles.map(profile => `
                                        <article class="wb-api-profile-card">
                                            <div>
                                                <strong>${escapeHtml(profile.name)}</strong>
                                                <span>${escapeHtml(profile.model || 'Chưa chọn model')} · ${escapeHtml(profile.transport === 'direct' ? 'Trình duyệt kết nối trực tiếp' : 'Tavern chuyển tiếp')}</span>
                                            </div>
                                            <div class="wb-api-profile-actions">
                                                <button class="wb-api-profile-chip is-accent" type="button" data-wb-action="edit-api-profile" data-profile-id="${escapeAttr(profile.id)}">Sửa</button>
                                                <button class="wb-api-profile-chip" type="button" data-wb-action="test-api-profile" data-profile-id="${escapeAttr(profile.id)}">Thử</button>
                                                <button class="wb-api-profile-chip" type="button" data-wb-action="pull-api-profile-models" data-profile-id="${escapeAttr(profile.id)}">Model</button>
                                                <button class="wb-api-profile-chip" type="button" data-wb-action="duplicate-api-profile" data-profile-id="${escapeAttr(profile.id)}">Nhân bản</button>
                                                <button class="wb-api-profile-chip is-danger" type="button" data-wb-action="delete-api-profile" data-profile-id="${escapeAttr(profile.id)}">Xóa</button>
                                            </div>
                                        </article>
                                    `).join('')}
                                </div>
                            ` : '<p>API hay dùng có thể lưu một chạm từ biểu mẫu API độc lập ở trên～ sau này phân luồng cho các module khác nhau thì không phải điền lại URL và Key nữa nha `(｡•̀ᴗ-)✧`</p>'}
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="connection-routing" ${subgroupOpen('connection-routing')}>
                        <summary><span>Phân luồng API theo module</span><small>Mặc định đều theo kết nối mặc định của 世界背面</small></summary>
                        <div class="wb-settings-subgroup-body">
                            <p>Ai muốn dùng model riêng thì chỉ cho người đó một lối nhỏ riêng～ không có yêu cầu gì đặc biệt thì mình đi đường mặc định, mình nhớ đường về nhà mà.</p>
                            <div class="wb-api-route-grid">
                                <label>Suy diễn thế giới
                                    <select data-wb-api-route="simulation">${routeOptions(apiModuleRoutes.simulation || 'default')}</select>
                                </label>
                                <label>Quan sát nhân vật tức thời
                                    <select data-wb-api-route="observation">${routeOptions(apiModuleRoutes.observation || 'default')}</select>
                                </label>
                                <label>Ký ức dài hạn / Sắp xếp lịch sử
                                    <select data-wb-api-route="history">${routeOptions(apiModuleRoutes.history || 'default')}</select>
                                </label>
                                <label>Dư luận thế giới
                                    <select data-wb-api-route="opinion">${routeOptions(apiModuleRoutes.opinion || 'default')}</select>
                                </label>
                            </div>
                        </div>
                    </details>

                </div>
            </details>

            <details class="wb-settings-group" data-settings-group="appearance" ${groupOpen('appearance')}>
                <summary><span>Giao diện và hé lộ</span><small>Chủ đề, cỡ chữ, chèn vào chính văn</small></summary>
                <div class="wb-settings-group-body wb-settings-subgroup-stack">
                    <details class="wb-settings-subgroup" data-settings-subgroup="appearance-ui" ${subgroupOpen('appearance-ui')}>
                        <summary><span>Giao diện</span><small>Sáng/tối và cỡ chữ đọc</small></summary>
                        <div class="wb-settings-subgroup-body">
            <div class="wb-setting-block">
                <label>Sáng/tối giao diện</label>
                <div class="wb-option-row">
                    ${themeButton('auto', 'Tự động')}
                    ${themeButton('day', 'Ban ngày')}
                    ${themeButton('night', 'Ban đêm')}
                </div>
                <p class="wb-setting-explanation">${escapeHtml(settingExplanation('theme', settings.theme))}</p>
            </div>

            <div class="wb-setting-block">
                <label>Cỡ chữ giao diện</label>
                <div class="wb-option-row">
                    ${settingButton('uiScale', settings.uiScale, 'compact', 'Gọn')}
                    ${settingButton('uiScale', settings.uiScale, 'comfortable', 'Tiêu chuẩn')}
                    ${settingButton('uiScale', settings.uiScale, 'large', 'Chữ lớn')}
                </div>
                <p class="wb-setting-explanation">${escapeHtml(settingExplanation('uiScale', settings.uiScale))}</p>
            </div>

            <div class="wb-setting-toggle">
                <div>
                    <strong>Hiện bóng nổi</strong>
                    <span>Không muốn nó nằm mãi trên màn hình thì tắt đi～ plugin vẫn chạy bình thường, sau này cũng mở lại được trong cài đặt tiện ích của Tavern.</span>
                </div>
                <label class="wb-switch">
                    <input type="checkbox" data-wb-setting="orbEnabled"
                        ${settings.orbEnabled !== false ? 'checked' : ''}>
                    <i></i>
                </label>
            </div>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="appearance-reveal" ${subgroupOpen('appearance-reveal')}>
                        <summary><span>Hé lộ</span><small>Mật độ và thời điểm đi vào chính văn</small></summary>
                        <div class="wb-settings-subgroup-body">
            <div class="wb-setting-block">
                <label>Mức hé lộ vào chính văn</label>
                <div class="wb-option-row">
                    ${densityButton('restrained', 'Tiết chế')}
                    ${densityButton('balanced', 'Cân bằng')}
                    ${densityButton('active', 'Sôi nổi')}
                </div>
                <p class="wb-setting-explanation">${escapeHtml(settingExplanation('deliveryDensity', settings.deliveryDensity))}</p>
            </div>

            <div class="wb-setting-block">
                <label for="wb-scene-timing">Thời điểm hé lộ</label>
                <select id="wb-scene-timing" data-wb-setting="sceneTiming">
                    <option value="strict" ${settings.sceneTiming === 'strict' ? 'selected' : ''}>Nghiêm ngặt: chỉ khi chuyển cảnh hoặc lúc trống</option>
                    <option value="smart" ${settings.sceneTiming === 'smart' ? 'selected' : ''}>Thông minh: lùi lại ở cảnh then chốt</option>
                    <option value="open" ${settings.sceneTiming === 'open' ? 'selected' : ''}>Cởi mở: cho phép thay đổi ngắn, tự nhiên</option>
                </select>
            </div>

            <div class="wb-setting-toggle">
                <div><strong>Công tắc tổng chèn vào chính văn</strong><span>Tắt chỉ là tạm không tha cho chính văn xem～ nhân vật, sự kiện, ký ức và dư luận vẫn tiếp tục sống ở phía sau.</span></div>
                <label class="wb-switch">
                    <input type="checkbox" data-wb-setting="worldPromptInjection"
                        ${settings.worldPromptInjection ? 'checked' : ''}>
                    <i></i>
                </label>
            </div>

            <div class="wb-injection-grid ${settings.worldPromptInjection ? '' : 'is-disabled'}">
                <div class="wb-setting-block wb-injection-time">
                    <label>「Lúc này」· Thời gian thế giới</label>
                    <div class="wb-option-row">
                        ${settingButton('injectionTimeMode', settings.injectionTimeMode, 'full', 'Đầy đủ')}
                        ${settingButton('injectionTimeMode', settings.injectionTimeMode, 'anchor', 'Điểm neo tối thiểu')}
                        ${settingButton('injectionTimeMode', settings.injectionTimeMode, 'off', 'Tắt')}
                    </div>
                    <p class="wb-setting-explanation">「Điểm neo tối thiểu」 chỉ để mình giữ tính liên tục của thời gian～ không ép chính văn đặt đồng hồ vào chính giữa ống kính.</p>
                </div>
                <div class="wb-setting-toggle"><div><strong>「Lúc này」· Bối cảnh thế giới</strong><span>Nền móng thế giới mình sẽ đè cho vững～ ở đây chỉ quyết định có đưa cho chính văn hay không.</span></div><label class="wb-switch"><input type="checkbox" data-wb-setting="injectionWorldBackground" ${settings.injectionWorldBackground !== false ? 'checked' : ''}><i></i></label></div>
                <div class="wb-setting-toggle"><div><strong>「Nhân vật」· Trạng thái hiện tại</strong><span>Vị trí và hành động của họ mình vẫn ghi như thường～ ở đây chỉ quyết định có đưa hay không.</span></div><label class="wb-switch"><input type="checkbox" data-wb-setting="injectionPeople" ${settings.injectionPeople !== false ? 'checked' : ''}><i></i></label></div>
                <div class="wb-setting-toggle"><div><strong>「Mạch ngầm」· Sự kiện đang diễn ra và môi trường thế giới</strong><span>Chuyện ngoài ống kính vẫn tiến lên như thường, mình sẽ ngồi bên cạnh trông.</span></div><label class="wb-switch"><input type="checkbox" data-wb-setting="injectionEvents" ${settings.injectionEvents !== false ? 'checked' : ''}><i></i></label></div>
                <div class="wb-setting-toggle"><div><strong>「Tiếng vọng」· Hậu quả đã kết toán</strong><span>Chỉ quyết định có tha vào chính văn hay không, không xóa hậu quả đã xảy ra.</span></div><label class="wb-switch"><input type="checkbox" data-wb-setting="injectionEchoes" ${settings.injectionEchoes !== false ? 'checked' : ''}><i></i></label></div>
                <div class="wb-setting-toggle"><div><strong>「Lúc này」· Sự thật thế giới</strong><span>Sự thật đã thành lập mình sẽ dùng để đối chiếu, không để thế giới tự mâu thuẫn.</span></div><label class="wb-switch"><input type="checkbox" data-wb-setting="injectionFacts" ${settings.injectionFacts !== false ? 'checked' : ''}><i></i></label></div>
                <div class="wb-setting-toggle"><div><strong>「Ký ức」· Ký ức dài hạn</strong><span>Tắt đi mình vẫn dọn hộp ký ức～ chỉ là không tha vào chính văn.</span></div><label class="wb-switch"><input type="checkbox" data-wb-setting="injectionMemory" ${settings.injectionMemory !== false ? 'checked' : ''}><i></i></label></div>
                <div class="wb-setting-toggle"><div><strong>「Dư luận」· Tin tức và diễn đàn</strong><span>Tiếng động bên ngoài vẫn tiếp tục thay đổi～ ở đây chỉ quyết định đứng gần ống kính tới đâu.</span></div><label class="wb-switch"><input type="checkbox" data-wb-setting="injectionPublicOpinion" ${settings.injectionPublicOpinion !== false ? 'checked' : ''}><i></i></label></div>
                <div class="wb-setting-toggle"><div><strong>「Liên lạc」· Chat gần đây</strong><span>Mặc định cách ly; bật lên thì chỉ cho chính văn tham khảo những gì đã nói, không coi lời hẹn là đã xảy ra.</span></div><label class="wb-switch"><input type="checkbox" data-wb-setting="injectionSocial" ${settings.injectionSocial === true ? 'checked' : ''}><i></i></label></div>
            </div>
            <p class="wb-setting-explanation">Các công tắc ở đây chỉ quyết định 「có cho chính văn xem hay không」～ đè dưới chân mèo không có nghĩa là nó không tồn tại đâu nha.</p>

            <div class="wb-setting-block">
                <label>Có muốn mình đưa tiếng gió lại gần hơn không</label>
                <div class="wb-option-row">
                    ${settingButton('publicOpinionRevealMode', settings.publicOpinionRevealMode, 'observe', 'Chỉ quan sát')}
                    ${settingButton('publicOpinionRevealMode', settings.publicOpinionRevealMode, 'relevant', 'Hé lộ khi liên quan')}
                </div>
                <p class="wb-setting-explanation">${escapeHtml(settingExplanation('publicOpinionRevealMode', settings.publicOpinionRevealMode))}</p>
            </div>
                        </div>
                    </details>

                </div>
            </details>

            <details class="wb-settings-group" data-settings-group="simulation" ${groupOpen('simulation')}>
                <summary><span>Vận hành thế giới</span><small>Để thế giới ngoài ống kính tự tiếp tục bước đi～</small></summary>
                <div class="wb-settings-group-body wb-settings-subgroup-stack">
                    <details class="wb-settings-subgroup" data-settings-subgroup="simulation-switches" ${subgroupOpen('simulation-switches')}>
                        <summary><span>Công tắc cơ bản</span><small>Có để nền tiếp tục chạy không</small></summary>
                        <div class="wb-settings-subgroup-body">
            <div class="wb-setting-toggle">
                <div><strong>Bật Động cơ thế giới</strong><span>Tắt thì cho nền nghỉ một lát～ thế giới hiện có không mất đâu</span></div>
                <label class="wb-switch">
                    <input type="checkbox" data-wb-setting="worldSimulationEnabled"
                        ${settings.worldSimulationEnabled ? 'checked' : ''}>
                    <i></i>
                </label>
            </div>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="simulation-trigger" ${subgroupOpen('simulation-trigger')}>
                        <summary><span>Cách vận hành</span><small>世界背面 nên siêng tới mức nào～</small></summary>
                        <div class="wb-settings-subgroup-body">
            <div class="wb-setting-block">
                <label>Cường độ vận hành thế giới</label>
                <div class="wb-option-row">
                    ${settingButton('autoSimulationMode', settings.autoSimulationMode, 'light', 'Nhẹ')}
                    ${settingButton('autoSimulationMode', settings.autoSimulationMode, 'balanced', 'Cân bằng')}
                    ${settingButton('autoSimulationMode', settings.autoSimulationMode, 'deep', 'Sâu')}
                </div>
                <p class="wb-setting-explanation">${escapeHtml(settingExplanation('autoSimulationMode', settings.autoSimulationMode))}</p>
                <label>Tần suất tự kích hoạt</label>
                <div class="wb-option-row wb-option-row-four">
                    ${settingButton('autoSimulationInterval', settings.autoSimulationInterval, 1, 'Mỗi lượt')}
                    ${settingButton('autoSimulationInterval', settings.autoSimulationInterval, 2, 'Mỗi 2 lượt')}
                    ${settingButton('autoSimulationInterval', settings.autoSimulationInterval, 3, 'Mỗi 3 lượt')}
                    ${settingButton('autoSimulationInterval', settings.autoSimulationInterval, 5, 'Mỗi 5 lượt')}
                </div>
                <label class="wb-number-setting">
                    Số lượt tích lũy tùy chỉnh
                    <input type="number" min="1" max="20" step="1"
                        data-wb-setting="autoSimulationInterval"
                        value="${escapeAttr(settings.autoSimulationInterval)}">
                </label>
                <div class="wb-setting-toggle">
                    <div><strong>Nhắc chính văn chưa suy diễn</strong><span>Tắt đi thì chỉ tự chạy theo tần suất đã đặt, không hỏi mỗi lần trả lời có muốn suy diễn bù sớm không; khi thật sự thất bại vẫn sẽ nhắc.</span></div>
                    <label class="wb-switch"><input type="checkbox" data-wb-setting="pendingSimulationPromptEnabled" ${settings.pendingSimulationPromptEnabled ? 'checked' : ''}><i></i></label>
                </div>
            </div>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="simulation-output" ${subgroupOpen('simulation-output')}>
                        <summary><span>Thất bại và yêu cầu bổ sung</span><small>Thử lại và trọng tâm suy diễn</small></summary>
                        <div class="wb-settings-subgroup-body">
            <div class="wb-setting-block">
                <label>Suy diễn thất bại rồi có để mình thử lại không</label>
                <div class="wb-option-row wb-option-row-four">
                    ${settingButton('autoRetryCount', settings.autoRetryCount, 0, 'Không thử lại')}
                    ${settingButton('autoRetryCount', settings.autoRetryCount, 1, 'Thử lại 1 lần')}
                    ${settingButton('autoRetryCount', settings.autoRetryCount, 2, 'Thử lại 2 lần')}
                    ${settingButton('autoRetryCount', settings.autoRetryCount, 3, 'Thử lại 3 lần')}
                </div>
                <label class="wb-number-setting">
                    Số lần thử lại tùy chỉnh
                    <input type="number" min="0" max="5" step="1"
                        data-wb-setting="autoRetryCount"
                        value="${escapeAttr(settings.autoRetryCount)}">
                </label>
                <label class="wb-custom-instruction">
                    Yêu cầu suy diễn tùy chỉnh
                    <textarea data-wb-setting="customSimulationInstruction" maxlength="1000" rows="3"
                        placeholder="Ví dụ: bớt tạo sự kiện mới; để ý thương hội và bến cảng nhiều hơn. 玲七 sẽ chú ý theo hướng này.">${escapeHtml(settings.customSimulationInstruction)}</textarea>
                </label>
            </div>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="simulation-npc" ${subgroupOpen('simulation-npc')}>
                        <summary><span>NPC và ranh giới người chơi</span><small>Số người ở nền và nội tâm người chơi</small></summary>
                        <div class="wb-settings-subgroup-body">
            <div class="wb-setting-block">
                <label>Ngân sách NPC nền</label>
                <div class="wb-option-row wb-option-row-four">
                    ${settingButton('backgroundNpcBudget', settings.backgroundNpcBudget, 0, 'Không chủ động suy diễn')}
                    ${settingButton('backgroundNpcBudget', settings.backgroundNpcBudget, 2, 'Tối đa 2 người')}
                    ${settingButton('backgroundNpcBudget', settings.backgroundNpcBudget, 4, 'Tối đa 4 người')}
                    ${settingButton('backgroundNpcBudget', settings.backgroundNpcBudget, 8, 'Tối đa 8 người')}
                </div>
                <label class="wb-number-setting">
                    Số người mỗi lượt tùy chỉnh
                    <input type="number" min="0" step="1"
                        data-wb-setting="backgroundNpcBudget"
                        value="${escapeAttr(settings.backgroundNpcBudget)}">
                </label>
                <p class="wb-setting-explanation">Muốn canh bao nhiêu người cứ tự điền～ khuyên dùng 2～8 người, mỗi lượt cố đừng quá 12 người; càng nhiều càng tốn Token, cũng chậm hơn.</p>
            </div>

            <div class="wb-setting-toggle">
                <div><strong>Tăng cường suy diễn nhân vật nền</strong><span>Ai cần kết toán mình sẽ tiện tay mang vào lượt suy diễn thế giới hiện có～ không mở thêm yêu cầu riêng, cũng không để họ chỉ sống khi đứng trước ống kính.</span></div>
                <label class="wb-switch">
                    <input type="checkbox" data-wb-setting="enhancedBackgroundSimulation"
                        ${settings.enhancedBackgroundSimulation ? 'checked' : ''}>
                    <i></i>
                </label>
            </div>

            <div class="wb-setting-toggle">
                <div><strong>Ghi nhận nhân vật người chơi</strong><span>Khi bật, mình chỉ ghi vị trí, hành động và trạng thái khách quan của user đã xảy ra rõ ràng trong chính văn; tắt đi thì không đưa user vào 「Nhân vật」, nhưng sự thật đã xảy ra trong chính văn vẫn được tính.</span></div>
                <label class="wb-switch">
                    <input type="checkbox" data-wb-setting="recordPlayerCharacter"
                        ${settings.recordPlayerCharacter !== false ? 'checked' : ''}>
                    <i></i>
                </label>
            </div>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="simulation-context" ${subgroupOpen('simulation-context')}>
                        <summary><span>Ngữ cảnh và thời gian</span><small>Phạm vi đọc và chiến lược đồng hồ thế giới</small></summary>
                        <div class="wb-settings-subgroup-body">
            <div class="wb-setting-block">
                <label>Phạm vi đọc chính văn</label>
                <div class="wb-option-row wb-option-row-four">
                    ${settingButton('contextTurns', settings.contextTurns, 1, '1 lượt gần nhất')}
                    ${settingButton('contextTurns', settings.contextTurns, 3, '3 lượt gần nhất')}
                    ${settingButton('contextTurns', settings.contextTurns, 5, '5 lượt gần nhất')}
                    <button type="button" data-wb-action="setting-button"
                        data-setting="contextTurns" data-value="${escapeAttr(settings.customContextTurns || 8)}"
                        class="${![1, 3, 5].includes(Number(settings.contextTurns)) ? 'is-active' : ''}">Tùy chỉnh</button>
                </div>
                ${![1, 3, 5].includes(Number(settings.contextTurns)) ? `
                    <label class="wb-number-setting wb-context-custom">
                        Số lượt gần nhất cần đọc
                        <input type="number" min="1" max="30" step="1"
                            data-wb-setting="contextTurns" value="${escapeAttr(settings.contextTurns)}">
                    </label>
                ` : ''}
                <p class="wb-setting-explanation">${escapeHtml(
                    [1, 3, 5].includes(Number(settings.contextTurns))
                        ? ({1: 'Chỉ xem lượt mới nhất, nhẹ và tiết kiệm nhất～ hợp với cốt truyện mà thông tin hiện tại đã rất rõ.', 3: 'Đọc 3 lượt gần nhất, tính liên tục và mức tiêu hao đều khá nhẹ nhàng, hợp với đa số cảnh đời thường.', 5: 'Khuyên dùng mặc định～ 5 lượt gần nhất thường đủ để nối tiếp nhân vật và sự kiện, lại không dễ làm ngữ cảnh phình tròn vo.'}[Number(settings.contextTurns)])
                        : `Hiện sẽ đọc ${settings.contextTurns} lượt gần nhất～ sự kiện dài và cốt truyện nhiều người sẽ ổn định hơn, nhưng số lượt càng cao thì Token cũng béo lên theo.`
                )}</p>
            </div>

            <div class="wb-setting-block">
                <label>Tiến trình thời gian</label>
                <div class="wb-option-row">
                    ${settingButton('timePolicy', settings.timePolicy, 'world', 'Đồng hồ thế giới')}
                    ${settingButton('timePolicy', settings.timePolicy, 'explicit', 'Nghiêm ngặt')}
                    ${settingButton('timePolicy', settings.timePolicy, 'cautious', 'Tiết chế')}
                    ${settingButton('timePolicy', settings.timePolicy, 'open', 'Cởi mở')}
                </div>
                <p class="wb-setting-explanation">${escapeHtml(settingExplanation('timePolicy', settings.timePolicy))}</p>
            </div>
                        </div>
                    </details>

                </div>
            </details>

            <details class="wb-settings-group" data-settings-group="worldbook" ${groupOpen('worldbook')}>
                <summary><span>Nhân vật World Info</span><small>Tìm kiếm, nhận diện và nhập hàng loạt</small></summary>
                <div class="wb-settings-group-body">
                    <div class="wb-settings-flat-section">
                    <form class="wb-worldbook-import" data-wb-form="worldbook">
                        <label>Chọn World Info
                            <select name="bookName" ${worldbookBooks.length ? '' : 'disabled'}>
                                ${worldbookBooks.length
                                    ? worldbookBooks.map(book => `<option value="${escapeAttr(book)}"
                                        ${book === worldbook.bookName ? 'selected' : ''}>${escapeHtml(book)}</option>`).join('')
                                    : '<option value="">Giờ mình chưa tìm thấy World Info nào đọc được</option>'}
                            </select>
                        </label>
                        <button class="wb-worldbook-scan-button" type="button" data-wb-action="scan-worldbook"
                            ${worldbook.phase === 'running' || !worldbookBooks.length ? 'disabled' : ''}>
                            ${worldbook.phase === 'running' ? 'Đang đọc…' : 'Đọc và nhận diện nhân vật'}
                        </button>
                        ${worldbook.message ? `<div class="wb-worldbook-status is-${escapeAttr(worldbook.phase)}">${escapeHtml(worldbook.message)}</div>` : ''}
                        ${worldbookEntries.length ? `
                            <div class="wb-worldbook-browser">
                                <label class="wb-worldbook-search">
                                    <span>Tìm mục</span>
                                    <input type="search" name="worldbookSearch" data-wb-worldbook-search value="${escapeAttr(worldbookQuery)}"
                                        placeholder="Tìm tên nhân vật, tên mục, từ khóa hoặc nội dung">
                                </label>
                                <div class="wb-worldbook-filter-row">
                                    <label class="wb-worldbook-filter-chip ${worldbookOnlyPeople ? 'is-active' : ''}">
                                        <input type="checkbox" data-wb-worldbook-filter="people" ${worldbookOnlyPeople ? 'checked' : ''}>
                                        <span>Chỉ xem mục có thể là nhân vật</span>
                                    </label>
                                    <label class="wb-worldbook-filter-chip ${worldbookOnlyEnabled ? 'is-active' : ''}">
                                        <input type="checkbox" data-wb-worldbook-filter="enabled" ${worldbookOnlyEnabled ? 'checked' : ''}>
                                        <span>Chỉ xem mục đang bật</span>
                                    </label>
                                </div>
                                <div class="wb-worldbook-toolbar">
                                    <span>Tổng ${worldbookEntries.length} mục · đang hiện ${filteredWorldbookEntries.length} mục · đã chọn ${worldbookSelectedCount} mục</span>
                                    <div>
                                        <button type="button" data-wb-action="select-worldbook-visible" ${filteredWorldbookEntries.length ? '' : 'disabled'}>Chọn hết mục đang hiện</button>
                                        <button type="button" data-wb-action="clear-worldbook-visible" ${filteredWorldbookEntries.length ? '' : 'disabled'}>Bỏ chọn mục đang hiện</button>
                                    </div>
                                </div>
                                <div class="wb-worldbook-entry-list">
                                    ${filteredWorldbookEntries.length ? filteredWorldbookEntries.map(entry => `
                                        <label class="wb-worldbook-entry ${entry.disabled ? 'is-disabled-entry' : ''} ${entry.likelyPerson ? 'is-person-candidate' : ''}">
                                            <input id="wb-worldbook-entry-${escapeAttr(entry.uid)}" type="checkbox" name="entryIds" data-wb-worldbook-entry-id="${escapeAttr(entry.uid)}"
                                                value="${escapeAttr(entry.uid)}" ${worldbookSelectedIds.has(String(entry.uid)) ? 'checked' : ''}>
                                            <span>
                                                <span class="wb-worldbook-entry-heading">
                                                    <strong>${escapeHtml(entry.parsedName || entry.name)}</strong>
                                                    ${entry.likelyPerson ? '<em>Có thể là nhân vật</em>' : ''}
                                                    ${entry.disabled ? '<em class="is-muted">Đã tắt</em>' : ''}
                                                </span>
                                                ${entry.parsedName && entry.parsedName !== entry.name
                                                    ? `<small>Mục: ${escapeHtml(entry.name)} · ${escapeHtml((entry.keys || []).join('、') || `UID ${entry.uid}`)}</small>`
                                                    : `<small>${escapeHtml((entry.keys || []).join('、') || `UID ${entry.uid}`)}</small>`}
                                                ${entry.profile?.matchedFields?.length
                                                    ? `<div class="wb-worldbook-profile-hints">Đã nhận diện: ${escapeHtml(entry.profile.matchedFields.slice(0, 6).map(field => ({
                                                        name: '姓名', nickname: '别称', gender: '性别', age: '年龄', birthday: '生日', species: '种族', identity: '身份', personality: '人格', values: '偏好', mbti: 'MBTI', appearance: '外貌', height: '身高', body: '体型', clothing: '穿着', background: '背景', relations: '关系', speech: 'Lời nói', behavior: 'Ranh giới hành vi',
                                                    }[field] || field)).join('、'))}</div>`
                                                    : ''}
                                                <p>${escapeHtml(entry.content.slice(0, 220))}${entry.content.length > 220 ? '…' : ''}</p>
                                            </span>
                                        </label>
                                    `).join('') : `<div class="wb-worldbook-empty">Không có mục nào với bộ lọc hiện tại. Có thể bỏ lọc hoặc đổi từ khóa.</div>`}
                                </div>
                                ${renderWorldbookImportActions(worldbook, worldbookSelectedCount, worldbookUi.draft || {})}
                            </div>
                        ` : ''}
                    </form>
                    </div>
                </div>
            </details>

            <details class="wb-settings-group" data-settings-group="memory" ${groupOpen('memory')}>
                <summary><span>Ký ức dài hạn</span><small>Tự động sắp xếp và lập hồ sơ lịch sử</small></summary>
                <div class="wb-settings-group-body wb-settings-subgroup-stack">
                    <details class="wb-settings-subgroup" data-settings-subgroup="memory-switches" ${subgroupOpen('memory-switches')}>
                        <summary><span>Công tắc ký ức</span><small>Sắp xếp và chèn vào chính văn</small></summary>
                        <div class="wb-settings-subgroup-body">
            <div class="wb-setting-toggle">
                <div><strong>Bật hệ thống ký ức</strong><span>Tắt đi thì mình không nhét thêm mẩu giấy mới～ ký ức đã cất kỹ, mình sẽ đè giữ nguyên vẹn.</span></div>
                <label class="wb-switch">
                    <input type="checkbox" data-wb-setting="memorySystemEnabled"
                        ${settings.memorySystemEnabled ? 'checked' : ''}>
                    <i></i>
                </label>
            </div>
            <p class="wb-setting-explanation">Có tha ký ức cho chính văn xem hay không, hãy vào 「Chèn vào chính văn」 báo mình～ ở đây chỉ quyết định hộp ký ức có nhận đồ mới nữa không.</p>
            <div class="wb-setting-toggle">
                <div>
                    <strong>Tự động ẩn các tầng đã lưu trữ</strong>
                    <span>Sau khi ký ức dài hạn đã được xác nhận cất xong, các tầng cũ hơn sẽ bị ẩn khỏi ngữ cảnh AI; luôn giữ lại 5 tầng chính văn đã lưu trữ gần nhất và toàn bộ chính văn chưa lưu trữ. Cần bật chèn ký ức dài hạn, lịch sử chat sẽ không bị xóa.</span>
                </div>
                <label class="wb-switch">
                    <input type="checkbox" data-wb-setting="autoHideArchivedFloors"
                        ${settings.autoHideArchivedFloors ? 'checked' : ''}
                        ${!settings.injectionMemory && !settings.autoHideArchivedFloors ? 'disabled' : ''}>
                    <i></i>
                </label>
            </div>
            <div class="wb-history-settings">
                <button type="button" data-wb-action="restore-auto-hidden-floors">Tắt và khôi phục các tầng do 世界背面 tự động ẩn</button>
                <p>Sẽ tắt tự động ẩn trước, rồi khôi phục các tầng mà 世界背面 đã tự giấu; không đụng tới nội dung bạn /hide thủ công.</p>
            </div>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="memory-history" ${subgroupOpen('memory-history')}>
                        <summary><span>Tự động sắp xếp</span><small>Tiến độ và sắp xếp thủ công</small></summary>
                        <div class="wb-settings-subgroup-body">
            <div class="wb-history-settings">
                <div class="wb-history-heading">
                    <div>
                        <label>Sắp xếp ký ức</label>
                        <strong>${escapeHtml(
                            historyRunning
                                ? memory.message || 'Đang dọn dẹp ký ức～'
                                : 'Mình sẽ tự dọn ký ức dài hạn～',
                        )}</strong>
                    </div>
                    <span>${historyRunning
    ? String(historyPercent) + '%'
    : Number(memory.pendingAssistantResponses || 0) > 0
        ? 'Có đồ mới đang chờ mình cất～'
        : memory.summaryBehind
            ? 'Tóm tắt dài hạn vẫn dừng ở mức ' + Math.max(0, Number(memory.latestSummaryMessageId || 0)) + ' tầng'
            : memory.pendingRollup
                ? 'Tóm tắt dài hạn vẫn đang chờ mình nén thêm một tầng～'
                : 'Ký ức dài hạn đã theo kịp chính văn～'}</span>
                </div>
                ${historyRunning ? `
                    <div class="wb-history-progress"><i style="width:${historyPercent}%"></i></div>
                ` : ''}
                <p>Sẽ tự động sắp xếp chính văn mới～ sự thật quan trọng, quan hệ, lời hứa và phục bút chưa khép lại sẽ được ngoan ngoãn giữ lại (｡•̀ᴗ-)✧</p>
                <div class="wb-memory-queue">
                    <span>Chờ sắp xếp ${Math.max(0, Number(memory.pendingAssistantResponses || 0))} tin chính văn</span>
                    <strong>${settings.memoryAutoIndexInterval > 0
                        ? `Tự động · mỗi ${settings.memoryAutoIndexInterval} lượt`
                        : 'Sắp xếp thủ công'}</strong>
                </div>
                <label>Cách sắp xếp</label>
                <div class="wb-option-row wb-option-row-four">
                    ${settingButton('memoryAutoIndexInterval', settings.memoryAutoIndexInterval, 0, 'Thủ công')}
                    ${settingButton('memoryAutoIndexInterval', settings.memoryAutoIndexInterval, 5, 'Mỗi 5 lượt')}
                    ${settingButton('memoryAutoIndexInterval', settings.memoryAutoIndexInterval, 10, 'Mỗi 10 lượt')}
                    ${settingButton('memoryAutoIndexInterval', settings.memoryAutoIndexInterval, 20, 'Mỗi 20 lượt')}
                </div>
                <label class="wb-number-setting">
                    Khoảng cách tùy chỉnh (lượt)
                    <input type="number" min="0" max="50" step="1"
                        data-wb-setting="memoryAutoIndexInterval"
                        value="${escapeAttr(settings.memoryAutoIndexInterval)}">
                </label>
                <button type="button" data-wb-action="scan-history"
                    ${historyRunning || !settings.memorySystemEnabled ? 'disabled' : ''}>
                    ${Number(memory.indexedThroughMessageId ?? -1) < 0 ? 'Sắp xếp ký ức hiện có' : 'Sắp xếp ngay'}
                </button>
            </div>
                        </div>
                    </details>

                </div>
            </details>

            <details class="wb-settings-group" data-settings-group="calendar" ${groupOpen('calendar')}>
                <summary><span>Lịch</span><small>Thời gian thế giới chính, hiệu chỉnh và tua nhanh</small></summary>
                <div class="wb-settings-group-body">
                    <form class="wb-clock-form" data-wb-form="clock">
                        <div class="wb-clock-form-heading">
                            <div><label>Lịch thế giới chính</label><strong>${escapeHtml(clockLabel)}</strong></div>
                            <span>Mỗi chat lưu riêng</span>
                        </div>
                        <label class="wb-calendar-name-field">
                            Tên lịch
                            <input name="calendarName" maxlength="40"
                                value="${escapeAttr(clock.calendarName)}" placeholder="Ví dụ: Lịch Đế quốc">
                        </label>
                        <div class="wb-calendar-date-fields">
                            <label><input name="year" type="number" min="1" max="999999"
                                value="${clock.year}"> năm</label>
                            <label><input name="month" type="number" min="1" max="12"
                                value="${clock.month}"> tháng</label>
                            <label><input name="day" type="number" min="1" max="31"
                                value="${clock.dayOfMonth}"> ngày</label>
                        </div>
                        <div class="wb-clock-fields">
                            <label><input name="hour" type="number" min="0" max="23" value="${clock.hour}"> giờ</label>
                            <label><input name="minute" type="number" min="0" max="59" value="${clock.minute}"> phút</label>
                            <button type="button" data-wb-action="sync-clock-from-story">Hiệu chỉnh theo chính văn</button>
                            <button type="submit" class="wb-clock-manual-save">Đặt thủ công</button>
                        </div>
                        <p class="wb-clock-sync-note">Chính văn thật sự nói rõ thời gian thì mình sẽ tự theo kịp～ nếu bạn rõ hơn mình, cũng có thể nói thẳng cho mình bây giờ là mấy giờ ở đây.</p>
                        <div class="wb-time-actions">
                            <button type="button" data-wb-action="advance-clock" data-minutes="60">+ 1 giờ</button>
                            <button type="button" data-wb-action="advance-clock" data-minutes="360">+ 6 giờ</button>
                            <button type="button" data-wb-action="advance-clock" data-minutes="1440">+ 1 ngày</button>
                        </div>
                    </form>
                </div>
            </details>

            <details class="wb-settings-group wb-settings-advanced-section" data-settings-group="advanced" ${sectionKey === 'advanced' ? 'open' : groupOpen('advanced')}>
                <summary><span>Nâng cao và bảo trì</span><small>Mấy thứ cứng cứng… mình tạm đè trong ổ</small></summary>
                <div class="wb-settings-group-body wb-advanced-settings-body wb-settings-subgroup-stack">
                    <details class="wb-settings-subgroup" data-settings-subgroup="advanced-generation" ${subgroupOpen('advanced-generation')}>
                        <summary><span>Giới hạn sinh</span><small>Token và thời gian chờ mỗi lần</small></summary>
                        <div class="wb-settings-subgroup-body">
                            <div class="wb-setting-block">
                                <label>Giới hạn Token toàn cục</label>
                                <div class="wb-option-row wb-option-row-four">
                                    ${settingButton('maxOutputTokens', settings.maxOutputTokens, 0, 'Tự động')}
                                    ${settingButton('maxOutputTokens', settings.maxOutputTokens, 4000, '4K')}
                                    ${settingButton('maxOutputTokens', settings.maxOutputTokens, 8000, '8K')}
                                    ${settingButton('maxOutputTokens', settings.maxOutputTokens, 12000, '12K')}
                                </div>
                                <label class="wb-number-setting">
                                    Giới hạn Token tùy chỉnh
                                    <input type="number" min="0" step="500"
                                        data-wb-setting="maxOutputTokens"
                                        value="${escapeAttr(settings.maxOutputTokens)}">
                                </label>
                                <p class="wb-setting-explanation">0 thì để mình tự tính～ suy diễn thế giới dùng ngân sách toàn cục, tác vụ nhỏ sẽ tự thu gọn; khi giới hạn phía máy chủ thấp hơn thì lấy máy chủ làm chuẩn.</p>
                            </div>

                            <div class="wb-setting-block">
                                <label>Thời gian chờ tối đa toàn cục</label>
                                <div class="wb-option-row wb-option-row-four">
                                    ${settingButton('generationTimeoutMs', settings.generationTimeoutMs, 0, 'Tự động')}
                                    ${settingButton('generationTimeoutMs', settings.generationTimeoutMs, 60000, '60s')}
                                    ${settingButton('generationTimeoutMs', settings.generationTimeoutMs, 120000, '120s')}
                                    ${settingButton('generationTimeoutMs', settings.generationTimeoutMs, 180000, '180s')}
                                </div>
                                <label class="wb-number-setting">
                                    Số giây chờ tùy chỉnh
                                    <input type="number" min="0" max="600" step="15"
                                        data-wb-setting-seconds="generationTimeoutMs"
                                        value="${escapeAttr(settings.generationTimeoutMs ? Math.round(settings.generationTimeoutMs / 1000) : 0)}">
                                </label>
                                <p class="wb-setting-explanation">0 thì để mình tự liệu～ chỉ đếm thời gian model thực sự sinh, chuyển sang nền, chờ hồi giới hạn tốc độ và xếp hàng đều không tính.</p>
                            </div>

                            <details class="wb-generation-module-overrides">
                                <summary>Cài riêng theo module <small>để 0 là kế thừa toàn cục</small></summary>
                                <div class="wb-generation-module-list">
                                    ${generationModuleRow('simulation')}
                                    ${generationModuleRow('observation')}
                                    ${generationModuleRow('history')}
                                    ${generationModuleRow('opinion')}
                                </div>
                            </details>

                            <div class="wb-generation-defaults">
                                <strong>Tham khảo thời gian chờ tự động</strong>
                                <span>Suy diễn thế giới 180s · Quan sát nhân vật 120s · Lịch sử/Ký ức 300s · Dư luận/Dạo chơi 150s</span>
                            </div>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="advanced-data" ${subgroupOpen('advanced-data')}>
                        <summary><span>Sao lưu dữ liệu</span><small>Mình giữ trước cho thế giới này một bản bảo hiểm</small></summary>
                        <div class="wb-settings-subgroup-body">
                            <div class="wb-setting-actions">
                                <button type="button" data-wb-action="export-state">Xuất thế giới hiện tại</button>
                                <button type="button" data-wb-action="import-state">Nhập trạng thái thế giới</button>
                                <input class="wb-import-input" type="file" accept=".json,application/json">
                            </div>
                            <p>Trước khi dọn nhà, thử nghiệm hay sửa lớn, để mình gói thế giới này vào hộp nhỏ giữ một bản nhé～ mất rồi khó nhặt lại lắm.</p>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="advanced-maintenance" ${subgroupOpen('advanced-maintenance')}>
                        <summary><span>Bảo trì dữ liệu</span><small>Xóa cache / đặt lại chat hiện tại</small></summary>
                        <div class="wb-settings-subgroup-body">
                            <div class="wb-maintenance-card">
                                <div>
                                    <strong>Dọn cache của chat hiện tại</strong>
                                    <p>Mình chỉ quét vụn tạm thời～ nhân vật, ký ức và trạng thái thế giới, một móng cũng không đụng.</p>
                                </div>
                                <button type="button" data-wb-action="clear-current-chat-cache">Dọn cache</button>
                            </div>
                            <div class="wb-maintenance-card">
                                <div>
                                    <strong>Để 玲七 kiểm tra trạng thái thế giới</strong>
                                    <p>Mình lấy chính văn và các sự thật rõ ràng đối chiếu lại một lượt. Nền sai thì mình sửa, chính văn đã xảy ra thì không đụng.</p>
                                </div>
                                <button type="button" data-wb-action="check-correct-world-state">Kiểm tra sửa lỗi</button>
                            </div>
                            <div class="wb-maintenance-card is-danger">
                                <div>
                                    <strong>Đặt lại dữ liệu chat hiện tại</strong>
                                    <p>Lần này là đổ sạch cái thùng này thật đấy. Chính văn và cấu hình API / model thì mình không đụng.</p>
                                    <small>Không thể hoàn tác～ muốn giữ thì sao lưu trước, thế giới cũ cũng sẽ không đội mồ sống dậy từ gầm giường nữa đâu.</small>
                                </div>
                                <button type="button" class="is-danger" data-wb-action="reset-current-chat-data">Đặt lại một chạm</button>
                            </div>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="advanced-tagfilter" ${subgroupOpen('advanced-tagfilter')}>
                        <summary><span>Lọc chính văn</span><small>Khối biến, khối script… cứng cứng, không ngon. Mình chỉ tha phần tự sự thật sự cho nền.</small></summary>
                        <div class="wb-settings-subgroup-body">
                    <div class="wb-setting-toggle">
                        <div><strong>Bật lọc thẻ</strong><span>Tắt rồi thì chú thích HTML mình vẫn nhặt ra trước, không nuốt.</span></div>
                        <label class="wb-switch">
                            <input type="checkbox" data-wb-setting="tagFilterEnabled"
                                ${settings.tagFilterEnabled !== false ? 'checked' : ''}>
                            <i></i>
                        </label>
                    </div>
                    <div class="wb-setting-block">
                        <div class="wb-narrative-filter-shortcuts">
                            <label>Chỉ đọc một thẻ chính văn nhất định (tùy chọn)
                                <input type="text" maxlength="80" data-wb-setting="narrativeIncludeTag"
                                    value="${escapeAttr(settings.narrativeIncludeTag || '')}"
                                    placeholder="Ví dụ narrative (không cần viết &lt; &gt;)" autocomplete="off" spellcheck="false">
                                <small>Tin nào có thẻ này thì chỉ lấy phần trong thẻ; không có thì giữ nguyên văn, không nuốt sạch một miếng đâu～</small>
                            </label>
                            <label>Loại trừ thêm bằng regex (tùy chọn)
                                <textarea rows="3" maxlength="2200" data-wb-setting="narrativeRegexFilters"
                                    placeholder="Mỗi dòng một quy tắc, ví dụ: &lt;UpdateVariable&gt;[\s\S]*?&lt;/UpdateVariable&gt;">${escapeHtml(settings.narrativeRegexFilters || '')}</textarea>
                                <small>Tối đa 8 quy tắc～ khối biến, thanh trạng thái hay nội dung preset đính kèm đều có thể gỡ ra trước khi vào nền.</small>
                            </label>
                        </div>
                        <p>Chú thích HTML <code>&lt;!-- ... --&gt;</code> sẽ bị gỡ nguyên khối～ các cặp thẻ dưới đây cũng có thể loại trừ trực tiếp; không cần biết regex vẫn dùng được (｡•̀ᴗ-)✧</p>
                        <div class="wb-tag-filter-list">
                            ${rules.map((rule, index) => `
                                <div class="wb-tag-filter-rule" data-tag-filter-index="${index}">
                                    <div class="wb-tag-filter-rule-head">
                                        <strong>Quy tắc ${index + 1}</strong>
                                        <button type="button" class="wb-tag-filter-remove is-delete"
                                            data-wb-action="remove-tag-filter-rule"
                                            data-index="${index}">Xóa</button>
                                    </div>
                                    <label>Thẻ mở <span>(có thể để trống)</span>
                                        <input type="text" maxlength="80"
                                            data-wb-tag-filter-field="open" data-index="${index}"
                                            value="${escapeAttr(rule.open || '')}"
                                            placeholder="Ví dụ &lt;options&gt;"
                                            autocomplete="off" spellcheck="false">
                                    </label>
                                    <label>Thẻ đóng <span>(có thể để trống)</span>
                                        <input type="text" maxlength="80"
                                            data-wb-tag-filter-field="close" data-index="${index}"
                                            value="${escapeAttr(rule.close || '')}"
                                            placeholder="Ví dụ &lt;/options&gt;"
                                            autocomplete="off" spellcheck="false">
                                    </label>
                                </div>
                            `).join('')}
                        </div>
                        <div class="wb-tag-auto-tools">
                            <div class="wb-tag-auto-head">
                                <div><strong>Tự động trích ứng viên</strong><span>Mình chỉ moi các thẻ khả nghi ra cho bạn xem～ không tự ý nhét vào quy tắc.</span></div>
                                <div class="wb-tag-auto-actions">
                                    <button type="button" data-wb-action="scan-tag-candidates" data-count="1">Quét chính văn mới nhất</button>
                                    <button type="button" data-wb-action="scan-tag-candidates" data-count="5">Quét 5 tin gần nhất</button>
                                </div>
                            </div>
                            ${tagCandidates.length ? `
                                <div class="wb-tag-candidate-list">
                                    ${tagCandidates.map((item, index) => `
                                        <label class="wb-tag-candidate ${item.broad ? 'is-risky' : ''} ${item.alreadyAdded ? 'is-added' : ''}">
                                            <input type="checkbox" data-wb-tag-candidate-index="${index}"
                                                ${item.recommended ? 'checked' : ''} ${item.alreadyAdded ? 'disabled' : ''}>
                                            <span>
                                                <strong>&lt;${escapeHtml(item.tagName)}&gt;${item.alreadyAdded ? ' · Đã thêm' : ''}</strong>
                                                <small>${item.count} lần${item.broad ? ' · Phạm vi khá rộng, nên xác nhận rồi hãy thêm' : ''}</small>
                                                <code>${escapeHtml(item.open)} … ${escapeHtml(item.close)}</code>
                                            </span>
                                        </label>
                                    `).join('')}
                                </div>
                                <button type="button" class="wb-tag-filter-add" data-wb-action="apply-tag-candidates">Thêm ứng viên đã chọn</button>
                            ` : '<p class="wb-tag-auto-empty">Bấm quét xong, plugin sẽ liệt kê các cặp thẻ khả nghi để bạn xác nhận.</p>'}
                        </div>

                        <button type="button" class="wb-tag-filter-add"
                            data-wb-action="add-tag-filter-rule"
                            ${rules.filter(rule => String(rule.open || '').trim() || String(rule.close || '').trim()).length >= 30 ? 'disabled' : ''}>
                            ＋ Thêm quy tắc
                        </button>
                    </div>

                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="advanced-recovery" ${subgroupOpen('advanced-recovery')}>
                        <summary><span>Khôi phục an toàn</span><small>${latestRecovery ? escapeHtml(latestRecovery.label) : 'Bản bảo hiểm mình giữ cho thế giới này'}</small></summary>
                        <div class="wb-settings-subgroup-body">
                            <div class="wb-maintenance-status">
                                <strong>${latestRecovery ? escapeHtml(latestRecovery.label) : 'Chưa có điểm khôi phục'}</strong>
                                <span>${latestRecovery ? escapeHtml(formatLocalTimestamp(latestRecovery.createdAt)) : 'Mỗi chat mình giữ riêng'}</span>
                            </div>
                            <p>${latestRecovery
                                ? `Hiện đang lưu ${Math.max(1, Number(recovery.count) || 1)} điểm khôi phục; khi khôi phục, mình vẫn sẽ giữ trước một bản bảo hiểm cho trạng thái hiện tại.`
                                : 'Khi nâng cấp dữ liệu cũ hay nhập trạng thái thế giới, mình sẽ giữ trước một bản～ bạn cũng có thể bảo mình lưu bảo hiểm ngay bây giờ.'}</p>
                            <div class="wb-setting-actions">
                                <button type="button" data-wb-action="create-recovery-point">Lưu điểm khôi phục ngay</button>
                                <button type="button" data-wb-action="restore-latest-recovery" ${latestRecovery ? '' : 'disabled'}>Khôi phục bản lưu gần nhất</button>
                            </div>
                        </div>
                    </details>

                    <details class="wb-settings-subgroup" data-settings-subgroup="advanced-diagnostics" ${subgroupOpen('advanced-diagnostics')}>
                        <summary><span>Chẩn đoán sự cố</span><small>Mình tha ra những thứ cần để bắt lỗi</small></summary>
                        <div class="wb-settings-subgroup-body">
                            <p>Mình chỉ tha ra phiên bản, thiết bị, chế độ API và trạng thái lỗi cần để bắt lỗi. Key, địa chỉ API, chính văn và thiết lập riêng tư của nhân vật? Mấy thứ đó mình đè lại, không tha ra ngoài.</p>
                            <div class="wb-setting-actions">
                                <button type="button" data-wb-action="copy-diagnostics">Tha chẩn đoán ra</button>
                                <button type="button" data-wb-action="preview-notice">Xem thử kiểu thông báo</button>
                            </div>
                        </div>
                    </details>
                </div>
            </details>

        </div>
    `;
}


function renderModuleSettings(state, settings, syncStatus, scope = 'now', openSubgroups = new Set(), worldbookUi = {}) {
    const scopeMeta = {
        now: { eyebrow: '玲七 đang xem', title: 'Cài đặt Lúc này' },
        people: { eyebrow: '玲七 đang xem', title: 'Cài đặt nhân vật' },
        currents: { eyebrow: '玲七 đang xem', title: 'Cài đặt Mạch ngầm' },
        opinion: { eyebrow: '玲七 đang nghe', title: 'Cài đặt Dư luận' },
        memory: { eyebrow: '玲七 đang dọn dẹp', title: 'Cài đặt ký ức' },
    };
    const scopeKey = Object.hasOwn(scopeMeta, scope) ? scope : 'now';
    const scopeInfo = scopeMeta[scopeKey];
    const clock = formatWorldCalendar(state);
    const clockLabel = worldClockLabel(state);
    const memory = syncStatus?.memory || {};
    const historyRunning = memory.phase === 'running';
    const historyPercent = memory.total > 0
        ? Math.min(100, Math.round((Number(memory.processed) || 0) / memory.total * 100))
        : 0;
    const worldbook = syncStatus?.worldbook || { books: [], entries: [], phase: 'idle' };
    const worldbookBooks = Array.isArray(worldbook.books) ? worldbook.books : [];
    const worldbookEntries = Array.isArray(worldbook.entries) ? worldbook.entries : [];
    const worldbookQuery = String(worldbookUi.query || '').slice(0, 120);
    const worldbookOnlyPeople = Boolean(worldbookUi.onlyPeople);
    const worldbookOnlyEnabled = Boolean(worldbookUi.onlyEnabled);
    const worldbookSelectedIds = worldbookUi.selectedIds instanceof Set
        ? worldbookUi.selectedIds
        : new Set(Array.isArray(worldbookUi.selectedIds) ? worldbookUi.selectedIds.map(String) : []);
    const filteredWorldbookEntries = filterWorldbookEntries(worldbookEntries, {
        query: worldbookQuery,
        onlyPeople: worldbookOnlyPeople,
        onlyEnabled: worldbookOnlyEnabled,
    });
    const worldbookSelectedCount = worldbookSelectedIds.size;
    const apiProfiles = Array.isArray(settings.apiProfiles) ? settings.apiProfiles : [];
    const apiModuleRoutes = settings.apiModuleRoutes && typeof settings.apiModuleRoutes === 'object'
        ? settings.apiModuleRoutes
        : {};
    const routeOptions = (current = 'default') => [
        `<option value="default" ${current === 'default' ? 'selected' : ''}>Theo kết nối mặc định của 世界背面</option>`,
        `<option value="tavern" ${current === 'tavern' ? 'selected' : ''}>Theo Tavern hiện tại</option>`,
        ...apiProfiles.map(profile => {
            const value = `profile:${profile.id}`;
            return `<option value="${escapeAttr(value)}" ${current === value ? 'selected' : ''}>${escapeHtml(profile.name)} · ${escapeHtml(profile.model || 'Chưa chọn model')}</option>`;
        }),
    ].join('');
    const settingButton = (setting, current, id, label) => `
        <button type="button" data-wb-action="setting-button"
            data-setting="${setting}" data-value="${id}"
            class="${String(current) === String(id) ? 'is-active' : ''}">${label}</button>
    `;
    const densityButton = (id, label) => settingButton('deliveryDensity', settings.deliveryDensity, id, label);
    const explanation = (setting, value) => ({
        deliveryDensity: {
            restrained: 'Mình sẽ ít tha đồ ra cạnh ống kính hơn～ nhưng ở nền, ai cần sống vẫn sống như thường.',
            balanced: 'Chuyện quan trọng mình tha ra cạnh ống kính, chuyện không quan trọng thì tạm đè dưới chân mèo. Ừm, vậy là không loạn.',
            active: 'Mình sẽ siêng tha các thay đổi ra cạnh ống kính hơn～ nhưng lúc đang bận thì mình cũng không cố nhào vào đâu.',
        },
        autoSimulationMode: {
            light: 'Mình nằm bò nhìn nhẹ nhàng thôi～ chỉ lo những thay đổi thật sự cần thiết, không chạy lung tung.',
            balanced: 'Mình sẽ ngó qua từng chỗ một～ cái gì cần động thì tự động, không có chuyện gì thì mình không lấy chân khều bừa.',
            deep: 'Mình sẽ ngồi canh lâu hơn, soi kỹ cả người lẫn nhân quả ngoài ống kính～ thế giới phức tạp thì dùng cái này.',
        },
        timePolicy: {
            world: 'Mình canh đồng hồ thế giới～ chính văn nói rõ mấy giờ thì mình mới khều kim qua đó.',
            explicit: 'Thật sự tính ra được thì mình mới chỉnh. Tính không chuẩn à? Vậy mình không đụng.',
            cautious: 'Có thể cho mình đoán một chút xíu～ nhưng không chắc thì mình rụt chân lại.',
            open: 'Mấy chuyện nhìn là biết tốn thời gian như đi đường, chờ đợi, làm việc, mình sẽ tiện tay đẩy đồng hồ lên trước.',
        },
        publicOpinionRevealMode: {
            observe: 'Mình đè hết tiếng gió bên ngoài ở góc này～ bạn đến xem thì mình mới lật ra cho, không tha vào chính văn.',
            relevant: 'Thật sự liên quan đến đoạn cốt truyện trước mắt thì mình mới tha sang một chút～ không liên quan thì mình cứ đè tiếp.',
        },
        worldPulseActivity: {
            quiet: 'Thế giới vẫn chuyển động～ chỉ là mình bớt quậy các thay đổi công cộng, để bên ngoài yên tĩnh hơn một chút.',
            natural: 'Mình trông thành phố, tổ chức, thời tiết và xã hội theo nhịp bình thường～ cái gì cần đổi thì tự đổi.',
            busy: 'Mình sẽ để ý động tĩnh ngoài ống kính nhiều hơn một chút～ nhưng không đem tai nạn lớn hay thảm họa ra cố góp vui.',
        },
    }[setting]?.[String(value)] || '');
    const advancedOpen = id => openSubgroups.has(id) ? 'open' : '';
    const sectionHeading = (title, note = '') => `
        <div class="wb-flat-section-heading">
            <div><strong>${escapeHtml(title)}</strong>${note ? `<span>${escapeHtml(note)}</span>` : ''}</div>
        </div>
    `;
    const routeSetting = (key, title, note = '') => `
        <div class="wb-setting-block wb-route-setting">
            <label>${escapeHtml(title)}</label>
            <select data-wb-api-route="${escapeAttr(key)}">${routeOptions(apiModuleRoutes[key] || 'default')}</select>
            ${note ? `<p class="wb-setting-explanation">${escapeHtml(note)}</p>` : ''}
        </div>
    `;
    const injectionStatusCard = (label, enabled, detail = '') => `
        <div class="wb-module-visibility-card ${enabled ? 'is-on' : 'is-off'}">
            <div>
                <span>Bên chân mèo có đưa ra không</span>
                <strong>${escapeHtml(label)} · ${enabled ? 'Mình sẽ tha sang' : 'Tạm đè dưới chân mèo'}</strong>
                ${detail ? `<small>${escapeHtml(detail)}</small>` : ''}
            </div>
            <button type="button" data-wb-action="open-global-settings-section" data-section="injection">Đi lục xem</button>
        </div>
    `;
    const worldBackground = String(state.world?.background || '').trim();
    const worldBackgroundLength = worldBackground.length;

    const nowHtml = `
        ${injectionStatusCard(
            'Lúc này · Thời gian thế giới / Bối cảnh',
            settings.worldPromptInjection && settings.injectionTimeMode !== 'off' && settings.injectionWorldBackground !== false,
            `Thời gian: ${settings.injectionTimeMode === 'full' ? 'Đầy đủ' : settings.injectionTimeMode === 'anchor' ? 'Điểm neo tối thiểu' : 'Tắt'} · Bối cảnh: ${settings.injectionWorldBackground !== false ? 'bật' : 'tắt'}`,
        )}
        <div class="wb-flat-setting-list">
            <div class="wb-setting-block">
                <label>Phạm vi đọc chính văn</label>
                <div class="wb-option-row wb-option-row-four">
                    ${settingButton('contextTurns', settings.contextTurns, 1, '1 lượt gần nhất')}
                    ${settingButton('contextTurns', settings.contextTurns, 3, '3 lượt gần nhất')}
                    ${settingButton('contextTurns', settings.contextTurns, 5, '5 lượt gần nhất')}
                    <button type="button" data-wb-action="setting-button" data-setting="contextTurns"
                        data-value="${escapeAttr(settings.customContextTurns || 8)}"
                        class="${![1, 3, 5].includes(Number(settings.contextTurns)) ? 'is-active' : ''}">Tùy chỉnh</button>
                </div>
                ${![1, 3, 5].includes(Number(settings.contextTurns)) ? `
                    <label class="wb-number-setting wb-context-custom">Số lượt gần nhất cần đọc
                        <input type="number" min="1" max="30" step="1" data-wb-setting="contextTurns" value="${escapeAttr(settings.contextTurns)}">
                    </label>` : ''}
                <p class="wb-setting-explanation">${escapeHtml(
                    [1, 3, 5].includes(Number(settings.contextTurns))
                        ? ({1: 'Mình chỉ xem lượt mới nhất～ nhẹ nhàng, tiết kiệm nhất.', 3: 'Mình nhìn lại 3 lượt～ cốt truyện đời thường thường là đủ rồi.', 5: 'Mình nhìn lại 5 lượt～ tính liên tục và mức tiêu hao khá vừa vặn.'}[Number(settings.contextTurns)])
                        : `Giờ mình sẽ nhìn lại ${settings.contextTurns} lượt～ sự kiện dài sẽ ổn định hơn, nhưng Token cũng béo lên theo.`
                )}</p>
            </div>
            <details class="wb-setting-block wb-world-background-setting" data-settings-subgroup="now-world-background" ${advancedOpen('now-world-background')}>
                <summary class="wb-world-background-heading">
                    <strong>Thiết lập bối cảnh thế giới</strong>
                    <span class="${worldBackground ? 'is-set' : ''}">${worldBackground ? `Đã thiết lập · ${worldBackgroundLength} chữ` : 'Chưa thiết lập'}</span>
                </summary>
                <div class="wb-world-background-body">
                    <div class="wb-world-background-preview ${worldBackground ? 'is-set' : 'is-empty'}">
                        ${escapeHtml(worldBackground
                            ? compactText(worldBackground, 150)
                            : 'Hãy viết cho mình thời đại, địa lý, thế lực, quy tắc và dòng thời gian quan trọng luôn đúng lâu dài của thế giới này～ mình sẽ luôn dùng nó làm nền móng.')}
                    </div>
                    <button class="wb-world-background-action" type="button" data-wb-action="open-world-editor">
                        ${worldBackground ? 'Sửa bối cảnh thế giới' : 'Bắt đầu thiết lập bối cảnh thế giới'}
                    </button>
                </div>
            </details>
            <div class="wb-setting-block">
                <label>Tiến trình thời gian</label>
                <div class="wb-option-row">
                    ${settingButton('timePolicy', settings.timePolicy, 'world', 'Đồng hồ thế giới')}
                    ${settingButton('timePolicy', settings.timePolicy, 'explicit', 'Nghiêm ngặt')}
                    ${settingButton('timePolicy', settings.timePolicy, 'cautious', 'Tiết chế')}
                    ${settingButton('timePolicy', settings.timePolicy, 'open', 'Cởi mở')}
                </div>
                <p class="wb-setting-explanation">${escapeHtml(explanation('timePolicy', settings.timePolicy))}</p>
            </div>
        </div>
        ${sectionHeading('Đồng hồ thế giới', 'Thời gian để mình canh～ bạn cũng có thể tự chỉnh')}
        <form class="wb-clock-form wb-flat-clock-form" data-wb-form="clock">
            <div class="wb-clock-form-heading"><div><label>Lịch thế giới chính</label><strong>${escapeHtml(clockLabel)}</strong></div><span>Mỗi chat mình ghi riêng</span></div>
            <label class="wb-calendar-name-field">Tên lịch<input name="calendarName" maxlength="40" value="${escapeAttr(clock.calendarName)}" placeholder="Ví dụ: Lịch Đế quốc"></label>
            <div class="wb-calendar-date-fields">
                <label><input name="year" type="number" min="1" max="999999" value="${clock.year}"> năm</label>
                <label><input name="month" type="number" min="1" max="12" value="${clock.month}"> tháng</label>
                <label><input name="day" type="number" min="1" max="31" value="${clock.dayOfMonth}"> ngày</label>
            </div>
            <div class="wb-clock-fields">
                <label><input name="hour" type="number" min="0" max="23" value="${clock.hour}"> giờ</label>
                <label><input name="minute" type="number" min="0" max="59" value="${clock.minute}"> phút</label>
                <button type="button" data-wb-action="sync-clock-from-story">Hiệu chỉnh theo chính văn</button>
                <button type="submit" class="wb-clock-manual-save">Đặt thủ công</button>
            </div>
            <p class="wb-clock-sync-note">Chính văn thật sự nói rõ thời gian thì mình sẽ tự theo kịp～ nếu bạn rõ hơn mình, cũng có thể nói thẳng cho mình bây giờ là mấy giờ ở đây.</p>
            <div class="wb-time-actions">
                <button type="button" data-wb-action="advance-clock" data-minutes="60">+ 1 giờ</button>
                <button type="button" data-wb-action="advance-clock" data-minutes="360">+ 6 giờ</button>
                <button type="button" data-wb-action="advance-clock" data-minutes="1440">+ 1 ngày</button>
            </div>
        </form>
    `;

    const peopleHtml = `
        ${injectionStatusCard(
            'Nhân vật · Trạng thái hiện tại',
            settings.worldPromptInjection && settings.injectionPeople !== false,
            'Không tha cho chính văn xem cũng không sao～ họ vẫn sống ở phía sau, mình sẽ ghi nhớ.',
        )}
        <div class="wb-person-group-life-note">
            <span>Đời sống tập thể · mặc định có hiệu lực</span>
            <strong>Cùng nơi, cùng đi, cùng tổ chức và sự kiện chung, mình sẽ đặt vào cùng một lượt để đối chiếu～</strong>
            <small>Thật sự có tương tác thì để lại kết quả cho cả hai bên; không gặp mặt thì ai sống đời nấy. Nó tận dụng đợt suy diễn gộp nhân vật hiện có, không mở thêm một lượt API chỉ vì “cảm giác tập thể”.</small>
        </div>
        <div class="wb-flat-setting-list">
            <div class="wb-setting-block">
                <label>Ngân sách NPC nền</label>
                <div class="wb-option-row wb-option-row-four">
                    ${settingButton('backgroundNpcBudget', settings.backgroundNpcBudget, 0, 'Không chủ động suy diễn')}
                    ${settingButton('backgroundNpcBudget', settings.backgroundNpcBudget, 2, 'Tối đa 2 người')}
                    ${settingButton('backgroundNpcBudget', settings.backgroundNpcBudget, 4, 'Tối đa 4 người')}
                    ${settingButton('backgroundNpcBudget', settings.backgroundNpcBudget, 8, 'Tối đa 8 người')}
                </div>
                <label class="wb-number-setting">Số người mỗi lượt tùy chỉnh
                    <input type="number" min="0" step="1" data-wb-setting="backgroundNpcBudget" value="${escapeAttr(settings.backgroundNpcBudget)}">
                </label>
                <p class="wb-setting-explanation">Muốn canh bao nhiêu người cứ tự điền～ khuyên dùng 2～8 người, mỗi lượt cố đừng quá 12 người; càng nhiều càng tốn Token, cũng chậm hơn.</p>
            </div>
            <div class="wb-setting-toggle">
                <div><strong>Tăng cường suy diễn nhân vật nền</strong><span>Khi bật, ai cần kết toán mình sẽ tiện tay vớt vào lượt suy diễn thế giới này xem luôn～ không chạy riêng thêm một chuyến.</span></div>
                <label class="wb-switch"><input type="checkbox" data-wb-setting="enhancedBackgroundSimulation" ${settings.enhancedBackgroundSimulation ? 'checked' : ''}><i></i></label>
            </div>
            <div class="wb-setting-toggle">
                <div><strong>Ghi nhận nhân vật người chơi</strong><span>Tắt đi thì mình không dựng thẻ nhân vật riêng cho user～ nhưng chuyện thật sự đã xảy ra trong chính văn thì mình vẫn công nhận. Không thể giả vờ không thấy.</span></div>
                <label class="wb-switch"><input type="checkbox" data-wb-setting="recordPlayerCharacter" ${settings.recordPlayerCharacter !== false ? 'checked' : ''}><i></i></label>
            </div>
            ${routeSetting('observation', 'Kết nối mình dùng khi xem nhân vật', 'Ở đây chỉ bảo mình đi đường nào khi xem nhân vật～ Key và địa chỉ vẫn để trong kết nối toàn cục.')}
        </div>
        <details class="wb-settings-subgroup wb-module-advanced" data-settings-subgroup="people-worldbook" ${advancedOpen('people-worldbook')}>
            <summary><span>Nhập nhân vật từ World Info</span><small>Khi muốn giới thiệu người mới cho mình thì hãy mở ra～ mình ngửi xem là ai trước đã.</small></summary>
            <div class="wb-module-advanced-body">
                <form class="wb-worldbook-import" data-wb-form="worldbook">
                    <label>Chọn World Info
                        <select name="bookName" ${worldbookBooks.length ? '' : 'disabled'}>
                            ${worldbookBooks.length
                                ? worldbookBooks.map(book => `<option value="${escapeAttr(book)}" ${book === worldbook.bookName ? 'selected' : ''}>${escapeHtml(book)}</option>`).join('')
                                : '<option value="">Giờ mình chưa tìm thấy World Info nào đọc được</option>'}
                        </select>
                    </label>
                    <div class="wb-worldbook-action-row">
                        <button class="wb-primary-button wb-worldbook-smart-button" type="button" data-wb-action="smart-import-worldbook-people" ${worldbook.phase === 'running' || !worldbookBooks.length ? 'disabled' : ''}>
                            ${worldbook.phase === 'running' ? 'Đang đọc…' : 'Nhập nhân vật thông minh một chạm'}
                        </button>
                        <button class="wb-worldbook-scan-button" type="button" data-wb-action="scan-worldbook" ${worldbook.phase === 'running' || !worldbookBooks.length ? 'disabled' : ''}>
                            Chọn thủ công nâng cao
                        </button>
                    </div>
                    <p class="wb-setting-explanation">MVU, biến, script mấy thứ này mình tránh trước. Nhân vật và thế lực chen chúc trên cùng một tờ giấy? Ừm… mình tha người thật ra trước, không coi cả một tổ chức là một người.</p>
                    ${worldbook.message ? `<div class="wb-worldbook-status is-${escapeAttr(worldbook.phase)}">${escapeHtml(worldbook.message)}</div>` : ''}
                    ${worldbookEntries.length ? `
                        <div class="wb-worldbook-browser">
                            <label class="wb-worldbook-search"><span>Tìm mục</span><input type="search" name="worldbookSearch" data-wb-worldbook-search value="${escapeAttr(worldbookQuery)}" placeholder="Tìm tên nhân vật, tên mục, từ khóa hoặc nội dung"></label>
                            <div class="wb-worldbook-filter-row">
                                <label class="wb-worldbook-filter-chip ${worldbookOnlyPeople ? 'is-active' : ''}"><input type="checkbox" data-wb-worldbook-filter="people" ${worldbookOnlyPeople ? 'checked' : ''}><span>Chỉ xem mục có thể là nhân vật</span></label>
                                <label class="wb-worldbook-filter-chip ${worldbookOnlyEnabled ? 'is-active' : ''}"><input type="checkbox" data-wb-worldbook-filter="enabled" ${worldbookOnlyEnabled ? 'checked' : ''}><span>Chỉ xem mục đang bật</span></label>
                            </div>
                            <div class="wb-worldbook-toolbar"><span>Ứng viên ${worldbookEntries.filter(entry => entry.importablePerson ?? entry.likelyPerson).length} người · đang hiện ${filteredWorldbookEntries.length} mục · đã chọn ${worldbookSelectedCount} người</span><div>
                                <button type="button" data-wb-action="select-worldbook-visible" ${filteredWorldbookEntries.some(entry => entry.importablePerson ?? entry.likelyPerson) ? '' : 'disabled'}>Chọn hết nhân vật đang hiện</button>
                                <button type="button" data-wb-action="clear-worldbook-visible" ${filteredWorldbookEntries.length ? '' : 'disabled'}>Bỏ chọn mục đang hiện</button>
                            </div></div>
                            <div class="wb-worldbook-entry-list">
                                ${filteredWorldbookEntries.length ? filteredWorldbookEntries.map(entry => {
                                    const importable = Boolean(entry.importablePerson ?? entry.likelyPerson);
                                    const manuallySelectable = isWorldbookEntryManuallySelectable(entry);
                                    const badge = entry.embeddedPerson
                                        ? '<em>Tách ra từ mục hỗn hợp</em>'
                                        : entry.smartAuto
                                            ? '<em>Nhân vật</em>'
                                            : importable
                                                ? '<em>Nên xác nhận</em>'
                                            : entry.technicalEntry
                                                     ? '<em class="is-muted">Kỹ thuật / MVU · có thể xác nhận thủ công</em>'
                                             : entry.mixedSource
                                                        ? '<em class="is-muted">Thiết lập hỗn hợp</em>'
                                                        : '';
                                    return `
                                    <label class="wb-worldbook-entry ${entry.disabled ? 'is-disabled-entry' : ''} ${importable ? 'is-person-candidate' : ''} ${entry.embeddedPerson ? 'is-embedded-person' : ''}">
                                        <input id="wb-worldbook-entry-${escapeAttr(entry.uid)}" type="checkbox" name="entryIds" data-wb-worldbook-entry-id="${escapeAttr(entry.uid)}" value="${escapeAttr(entry.uid)}" ${worldbookSelectedIds.has(String(entry.uid)) ? 'checked' : ''} ${manuallySelectable ? '' : 'disabled'}>
                                        <span><span class="wb-worldbook-entry-heading"><strong>${escapeHtml(entry.parsedName || entry.name)}</strong>${badge}${entry.disabled ? '<em class="is-muted">Đã tắt</em>' : ''}</span>
                                            <small>${escapeHtml(entry.embeddedPerson && entry.sourceEntryName ? `Từ: ${entry.sourceEntryName}` : ((entry.keys || []).join('、') || `UID ${entry.sourceUid || entry.uid}`))}</small>
                                            <p>${escapeHtml(entry.content.slice(0, 220))}${entry.content.length > 220 ? '…' : ''}</p>
                                        </span>
                                    </label>`;
                                }).join('') : '<div class="wb-worldbook-empty">Ở đây không tìm thấy mục phù hợp～ đổi từ khóa hoặc nới bộ lọc rồi để mình tìm lại nhé.</div>'}
                            </div>
                            ${renderWorldbookImportActions(worldbook, worldbookSelectedCount, worldbookUi.draft || {})}
                        </div>` : ''}
                </form>
            </div>
        </details>
    `;

    const currentsHtml = `
        ${injectionStatusCard(
            'Mạch ngầm · Sự kiện đang diễn ra / Môi trường thế giới',
            settings.worldPromptInjection && settings.injectionEvents !== false,
            `Tiếng vọng: ${settings.worldPromptInjection && settings.injectionEchoes !== false ? 'Mình sẽ đưa' : 'Mình giữ lại trước'} · Sự thật thế giới: ${settings.worldPromptInjection && settings.injectionFacts !== false ? 'Mình sẽ đưa' : 'Mình giữ lại trước'}`,
        )}
        ${sectionHeading('Vận hành thế giới', 'Ống kính quay đi rồi, mình vẫn ngồi bên đó trông chừng～')}
        <div class="wb-flat-setting-list">
            <div class="wb-module-runtime-summary">
                <div><span>Tự động chạy</span><strong>${settings.worldAutoEnabled ? 'Mình sẽ tự dậy đi tuần một vòng' : 'Mình nằm bò, chờ bạn chọc'}</strong></div>
                <button type="button" data-wb-action="open-global-settings-section" data-section="common">Đến cài đặt thường dùng</button>
            </div>
            <div class="wb-setting-block">
                <label>Nhịp đập thế giới</label>
                <div class="wb-option-row">
                    ${settingButton('worldPulseActivity', settings.worldPulseActivity, 'quiet', 'Yên tĩnh')}
                    ${settingButton('worldPulseActivity', settings.worldPulseActivity, 'natural', 'Tự nhiên')}
                    ${settingButton('worldPulseActivity', settings.worldPulseActivity, 'busy', 'Náo nhiệt')}
                </div>
                <p class="wb-setting-explanation">${escapeHtml(explanation('worldPulseActivity', settings.worldPulseActivity))}</p>
            </div>
            <div class="wb-setting-block">
                <label>Cường độ vận hành thế giới</label>
                <div class="wb-option-row">
                    ${settingButton('autoSimulationMode', settings.autoSimulationMode, 'light', 'Nhẹ')}
                    ${settingButton('autoSimulationMode', settings.autoSimulationMode, 'balanced', 'Cân bằng')}
                    ${settingButton('autoSimulationMode', settings.autoSimulationMode, 'deep', 'Sâu')}
                </div>
                <p class="wb-setting-explanation">${escapeHtml(explanation('autoSimulationMode', settings.autoSimulationMode))}</p>
            </div>
            <div class="wb-setting-block">
                <label>Tần suất tự kích hoạt</label>
                <div class="wb-option-row wb-option-row-four">
                    ${settingButton('autoSimulationInterval', settings.autoSimulationInterval, 1, 'Mỗi lượt')}
                    ${settingButton('autoSimulationInterval', settings.autoSimulationInterval, 2, 'Mỗi 2 lượt')}
                    ${settingButton('autoSimulationInterval', settings.autoSimulationInterval, 3, 'Mỗi 3 lượt')}
                    ${settingButton('autoSimulationInterval', settings.autoSimulationInterval, 5, 'Mỗi 5 lượt')}
                </div>
                <label class="wb-number-setting">Số lượt tích lũy tùy chỉnh<input type="number" min="1" max="20" step="1" data-wb-setting="autoSimulationInterval" value="${escapeAttr(settings.autoSimulationInterval)}"></label>
            </div>
            <div class="wb-setting-toggle">
                <div><strong>Nhắc chính văn chưa suy diễn</strong><span>Tắt đi thì chỉ tự chạy theo tần suất đã đặt, không hỏi mỗi lần trả lời có muốn suy diễn bù sớm không; khi thật sự thất bại vẫn sẽ nhắc.</span></div>
                <label class="wb-switch"><input type="checkbox" data-wb-setting="pendingSimulationPromptEnabled" ${settings.pendingSimulationPromptEnabled ? 'checked' : ''}><i></i></label>
            </div>
            ${routeSetting('simulation', 'Kết nối mình dùng khi suy diễn thế giới', 'Chỉ cần bảo mình đi đường nào ra ngoài suy diễn～ Key và địa chỉ mình về cái ngăn kéo toàn cục mà tìm.')}
        </div>
        <details class="wb-settings-subgroup wb-module-advanced" data-settings-subgroup="currents-advanced" ${advancedOpen('currents-advanced')}>
            <summary><span>Nâng cao</span><small>Ở đây là thất bại rồi thì mình nên làm gì</small></summary>
            <div class="wb-module-advanced-body wb-flat-setting-list">
                <div class="wb-setting-block">
                    <label>Suy diễn thất bại rồi có để mình thử lại không</label>
                    <div class="wb-option-row wb-option-row-four">
                        ${settingButton('autoRetryCount', settings.autoRetryCount, 0, 'Không thử lại')}
                        ${settingButton('autoRetryCount', settings.autoRetryCount, 1, 'Thử lại 1 lần')}
                        ${settingButton('autoRetryCount', settings.autoRetryCount, 2, 'Thử lại 2 lần')}
                        ${settingButton('autoRetryCount', settings.autoRetryCount, 3, 'Thử lại 3 lần')}
                    </div>
                    <label class="wb-number-setting">Thử lại tối đa mấy lần<input type="number" min="0" max="5" step="1" data-wb-setting="autoRetryCount" value="${escapeAttr(settings.autoRetryCount)}"></label>
                </div>
                <label class="wb-custom-instruction">Yêu cầu suy diễn tùy chỉnh<textarea data-wb-setting="customSimulationInstruction" maxlength="1000" rows="3" placeholder="Ví dụ: bớt tạo sự kiện mới; để ý thương hội và bến cảng nhiều hơn. 玲七 sẽ chú ý theo hướng này.">${escapeHtml(settings.customSimulationInstruction)}</textarea></label>
            </div>
        </details>
    `;

    const opinionHtml = `
        ${injectionStatusCard(
            'Dư luận · Tin tức / Diễn đàn',
            settings.worldPromptInjection && settings.injectionPublicOpinion !== false,
            'Tiếng gió bên ngoài mình vẫn tiếp tục nghe～ ở đây chỉ để báo bạn là mình có đưa nó cho chính văn hay không.',
        )}
        <div class="wb-flat-setting-list">
            <div class="wb-setting-toggle">
                <div>
                    <strong>Tự động cập nhật dư luận</strong>
                    <span>Bên ngoài thật sự có động tĩnh đáng lan truyền thì mình sẽ tự dỏng tai nghe～ nếu tắt, bạn chọc mình thì mình cũng sẽ đi nghe.</span>
                </div>
                <label class="wb-switch">
                    <input type="checkbox" data-wb-setting="publicOpinionAutoEnabled"
                        ${settings.publicOpinionAutoEnabled ? 'checked' : ''}>
                    <i></i>
                </label>
            </div>
            <div class="wb-setting-block">
                <label>Có muốn mình đưa tiếng gió lại gần hơn không</label>
                <div class="wb-option-row">
                    ${settingButton('publicOpinionRevealMode', settings.publicOpinionRevealMode, 'observe', 'Chỉ quan sát')}
                    ${settingButton('publicOpinionRevealMode', settings.publicOpinionRevealMode, 'relevant', 'Hé lộ khi liên quan')}
                </div>
                <p class="wb-setting-explanation">${escapeHtml(explanation('publicOpinionRevealMode', settings.publicOpinionRevealMode))}</p>
            </div>
            ${routeSetting('opinion', 'Kết nối mình dùng khi nghe ngóng', 'Chỉ cần bảo mình đi đường nào ra ngoài nghe ngóng～ phần API thì mình không khuân lung tung ở đây.')}
        </div>
        <p class="wb-flat-footnote">Tin tức công khai sẽ nối ảnh hưởng thật trở lại nhân vật và môi trường, nhưng phải khớp với sự kiện thế giới trước, rồi theo địa điểm, công việc, tổ chức và kênh tin tức mà ảnh hưởng đến đúng người; tin đồn trên diễn đàn vẫn chỉ là tiếng gió, mình sẽ không để cả thế giới bỗng nhiên cùng biết～</p>
    `;

    const memoryHtml = `
        ${injectionStatusCard(
            'Ký ức · Ký ức dài hạn',
            settings.worldPromptInjection && settings.injectionMemory !== false,
            'Hộp ký ức là chuyện của hộp ký ức, chính văn là chuyện của chính văn. Mình có dọn hay không và có tha ra hay không là hai chuyện khác nhau.',
        )}
        <div class="wb-flat-setting-list">
            <div class="wb-setting-toggle">
                <div><strong>Bật hệ thống ký ức</strong><span>Tắt đi thì mình tạm không nhét mẩu giấy mới vào hộp ký ức～ những gì đã cất mình đè giữ, không mất.</span></div>
                <label class="wb-switch"><input type="checkbox" data-wb-setting="memorySystemEnabled" ${settings.memorySystemEnabled ? 'checked' : ''}><i></i></label>
            </div>
            <div class="wb-setting-toggle">
                <div><strong>Tự động ẩn các tầng đã lưu trữ</strong><span>Chỉ giấu các tầng cũ mà ký ức đã cất xong, luôn chừa 5 tầng gần nhất làm đệm; không xóa chat. Khi tắt chèn ký ức dài hạn thì sẽ không hoạt động.</span></div>
                <label class="wb-switch"><input type="checkbox" data-wb-setting="autoHideArchivedFloors" ${settings.autoHideArchivedFloors ? 'checked' : ''} ${!settings.injectionMemory && !settings.autoHideArchivedFloors ? 'disabled' : ''}><i></i></label>
            </div>
            <button type="button" data-wb-action="restore-auto-hidden-floors">Tắt và khôi phục các tầng tự động ẩn</button>
            ${routeSetting('history', 'Kết nối mình dùng khi sắp xếp ký ức', 'Ở đây chỉ bảo mình đi đường nào khi sắp xếp ký ức～ Key và địa chỉ không cần điền lại.')}
        </div>
        ${sectionHeading('Tham gia giữa chừng', 'Mình đến muộn à? Không sao. Mình có thể lần theo mùi từ các đoạn chat trước mà về～')}
        <div class="wb-history-settings wb-flat-history-settings wb-world-bootstrap-settings">
            <div class="wb-history-heading">
                <div>
                    <label>Nối quá khứ thành hiện tại</label>
                    <strong>${escapeHtml(historyRunning && memory.kind === 'world-bootstrap'
                        ? memory.message || 'Mình đang nhặt lại từng tầng chat phía trước… đừng giẫm, mình vừa xếp xong.'
                        : 'Thời gian, nhân vật, sự thật, mạch ngầm chưa đi hết và ký ức, mình tha về cùng lúc rồi xếp gọn')}</strong>
                </div>
                <span>${historyRunning && memory.kind === 'world-bootstrap' ? `${historyPercent}%` : 'Có thể chạy tiếp từ điểm dừng'}</span>
            </div>
            ${historyRunning && memory.kind === 'world-bootstrap'
                ? `<div class="wb-history-progress"><i style="width:${historyPercent}%"></i></div>`
                : ''}
            <p>Mỗi đợt cất xong mình đều để lại một dấu chân; dừng giữa chừng thì lần sau tiếp tục từ dấu chân đó. Thế giới chính thức vẫn đợi xong hết mới nối vào cùng lúc.</p>
            <button type="button" data-wb-action="bootstrap-history" ${historyRunning ? 'disabled' : ''}>Để 玲七 truy hồi chat hiện tại</button>
        </div>

        ${sectionHeading('Sắp xếp ký ức', 'Ở đây chỉ để mình dọn hộp ký ức～ không tiện tay lật tung cả thế giới đâu')}
        <div class="wb-history-settings wb-flat-history-settings">
            <div class="wb-history-heading"><div><label>Ký ức dài hạn</label><strong>${escapeHtml(historyRunning && memory.kind !== 'world-bootstrap' ? memory.message || 'Mình đang dọn ký ức～' : 'Mình sẽ tự dọn ký ức dài hạn～')}</strong></div>
                <span>${historyRunning && memory.kind !== 'world-bootstrap' ? `${historyPercent}%` : (Number(memory.pendingAssistantResponses || 0) > 0 ? 'Có đồ mới đang chờ mình cất～' : 'Mình đã theo kịp chính văn rồi～')}</span></div>
            ${historyRunning && memory.kind !== 'world-bootstrap' ? `<div class="wb-history-progress"><i style="width:${historyPercent}%"></i></div>` : ''}
            <p>Sự thật quan trọng, quan hệ, lời hứa, phục bút chưa khép lại, mình sẽ nhặt ra đè giữ cẩn thận. Vụn vặt nhiều quá sẽ làm hộp nổ tung, mình mới không chịu đâu.</p>
            <div class="wb-memory-queue"><span>Chờ sắp xếp ${Math.max(0, Number(memory.pendingAssistantResponses || 0))} tin chính văn</span><strong>${settings.memoryAutoIndexInterval > 0 ? `Tự động · mỗi ${settings.memoryAutoIndexInterval} lượt` : 'Sắp xếp thủ công'}</strong></div>
            <label>Cách sắp xếp</label>
            <div class="wb-option-row wb-option-row-four">
                ${settingButton('memoryAutoIndexInterval', settings.memoryAutoIndexInterval, 0, 'Thủ công')}
                ${settingButton('memoryAutoIndexInterval', settings.memoryAutoIndexInterval, 5, 'Mỗi 5 lượt')}
                ${settingButton('memoryAutoIndexInterval', settings.memoryAutoIndexInterval, 10, 'Mỗi 10 lượt')}
                ${settingButton('memoryAutoIndexInterval', settings.memoryAutoIndexInterval, 20, 'Mỗi 20 lượt')}
            </div>
            <label class="wb-number-setting">Khoảng cách tùy chỉnh (lượt)<input type="number" min="0" max="50" step="1" data-wb-setting="memoryAutoIndexInterval" value="${escapeAttr(settings.memoryAutoIndexInterval)}"></label>
            <button type="button" data-wb-action="scan-history" ${historyRunning || !settings.memorySystemEnabled ? 'disabled' : ''}>Để 玲七 sắp xếp ký ức</button>
        </div>
    `;

    const contentByScope = { now: nowHtml, people: peopleHtml, currents: currentsHtml, opinion: opinionHtml, memory: memoryHtml };
    return `
        <div class="wb-settings-popover wb-module-settings-popover wb-module-settings-${scopeKey}" role="dialog" aria-modal="true" aria-label="${escapeAttr(scopeInfo.title)}">
            <div class="wb-popover-heading">
                <div><span>${scopeInfo.eyebrow}</span><h3>${scopeInfo.title}</h3></div>
                <button type="button" data-wb-action="toggle-module-settings" data-view="${scopeKey}" aria-label="Đóng cài đặt">×</button>
            </div>
            <div class="wb-module-settings-body">${contentByScope[scopeKey]}</div>
        </div>
    `;
}

function renderEventModal(state, editorId = '') {
    const event = editorId
        ? state.events.find(item => item.id === editorId) || null
        : null;
    const isEdit = Boolean(event);
    const durationHours = Math.max(0, Number(event?.durationMinutes || 0) / 60);
    const durationValue = Number.isInteger(durationHours)
        ? String(durationHours)
        : String(Number(durationHours.toFixed(2)));
    const startedStamp = event
        ? formatWorldCalendar(state, event.startedAt).stamp
        : formatWorldCalendar(state).stamp;
    return `
        <div class="wb-drawer-scrim" data-wb-action="close-event-form">
            <form class="wb-event-form" data-wb-form="event">
                <div class="wb-form-heading">
                    <div><span>${isEdit ? 'EDIT CURRENT' : 'NEW CURRENT'}</span><h3>${isEdit ? 'Sửa mạch ngầm này' : 'Thả vào một mạch ngầm'}</h3></div>
                    <button type="button" data-wb-action="close-event-form">×</button>
                </div>
                <input type="hidden" name="id" value="${escapeAttr(event?.id || '')}">
                <label>Tên sự kiện<input name="title" required maxlength="140"
                    value="${escapeAttr(event?.title || '')}" placeholder="Ví dụ: sửa một chiếc máy liên lạc cũ"></label>
                <label>Địa điểm<input name="place" maxlength="140"
                    value="${escapeAttr(event?.place || '')}" placeholder="Trạm sửa chữa Nam Ngạn"></label>
                <label>Đang xảy ra chuyện gì<textarea name="summary" maxlength="420" rows="3">${escapeHtml(event?.summary || '')}</textarea></label>
                <label>Kết quả dự kiến<textarea name="expectedResult" maxlength="420" rows="2">${escapeHtml(event?.expectedResult || event?.consequence || '')}</textarea></label>
                ${isEdit ? `
                    <div class="wb-form-grid">
                        <label>Trạng thái hiện tại
                            <select name="status">
                                <option value="active" ${event?.status === 'active' ? 'selected' : ''}>Đang phát triển</option>
                                <option value="waiting" ${event?.status === 'waiting' ? 'selected' : ''}>Chờ điều kiện</option>
                                <option value="ready" ${event?.status === 'ready' ? 'selected' : ''}>Đến hạn chờ xác nhận</option>
                                <option value="resolved" ${event?.status === 'resolved' ? 'selected' : ''}>Đã kết thúc</option>
                                <option value="cancelled" ${event?.status === 'cancelled' ? 'selected' : ''}>Đã hủy</option>
                                <option value="missed" ${event?.status === 'missed' ? 'selected' : ''}>Đã bỏ lỡ</option>
                            </select>
                        </label>
                        <label>Kết quả thực tế (tùy chọn)
                            <textarea name="result" maxlength="620" rows="2" placeholder="Chỉ ghi kết quả đã thực sự hình thành">${escapeHtml(event?.result || '')}</textarea>
                        </label>
                    </div>
                    <p class="wb-form-hint">Trạng thái thủ công là sự thật thế giới hiện tại; sau khi đánh dấu Đã kết thúc / Đã hủy / Đã bỏ lỡ, suy diễn nền sẽ không lén đổi Mạch ngầm cũ này về Đang phát triển. Nếu sau này thật sự xuất hiện hậu quả mới, hãy tiếp tục bằng một Mạch ngầm mới.</p>
                ` : ''}
                <div class="wb-form-grid">
                    <label>Cách tính giờ
                        <select name="clockMode">
                            <option value="duration" ${event?.clockMode === 'duration' || !event ? 'selected' : ''}>Trôi tự nhiên</option>
                            <option value="active" ${event?.clockMode === 'active' ? 'selected' : ''}>Giờ làm hiệu quả</option>
                            <option value="scheduled" ${event?.clockMode === 'scheduled' ? 'selected' : ''}>Thời gian định trước</option>
                            <option value="condition" ${event?.clockMode === 'condition' ? 'selected' : ''}>Chờ điều kiện</option>
                        </select>
                    </label>
                    <label>Thời lượng dự kiến (giờ)
                        <input name="durationHours" type="number" min="0" step="0.5"
                            value="${isEdit ? escapeAttr(durationValue) : '12'}">
                    </label>
                </div>
                <label>Ranh giới hiển thị
                    <select name="visibility">
                        <option value="hidden" ${event?.visibility === 'hidden' || !event ? 'selected' : ''}>Nhân vật chưa thể biết</option>
                        <option value="trace" ${event?.visibility === 'trace' ? 'selected' : ''}>Có thể nhận ra qua dấu vết</option>
                        <option value="known" ${event?.visibility === 'known' ? 'selected' : ''}>Có thể biết qua tin tức</option>
                        <option value="direct" ${event?.visibility === 'direct' ? 'selected' : ''}>Có thể trực tiếp cảm nhận</option>
                    </select>
                </label>
                <div class="wb-form-note">
                    ${isEdit
                        ? `Mạch ngầm này tính từ ${escapeHtml(startedStamp)}. Sau khi đổi cách tính giờ hoặc thời lượng, sẽ tính lại theo thời điểm bắt đầu ban đầu; chỉ sửa chữ thì không thay đổi tiến độ hiện có.`
                        : `Từ ${escapeHtml(formatWorldCalendar(state).stamp)} bắt đầu tính giờ. Số lượt trả lời không làm tăng tiến độ.`}
                </div>
                <button class="wb-primary-button" type="submit">${isEdit ? 'Lưu thay đổi mạch ngầm' : 'Bắt đầu phát triển ở nền'}</button>
            </form>
        </div>
    `;
}

function renderPersonDrawer(person, observerMode, worldMinute, {
    canObserve = false,
    observation = null,
    busy = false,
} = {}) {
    if (!person) return '';
    return `
        <div class="wb-drawer-scrim" data-wb-action="close-person">
            <div class="wb-person-drawer" role="dialog" aria-modal="true" aria-label="Chi tiết nhân vật">
                <button class="wb-drawer-close" type="button" data-wb-action="close-person">×</button>
                ${renderPersonAvatar(person, 'is-feature')}
                <span class="wb-drawer-overline">LIVING TRACE</span>
                <h3>${escapeHtml(person.name)}</h3>
                <p class="wb-drawer-place">${escapeHtml(person.location)}</p>
                <button class="wb-person-edit-button" type="button" data-wb-action="open-person-editor"
                    data-person-id="${escapeAttr(person.id)}" data-person-name="${escapeAttr(person.name)}">Sửa thẻ nhân vật</button>
                ${!person.isUser ? `
                    <div class="wb-person-life-actions">
                        <button type="button" class="is-catchup" data-wb-action="catch-up-person"
                            data-person-id="${escapeAttr(person.id)}"
                            ${busy || person.simulationEnabled === false ? 'disabled' : ''}
                            title="Không đẩy thời gian thế giới, chỉ bổ sung trạng thái sinh hoạt hậu trường của nhân vật này tính đến hiện tại">
                            ${busy ? 'Đang kết toán…' : 'Cập nhật tình hình gần đây'}
                        </button>
                        <button type="button" class="is-priority ${person.lifeTickPriority ? 'is-active' : ''}"
                            data-wb-action="prioritize-person" data-person-id="${escapeAttr(person.id)}"
                            data-enabled="${person.lifeTickPriority ? 'false' : 'true'}"
                            aria-pressed="${person.lifeTickPriority ? 'true' : 'false'}"
                            ${busy || person.simulationEnabled === false ? 'disabled' : ''}
                            title="Không gọi API ngay, xếp cô ấy lên đầu lượt kết toán nhân vật nền kế tiếp">
                            ${person.lifeTickPriority ? 'Đã xếp lên trước' : 'Ưu tiên lượt sau'}
                        </button>
                    </div>
                    ${person.simulationEnabled === false ? '<p class="wb-person-life-note">Suy diễn ngoài ống kính đã tắt</p>' : ''}
                ` : ''}
                <div class="wb-drawer-section"><span>Đang làm</span><strong>${escapeHtml(person.action)}</strong></div>
                <div class="wb-drawer-section"><span>Ý định ngắn hạn</span><strong>${escapeHtml(person.intent)}</strong></div>
                ${person.longTermGoal ? `
                    <div class="wb-drawer-section"><span>Mục tiêu dài hạn</span><strong>${escapeHtml(person.longTermGoal)}</strong></div>
                ` : ''}
                ${person.identityAnchor ? `
                    <div class="wb-drawer-section is-character-anchor"><span>Neo thân phận</span><strong>${escapeHtml(person.identityAnchor)}</strong></div>
                ` : ''}
                ${person.appearanceProfile ? `
                    <div class="wb-drawer-section is-character-anchor"><span>Thiết lập ngoại hình</span><strong>${escapeHtml(person.appearanceProfile)}</strong></div>
                ` : ''}
                ${person.personalityAnchor ? `
                    <div class="wb-drawer-section is-character-anchor"><span>Neo nhân cách</span><strong>${escapeHtml(person.personalityAnchor)}</strong></div>
                ` : ''}
                ${person.backgroundProfile ? `
                    <div class="wb-drawer-section is-character-anchor"><span>Bối cảnh & quan hệ</span><strong>${escapeHtml(person.backgroundProfile)}</strong></div>
                ` : ''}
                ${person.abilityProfile ? `<div class="wb-drawer-section is-character-anchor"><span>Năng lực & giới hạn</span><strong>${escapeHtml(person.abilityProfile)}</strong></div>` : ''}
                ${person.speakingStyle ? `
                    <div class="wb-drawer-section is-character-anchor"><span>Thói quen nói chuyện</span><strong>${escapeHtml(person.speakingStyle)}</strong></div>
                ` : ''}
                ${person.behaviorBoundaries ? `
                    <div class="wb-drawer-section is-character-anchor"><span>Ranh giới hành vi</span><strong>${escapeHtml(person.behaviorBoundaries)}</strong></div>
                ` : ''}
                ${person.worldbookRaw ? `
                    <details class="wb-worldbook-source-profile">
                        <summary><span>Thiết lập gốc trong World Info</span><small>${String(person.worldbookRaw).length} chữ · bấm để xem</small></summary>
                        <pre>${escapeHtml(person.worldbookRaw)}</pre>
                    </details>
                ` : ''}
                ${person.trace ? `
                    <div class="wb-drawer-section"><span>Quỹ đạo gần đây</span><strong>${escapeHtml(person.trace)}</strong></div>
                ` : ''}
                ${observerMode === 'backstage'
                    ? renderInnerVoice(person, worldMinute)
                    : `
                        <div class="wb-knowledge-boundary">
                            <i></i><div><strong>Ranh giới hiểu biết</strong><p>Góc nhìn “Nhân vật biết” sẽ không đọc độc thoại hậu trường của cô ấy.</p></div>
                        </div>
                    `}
                <div class="wb-person-observation ${observation?.personId === person.id ? 'has-result' : ''}">
                    ${observation?.personId === person.id ? `
                        <article>
                            <span>Quan sát hậu trường · ${escapeHtml(formatWorldMinute(observation.worldMinute).time)}</span>
                            <p>${escapeHtml(observation.text)}</p>
                        </article>
                    ` : ''}
                    ${canObserve ? `
                        <div class="wb-observation-primary">
                            ${observation?.personId === person.id
                                ? '<span>Đã lưu theo chính văn và trạng thái thế giới hiện tại</span>'
                                : '<span>Không đẩy thời gian, cũng không ghi thẳng vào chính văn</span>'}
                            <button type="button" data-wb-action="observe-person"
                                data-person-id="${escapeAttr(person.id)}"
                                data-force="${observation?.personId === person.id ? 'true' : 'false'}"
                                ${busy ? 'disabled' : ''}>
                                ${busy
                                    ? 'Đang quan sát……'
                                    : observation?.personId === person.id
                                        ? 'Quan sát lại'
                                        : `Xem ${escapeHtml(person.name)} đang làm gì`}
                            </button>
                        </div>
                    ` : `
                        <p>${person.isUser
                            ? 'Nhân vật người chơi không dùng quan sát nhân vật tức thời.'
                            : observerMode !== 'backstage'
                                ? 'Chuyển về góc nhìn hậu trường để quan sát nhân vật.'
                                : 'Hiện không thể quan sát nhân vật này.'}</p>
                    `}
                </div>
                <div class="wb-knowledge-boundary wb-observation-boundary ${observation?.queued ? 'is-enabled' : ''} ${observation?.revealState === 'delivered' ? 'is-delivered' : ''}">
                    <i></i>
                    <div>
                        <strong>${observation?.revealState === 'delivered' ? 'Đã hé lộ' : 'Hé lộ tự nhiên'}</strong>
                        <p>${observation?.revealState === 'delivered'
                            ? 'Đoạn quan sát này đã được chính văn phía sau tiếp nối tự nhiên; đóng cửa sổ quan sát sẽ không xóa phần chính văn đã tạo.'
                            : observation?.revealState === 'expired'
                                ? 'Trước đó chưa gặp thời điểm hé lộ phù hợp nên đã ngừng đề xuất; bạn có thể bật lại.'
                                : observation?.queued
                                    ? 'Đã cho phép: đoạn quan sát này sẽ thành ứng viên cho chính văn khi ngữ cảnh phía sau phù hợp; không chèn ép buộc, cũng không đảm bảo xuất hiện ngay ở lượt kế tiếp.'
                                    : 'Mặc định tắt: chỉ để xem ở hậu trường, không vào chính văn, không đẩy thời gian, cũng không sửa ký ức.'}</p>
                    </div>
                    ${observation?.personId === person.id ? `
                        <button type="button" role="switch"
                            aria-checked="${observation.queued || observation.revealState === 'delivered' ? 'true' : 'false'}"
                            aria-label="Cho phép đoạn quan sát này hé lộ tự nhiên"
                            data-wb-action="queue-person-observation"
                            data-person-id="${escapeAttr(person.id)}"
                            ${observation.revealState === 'delivered' ? 'disabled' : ''}>
                            <span></span>
                        </button>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
}

export function sortEventsForDisplay(events, state, presentPeople = []) {
    const now = Number(state?.clock?.absoluteMinute || 0);
    const presentIds = new Set(presentPeople.map(person => String(person?.id || '')).filter(Boolean));
    const presentNames = new Set(presentPeople.map(person => String(person?.name || '')).filter(Boolean));
    const presentPlaces = new Set(presentPeople.map(person => String(person?.location || '')).filter(Boolean));
    const score = event => {
        let value = 0;
        if (event?.delivery?.manualQueued) value += 100000;
        const actors = new Set((event?.actors || []).map(String));
        if ([...actors].some(actor => presentIds.has(actor) || presentNames.has(actor))) value += 24000;
        if (presentPlaces.has(String(event?.place || ''))) value += 16000;
        value += ({ direct: 6000, known: 4200, trace: 2600, hidden: 0 }[event?.visibility] || 0);
        if (event?.status === 'active') value += 1800;
        if (Number.isFinite(Number(event?.dueAt)) && now > 0) {
            const remaining = Number(event.dueAt) - now;
            if (remaining <= 60 && remaining >= 0) value += 7000;
            else if (remaining <= 360 && remaining >= 0) value += 3500;
        }
        const age = Math.max(0, now - Number(event?.updatedAt || 0));
        value += Math.max(0, 1440 - Math.min(1440, age));
        return value;
    };
    return [...events].sort((a, b) => score(b) - score(a) || Number(b?.updatedAt || 0) - Number(a?.updatedAt || 0));
}

export function sortPeopleForDisplay(people, activeEvents, presentPersonIds = new Set(), worldMinute = 0) {
    const activeActors = new Set();
    for (const event of activeEvents || []) {
        for (const actor of event?.actors || []) activeActors.add(String(actor));
    }
    const score = person => {
        let value = 0;
        if (presentPersonIds.has(String(person?.id || ''))) value += 100000;
        if (activeActors.has(String(person?.id || '')) || activeActors.has(String(person?.name || ''))) value += 24000;
        if (person?.simulationEnabled !== false) value += 1800;
        value += Number(person?.relevance || 0) * 3200;
        const age = Math.max(0, Number(worldMinute || 0) - Number(person?.updatedAt || 0));
        value += Math.max(0, 1440 - Math.min(1440, age));
        return value;
    };
    return [...people].sort((a, b) => score(b) - score(a) || String(a?.name || '').localeCompare(String(b?.name || ''), 'zh-CN'));
}



const LINGQI_MASCOT_ASSETS = LINGQI_MASCOT_DATA_URLS;

function lingqiMascotState(lingqi = {}, _activeNotes = [], pending = null, override = '') {
    // 模型硬状态永远优先于随机待机/点击反应。
    if (lingqi.phase === 'running') return 'confused';
    if (lingqi.phase === 'error') return 'hold';
    if (Object.hasOwn(LINGQI_MASCOT_ASSETS, override)) return override;
    if (Object.hasOwn(LINGQI_MASCOT_ASSETS, lingqi.mascotState)) return lingqi.mascotState;
    if (pending) return 'note';
    if (Array.isArray(lingqi.messages) && lingqi.messages.length) return 'watch';
    return 'idle';
}

function lingqiMascotAssetState(state = 'idle') {
    return Object.hasOwn(LINGQI_MASCOT_ASSETS, state) ? state : 'idle';
}

function lingqiSupportCategoryLabel(category = 'unknown') {
    return {
        usage: 'Cách sử dụng',
        settings: 'Cài đặt / cấu hình',
        api: 'API / trung chuyển',
        task: 'Tác vụ nền',
        memory: 'Ký ức',
        people: 'Nhân vật',
        injection: 'Chèn vào chính văn',
        opinion: 'Dư luận / tin tức',
        worldbook: 'Nhập World Info',
        data: 'Tính nhất quán dữ liệu',
        ui: 'Giao diện / tương tác',
        compatibility: 'Tính tương thích',
        performance: 'Hiệu năng / giới hạn tốc độ',
        unknown: 'Chưa phân loại',
    }[String(category || 'unknown')] || 'Chưa phân loại';
}

function renderLingqiView(lingqi = {}, draft = '', mascotOverride = '', openReadableKeys = new Set()) {
    const storedMessages = Array.isArray(lingqi.messages) ? lingqi.messages : [];
    const messages = storedMessages.slice(-120);
    const hiddenMessageCount = Math.max(0, storedMessages.length - messages.length);
    const notes = Array.isArray(lingqi.notes) ? lingqi.notes : [];
    const pending = lingqi.pendingProposal && typeof lingqi.pendingProposal === 'object'
        ? lingqi.pendingProposal
        : null;
    const pendingAction = lingqi.pendingAction && typeof lingqi.pendingAction === 'object'
        ? lingqi.pendingAction
        : null;
    const activeNotes = notes.filter(note => ['active', 'paused'].includes(note.status));
    const archivedNotes = notes.filter(note => ['completed', 'expired'].includes(note.status)).slice(-4).reverse();
    // Archived notes now live behind a collapsed box, so they should not keep
    // the whole notes column stretched when there is no active paper on the board.
    const notesEmpty = activeNotes.length === 0;
    const lingqiBusy = lingqi.phase === 'running';
    const mascotState = lingqiMascotState(lingqi, activeNotes, pending, mascotOverride);
    const mascotAssetState = lingqiMascotAssetState(mascotState);
    const mascotSrc = LINGQI_MASCOT_ASSETS[mascotAssetState] || LINGQI_MASCOT_ASSETS.idle;
    const noteStatus = note => ({
        active: '',
        paused: 'Đè dưới chân mèo',
        completed: 'Làm xong rồi',
        expired: 'Cất đi rồi',
        cancelled: 'Gỡ xuống rồi',
    }[note.status] || '');
    const readableOpenAttr = key => openReadableKeys?.has?.(key) ? ' open' : '';

    return `
        <div class="wb-lingqi-layout">
            <div class="wb-lingqi-surface">
                <div class="wb-lingqi-perch" aria-hidden="false">
                    <button class="wb-lingqi-mascot is-${mascotState} is-asset-${mascotAssetState}" type="button"
                        data-wb-action="lingqi-pet" data-mascot-state="${mascotState}"
                        aria-label="Chạm vào 玲七" title="${lingqiBusy ? '玲七 đang nghĩ……' : 'Chạm vào 玲七'}">
                        <img src="${escapeAttr(mascotSrc)}" alt="" draggable="false">
                    </button>
                </div>

                <section class="wb-lingqi-chat-card">
                    <div class="wb-lingqi-chat-log ${messages.length ? '' : 'is-empty'}" aria-live="polite">
                        ${hiddenMessageCount ? `
                            <div class="wb-lingqi-history-fold-note">
                                Cũ hơn: ${hiddenMessageCount} tin nhắn vẫn đang được cất giữ. Cứ nói thẳng với 玲七 muốn tìm đoạn nào, xóa đoạn nào là được.
                            </div>
                        ` : ''}
                        ${messages.length ? messages.map(message => `
                            <div class="wb-lingqi-message is-${message.role === 'user' ? 'user' : 'assistant'}">
                                <p>${escapeHtml(message.text).replaceAll('\n', '<br>')}</p>
                                ${message.role !== 'user' && message.planText ? `
                                    <details class="wb-lingqi-readable"
                                        data-lingqi-readable-key="${escapeAttr(`message:${message.id}`)}"${readableOpenAttr(`message:${message.id}`)}>
                                        <summary aria-label="Mở rộng bản ghi tiến triển thực tế">⌄</summary>
                                        <div>${escapeHtml(message.planText).replaceAll('\n', '<br>')}</div>
                                    </details>
                                ` : ''}
                                ${message.role !== 'user' && message.needsAuthorHelp ? `
                                    <div class="wb-lingqi-support-card">
                                        <div class="wb-lingqi-support-head">
                                            <span class="wb-lingqi-support-note-icon" aria-hidden="true"></span>
                                            <strong>${escapeHtml(lingqiSupportCategoryLabel(message.supportTriage?.category))}</strong>
                                        </div>
                                        <p>${escapeHtml(
                                            message.supportTriage?.summary
                                            || message.supportReason
                                            || 'Trạng thái hiện có tạm thời chưa giải thích được câu hỏi này.',
                                        )}</p>
                                        ${message.supportTriage?.checked?.length ? `
                                            <small>玲七 đã tra: ${escapeHtml(message.supportTriage.checked.join('；'))}</small>
                                        ` : ''}
                                        <div class="wb-lingqi-support-row">
                                            <button type="button" class="wb-lingqi-support-note"
                                                data-wb-action="lingqi-copy-support-pack"
                                                data-message-id="${escapeAttr(message.id)}"
                                                title="Nhận mảnh giấy nhỏ 玲七 viết cho mẹ">
                                                <span>Nhận giấy nhắn</span>
                                            </button>
                                        </div>
                                    </div>
                                ` : ''}
                            </div>
                        `).join('') : ''}
                    </div>
                    ${pending ? `
                        <div class="wb-lingqi-proposal">
                            <span class="wb-lingqi-tape" aria-hidden="true"></span>
                            <p>${escapeHtml(pending.paperText)}</p>
                            ${(pending.planText || pending.directive) ? `
                                <details class="wb-lingqi-readable is-paper"
                                    data-lingqi-readable-key="pending"${readableOpenAttr('pending')}>
                                    <summary aria-label="Mở rộng bản ghi tiến triển thực tế">⌄</summary>
                                    <div>${escapeHtml(pending.planText || pending.directive).replaceAll('\n', '<br>')}</div>
                                </details>
                            ` : ''}
                            <div class="wb-lingqi-proposal-actions">
                                <button type="button" data-wb-action="lingqi-confirm-note">Giữ lại đã</button>
                                <button type="button" data-wb-action="lingqi-dismiss-note">Không cần nữa</button>
                            </div>
                        </div>
                    ` : ''}
                    ${pendingAction ? `
                        <div class="wb-lingqi-action-confirm" role="alertdialog"
                            aria-label="${escapeAttr(pendingAction.title || 'Xác nhận việc 玲七 làm hộ')}">
                            <span class="wb-lingqi-action-kaomoji" aria-hidden="true">(^. .^)</span>
                            <div>
                                <strong>${escapeHtml(pendingAction.title || 'Có muốn mình đi làm không?')}</strong>
                                <p>${escapeHtml(pendingAction.detail || 'Thao tác này sẽ gọi model nền.')}</p>
                                ${Array.isArray(pendingAction.previewLines) && pendingAction.previewLines.length ? `
                                    <div class="wb-lingqi-action-preview">
                                        ${pendingAction.previewLines.map(line => `<span>${escapeHtml(line)}</span>`).join('')}
                                    </div>
                                ` : ''}
                                ${pendingAction.caution ? `<small>${escapeHtml(pendingAction.caution)}</small>` : ''}
                            </div>
                            <div class="wb-lingqi-action-confirm-buttons">
                                <button type="button" data-wb-action="lingqi-dismiss-action">Khoan đã</button>
                                <button type="button" class="is-confirm" data-wb-action="lingqi-confirm-action">
                                    ${escapeHtml(pendingAction.confirmLabel || 'Gật đầu')}
                                </button>
                            </div>
                        </div>
                    ` : ''}
                    <form class="wb-lingqi-input" data-wb-form="lingqi-chat">
                        <textarea name="text" rows="1" maxlength="3000" ${lingqiBusy ? 'disabled' : ''}
                            placeholder="……">${escapeHtml(draft)}</textarea>
                        <button type="submit" aria-label="Chọc" title="Chọc" ${lingqiBusy ? 'disabled' : ''}>${lingqiBusy ? '…' : 'Chọc'}</button>
                    </form>
                </section>

                <section class="wb-lingqi-notes-card ${notesEmpty ? 'is-empty' : ''}">
                <div class="wb-lingqi-notes-head">
                    <div><span>🐾</span><strong>Giấy nhắn của 玲七</strong></div>
                    ${activeNotes.length ? `<small>× ${activeNotes.length}</small>` : ''}
                </div>
                <div class="wb-lingqi-notes-scroll">
                <div class="wb-lingqi-note-board">
                    ${activeNotes.length ? activeNotes.map((note, index) => `
                        <article class="wb-lingqi-note is-${escapeAttr(note.status)} is-tone-${index % 4}" style="--wb-note-tilt:${index % 2 ? '0.8deg' : '-0.7deg'}">
                            <span class="wb-lingqi-note-tape" aria-hidden="true"></span>
                            <p>${escapeHtml(note.paperText)}</p>
                            ${note.lastComment ? `<small>${escapeHtml(note.lastComment)}</small>` : ''}
                            ${(note.planText || note.directive) ? `
                                <details class="wb-lingqi-readable is-paper"
                                    data-lingqi-readable-key="${escapeAttr(`note:${note.id}`)}"${readableOpenAttr(`note:${note.id}`)}>
                                    <summary aria-label="Mở rộng bản ghi tiến triển thực tế">⌄</summary>
                                    <div>${escapeHtml(note.planText || note.directive).replaceAll('\n', '<br>')}</div>
                                </details>
                            ` : ''}
                            <div class="wb-lingqi-note-foot">
                                ${noteStatus(note) ? `<em>${escapeHtml(noteStatus(note))}</em>` : ''}
                                <div>
                                    ${note.status === 'active' ? `
                                        <button type="button" data-wb-action="lingqi-pause-note" data-note-id="${escapeAttr(note.id)}" title="Tạm đè dưới chân mèo đã">Đè lại</button>
                                    ` : `
                                        <button type="button" data-wb-action="lingqi-resume-note" data-note-id="${escapeAttr(note.id)}" title="Dán trở lại">Dán lại</button>
                                    `}
                                    <button type="button" data-wb-action="lingqi-cancel-note" data-note-id="${escapeAttr(note.id)}">Gỡ bỏ</button>
                                </div>
                            </div>
                        </article>
                    `).join('') : `
                        <div class="wb-lingqi-note-empty" aria-label="Tạm thời chưa có giấy nhắn">
                            <span aria-hidden="true">₍^. .^₎⟆</span>
                        </div>
                    `}
                </div>
                ${archivedNotes.length ? `
                    <details class="wb-lingqi-note-box"
                        data-lingqi-readable-key="archive"${readableOpenAttr('archive')}>
                        <summary>
                            <strong>Trong hộp nhỏ</strong>
                            <span>${archivedNotes.length} tờ giấy nhắn đã cất</span>
                            <i aria-hidden="true"></i>
                        </summary>
                        <div class="wb-lingqi-note-box-body">
                            ${archivedNotes.map(note => `
                                <div><span>${escapeHtml(noteStatus(note))}</span><p>${escapeHtml(note.paperText)}</p></div>
                            `).join('')}
                        </div>
                    </details>
                ` : ''}
                </div>
                </section>
            </div>
        </div>
    `;
}

function renderNowView(state, observerMode, people, activeEvents, narrativeSync = {}) {
    const clock = formatWorldCalendar(state);
    const clockLabel = worldClockLabel(state);
    return `
        <div class="wb-overview">
            <section class="wb-world-card">
                <div class="wb-world-card-copy">
                    <div class="wb-world-card-heading-row">
                        <span class="wb-section-kicker">WORLD STATE · ${escapeHtml(clockLabel)}</span>
                        <button class="wb-card-action-button is-edit" type="button"
                            data-wb-action="open-world-editor" aria-label="Sửa thiết lập thế giới">Sửa</button>
                    </div>
                    <h3>${escapeHtml(state.world.title)}</h3>
                    <p>${escapeHtml(state.world.detail)}</p>
                    ${state.world?.background
                        ? '<span class="wb-section-kicker">WORLD BACKGROUND · Đã thiết lập</span>'
                        : ''}
                </div>
                <div class="wb-world-pulse" aria-hidden="true">
                    <i></i><i></i><span></span>
                    <strong>${state.needsReconciliation ? 'Chờ hiệu chỉnh' : narrativeSync.needsSimulation ? 'chờ suy diễn' : 'Đang tiếp diễn'}</strong>
                </div>
            </section>

            <div class="wb-overview-grid">
                <section class="wb-overview-section">
                    <div class="wb-section-heading">
                        <div><span>Đang hình thành</span><h3>Mạch ngầm</h3></div>
                        <button type="button" data-wb-action="set-view" data-view="currents">Xem tất cả →</button>
                    </div>
                    <div class="wb-event-list is-compact">
                        ${activeEvents.slice(0, 2).map(event => renderEventCard(event, state)).join('')
                            || renderEmpty('Mạch ngầm hôm nay yên ắng quá～', 'Không có sự kiện nào đang phát triển cũng không sao, các nhân vật vẫn sống cuộc sống của mình như thường (˘ω˘)')}
                    </div>
                </section>

                <section class="wb-overview-section">
                    <div class="wb-section-heading">
                        <div><span>Đang tiếp tục sống</span><h3>Quỹ đạo nhân vật</h3></div>
                        <button type="button" data-wb-action="set-view" data-view="people">Xem tất cả →</button>
                    </div>
                    <div class="wb-person-list">
                        ${people.slice(0, 3).map(person => renderPersonRow(
                            person,
                            observerMode,
                            state.clock.absoluteMinute,
                        )).join('') || renderEmpty('Quỹ đạo nhân vật vẫn chưa khai trương～', 'Chạy suy diễn thế giới một lần, các cô ấy sẽ dần để lại dấu vết cuộc sống của riêng mình.')}
                    </div>
                </section>
            </div>
        </div>
    `;
}

function renderSocialView(state, social = {}, settings = {}, {
    draft = '',
    groupOpen = false,
    groupSelectedIds = new Set(),
    page = 'messages',
    searchQuery = '',
} = {}) {
    const people = (Array.isArray(state?.people) ? state.people : []).filter(person => !person?.isUser);
    const peopleById = new Map(people.map(person => [String(person.id || ''), person]));
    const allConversations = Array.isArray(social?.conversations) ? social.conversations : [];
    const connections = Array.isArray(social?.connections) ? social.connections : [];
    const connectionsByPersonId = new Map(connections.map(item => [String(item.personId || ''), item]));
    const acceptedIds = new Set(connections.filter(item => item.status === 'accepted').map(item => String(item.personId || '')));
    const conversations = allConversations.filter(conversation => (
        conversation?.type === 'group'
        || acceptedIds.has(String(conversation?.memberIds?.[0] || ''))
    ));
    const friends = people.filter(person => acceptedIds.has(String(person.id || '')));
    const active = conversations.find(item => item.id === social.activeConversationId) || null;
    const activeBusy = social.running === true
        && (!social.conversationId || social.conversationId === active?.id);
    const emptyMascot = '<div class="wb-social-empty-sticker" aria-hidden="true"><span>(^..^)</span></div>';
    const conversationAvatar = conversation => {
        if (conversation?.type === 'group') {
            const members = (conversation.memberIds || [])
                .map(id => peopleById.get(String(id)))
                .filter(Boolean)
                .slice(0, 3);
            return `<span class="wb-social-group-avatar is-members" aria-hidden="true">${members.map(person => `<b>${escapeHtml(String(person.name || '·').slice(0, 1))}</b>`).join('') || '<b>Nhóm</b>'}</span>`;
        }
        const person = conversation?.memberIds
            ?.map(id => peopleById.get(String(id)))
            .find(Boolean);
        return person
            ? renderPersonAvatar(person, 'is-social')
            : '<span class="wb-social-group-avatar is-direct" aria-hidden="true">·</span>';
    };
    const activeMembers = active?.memberIds
        ?.map(id => peopleById.get(String(id)))
        .filter(Boolean) || [];
    const activePerson = active?.type === 'direct' ? activeMembers[0] : null;
    const activeSubtitle = active?.type === 'group'
        ? `${activeMembers.length} người · nhóm nhỏ`
        : (activePerson?.location || activePerson?.role || 'Chat riêng');
    const directConversationPersonIds = new Set(conversations
        .filter(conversation => conversation?.type === 'direct')
        .flatMap(conversation => conversation.memberIds || [])
        .map(String));
    const availableContacts = friends.filter(person => !directConversationPersonIds.has(String(person.id || '')));
    const normalizedSearch = String(searchQuery || '').trim().toLocaleLowerCase();
    const searchResults = normalizedSearch.length >= 2
        ? people.filter(person => `${person.name || ''}\n${person.identityAnchor || ''}`.toLocaleLowerCase().includes(normalizedSearch)).slice(0, 12)
        : [];
    const suggestedPeople = connections
        .filter(item => item.status === 'suggested')
        .map(item => peopleById.get(String(item.personId || '')))
        .filter(Boolean)
        .slice(0, 8);
    const incomingPeople = connections
        .filter(item => item.status === 'incoming')
        .map(item => peopleById.get(String(item.personId || '')))
        .filter(Boolean);
    const moments = (Array.isArray(social?.moments) ? social.moments : [])
        .map(moment => ({ ...moment, person: peopleById.get(String(moment.personId || '')) }))
        .filter(moment => moment.person && acceptedIds.has(String(moment.personId || '')))
        .reverse();
    const unreadNotices = (Array.isArray(social?.notices) ? social.notices : []).filter(item => !item?.readAt);
    const hasUnreadMessages = unreadNotices.some(item => item.kind === 'message');
    const hasUnreadContacts = unreadNotices.some(item => ['friend_request', 'friend_removed'].includes(item.kind));
    const hasUnreadMoments = unreadNotices.some(item => item.kind === 'moment');
    const messageAvatar = message => {
        if (message?.senderId === 'user') {
            return '<span class="wb-social-self-avatar" aria-hidden="true">Tôi</span>';
        }
        const person = peopleById.get(String(message?.senderId || ''))
            || activeMembers.find(item => item.name === message?.senderName);
        return person
            ? renderPersonAvatar(person, 'is-social')
            : '<span class="wb-social-group-avatar is-direct" aria-hidden="true">·</span>';
    };
    const messageTime = message => formatWorldMinute(Math.max(0, Number(message?.worldMinute) || 0)).time;
    const emptyThread = friends.length
        ? `<div class="wb-social-empty-thread is-large">
            ${emptyMascot}
            <strong>Muốn tìm ai để trò chuyện nè?</strong>
            <button type="button" data-wb-action="social-toggle-group" ${friends.length < 2 ? 'disabled' : ''}>${friends.length < 2 ? 'Cần hai người bạn mới tạo được nhóm' : 'Tạo nhóm chat mới'}</button>
        </div>`
        : people.length
            ? `<div class="wb-social-empty-thread is-large is-first-use">
                ${emptyMascot}
                <strong>玲七 vẫn chưa tìm được bạn nào cả</strong>
                <div class="wb-social-empty-actions"><button class="is-primary" type="button" data-wb-action="social-set-page" data-page="contacts">Đi kết bạn</button></div>
            </div>`
        : `<div class="wb-social-empty-thread is-large is-first-use">
            ${emptyMascot}
            <strong>Trước hết hãy để 玲七 quen vài người đã</strong>
            <div class="wb-social-empty-actions">
                <button class="is-primary" type="button" data-wb-action="social-import-people">Để 玲七 đi tìm trong World Info</button>
                <button type="button" data-wb-action="social-go-people">Sang trang nhân vật xem thử</button>
            </div>
        </div>`;
    const messagesView = `
        ${groupOpen ? `
            <form class="wb-social-group-form" data-wb-form="social-group">
                <label>Tên nhóm<input name="title" maxlength="120" placeholder="Để trống thì dùng tên thành viên"></label>
                <div class="wb-social-group-people">
                    ${friends.map(person => `<label><input type="checkbox" name="memberIds" value="${escapeAttr(person.id)}" ${groupSelectedIds.has(String(person.id || '')) ? 'checked' : ''}><span>${escapeHtml(person.name)}</span></label>`).join('') || '<span>Chưa có bạn bè</span>'}
                </div>
                <button type="submit" ${friends.length < 2 ? 'disabled' : ''}>Tạo nhóm</button>
            </form>
        ` : ''}
        <div class="wb-social-layout">
            <aside class="wb-social-sidebar">
                <header class="wb-social-sidebar-head">
                    <div><strong>Trò chuyện gần đây</strong>${conversations.length ? `<small>${conversations.length}</small>` : ''}</div>
                    <button type="button" data-wb-action="social-toggle-group" ${friends.length < 2 ? 'disabled title="Cần ít nhất hai người bạn"' : ''}><span aria-hidden="true">＋</span>${groupOpen ? 'Thu gọn' : 'Nhóm nhỏ'}</button>
                </header>
                <div class="wb-social-sidebar-scroll">
                    <div class="wb-social-conversations">
                        ${conversations.map(conversation => {
                            const last = conversation.rawMessages?.at(-1);
                            return `<button type="button" class="${conversation.id === active?.id ? 'is-active' : ''}" data-wb-action="social-select-conversation" data-conversation-id="${escapeAttr(conversation.id)}">
                                ${conversationAvatar(conversation)}<span><strong>${escapeHtml(conversation.title)}</strong><small>${escapeHtml(last?.text || 'Chưa có tin nhắn')}</small></span>
                            </button>`;
                        }).join('')}
                    </div>
                    ${availableContacts.length ? `<div class="wb-social-section-title"><strong>玲七 có thể giúp bạn chuyển lời</strong><small>${availableContacts.length}</small></div>
                    <div class="wb-social-contacts">
                        ${availableContacts.map(person => `<button type="button" data-wb-action="social-open-person" data-person-id="${escapeAttr(person.id)}">${renderPersonAvatar(person, 'is-social')}<span><strong>${escapeHtml(person.name)}</strong><small>${escapeHtml(person.location || 'Chưa ghi nhận vị trí')}</small></span></button>`).join('')}
                    </div>` : ''}
                </div>
                <label class="wb-social-isolation-control" title="Khi bật, cuộc chat gần đây sẽ được dùng làm bản ghi chưa kết toán để chính văn tham khảo">
                    <span><i></i><b>${settings.injectionSocial === true ? 'Đưa vào chính văn' : 'Chỉ giữ ở đây'}</b></span>
                    <span class="wb-switch"><input type="checkbox" data-wb-setting="injectionSocial" ${settings.injectionSocial === true ? 'checked' : ''}><i></i></span>
                </label>
            </aside>
            <main class="wb-social-thread">
                ${active ? `
                    <header>
                        <div class="wb-social-thread-contact">${conversationAvatar(active)}<div><h3>${escapeHtml(active.title)}</h3><span>${escapeHtml(activeSubtitle)}</span></div></div>
                        ${activeBusy ? '<span class="wb-social-thread-state"><i></i>Đang trả lời…</span>' : ''}
                    </header>
                    <div class="wb-social-log" aria-live="polite">
                        ${settings.injectionSocial === true ? '<p class="wb-social-context-banner">Đoạn chat này sẽ được đưa vào chính văn</p>' : ''}
                        ${(active.rawMessages || []).map(message => `<article class="${message.senderId === 'user' ? 'is-user' : ''}">${messageAvatar(message)}<div class="wb-social-message-main"><span><b>${escapeHtml(message.senderName)}</b><time>${escapeHtml(messageTime(message))}</time></span><p>${escapeHtml(message.text)}</p></div></article>`).join('') || `<div class="wb-social-empty-thread is-conversation"><span class="wb-social-empty-monogram">${escapeHtml(active.title.slice(0, 1))}</span><strong>Nói gì đó với ${escapeHtml(active.title)} đi nào</strong></div>`}
                    </div>
                    ${active.lastError ? `<p class="wb-social-error">Lỗi lần trước: ${escapeHtml(active.lastError)}</p>` : ''}
                    <button class="wb-social-cat-delivery" type="button"
                        data-wb-action="social-request-reply"
                        data-conversation-id="${escapeAttr(active.id)}"
                        title="Gọi API một lần để hội thoại này trả lời một lượt ngay bây giờ"
                        ${settings.socialInstantReply !== false || active?.rawMessages?.at(-1)?.senderId !== 'user' ? 'hidden' : ''}
                        ${activeBusy ? 'disabled' : ''}><span aria-hidden="true">🐾</span> Mèo con chuyển lời</button>
                    <form class="wb-social-compose" data-wb-form="social-message">
                        <input type="hidden" name="conversationId" value="${escapeAttr(active.id)}">
                        <textarea name="text" rows="1" maxlength="1600" placeholder="Nhờ 玲七 nhắn một câu…" ${activeBusy ? 'disabled' : ''}>${escapeHtml(draft)}</textarea>
                        <button type="submit" ${activeBusy ? 'disabled' : ''}>${activeBusy ? '玲七 đang trên đường…' : 'Gửi đi'}</button>
                    </form>
                ` : emptyThread}
            </main>
        </div>`;

    const friendCard = person => {
        const connection = connectionsByPersonId.get(String(person.id || ''));
        const requestBusy = social?.friendRequest?.running && social.friendRequest.personId === String(person.id || '');
        const status = connection?.status || '';
        const action = status === 'accepted'
            ? `<div class="wb-social-friend-actions"><button type="button" data-wb-action="social-open-person" data-person-id="${escapeAttr(person.id)}">Nhắn tin</button><button class="is-danger" type="button" data-wb-action="social-remove-friend" data-person-id="${escapeAttr(person.id)}" data-person-name="${escapeAttr(person.name)}">Xóa</button></div>`
            : status === 'incoming'
                ? `<div class="wb-social-friend-actions"><button class="is-primary" type="button" data-wb-action="social-respond-friend-request" data-person-id="${escapeAttr(person.id)}" data-accept="true">Chấp nhận</button><button type="button" data-wb-action="social-respond-friend-request" data-person-id="${escapeAttr(person.id)}" data-accept="false">Từ chối</button></div>`
            : status === 'pending'
                ? '<button type="button" disabled>Chờ xử lý</button>'
                : `<form data-wb-form="social-friend-request"><input type="hidden" name="personId" value="${escapeAttr(person.id)}"><input name="message" maxlength="300" placeholder="${status === 'declined' ? 'Lời nhắn xin kết bạn lại (tùy chọn)' : status === 'removed' ? 'Lời nhắn thêm lại (tùy chọn)' : 'Lời nhắn xác minh (không bắt buộc)'}"><button type="submit" ${requestBusy ? 'disabled' : ''}>${requestBusy ? 'Đang chờ…' : status === 'declined' || status === 'removed' ? 'Gửi lại lời mời' : 'Kết bạn'}</button></form>`;
        const visibleReply = connection?.decisionReply
            || (status === 'incoming' ? connection?.requestMessage : '')
            || (status === 'removed' || status === 'declined' ? connection?.decisionReason : '')
            || (status === 'suggested' ? connection?.evidence : '')
            || (status === 'accepted' ? connection?.evidence : 'Nhân vật tìm thấy theo tên');
        return `<article class="wb-social-friend-card">${renderPersonAvatar(person, 'is-social')}<div><strong>${escapeHtml(person.name)}</strong><span>${escapeHtml(person.identityAnchor || 'Nhân vật thế giới')}</span>${visibleReply ? `<small>${escapeHtml(visibleReply)}</small>` : ''}</div>${action}</article>`;
    };
    const contactsView = `
        <div class="wb-social-directory">
            <aside class="wb-social-friend-list">
                <header><strong>Bạn bè</strong><small>${friends.length}</small></header>
                <div>${friends.map(person => `<article>${renderPersonAvatar(person, 'is-social')}<button type="button" data-wb-action="social-open-person" data-person-id="${escapeAttr(person.id)}"><span><strong>${escapeHtml(person.name)}</strong><small>${escapeHtml(connectionsByPersonId.get(String(person.id || ''))?.evidence || 'Đã là bạn bè rồi')}</small></span></button><button class="wb-social-friend-remove" type="button" data-wb-action="social-remove-friend" data-person-id="${escapeAttr(person.id)}" data-person-name="${escapeAttr(person.name)}" title="Xóa bạn">×</button></article>`).join('') || '<p>Chưa có bạn bè</p>'}</div>
            </aside>
            <main class="wb-social-add-friend">
                <header><strong>玲七 giúp bạn tìm nè ฅ</strong></header>
                <label class="wb-social-auto-control"><span><strong>Nhờ 玲七 để ý động tĩnh mới</strong></span><span class="wb-switch"><input type="checkbox" data-wb-setting="socialAutoEnabled" ${settings.socialAutoEnabled !== false ? 'checked' : ''}><i></i></span></label>
                <label class="wb-social-search"><span aria-hidden="true">⌕</span><input type="search" data-wb-social-search value="${escapeAttr(searchQuery)}" placeholder="Nói tên cho 玲七…" autocomplete="off"></label>
                ${social?.friendRequest?.phase === 'error' ? `<p class="wb-social-request-error">${escapeHtml(social.friendRequest.error || social.friendRequest.message)}</p>` : ''}
                <div class="wb-social-search-results">
                    ${normalizedSearch.length >= 2
                        ? (searchResults.map(friendCard).join('') || '<div class="wb-social-directory-empty">玲七 không tìm thấy cái tên này rồi.</div>')
                        : incomingPeople.length || suggestedPeople.length
                            ? `${incomingPeople.length ? `<div class="wb-social-suggestion-title"><strong>Có người nhờ 玲七 đến gõ cửa</strong><span>${incomingPeople.length}</span></div>${incomingPeople.map(friendCard).join('')}` : ''}${suggestedPeople.length ? `<div class="wb-social-suggestion-title"><strong>玲七 hình như đã gặp</strong></div>${suggestedPeople.map(friendCard).join('')}` : ''}`
                            : '<div class="wb-social-directory-empty">Nói tên cho 玲七, 玲七 sẽ đi tìm.</div>'}
                </div>
            </main>
        </div>`;

    const momentsView = `
        <div class="wb-social-moments">
            <header><div><h3>Khoảnh khắc</h3></div><button type="button" data-wb-action="social-refresh-moments" ${social?.momentsStatus?.running ? 'disabled' : ''}>${social?.momentsStatus?.running ? '玲七 đang đi lòng vòng bên ngoài…' : 'Để 玲七 đi dạo một vòng'}</button></header>
            ${social?.momentsStatus?.phase === 'error' ? `<p class="wb-social-request-error">${escapeHtml(social.momentsStatus.error || social.momentsStatus.message)}</p>` : ''}
            <div class="wb-social-moment-feed">
                ${moments.map(moment => `<article class="wb-social-moment-card">
                    ${renderPersonAvatar(moment.person, 'is-social')}
                    <div class="wb-social-moment-body"><header><strong>${escapeHtml(moment.person.name)}</strong><time>${escapeHtml(formatWorldMinute(moment.worldMinute).time)}</time></header><p>${escapeHtml(moment.text)}</p>
                    ${moment.imageUrl ? `<img src="${escapeAttr(moment.imageUrl)}" alt="${escapeAttr(moment.person.name)} — ảnh đăng Khoảnh khắc" loading="lazy">` : ''}
                    <footer><span>Bạn bè có thể xem${moment.imageError ? ' · Tạo ảnh thất bại, đã giữ lại phần chữ' : ''}</span><button type="button" class="${moment.likedByUser ? 'is-active' : ''}" data-wb-action="social-toggle-moment-like" data-moment-id="${escapeAttr(moment.id)}">♡ ${Math.max(0, Number(moment.likes) || 0)}</button></footer></div>
                </article>`).join('') || `<div class="wb-social-moments-empty">${emptyMascot}<strong>${friends.length ? '玲七 chưa nghe được chuyện gì mới' : 'Trước hết hãy để 玲七 quen vài người bạn đã'}</strong></div>`}
            </div>
        </div>`;

    return `
        <section class="wb-social-shell is-page-${escapeAttr(page)}">
            <nav class="wb-social-page-tabs" aria-label="Trang liên lạc">
                <button type="button" class="${page === 'messages' ? 'is-active' : ''}" data-wb-action="social-set-page" data-page="messages"><i></i>Tin nhắn${hasUnreadMessages ? '<em></em>' : ''}</button>
                <button type="button" class="${page === 'contacts' ? 'is-active' : ''}" data-wb-action="social-set-page" data-page="contacts"><i></i>Bạn bè${hasUnreadContacts || connections.some(item => item.status === 'incoming') ? '<em></em>' : ''}</button>
                <button type="button" class="${page === 'moments' ? 'is-active' : ''}" data-wb-action="social-set-page" data-page="moments"><i></i>Khoảnh khắc${hasUnreadMoments ? '<em></em>' : ''}</button>
            </nav>
            ${page === 'messages' ? `
                <div class="wb-social-reply-toggle">
                    <div>
                        <strong>Trả lời ngay</strong>
                        <span>${settings.socialInstantReply !== false
                            ? 'Mỗi tin nhắn gửi đi sẽ gọi API 1 lần, chờ ngay một lượt trả lời.'
                            : 'Chỉ chuyển tin nhắn đi trước; khi muốn đối phương trả lời ngay thì bấm «Mèo con chuyển lời».'}</span>
                    </div>
                    <label class="wb-switch" title="Điều khiển việc có yêu cầu nhân vật trả lời ngay sau khi bạn chủ động gửi tin nhắn hay không">
                        <input type="checkbox" data-wb-setting="socialInstantReply"
                            ${settings.socialInstantReply !== false ? 'checked' : ''}>
                        <i></i>
                    </label>
                </div>
            ` : ''}
            <div class="wb-social-page-body">${page === 'contacts' ? contactsView : page === 'moments' ? momentsView : messagesView}</div>
        </section>
    `;
}

function renderPeopleView(state, observerMode, people, openFolds = new Set(), {
    selectionMode = false,
    selectedIds = new Set(),
} = {}) {
    const deletablePeople = people.filter(person => !person.locked && !person.isUser);
    return `
        <div class="wb-view-intro">
            <div class="wb-memory-intro-actions wb-people-batch-actions">
                <span>${selectionMode ? `Đã chọn ${selectedIds.size} người` : `${people.length} quỹ đạo có thể quan sát`}</span>
                ${selectionMode ? `
                    <button type="button" data-wb-action="select-all-people" ${deletablePeople.length ? '' : 'disabled'}>Chọn hết mục có thể xóa</button>
                    <button type="button" data-wb-action="clear-people-selection" ${selectedIds.size ? '' : 'disabled'}>Bỏ chọn</button>
                    <button class="is-danger" type="button" data-wb-action="delete-selected-people" ${selectedIds.size ? '' : 'disabled'}>Xóa mục đã chọn · ${selectedIds.size}</button>
                    <button type="button" data-wb-action="toggle-people-batch">Thoát chế độ hàng loạt</button>
                ` : `
                    <button type="button" data-wb-action="toggle-people-batch" ${deletablePeople.length ? '' : 'disabled'}>Quản lý hàng loạt</button>
                    <button type="button" data-wb-action="open-person-editor">＋ Thêm NPC hậu trường</button>
                `}
            </div>
        </div>
        <div class="wb-view-fold-head">
            ${renderFoldToolbar('people:')}
        </div>
        <div class="wb-people-grid">
            ${people.map(person => `
                <div class="wb-person-batch-item ${selectionMode ? 'is-selecting' : ''} ${selectedIds.has(person.id) ? 'is-selected' : ''}">
                    ${selectionMode ? `
                        <label class="wb-person-batch-check ${person.locked || person.isUser ? 'is-disabled' : ''}">
                            <input type="checkbox" data-wb-person-select value="${escapeAttr(person.id)}"
                                ${selectedIds.has(person.id) ? 'checked' : ''}
                                ${person.locked || person.isUser ? 'disabled' : ''}>
                            <span>${person.isUser ? 'nhân vật người chơi' : person.locked ? 'Đã khóa' : 'Chọn'}</span>
                        </label>
                    ` : ''}
                    ${renderPersonCard(
                        person,
                        observerMode,
                        state.clock.absoluteMinute,
                        openFolds,
                    )}
                </div>
            `).join('') || renderEmpty(
                observerMode === 'known' ? 'Nhân vật hiện chưa có quỹ đạo nhân vật nào có thể xác nhận' : 'Chưa tạo nhân vật nền',
                observerMode === 'known' ? 'Chuyển về góc nhìn hậu trường để xem các quỹ đạo chưa biết.' : 'Tự động suy diễn sau khi trả lời, hoặc suy diễn thủ công một lần.',
            )}
        </div>
    `;
}

function renderPersonEditorModal(state, editor) {
    const editorId = String(editor?.id || '');
    const editorName = String(editor?.name || '');
    const person = state.people.find(item => (
        item.id === editorId
        && (!editorName || item.name === editorName)
    )) || state.people.find(item => item.id === editorId) || null;
    return `
        <div class="wb-drawer-scrim" data-wb-action="close-person-editor">
            <form class="wb-event-form wb-person-editor" data-wb-form="person">
                <div class="wb-form-heading">
                    <div><span>BACKSTAGE CAST</span><h3>${person ? 'Sửa nhân vật hậu trường' : 'Thêm NPC hậu trường'}</h3></div>
                    <button type="button" data-wb-action="close-person-editor">×</button>
                </div>
                <input type="hidden" name="id" value="${escapeAttr(person?.id || '')}">
                <input type="hidden" name="originalName" value="${escapeAttr(person?.name || '')}">
                <div class="wb-person-avatar-editor">
                    ${renderPersonAvatar(person || { name: '·', monogram: '·' }, 'is-large')}
                    <div>
                        <label class="wb-avatar-upload">Đổi avatar～
                            <input name="avatarFile" type="file" accept="image/*">
                        </label>
                        <small>Sẽ tự động cắt thành avatar nhỏ 160×160 để lưu, không nhét vào ngữ cảnh của model (｡•̀ᴗ-)✧</small>
                    </div>
                    ${person?.avatarDataUrl ? `<button type="button" data-wb-action="clear-person-avatar"
                        data-person-id="${escapeAttr(person.id)}">Khôi phục ảnh đại diện chữ</button>` : ''}
                </div>
                <label>Họ tên<input name="name" required maxlength="80" value="${escapeAttr(person?.name || '')}"></label>
                <label>Vị trí hiện tại<input name="location" maxlength="160" value="${escapeAttr(person?.location || '')}"></label>
                <label>Đang làm<textarea name="action" maxlength="280" rows="2">${escapeHtml(person?.action || '')}</textarea></label>
                <label>Ý định ngắn hạn<textarea name="intent" maxlength="320" rows="2">${escapeHtml(person?.intent || '')}</textarea></label>
                <label>Mục tiêu dài hạn<textarea name="longTermGoal" maxlength="420" rows="3">${escapeHtml(person?.longTermGoal || '')}</textarea></label>
                <label>Độc thoại hậu trường hiện tại<textarea name="innerVoice" maxlength="240" rows="3"
                    placeholder="Chỉ sửa điều cô ấy đang nghĩ ở khoảnh khắc này～ Khi trạng thái sau này thật sự thay đổi, AI vẫn có thể cập nhật tự nhiên.">${escapeHtml(person?.innerVoice || '')}</textarea>
                    <small>Đây là tiếng lòng hiện tại, không phải khóa thiết lập vĩnh viễn～ Viết lệch thì cứ bẻ lại ngay (｡•̀ᴗ-)✧</small>
                </label>
                <fieldset class="wb-character-anchor-fields">
                    <legend><span>Ràng buộc nhân vật</span><small>Cả suy diễn lẫn quan sát tức thời đều tuân theo, AI sẽ không tự động viết lại</small></legend>
                    <label>Điểm neo danh tính nhân vật<textarea name="identityAnchor" rows="3"
                        placeholder="Ví dụ: nam, ngoại hình thiên nữ tính, dùng “anh ấy” và danh xưng nam; phi nhân tộc cáo. Cũng có thể điền phi nhị nguyên, vô giới hoặc danh xưng tự chọn.">${escapeHtml(person?.identityAnchor || '')}</textarea>
                        <small>Tự do điền bản dạng giới, danh xưng/đại từ, giống loài, giai đoạn tuổi và thân phận xã hội; ngoại hình hãy viết riêng ở mục “Ngoại hình”. Không giới hạn chọn một trong nam hoặc nữ.</small>
                    </label>
                    <label>Ngoại hình<textarea name="appearanceProfile" rows="3"
                        placeholder="Ví dụ: tóc ngắn đen, cao 185cm, hay mặc sơ mi tối màu.">${escapeHtml(person?.appearanceProfile || '')}</textarea></label>
                    <label>Điểm neo tính cách<textarea name="personalityAnchor" rows="3"
                        placeholder="Ví dụ: ngoài lạnh trong nóng, cảnh giác với quyền uy; coi trọng lời hứa nhưng không dễ tỏ ra yếu đuối.">${escapeHtml(person?.personalityAnchor || '')}</textarea></label>
                    <label>Bối cảnh & quan hệ<textarea name="backgroundProfile" rows="4"
                        placeholder="Ví dụ: quá trình trưởng thành, quan hệ gia đình, quan hệ xã hội và các trải nghiệm quan trọng đã có.">${escapeHtml(person?.backgroundProfile || '')}</textarea></label>
                    <label>Năng lực & giới hạn<textarea name="abilityProfile" rows="5" placeholder="Điền hiệu quả năng lực, phạm vi tác dụng, điều kiện kích hoạt, cái giá, điểm yếu và giới hạn. Năng lực chưa thiết lập sẽ không được tự động bịa thêm.">${escapeHtml(person?.abilityProfile || '')}</textarea></label>
                    <label>Thói quen nói chuyện<textarea name="speakingStyle" rows="2"
                        placeholder="Ví dụ: câu ngắn gọn, hiếm khi dùng dấu chấm than; khi căng thẳng sẽ lảng sang chuyện khác.">${escapeHtml(person?.speakingStyle || '')}</textarea></label>
                    <label>Ranh giới hành vi<textarea name="behaviorBoundaries" rows="3"
                        placeholder="Ví dụ: không phản bội đồng đội khi không có bằng chứng; không quyết định thay người chơi; thông tin hậu trường không biết thì không được nói ra.">${escapeHtml(person?.behaviorBoundaries || '')}</textarea></label>
                </fieldset>
                <div class="wb-form-grid">
                    <label>Ranh giới hiểu biết
                        <select name="knowledge">
                            <option value="backstage" ${person?.knowledge !== 'known' ? 'selected' : ''}>Chỉ hậu trường biết</option>
                            <option value="known" ${person?.knowledge === 'known' ? 'selected' : ''}>Nhân vật có thể biết</option>
                        </select>
                    </label>
                    <label>Mức độ quan trọng
                        <select name="relevance">
                            <option value="1" ${Number(person?.relevance || 2) === 1 ? 'selected' : ''}>Bình thường</option>
                            <option value="2" ${Number(person?.relevance || 2) === 2 ? 'selected' : ''}>Quan trọng</option>
                            <option value="3" ${Number(person?.relevance || 2) === 3 ? 'selected' : ''}>Cốt lõi</option>
                        </select>
                    </label>
                </div>
                <div class="wb-memory-editor-flags">
                    <label><input name="simulationEnabled" type="checkbox"
                        ${person?.simulationEnabled !== false ? 'checked' : ''}> Tham gia suy diễn ngoài ống kính</label>
                    <label><input name="locked" type="checkbox" ${person?.locked ? 'checked' : ''}> Khóa thiết lập cốt lõi</label>
                </div>
                <div class="wb-form-note">Sau khi tắt “Tham gia suy diễn ngoài ống kính”, nhân vật vẫn được giữ trong danh sách; chỉ cập nhật khi chính văn cho nhân vật xuất hiện.</div>
                <div class="wb-person-editor-actions">
                    ${person ? `<button class="wb-person-delete-button" type="button" data-wb-action="delete-manual-person"
                        data-person-id="${escapeAttr(person.id)}" ${person.locked ? 'disabled' : ''}>Xóa nhân vật</button>` : ''}
                    <button class="wb-primary-button" type="submit">${person ? 'Lưu thẻ nhân vật' : 'Thêm vào danh sách hậu trường'}</button>
                </div>
            </form>
        </div>
    `;
}

function renderCurrentsView(state, activeEvents, openFolds = new Set(), settings = {}) {
    return `
        <div class="wb-view-intro">
            <div class="wb-view-inline-actions">
                <button class="wb-inline-add" type="button" data-wb-action="open-event-form">＋ Thả vào một mạch ngầm</button>
            </div>
        </div>
        <div class="wb-view-fold-head">
            ${renderFoldToolbar('currents:')}
        </div>
        <div class="wb-event-list is-full">
            ${activeEvents.map(event => renderEventCard(event, state, true, openFolds)).join('')
                || renderEmpty('Mạch ngầm tạm thời trống trơn rồi～', 'Những việc đến hạn, bị hủy hoặc bị bỏ lỡ sẽ rời khỏi đây, kết quả sẽ ngoan ngoãn chuyển sang Tiếng vọng.')}
        </div>
    `;
}

function renderEchoesView(state, outcomes, openFolds = new Set()) {
    return `
        <div class="wb-view-fold-head">
            ${renderFoldToolbar('echoes:')}
        </div>
        <div class="wb-echo-timeline">
            ${outcomes.map(event => renderOutcome(event, state, openFolds)).join('')
                || renderEmpty('Chưa có tiếng vọng nào～', 'Chuyện đã xảy ra ở hậu trường không có nghĩa là chính văn đã thấy. Đợi nó thật sự thành kết quả rồi hãy quay lại đây.')}
        </div>
    `;
}

function publicOpinionClaimLabel(status) {
    return {
        fact: 'Dựa trên sự thật công khai',
        mixed: 'Sự thật lẫn suy đoán',
        rumor: 'Tin đồn / Chưa xác thực',
    }[status] || 'Sự thật lẫn suy đoán';
}

function publicOpinionConfidenceLabel(confidence) {
    return confidence === 'high' ? 'Độ tin cậy khá cao' : 'Thông tin hạn chế';
}

function publicOpinionSourceTypeLabel(sourceType) {
    return sourceType === 'official' ? '🏛 Chính thức / Uy tín' : '🗣 Không chính thức / Tin hành lang';
}

function renderPublicOpinionAudience(item) {
    const audiences = Array.isArray(item?.audienceTags) ? item.audienceTags.filter(Boolean).slice(0, 5) : [];
    if (!audiences.length && !item?.scope) return '';
    return `
        <div class="wb-opinion-audience">
            ${item?.scope ? `<span class="wb-opinion-scope">${escapeHtml(item.scope)}</span>` : ''}
            ${audiences.map(tag => `<span>${escapeHtml(tag)}</span>`).join('')}
        </div>
    `;
}

function publicOpinionGeneratedLabel(value) {
    if (!value) return 'Chưa tạo';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return 'Ảnh chụp gần nhất';
    return date.toLocaleString('zh-CN', {
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
    });
}

function publicOpinionWorldTimeLabel(state, item) {
    const minute = Number(item?.worldMinute);
    if (!Number.isFinite(minute) || minute < 0) return '';
    const calendar = formatWorldCalendar(state, minute);
    return calendar?.stamp || formatWorldMinute(minute).stamp;
}

function renderPublicOpinionView(state, opinion = {}, mode = 'news', settings = {}) {
    const news = Array.isArray(opinion.news) ? opinion.news : [];
    const forums = Array.isArray(opinion.forums) ? opinion.forums : [];
    const interactionBusy = Boolean(opinion.interactionBusy);
    const sandboxInteractionBusy = Boolean(opinion.sandboxInteractionBusy);
    const canonRunning = Boolean(
        opinion.canonRunning
        || interactionBusy
        || opinion.phase === 'running'
        || opinion.phase === 'queued'
    );
    const sandboxStatus = opinion.sandboxStatus && typeof opinion.sandboxStatus === 'object'
        ? opinion.sandboxStatus
        : { phase: 'idle', message: '', error: '' };
    const sandboxRunning = Boolean(
        opinion.sandboxRunning
        || sandboxInteractionBusy
        || sandboxStatus.phase === 'running'
    );
    const running = canonRunning || sandboxRunning;
    const stale = Boolean(opinion.stale && opinion.generatedAt);
    const lastWorldSweepMinute = Number(state?.worldPulse?.coverage?.lastSweepAt ?? -1);
    const lastWorldSweepLabel = lastWorldSweepMinute >= 0
        ? (formatWorldCalendar(state, lastWorldSweepMinute)?.stamp || formatWorldMinute(lastWorldSweepMinute).stamp)
        : 'Chưa tuần tra';
    const recentWorldCoverageLabels = (Array.isArray(state?.worldPulse?.coverage?.entries)
        ? state.worldPulse.coverage.entries
        : [])
        .slice(0, 3)
        .map(item => String(item?.label || '').trim())
        .filter(Boolean);
    const relatedEvents = new Map((state.events || []).map(event => [event.id, event]));
    const sandbox = opinion.sandbox && typeof opinion.sandbox === 'object' ? opinion.sandbox : { news: [], forums: [], generatedAt: '' };
    const sandboxItems = [...(sandbox.news || []), ...(sandbox.forums || [])];
    const activeMode = ['forum', 'sandbox'].includes(mode) ? mode : 'news';
    const canonStatusMessage = (
        interactionBusy && !['running', 'queued', 'error'].includes(opinion.phase)
            ? 'Đang kiểm tra thay đổi của thế giới～'
            : (opinion.error || opinion.message || '')
    );
    const sandboxStatusMessage = (
        sandboxInteractionBusy && sandboxStatus.phase !== 'error'
            ? 'Đang dạo phố linh tinh～'
            : (sandboxStatus.error || sandboxStatus.message || '')
    );
    const statusMessage = activeMode === 'sandbox'
        ? sandboxStatusMessage
        : canonStatusMessage;
    const statusPhase = activeMode === 'sandbox'
        ? (sandboxStatus.phase || (sandboxInteractionBusy ? 'running' : 'idle'))
        : (opinion.phase || (interactionBusy ? 'running' : 'idle'));
    const hasMainOpinion = news.length > 0 || forums.length > 0;
    const hasSandboxOpinion = sandboxItems.length > 0;
    const showStatusMessage = Boolean(
        statusMessage
        && (
            statusPhase === 'error'
            || activeMode !== 'sandbox'
            || !hasSandboxOpinion
            || sandboxRunning
        )
    );
    const renderRelated = item => {
        const event = relatedEvents.get(item.relatedEventId);
        return event
            ? `<span class="wb-opinion-related">Sự kiện nguồn · ${escapeHtml(event.title)}</span>`
            : '';
    };
    return `
        <div class="wb-opinion-toolbar" aria-busy="${running ? 'true' : 'false'}">
            <div class="wb-opinion-summary">
                <div class="wb-opinion-meta">
                    <span>Cập nhật đến · ${escapeHtml(publicOpinionGeneratedLabel(opinion.generatedAt))}</span>
                    <span>Tuần tra ngoài ống kính · ${escapeHtml(lastWorldSweepLabel)}</span>
                    ${recentWorldCoverageLabels.length
                        ? `<span title="Phạm vi vừa được suy diễn thế giới thực sự kiểm tra gần đây">Đã tuần · ${recentWorldCoverageLabels.map(escapeHtml).join(' / ')}</span>`
                        : ''}
                    ${stale
                        ? '<span class="is-stale">Thế giới đã đi tiếp rồi · làm mới để chính xác hơn</span>'
                        : `<span>${settings.publicOpinionRevealMode === 'relevant' ? 'Có thể hé lộ khi liên quan' : 'Chế độ hóng chuyện an toàn'}</span>`}
                </div>
            </div>
            <div class="wb-opinion-actions">
                ${opinion.generatedAt ? `<button type="button" data-wb-action="clear-public-opinion" title="Chỉ xóa sạch danh sách dư luận, không xóa sự thật thế giới hay ảnh hưởng đã xảy ra" ${canonRunning ? 'disabled' : ''}>Xóa danh sách</button>` : ''}
                <button type="button" data-wb-action="generate-public-opinion-sandbox" ${sandboxRunning ? 'disabled' : ''}>${sandboxRunning ? 'Đang dạo chơi…' : 'Dạo quanh một vòng～'}</button>
                <button class="wb-inline-add" type="button" data-wb-action="generate-public-opinion" ${canonRunning ? 'disabled' : ''}
                    title="Khi thời gian thế giới trôi đủ ba giờ, lần đầu nâng cấp hoặc khi trọng tâm thay đổi, mình sẽ đi tuần một vòng nhỏ quanh thế giới công cộng ngoài ống kính trước; khi không có thay đổi thật thì sẽ không gửi lại yêu cầu chỉ để đổi cách diễn đạt">
                    ${canonRunning ? 'Đang làm mới…' : (opinion.generatedAt ? 'Đi tuần một vòng' : 'Tạo dư luận hiện tại')}
                </button>
            </div>
        </div>
        <div class="wb-opinion-tabs" role="tablist" aria-label="Loại dư luận">
            <button type="button" role="tab" data-wb-action="set-public-opinion-mode" data-mode="news"
                aria-selected="${activeMode === 'news'}" class="${activeMode === 'news' ? 'is-active' : ''}">📰 Tin tức <small>${news.length}</small></button>
            <button type="button" role="tab" data-wb-action="set-public-opinion-mode" data-mode="forum"
                aria-selected="${activeMode === 'forum'}" class="${activeMode === 'forum' ? 'is-active' : ''}">💬 Diễn đàn <small>${forums.length}</small></button>
            <button type="button" role="tab" data-wb-action="set-public-opinion-mode" data-mode="sandbox"
                aria-selected="${activeMode === 'sandbox'}" class="${activeMode === 'sandbox' ? 'is-active' : ''}">🍿 Dạo chơi <small>${sandboxItems.length}</small></button>
        </div>
        ${showStatusMessage ? `<div role="status" aria-live="polite" class="wb-opinion-status is-${escapeAttr(statusPhase)} ${hasMainOpinion || hasSandboxOpinion ? 'is-compact' : ''}">${escapeHtml(statusMessage)}</div>` : ''}
        ${activeMode === 'news' ? `
            <div class="wb-news-grid">
                ${news.map(item => `
                    <article class="wb-news-card">
                        <div class="wb-news-card-top">
                            <span>${escapeHtml(item.category || 'Tin tức thế giới')}${item.publishedAt && item.updatedAt && item.publishedAt !== item.updatedAt ? ' · Diễn biến tiếp' : ''}</span>
                            <span class="wb-opinion-card-tools">
                                <small>${'●'.repeat(Math.max(1, Math.min(3, Number(item.heat) || 1)))}</small>
                                <button type="button" class="wb-opinion-delete" data-wb-action="dismiss-public-opinion-item"
                                    data-opinion-kind="news" data-item-id="${escapeAttr(item.id)}" title="Xóa mục này khỏi danh sách dư luận; không xóa sự kiện thế giới">×</button>
                            </span>
                        </div>
                        <div class="wb-opinion-source-row">
                            <span class="is-${escapeAttr(item.sourceType || 'official')}">${escapeHtml(publicOpinionSourceTypeLabel(item.sourceType))}</span>
                        </div>
                        <h3>${escapeHtml(item.headline)}</h3>
                        <p>${escapeHtml(item.summary)}</p>
                        ${renderPublicOpinionAudience(item)}
                        <div class="wb-news-card-foot">
                            <span>${escapeHtml(item.source || 'Thông tin công khai')} · ${escapeHtml(publicOpinionConfidenceLabel(item.confidence))}${item.worldSynced ? ' · Đồng bộ sự kiện thế giới' : ''}${publicOpinionWorldTimeLabel(state, item) ? ` · ${escapeHtml(publicOpinionWorldTimeLabel(state, item))}` : ''}</span>
                            ${renderRelated(item)}
                        </div>
                    </article>
                `).join('') || renderEmpty('Thế giới hôm nay hơi yên ắng～', 'Chưa có chuyện gì đáng lên tin tức, hoặc bạn chưa tạo ảnh chụp dư luận (˘▾˘)')}
            </div>
        ` : activeMode === 'forum' ? `
            <div class="wb-forum-list">
                ${forums.map(item => `
                    <article class="wb-forum-card">
                        <div class="wb-forum-card-top">
                            <span>${escapeHtml(item.board || 'Tán gẫu')}</span>
                            <span class="wb-opinion-card-tools">
                                <small class="is-${escapeAttr(item.claimStatus || 'mixed')}">${escapeHtml(publicOpinionClaimLabel(item.claimStatus))}</small>
                                <button type="button" class="wb-opinion-delete" data-wb-action="dismiss-public-opinion-item"
                                    data-opinion-kind="forum" data-item-id="${escapeAttr(item.id)}" title="Xóa thảo luận này khỏi danh sách diễn đàn">×</button>
                            </span>
                        </div>
                        <div class="wb-opinion-source-row">
                            <span class="is-${escapeAttr(item.sourceType || 'unofficial')}">${escapeHtml(publicOpinionSourceTypeLabel(item.sourceType))}</span>
                        </div>
                        <h3>${escapeHtml(item.title)}</h3>
                        <p>${escapeHtml(item.summary)}</p>
                        ${renderPublicOpinionAudience(item)}
                        <div class="wb-forum-heat"><span>Độ hot</span><strong>${'●'.repeat(Math.max(1, Math.min(5, Number(item.heat) || 1)))}</strong></div>
                        ${item.replies?.length ? `
                            <details class="wb-forum-reply-fold">
                                <summary>Xem ${item.replies.length} phản hồi tiêu biểu～</summary>
                                <div class="wb-forum-replies">
                                    ${item.replies.map(reply => `
                                        <div><strong>${escapeHtml(reply.author)}</strong><p>${escapeHtml(reply.text)}</p></div>
                                    `).join('')}
                                </div>
                            </details>
                        ` : ''}
                        <div class="wb-news-card-foot">
                            <span>${publicOpinionWorldTimeLabel(state, item) ? escapeHtml(publicOpinionWorldTimeLabel(state, item)) : ''}</span>
                            ${renderRelated(item)}
                        </div>
                    </article>
                `).join('') || renderEmpty('Diễn đàn hôm nay chưa cãi nhau～', 'Không có chuyện gì hợp để bàn luận công khai, hoặc bạn chưa tạo ảnh chụp dư luận.')}
            </div>
        ` : `
            <div class="wb-opinion-sandbox">
                <div class="wb-memory-fact-note"><strong>🍿 Hộp cát thuần giải trí</strong> · Những thứ dưới đây chỉ là bản tin vặt kiểu “trong thế giới có thể có người đang bàn tán gì đó”, không tính là chính sử, sẽ không được ghi vào sự kiện, ký ức, nhận thức của NPC hay nhân quả của chính văn.</div>
                ${sandbox.generatedAt ? `<div class="wb-opinion-meta wb-opinion-meta-inline"><span>Ảnh chụp dạo chơi · ${escapeHtml(publicOpinionGeneratedLabel(sandbox.generatedAt))}</span><button class="wb-opinion-meta-button" type="button" data-wb-action="clear-public-opinion-sandbox">Dẹp nồi drama này</button></div>` : ''}
                <div class="wb-news-grid">
                    ${(sandbox.news || []).map(item => `
                        <article class="wb-news-card is-sandbox">
                            <div class="wb-news-card-top"><span>${escapeHtml(item.category || 'Tin dạo chơi')}</span><small>NON-CANON</small></div>
                            <h3>${escapeHtml(item.headline)}</h3>
                            <p>${escapeHtml(item.summary)}</p>
                            <div class="wb-news-card-foot"><span>${escapeHtml(item.source || 'Thông tin công khai thường ngày trong thế giới')}</span></div>
                        </article>
                    `).join('')}
                </div>
                <div class="wb-forum-list">
                    ${(sandbox.forums || []).map(item => `
                        <article class="wb-forum-card is-sandbox">
                            <div class="wb-forum-card-top"><span>${escapeHtml(item.board || 'Tán gẫu')}</span><small>NON-CANON</small></div>
                            <h3>${escapeHtml(item.title)}</h3>
                            <p>${escapeHtml(item.summary)}</p>
                            ${item.replies?.length ? `<details class="wb-forum-reply-fold"><summary>Xem ${item.replies.length} phản hồi tiêu biểu～</summary><div class="wb-forum-replies">${item.replies.map(reply => `<div><strong>${escapeHtml(reply.author)}</strong><p>${escapeHtml(reply.text)}</p></div>`).join('')}</div></details>` : ''}
                        </article>
                    `).join('')}
                </div>
                ${sandboxItems.length ? '' : renderEmpty('Hôm nay chưa đi dạo lung tung～', 'Bấm “Dạo quanh một vòng～” để bốc một nồi tin vặt và bài nhảm diễn đàn không liên quan đến mạch chính.')}
            </div>
        `}
    `;
}

function clueStatusLabel(status) {
    return {
        open: 'Chờ nảy mầm',
        developing: 'Đang phát triển',
        echoed: 'Đang phát triển',
        triggered: 'Đã kích hoạt',
        resolved: 'Đã thu hồi',
        discarded: 'Đã gác lại',
    }[status] || 'Chưa được hô ứng';
}

function memoryFactStatusLabel(status) {
    return {
        active: 'Đang hiệu lực',
        disputed: 'Thông tin mâu thuẫn',
        superseded: 'Đã bị phiên bản mới ghi đè',
        invalidated: 'Đã mất hiệu lực',
    }[status] || 'Đang hiệu lực';
}

function memoryConfidenceLabel(confidence) {
    return {
        high: 'Rõ ràng',
        medium: 'Khá đáng tin',
        low: 'Chờ xác nhận',
    }[confidence] || 'Khá đáng tin';
}

function memoryItemMatches(item, query) {
    const normalized = String(query || '').trim().toLocaleLowerCase();
    if (!normalized) return true;
    return [
        item?.key,
        item?.subject,
        item?.predicate,
        item?.value,
        item?.title,
        item?.text,
        item?.summary,
        ...(item?.people || []),
        ...(item?.locations || []),
        ...(item?.events || []),
        ...(item?.tags || []),
    ].filter(Boolean).join(' ').toLocaleLowerCase().includes(normalized);
}

function resolvePersonEntity(state, value, { allowSubjectPrefix = false } = {}) {
    const raw = String(value || '').trim();
    if (!raw) return null;
    const token = raw.toLocaleLowerCase();
    const people = state?.people || [];
    const exact = people.find(item => (
        String(item?.id || '').trim().toLocaleLowerCase() === token
        || String(item?.name || '').trim().toLocaleLowerCase() === token
    ));
    if (exact) return exact;
    if (!allowSubjectPrefix) return null;
    return [...people]
        .filter(item => String(item?.name || '').trim())
        .sort((a, b) => String(b.name).length - String(a.name).length)
        .find(item => {
            const name = String(item.name).trim();
            return raw.startsWith(`${name}的`)
                || raw.startsWith(`${name}·`)
                || raw.startsWith(`${name}：`)
                || raw.startsWith(`${name}:`);
        }) || null;
}

function resolvePersonDisplayName(state, value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    return resolvePersonEntity(state, raw)?.name || raw;
}

function memoryFactGroupDescriptor(fact, state) {
    const linkedPerson = Array.isArray(fact?.people) && fact.people.length
        ? resolvePersonEntity(state, fact.people[0])
        : null;
    const subjectPerson = linkedPerson || resolvePersonEntity(
        state,
        fact?.subject || fact?.key,
        { allowSubjectPrefix: true },
    );
    if (subjectPerson) {
        return {
            key: `person:${subjectPerson.id || subjectPerson.name}`,
            label: subjectPerson.name,
        };
    }
    const label = String(fact?.subject || fact?.key || '').trim() || 'Sự thật khác';
    return { key: `fact:${label}`, label };
}

function memoryClueGroupDescriptor(clue) {
    if (clue?.archived) return { key: 'clue:archived', label: 'Đã lưu trữ' };
    if (['resolved', 'discarded'].includes(clue?.status)) {
        return { key: 'clue:resolved', label: 'Đã thu hồi / gác lại' };
    }
    if (clue?.status === 'triggered') return { key: 'clue:triggered', label: 'Đã kích hoạt' };
    return { key: 'clue:active', label: 'Vẫn đang phát triển' };
}

function memoryClueRelationMatches(clue, relationFilter = 'all', state = null) {
    const filter = String(relationFilter || 'all');
    if (filter === 'all') return true;
    const separator = filter.indexOf(':');
    if (separator < 0) return true;
    const kind = filter.slice(0, separator);
    const expected = filter.slice(separator + 1).trim().toLocaleLowerCase();
    if (!expected) return true;
    const values = kind === 'person'
        ? (clue?.people || [])
        : kind === 'location'
            ? (clue?.locations || [])
            : kind === 'event'
                ? (clue?.events || [])
                : [];
    if (kind === 'person') {
        return values.some(value => {
            const raw = String(value || '').trim();
            const person = resolvePersonEntity(state, raw);
            return [raw, person?.id, person?.name]
                .filter(Boolean)
                .some(candidate => String(candidate).trim().toLocaleLowerCase() === expected);
        });
    }
    if (kind === 'event') {
        const events = [...(state?.events || []), ...(state?.archive || [])];
        return values.some(value => {
            const raw = String(value || '').trim();
            const matched = events.find(event => (
                String(event?.id || '').trim().toLocaleLowerCase() === raw.toLocaleLowerCase()
                || String(event?.title || '').trim().toLocaleLowerCase() === raw.toLocaleLowerCase()
            ));
            return [raw, matched?.id, matched?.title]
                .filter(Boolean)
                .some(candidate => String(candidate).trim().toLocaleLowerCase() === expected);
        });
    }
    return values.some(value => String(value || '').trim().toLocaleLowerCase() === expected);
}

function clueRelationMeta(clue, state) {
    const events = [...(state?.events || []), ...(state?.archive || [])];
    const people = [...new Set((clue?.people || []).map(value => resolvePersonDisplayName(state, value)).filter(Boolean))];
    const locations = [...new Set((clue?.locations || []).map(value => String(value || '').trim()).filter(Boolean))];
    const eventItems = [...new Set((clue?.events || []).map(value => {
        const raw = String(value || '').trim();
        const event = events.find(item => (
            String(item?.id || '').trim().toLocaleLowerCase() === raw.toLocaleLowerCase()
            || String(item?.title || '').trim().toLocaleLowerCase() === raw.toLocaleLowerCase()
        ));
        return event?.title || raw;
    }).filter(Boolean))];
    return { people, locations, events: eventItems };
}


function memorySummaryLevelMeta(summary) {
    if (!summary?.hierarchyManaged) {
        return { label: 'Trải nghiệm bản cũ', tone: 'legacy', description: 'Những trải nghiệm giai đoạn để lại từ trước～ vẫn được ghi nhớ cẩn thận.' };
    }
    const level = Math.max(0, Math.min(3, Number(summary?.level) || 0));
    const meta = [
        { label: 'Đoạn gần đây', tone: 'detail', description: 'Những đoạn nhỏ gần chính văn gốc nhất～ chi tiết sẽ khá nhiều.' },
        { label: 'Tóm tắt giai đoạn', tone: 'stage', description: 'Trọng điểm của một đoạn cốt truyện ngắn đều được gom ở đây nè～' },
        { label: 'Trải nghiệm theo chương', tone: 'chapter', description: 'Gom một đoạn trải nghiệm dài hơn thành trọng điểm～ để tiện nối tiếp về sau.' },
        { label: 'Trải nghiệm dài hạn', tone: 'longterm', description: 'Những thay đổi thật sự vẫn quan trọng sau một thời gian rất dài sẽ ngoan ngoãn ở lại đây.' },
    ];
    return meta[level];
}

function renderMemoryActions(kind, item, selectedKeys = new Set()) {
    const selectionKey = `${kind}:${item.id}`;
    return `
        <div class="wb-memory-card-actions">
            <label class="wb-memory-select">
                <input type="checkbox" data-wb-memory-select
                    data-memory-kind="${kind}" data-memory-id="${escapeAttr(item.id)}"
                    ${selectedKeys.has(selectionKey) ? 'checked' : ''}
                    ${item.locked ? 'disabled' : ''}>
                <span>${item.locked ? 'Đã khóa' : 'Chọn'}</span>
            </label>
            <button class="is-edit" type="button" data-wb-action="open-memory-editor"
                data-memory-kind="${kind}" data-memory-id="${escapeAttr(item.id)}"
                ${item.locked ? 'disabled' : ''}>Sửa</button>
            <button type="button" data-wb-action="toggle-memory-flag"
                data-memory-kind="${kind}" data-memory-id="${escapeAttr(item.id)}"
                data-memory-field="important" class="is-important ${item.important ? 'is-active' : ''}">
                ${item.important ? 'Đã đánh dấu quan trọng' : 'Đánh dấu quan trọng'}
            </button>
            <button type="button" data-wb-action="toggle-memory-flag"
                data-memory-kind="${kind}" data-memory-id="${escapeAttr(item.id)}"
                data-memory-field="locked" class="is-lock ${item.locked ? 'is-active' : ''}">
                ${item.locked ? 'Đã khóa' : 'Khóa'}
            </button>
            <button class="is-delete" type="button" data-wb-action="delete-memory-item"
                data-memory-kind="${kind}" data-memory-id="${escapeAttr(item.id)}"
                ${item.locked ? 'disabled' : ''}>Xóa</button>
        </div>
    `;
}

function renderMemoryView(state, observerMode, {
    query = '',
    filter = 'active',
    visibleCount = 12,
    openFolds = new Set(),
    selectedKeys = new Set(),
    clueRelationFilter = 'all',
} = {}) {
    const memory = state.storyMemory || {
        digest: null,
        facts: [],
        summaries: [],
        clues: [],
    };
    const allFacts = [...(memory.facts || [])]
        .filter(fact => observerMode === 'backstage' || fact.visibility !== 'hidden')
        .sort((a, b) => (
            Number(['active', 'disputed'].includes(b.status))
            - Number(['active', 'disputed'].includes(a.status))
            || Number(b.importance || 0) - Number(a.importance || 0)
            || Number(b.updatedAt || 0) - Number(a.updatedAt || 0)
        ));
    const allClues = [...(memory.clues || [])]
        .filter(clue => observerMode === 'backstage' || clue.visibility !== 'hidden')
        .sort((a, b) => (
            Number(Boolean(a.archived)) - Number(Boolean(b.archived))
            || Number(['open', 'developing', 'echoed', 'triggered'].includes(b.status))
            - Number(['open', 'developing', 'echoed', 'triggered'].includes(a.status))
            || Number(b.importance || 0) - Number(a.importance || 0)
            || Number(b.updatedAt || 0) - Number(a.updatedAt || 0)
        ));
    const allSummaries = observerMode === 'backstage'
        ? [...(memory.summaries || [])].sort(
            (a, b) => Number(b.endMessageId || 0) - Number(a.endMessageId || 0),
        )
        : [];
    const summaryById = new Map(allSummaries.map(summary => [String(summary.id || ''), summary]));
    const digest = observerMode === 'backstage' ? memory.digest : null;
    const normalizedFilter = ['active', 'facts', 'clues', 'resolved-clues', 'archived-clues', 'episodes', 'all'].includes(filter)
        ? filter
        : 'active';
    const maximum = Math.max(6, Number(visibleCount) || 12);
    const facts = allFacts.filter(fact => (
        memoryItemMatches(fact, query)
        && (
            normalizedFilter === 'all'
            || normalizedFilter === 'facts'
            || (normalizedFilter === 'active' && ['active', 'disputed'].includes(fact.status))
        )
    ));
    const clues = allClues.filter(clue => (
        memoryItemMatches(clue, query)
        && memoryClueRelationMatches(clue, clueRelationFilter, state)
        && (
            normalizedFilter === 'all'
            || (normalizedFilter === 'clues' && !clue.archived)
            || (normalizedFilter === 'resolved-clues' && !clue.archived && ['resolved', 'discarded'].includes(clue.status))
            || (normalizedFilter === 'archived-clues' && clue.archived)
            || (
                normalizedFilter === 'active'
                && !clue.archived
                && ['open', 'developing', 'echoed', 'triggered'].includes(clue.status)
            )
        )
    ));
    const summaries = allSummaries.filter(summary => (
        memoryItemMatches(summary, query)
        && ['all', 'episodes'].includes(normalizedFilter)
    ));
    const shownFacts = facts.slice(0, maximum);
    const shownClues = clues.slice(0, maximum);
    const shownSummaries = summaries.slice(0, maximum);
    const factGroups = groupItems(shownFacts, fact => memoryFactGroupDescriptor(fact, state));
    const clueGroups = groupItems(shownClues, clue => memoryClueGroupDescriptor(clue));
    const resultCount = facts.length + clues.length + summaries.length;
    const shownCount = shownFacts.length + shownClues.length + shownSummaries.length;
    const hasMore = shownFacts.length < facts.length
        || shownClues.length < clues.length
        || shownSummaries.length < summaries.length;
    const filterButton = (id, label) => `
        <button type="button" data-wb-action="set-memory-filter" data-filter="${id}"
            aria-pressed="${normalizedFilter === id}"
            class="${normalizedFilter === id ? 'is-active' : ''}">${label}</button>
    `;
    const relationPeople = new Map();
    const relationLocations = new Set();
    const relationEvents = new Map();
    const allWorldEvents = [...(state.events || []), ...(state.archive || [])];
    for (const clue of allClues) {
        for (const value of clue.people || []) {
            const raw = String(value || '').trim();
            if (!raw) continue;
            const person = resolvePersonEntity(state, raw);
            const key = String(person?.id || person?.name || raw);
            relationPeople.set(key, person?.name || raw);
        }
        for (const value of clue.locations || []) {
            const raw = String(value || '').trim();
            if (raw) relationLocations.add(raw);
        }
        for (const value of clue.events || []) {
            const raw = String(value || '').trim();
            if (!raw) continue;
            const event = allWorldEvents.find(item => (
                String(item?.id || '').trim().toLocaleLowerCase() === raw.toLocaleLowerCase()
                || String(item?.title || '').trim().toLocaleLowerCase() === raw.toLocaleLowerCase()
            ));
            const key = String(event?.id || event?.title || raw);
            relationEvents.set(key, event?.title || raw);
        }
    }
    const relationOption = (value, label) => (
        `<option value="${escapeAttr(value)}" ${String(clueRelationFilter) === String(value) ? 'selected' : ''}>${escapeHtml(label)}</option>`
    );
    const clueRelationSelect = `
        <label class="wb-clue-relation-filter">
            <span>Liên kết phục bút</span>
            <select data-wb-clue-relation-filter>
                ${relationOption('all', 'Tất cả liên kết')}
                ${relationPeople.size ? `<optgroup label="Nhân vật">${[...relationPeople.entries()].map(([id, label]) => relationOption(`person:${id}`, label)).join('')}</optgroup>` : ''}
                ${relationEvents.size ? `<optgroup label="Sự kiện">${[...relationEvents.entries()].map(([id, label]) => relationOption(`event:${id}`, label)).join('')}</optgroup>` : ''}
                ${relationLocations.size ? `<optgroup label="Địa điểm">${[...relationLocations].map(label => relationOption(`location:${label}`, label)).join('')}</optgroup>` : ''}
            </select>
        </label>
    `;
    const renderFactCard = (fact, groupLabel = '') => {
        const subject = String(fact.subject || fact.key || '').trim();
        const normalizedGroup = String(groupLabel || '').trim();
        const duplicateSubject = normalizedGroup && subject === normalizedGroup;
        return `
        <article class="wb-memory-fact-card is-${escapeAttr(fact.status)}">
            <div class="wb-memory-fact-meta">
                <span>${escapeHtml(memoryFactStatusLabel(fact.status))}</span>
                <span>${escapeHtml(memoryConfidenceLabel(fact.confidence))}</span>
            </div>
            ${!duplicateSubject && subject ? `<h4>${escapeHtml(subject)}</h4>` : ''}
            ${fact.predicate ? `<small>${escapeHtml(fact.predicate)}</small>` : ''}
            <p>${escapeHtml(fact.value)}</p>
            ${fact.invalidationReason
                ? `<div class="wb-memory-fact-note">${escapeHtml(fact.invalidationReason)}</div>`
                : ''}
            ${renderMemoryActions('fact', fact, selectedKeys)}
        </article>
    `;
    };
    const renderClueCard = clue => {
        const relations = clueRelationMeta(clue, state);
        return `
        <article class="wb-clue-card is-${escapeAttr(clue.status)} ${clue.archived ? 'is-archived' : ''}">
            <div class="wb-clue-meta">
                <span>${escapeHtml(clue.archived ? 'Đã lưu trữ' : clueStatusLabel(clue.status))}</span>
                ${!clue.archived && ['resolved', 'discarded'].includes(clue.status)
                    ? `<button type="button" data-wb-action="set-clue-archive-state" data-clue-id="${escapeAttr(clue.id)}" data-archived="true" ${clue.locked ? 'disabled' : ''}>Lưu trữ</button>`
                    : ''}
                ${clue.archived
                    ? `<button type="button" data-wb-action="set-clue-archive-state" data-clue-id="${escapeAttr(clue.id)}" data-archived="false" ${clue.locked ? 'disabled' : ''}>Chuyển về đã thu hồi</button>`
                    : ''}
            </div>
            <h4>${escapeHtml(clue.title)}</h4>
            <p>${escapeHtml(clue.text)}</p>
            ${(relations.people.length || relations.events.length || relations.locations.length) ? `
                <div class="wb-clue-relations">
                    ${relations.people.map(value => `<span class="is-person">Nhân vật · ${escapeHtml(value)}</span>`).join('')}
                    ${relations.events.map(value => `<span class="is-event">Sự kiện · ${escapeHtml(value)}</span>`).join('')}
                    ${relations.locations.map(value => `<span class="is-location">Địa điểm · ${escapeHtml(value)}</span>`).join('')}
                </div>
            ` : ''}
            ${clue.sourceExcerpt ? `<blockquote>${escapeHtml(clue.sourceExcerpt)}</blockquote>` : ''}
            ${clue.resolution ? `<div class="wb-clue-resolution">${escapeHtml(clue.resolution)}</div>` : ''}
            ${clue.lifecycleReason && clue.lifecycleReason !== clue.resolution ? `<div class="wb-memory-fact-note">Lý do thay đổi: ${escapeHtml(clue.lifecycleReason)}</div>` : ''}
            ${renderMemoryActions('clue', clue, selectedKeys)}
        </article>
    `;
    };
    return `
        <div class="wb-memory-shell">
            <div class="wb-memory-toolbar">
                <div class="wb-memory-toolbar-top">
                    <span class="wb-memory-toolbar-summary">${allFacts.filter(fact => ['active', 'disputed'].includes(fact.status)).length} sự thật · ${allClues.filter(clue => !clue.archived && ['open', 'developing', 'echoed', 'triggered'].includes(clue.status)).length} phục bút đang diễn ra · ${allClues.filter(clue => clue.archived).length} lưu trữ</span>
                    <span class="wb-memory-intro-buttons">
                        <button type="button" data-wb-action="open-memory-editor" data-memory-kind="fact">＋ Thêm ký ức</button>
                        <button type="button" data-wb-action="open-memory-editor" data-memory-kind="clue">＋ Thêm phục bút</button>
                    </span>
                </div>
                <div class="wb-memory-tools">
                <div class="wb-memory-filters" aria-label="Lọc ký ức">
                    ${filterButton('active', 'Đang diễn ra')}
                    ${filterButton('facts', 'Sự thật')}
                    ${filterButton('clues', 'Phục bút')}
                    ${filterButton('resolved-clues', 'Đã thu hồi')}
                    ${filterButton('archived-clues', 'Đã lưu trữ')}
                    ${filterButton('episodes', 'Trải nghiệm')}
                    ${filterButton('all', 'Tất cả')}
                </div>
                ${clueRelationSelect}
                <label class="wb-memory-search">
                    <span>Tìm ký ức</span>
                    <input type="search" data-wb-memory-search maxlength="80"
                        value="${escapeAttr(query)}" placeholder="Nhân vật, địa điểm, vật phẩm hoặc từ khóa">
                </label>
                <small>${query ? `Tìm thấy ${resultCount} mục` : `${resultCount} mục`}</small>
                ${observerMode === 'backstage' && resultCount ? `
                    <div class="wb-memory-bulk-tools">
                        <button type="button" data-wb-action="select-visible-memory"
                            data-memory-items="${escapeAttr(JSON.stringify([
                                ...shownFacts.filter(item => !item.locked).map(item => ({ kind: 'fact', id: item.id })),
                                ...shownClues.filter(item => !item.locked).map(item => ({ kind: 'clue', id: item.id })),
                                ...shownSummaries.filter(item => !item.locked).map(item => ({ kind: 'summary', id: item.id })),
                            ]))}">Chọn mục đang hiện</button>
                        <button type="button" data-wb-action="clear-memory-selection"
                            ${selectedKeys.size ? '' : 'disabled'}>Bỏ chọn tất cả</button>
                        <button type="button" data-wb-action="bulk-delete-memory" data-wb-memory-selected-count
                            ${selectedKeys.size ? '' : 'disabled'}>Xóa mục đã chọn${selectedKeys.size ? ` · ${selectedKeys.size}` : ''}</button>
                        <button class="is-danger" type="button" data-wb-action="clear-filtered-memory">
                            ${normalizedFilter === 'all' && !query ? 'Xóa sạch toàn bộ ký ức chưa khóa' : 'Xóa theo bộ lọc hiện tại'}
                        </button>
                    </div>
                ` : ''}
                </div>
            </div>
            ${(memory.metabolismLog || []).length ? `
                <details class="wb-fold wb-memory-digest" data-fold-key="memory:metabolism"
                    ${foldOpenAttr(openFolds, 'memory:metabolism')}>
                    <summary class="wb-memory-digest-summary">
                        <span><strong>Gần đây đã dọn dẹp gì～</strong></span>
                        <span class="wb-fold-meta"><small>${Math.min(12, (memory.metabolismLog || []).length)} thay đổi gần đây</small><i class="wb-fold-chevron" aria-hidden="true"></i></span>
                    </summary>
                    <div class="wb-fold-body wb-memory-digest-body">
                        ${(memory.metabolismLog || []).slice(-12).reverse().map(item => `<p><strong>${escapeHtml(item.kind === 'fact' ? 'Sự thật' : item.kind === 'clue' ? 'Phục bút' : 'Trải nghiệm')}</strong> · ${escapeHtml(item.action || 'Cập nhật')}<br><small>${escapeHtml(item.reason || 'Đã sắp xếp theo nội dung về sau')}</small></p>`).join('')}
                    </div>
                </details>
            ` : ''}
            ${digest?.text ? `
                <details class="wb-fold wb-memory-digest" data-fold-key="memory:digest"
                    ${foldOpenAttr(openFolds, 'memory:digest')}>
                    <summary class="wb-memory-digest-summary">
                        <span><strong>Tóm tắt dài hạn</strong></span>
                        <span class="wb-fold-meta">
                            <small>Đã sắp xếp ngoan ngoãn xong rồi～</small>
                            <i class="wb-fold-chevron" aria-hidden="true"></i>
                        </span>
                    </summary>
                    <div class="wb-fold-body wb-memory-digest-body">
                        <p>${escapeHtml(digest.text)}</p>
                    </div>
                </details>
            ` : ''}
            ${resultCount === 0 ? renderEmpty(
                query ? 'Không tìm thấy ký ức phù hợp' : 'Mục phân loại này tạm thời còn trống',
                query ? 'Thử đổi nhân vật, địa điểm, vật phẩm hoặc từ khóa khác xem.' : 'Sẽ tự động bổ sung sau khi sắp xếp chính văn mới.',
            ) : `
            <div class="wb-memory-layout">
                <section class="wb-memory-section ${shownFacts.length ? '' : 'is-hidden'}">
                    <div class="wb-section-heading wb-memory-heading-with-folds">
                        <div><h3>Sự thật dài hạn</h3></div>
                        ${renderFoldToolbar('memory:facts:')}
                    </div>
                    <div class="wb-memory-group-list">
                        ${factGroups.map(group => {
                            const foldKey = `memory:facts:${encodeURIComponent(group.key || group.label)}`;
                            return `
                                <details class="wb-fold wb-memory-group" data-fold-key="${escapeAttr(foldKey)}"
                                    ${foldOpenAttr(openFolds, foldKey)}>
                                    <summary class="wb-memory-group-summary">
                                        <span>
                                            <strong>${escapeHtml(group.label)}</strong>
                                            <small>${group.items.length} sự thật dài hạn</small>
                                        </span>
                                        <i class="wb-fold-chevron" aria-hidden="true"></i>
                                    </summary>
                                    <div class="wb-fold-body wb-memory-group-body">
                                        ${group.items.map(item => renderFactCard(item, group.label)).join('')}
                                    </div>
                                </details>
                            `;
                        }).join('') || renderEmpty('Chưa có sự thật dài hạn nào～', 'Sau này những chuyện thật sự quan trọng, còn dùng đến sẽ dần dần ở lại đây.')}
                    </div>
                </section>
                <section class="wb-memory-section ${shownClues.length ? '' : 'is-hidden'}">
                    <div class="wb-section-heading wb-memory-heading-with-folds">
                        <div><h3>Sổ phục bút</h3></div>
                        ${renderFoldToolbar('memory:clues:')}
                    </div>
                    <div class="wb-memory-group-list">
                        ${clueGroups.map(group => {
                            const foldKey = `memory:clues:${encodeURIComponent(group.key || group.label)}`;
                            return `
                                <details class="wb-fold wb-memory-group" data-fold-key="${escapeAttr(foldKey)}"
                                    ${foldOpenAttr(openFolds, foldKey)}>
                                    <summary class="wb-memory-group-summary">
                                        <span>
                                            <strong>${escapeHtml(group.label)}</strong>
                                            <small>${group.items.length} phục bút liên quan</small>
                                        </span>
                                        <i class="wb-fold-chevron" aria-hidden="true"></i>
                                    </summary>
                                    <div class="wb-fold-body wb-memory-group-body">
                                        ${group.items.map(renderClueCard).join('')}
                                    </div>
                                </details>
                            `;
                        }).join('') || renderEmpty('Sổ phục bút vẫn còn trống～', 'Sau này những manh mối cần nhớ để thu hồi sẽ tự xuất hiện.')}
                    </div>
                </section>
            </div>
            <section class="wb-memory-summary-section ${shownSummaries.length ? '' : 'is-hidden'}">
                <div class="wb-section-heading wb-memory-heading-with-folds">
                    <div><h3>Trải nghiệm</h3></div>
                    ${renderFoldToolbar('memory:summary:')}
                </div>
                <div class="wb-summary-list">
                    ${shownSummaries.map(summary => {
                        const foldKey = `memory:summary:${summary.id || `${summary.startMessageId}-${summary.endMessageId}`}`;
                        const levelMeta = memorySummaryLevelMeta(summary);
                        const sourceSummaries = (summary.sourceSummaryIds || [])
                            .map(id => summaryById.get(String(id)))
                            .filter(Boolean);
                        const parent = summary.parentId ? summaryById.get(String(summary.parentId)) : null;
                        return `
                            <details class="wb-fold wb-summary-card is-${escapeAttr(levelMeta.tone)}" data-fold-key="${escapeAttr(foldKey)}"
                                ${foldOpenAttr(openFolds, foldKey)}>
                                <summary class="wb-summary-card-summary">
                                    <span><strong>${escapeHtml(summary.title)}</strong></span>
                                    <i class="wb-fold-chevron" aria-hidden="true"></i>
                                </summary>
                                <div class="wb-fold-body wb-summary-card-body">
                                    <p>${escapeHtml(summary.summary)}</p>
                                    <details class="wb-memory-lineage">
                                        <summary>Ký ức này từ đâu ra～</summary>
                                        <div>
                                            <p>${escapeHtml(levelMeta.label)} · Tin ${escapeHtml(summary.startMessageId)}—${escapeHtml(summary.endMessageId)}</p>
                                            ${parent ? `<p>Đã gộp vào: ${escapeHtml(parent.title)}</p>` : ''}
                                            ${sourceSummaries.length ? `<p>Còn ${sourceSummaries.length} nguồn chi tiết hơn có thể truy lại～</p>` : ''}
                                        </div>
                                    </details>
                                    ${renderMemoryActions('summary', summary, selectedKeys)}
                                </div>
                            </details>
                        `;
                    }).join('') || renderEmpty(
                        observerMode === 'backstage' ? 'Chưa có trải nghiệm phân tầng' : 'Trải nghiệm phân tầng chỉ hiển thị ở góc nhìn hậu trường',
                        observerMode === 'backstage' ? 'Sau khi sắp xếp chính văn, các trải nghiệm quan trọng sẽ dần xuất hiện ở đây～' : '',
                    )}
                </div>
            </section>
            `}
            ${hasMore ? `
                <button class="wb-memory-load-more" type="button" data-wb-action="load-more-memory">
                    Hiển thị thêm · Hiện tại ${shownCount}/${resultCount}
                </button>
            ` : ''}
        </div>
    `;
}

function renderMemoryEditorModal(state, editor) {
    const requestedKind = ['fact', 'clue', 'summary'].includes(editor?.kind)
        ? editor.kind
        : 'fact';
    const collection = requestedKind === 'fact'
        ? state.storyMemory?.facts
        : requestedKind === 'clue'
            ? state.storyMemory?.clues
            : state.storyMemory?.summaries;
    const item = collection?.find(entry => entry.id === editor?.id) || null;
    const title = requestedKind === 'fact' ? item?.subject : item?.title;
    const relation = requestedKind === 'fact' ? item?.predicate : '';
    const content = requestedKind === 'fact'
        ? item?.value
        : requestedKind === 'clue'
            ? item?.text
            : item?.summary;
    const peopleText = requestedKind === 'clue' ? (item?.people || []).join('、') : '';
    const locationsText = requestedKind === 'clue' ? (item?.locations || []).join('、') : '';
    const eventsText = requestedKind === 'clue' ? (item?.events || []).join('、') : '';
    return `
        <div class="wb-drawer-scrim" data-wb-action="close-memory-editor">
            <form class="wb-event-form wb-memory-editor" data-wb-form="memory">
                <div class="wb-form-heading">
                    <div><span>MEMORY DESK</span><h3>${item ? 'Sửa ký ức' : 'Thêm ký ức thủ công'}</h3></div>
                    <button type="button" data-wb-action="close-memory-editor">×</button>
                </div>
                <input type="hidden" name="id" value="${escapeAttr(item?.id || '')}">
                <label>Loại ký ức
                    <select name="kind" ${item ? 'disabled' : ''}>
                        <option value="fact" ${requestedKind === 'fact' ? 'selected' : ''}>Sự thật dài hạn</option>
                        <option value="clue" ${requestedKind === 'clue' ? 'selected' : ''}>Phục bút</option>
                        <option value="summary" ${requestedKind === 'summary' ? 'selected' : ''}>Trải nghiệm giai đoạn</option>
                    </select>
                    ${item ? `<input type="hidden" name="kind" value="${requestedKind}">` : ''}
                </label>
                <label>Tiêu đề<input name="title" required maxlength="120"
                    value="${escapeAttr(title || '')}" placeholder="Nhân vật, vật phẩm, lời hẹn hoặc sự kiện"></label>
                <label>Quan hệ (dùng cho sự thật dài hạn)<input name="relation" maxlength="100"
                    value="${escapeAttr(relation || '')}" placeholder="Ví dụ: hứa, nắm giữ, thân phận thật"></label>
                <label>Nội dung<textarea name="content" required maxlength="1400" rows="5"
                    placeholder="Viết nội dung chính xác cần lưu giữ lâu dài">${escapeHtml(content || '')}</textarea></label>
                ${requestedKind === 'clue' ? `
                    <div class="wb-memory-relation-editor">
                        <label>Nhân vật liên quan<input name="people" maxlength="500"
                            value="${escapeAttr(peopleText)}" placeholder="Có thể nhiều, ngăn cách bằng 、 hoặc dấu phẩy"></label>
                        <label>Sự kiện liên quan<input name="events" maxlength="500"
                            value="${escapeAttr(eventsText)}" placeholder="Tên sự kiện hoặc ID sự kiện, có thể nhiều"></label>
                        <label>Địa điểm liên quan<input name="locations" maxlength="500"
                            value="${escapeAttr(locationsText)}" placeholder="Tên địa điểm, có thể nhiều"></label>
                    </div>
                    <div class="wb-form-note">Liên kết chỉ để tiện tìm phục bút, không có nghĩa là nó “thuộc về” một người nào. Manh mối trải qua nhiều nhân vật, sự kiện, địa điểm có thể gắn nhiều liên kết cùng lúc.</div>
                ` : ''}
                <div class="wb-memory-editor-flags">
                    <label><input name="important" type="checkbox" ${item?.important ? 'checked' : ''}> Đánh dấu quan trọng</label>
                    <label><input name="locked" type="checkbox" ${item?.locked ? 'checked' : ''}> Khóa sau khi lưu</label>
                </div>
                <div class="wb-form-note">Sau khi khóa, việc tự động sắp xếp sẽ không ghi đè hay xóa ký ức này; khi cần sửa hãy mở khóa trên thẻ trước.</div>
                <button class="wb-primary-button" type="submit">${item ? 'Lưu thay đổi' : 'Thêm vào ký ức'}</button>
            </form>
        </div>
    `;
}

function renderArchiveView(state, openFolds = new Set()) {
    const archived = Array.isArray(state.archive) ? state.archive : [];
    return `
        <div class="wb-archive-ledger">
            ${archived.map(entry => renderArchiveEntry(entry, state, 'archive', openFolds)).join('')
                || renderEmpty('Sổ biên niên vẫn còn trống～', 'Vẫn chưa có đoạn lịch sử thế giới nào lặng lẽ lọt khỏi ống kính (˘ω˘)')}
        </div>
    `;
}

function renderWorldEditorModal(state) {
    return `
        <div class="wb-drawer-scrim" data-wb-action="close-world-editor">
            <form class="wb-event-form wb-world-editor" data-wb-form="world">
                <div class="wb-form-heading">
                    <div><span>WORLD DESK</span><h3>Sửa thiết lập thế giới</h3></div>
                    <button type="button" data-wb-action="close-world-editor">×</button>
                </div>
                <label>Tiêu đề thế giới
                    <input name="title" required maxlength="140" value="${escapeAttr(state.world?.title || '')}">
                </label>
                <label>Tình hình hiện tại
                    <textarea name="detail" required maxlength="900" rows="6">${escapeHtml(state.world?.detail || '')}</textarea>
                </label>
                <label>Thiết lập bối cảnh thế giới
                    <textarea name="background" maxlength="5000" rows="12"
                        placeholder="Viết nền tảng lâu dài của thế giới này: thời đại và trình độ khoa học/ma pháp, địa lý và các thế lực chính, quy tắc xã hội, lịch sử quan trọng, điểm neo dòng thời gian của nguyên tác……">${escapeHtml(state.world?.background || '')}</textarea>
                </label>
                <div class="wb-form-note">
                    Đây là “móng nhà” của thế giới～ nhân vật nền, World Pulse, sự kiện công cộng và tính nhất quán của chính văn đều tham khảo nó; suy diễn thông thường sẽ không tự viết lại. Hợp để viết quy tắc lâu dài và dòng thời gian quan trọng, không cần nhét cả thẻ nhân vật vào đây (｡•̀ᴗ-)✧
                </div>
                <button class="wb-primary-button" type="submit">Lưu thiết lập thế giới</button>
            </form>
        </div>
    `;
}

function recordEditorData(state, editor) {
    if (!editor) return null;
    if (editor.kind === 'echo') {
        const event = state.events.find(item => item.id === editor.id);
        if (!event) return null;
        return {
            kind: 'echo',
            id: event.id,
            title: event.title || '',
            text: event.result || event.expectedResult || event.consequence || '',
            place: event.place || '',
            visibility: event.visibility || 'hidden',
            deliveryState: event.delivery?.state || 'none',
        };
    }
    const entry = state.archive.find(item => item.id === editor.id);
    if (!entry) return null;
    return {
        kind: 'archive',
        id: entry.id,
        title: entry.title || 'Bản ghi chưa đặt tên',
        text: entry.result || entry.text || entry.consequence || entry.route || '',
        place: '',
        visibility: entry.visibility || 'hidden',
        deliveryState: entry.deliveryState || entry.delivery?.state || 'none',
    };
}

function renderRecordEditorModal(state, editor) {
    const record = recordEditorData(state, editor);
    if (!record) return '';
    const isEcho = record.kind === 'echo';
    return `
        <div class="wb-drawer-scrim" data-wb-action="close-record-editor">
            <form class="wb-event-form wb-record-editor" data-wb-form="record">
                <div class="wb-form-heading">
                    <div><span>${isEcho ? 'ECHO DESK' : 'ARCHIVE DESK'}</span><h3>${isEcho ? 'Sửa tiếng vọng' : 'Sửa biên niên'}</h3></div>
                    <button type="button" data-wb-action="close-record-editor">×</button>
                </div>
                <input type="hidden" name="kind" value="${escapeAttr(record.kind)}">
                <input type="hidden" name="id" value="${escapeAttr(record.id)}">
                <label>Tiêu đề
                    <input name="title" required maxlength="140" value="${escapeAttr(record.title)}">
                </label>
                <label>${isEcho ? 'Kết quả hình thành' : 'Nội dung biên niên'}
                    <textarea name="text" required maxlength="900" rows="6">${escapeHtml(record.text)}</textarea>
                </label>
                ${isEcho ? `<label>Địa điểm
                    <input name="place" maxlength="160" value="${escapeAttr(record.place)}">
                </label>` : ''}
                <div class="wb-form-grid">
                    <label>Ranh giới hiển thị
                        <select name="visibility">
                            <option value="hidden" ${record.visibility === 'hidden' ? 'selected' : ''}>Hoàn toàn hậu trường</option>
                            <option value="trace" ${record.visibility === 'trace' ? 'selected' : ''}>Để lại dấu vết</option>
                            <option value="known" ${record.visibility === 'known' ? 'selected' : ''}>Nhân vật có thể biết</option>
                            <option value="direct" ${record.visibility === 'direct' ? 'selected' : ''}>Có thể hé lộ trực tiếp</option>
                        </select>
                    </label>
                    ${isEcho ? `<label>Trạng thái chuyển giao
                        <select name="deliveryState">
                            <option value="none" ${record.deliveryState === 'none' ? 'selected' : ''}>Chưa chuyển giao</option>
                            <option value="pending" ${record.deliveryState === 'pending' ? 'selected' : ''}>Chờ hé lộ</option>
                            <option value="delivered" ${record.deliveryState === 'delivered' ? 'selected' : ''}>Chính văn đã tiếp nhận</option>
                            <option value="expired" ${record.deliveryState === 'expired' ? 'selected' : ''}>Chưa hé lộ, đã lưu trữ</option>
                        </select>
                    </label>` : ''}
                </div>
                <div class="wb-form-note">Chỉnh sửa chỉ sửa bản ghi thế giới hiện tại, không đẩy thời gian thế giới chính. Còn nếu xóa thì có thể khôi phục bằng nút Hoàn tác ở dưới cùng.</div>
                <button class="wb-primary-button" type="submit">Lưu thay đổi</button>
            </form>
        </div>
    `;
}

function visualViewportBounds() {
    const viewport = window.visualViewport;
    const left = Math.max(0, Number(viewport?.offsetLeft || 0));
    const top = Math.max(0, Number(viewport?.offsetTop || 0));
    const width = Math.max(0, Number(viewport?.width || window.innerWidth || 0));
    const height = Math.max(0, Number(viewport?.height || window.innerHeight || 0));
    return { left, top, width, height, right: left + width, bottom: top + height };
}

function responsiveOrbSize(
    viewportWidth = window.innerWidth,
    viewportHeight = window.innerHeight,
) {
    const shortestSide = Math.min(viewportWidth, viewportHeight);
    if (shortestSide > 680) return 52;
    return Math.round(Math.max(34, Math.min(38, shortestSide * 0.09)));
}

function clampOrbPosition(position) {
    if (
        !position
        || !Number.isFinite(Number(position.x))
        || !Number.isFinite(Number(position.y))
        || typeof window === 'undefined'
    ) {
        return null;
    }
    const viewport = visualViewportBounds();
    const size = responsiveOrbSize(viewport.width, viewport.height);
    const margin = 10;
    const minX = viewport.left + margin;
    const minY = viewport.top + margin;
    const maxX = Math.max(minX, viewport.right - size - margin);
    const maxY = Math.max(minY, viewport.bottom - size - margin);
    return {
        x: Math.min(maxX, Math.max(minX, Number(position.x))),
        y: Math.min(maxY, Math.max(minY, Number(position.y))),
        size,
    };
}

function orbInlineStyles(position) {
    const placed = clampOrbPosition(position);
    if (!placed) return { orb: '', caption: '' };
    const captionWidth = 210;
    const captionX = placed.x > captionWidth + 28
        ? placed.x - captionWidth - 10
        : placed.x + placed.size + 10;
    return {
        orb: `left:${Math.round(placed.x)}px;top:${Math.round(placed.y)}px;right:auto;bottom:auto;`,
        caption: `left:${Math.round(Math.max(8, Math.min(window.innerWidth - captionWidth - 8, captionX)))}px;top:${Math.round(placed.y + 5)}px;right:auto;bottom:auto;`,
    };
}

function defaultVisibleOrbPosition(side = 'right') {
    const viewport = visualViewportBounds();
    const size = responsiveOrbSize(viewport.width, viewport.height);
    const margin = 12;
    return {
        x: side === 'left'
            ? viewport.left + margin
            : viewport.right - size - margin,
        y: Math.max(viewport.top + margin, viewport.bottom - size - 24),
        size,
    };
}

function nearestOrbEdgeSide(position) {
    const placed = clampOrbPosition(position);
    if (!placed) return 'right';
    const viewport = visualViewportBounds();
    return placed.x + placed.size / 2 < viewport.left + viewport.width / 2 ? 'left' : 'right';
}

function halfDockOrbPosition(position, side = 'right') {
    const viewport = visualViewportBounds();
    const placed = clampOrbPosition(position) || defaultVisibleOrbPosition(side);
    const size = placed.size || responsiveOrbSize(viewport.width, viewport.height);
    const y = Math.min(
        Math.max(viewport.top + 8, placed.y),
        Math.max(viewport.top + 8, viewport.bottom - size - 8),
    );
    // Put the orb centre exactly on the viewport edge: half visible, half outside.
    const x = side === 'left'
        ? viewport.left - size / 2
        : viewport.right - size / 2;
    return { x, y, size };
}

function halfDockOrbInlineStyle(position, side = 'right') {
    const placed = halfDockOrbPosition(position, side);
    return `left:${Math.round(placed.x)}px;top:${Math.round(placed.y)}px;right:auto;bottom:auto;`;
}

export function createWorldBackstageUI({
    getState,
    getSettings,
    getSyncStatus = () => ({ phase: 'idle', message: 'Chưa suy diễn thế giới' }),
    getTavernProfiles = () => [],
    onAction,
    pluginVersion = '',
}) {
    const root = document.createElement('div');
    root.id = 'world-backstage-root';
    document.body.appendChild(root);

    function syncVisualViewportInsets() {
        const viewport = window.visualViewport;
        const viewportWidth = Number(viewport?.width || window.innerWidth || 0);
        const viewportHeight = Number(viewport?.height || window.innerHeight || 0);
        const offsetLeft = Math.max(0, Number(viewport?.offsetLeft || 0));
        const offsetTop = Math.max(0, Number(viewport?.offsetTop || 0));
        const right = Math.max(0, Number(window.innerWidth || 0) - viewportWidth - offsetLeft);
        root.style.setProperty('--wb-visual-inset-top', `${Math.round(offsetTop)}px`);
        root.style.setProperty('--wb-visual-inset-right', `${Math.round(right)}px`);
        root.style.setProperty('--wb-visual-inset-left', `${Math.round(offsetLeft)}px`);
        root.style.setProperty('--wb-visual-width', `${Math.round(viewportWidth)}px`);
        root.style.setProperty('--wb-visual-height', `${Math.round(viewportHeight)}px`);
    }
    syncVisualViewportInsets();

    function ensureMounted() {
        if (!root.isConnected) document.body.appendChild(root);
        syncVisualViewportInsets();
        const settings = getSettings();
        const orb = root.querySelector('.wb-world-orb');
        if (settings.orbEnabled !== false) {
            if (settings.orbPosition && orb) {
                positionOrbFromSettings(settings);
            }
            if (!orb) render();
        } else if (orb) {
            render();
        }
        const latestRevision = Math.max(0, Number(getState()?.revision) || 0);
        if (latestRevision !== renderedRevision) render();
        return root.isConnected;
    }

    let activeView = 'now';
    let renderedView = activeView;
    let observerMode = 'backstage';
    let isOpen = false;
    let settingsOpen = false;
    let settingsSection = 'common';
    let moduleSettingsView = '';
    let eventFormOpen = false;
    let eventEditorId = '';
    let selectedPersonId = null;
    let personObservation = null;
    let busy = false;
    let toast = '';
    let toastTimer = null;
    let closeTimer = null;
    let closing = false;
    let panelEntrancePending = false;
    let publicOpinionMode = 'news';
    let lingqiDraft = '';
    let lingqiMascotOverride = '';
    let lingqiMascotTimer = null;
    let lingqiChatScrollState = { top: 0, atBottom: true, initialized: false };
    let lingqiNotesScrollTop = 0;
    let lingqiReadableOpenKeys = new Set();
    let lingqiPetCount = 0;
    let lingqiPetWindowAt = 0;
    let socialDraft = '';
    let socialGroupOpen = false;
    let socialGroupSelectedIds = new Set();
    let socialChatScrollState = { top: 0, atBottom: true, initialized: false };
    let socialPage = 'messages';
    let socialSearchQuery = '';
    let socialSearchTimer = null;
    let socialNoticeTimer = null;
    let socialNoticeVisibleId = '';
    const socialNoticeShownIds = new Set();

    function currentLingqiMascotState(override = '') {
        const latest = getSyncStatus()?.lingqi || {};
        const notes = Array.isArray(latest.notes) ? latest.notes : [];
        const activeNotes = notes.filter(note => ['active', 'paused'].includes(note.status));
        const pending = latest.pendingProposal && typeof latest.pendingProposal === 'object'
            ? latest.pendingProposal
            : null;
        return lingqiMascotState(latest, activeNotes, pending, override);
    }

    function applyLingqiMascotPose(state = '') {
        if (!isOpen || activeView !== 'lingqi') return false;
        const mascot = root.querySelector('.wb-lingqi-mascot');
        if (!mascot) return false;

        const nextState = lingqiMascotAssetState(state || currentLingqiMascotState());
        const image = mascot.querySelector('img');
        const busyNow = getSyncStatus()?.lingqi?.phase === 'running';

        for (const mascotState of Object.keys(LINGQI_MASCOT_ASSETS)) {
            mascot.classList.remove(`is-${mascotState}`, `is-asset-${mascotState}`);
        }
        mascot.classList.add(`is-${nextState}`, `is-asset-${nextState}`);
        mascot.dataset.mascotState = nextState;
        mascot.title = busyNow ? '玲七 đang nghĩ……' : 'Chạm vào 玲七';
        if (image) {
            image.src = LINGQI_MASCOT_ASSETS[nextState] || LINGQI_MASCOT_ASSETS.idle;
        }
        return true;
    }

    function showLingqiMascotReaction(state, duration = 1200) {
        lingqiMascotOverride = state;
        window.clearTimeout(lingqiMascotTimer);
        // Explicit user interaction may create one short reaction, but afterwards
        // Lingqi always returns to the pose chosen by the latest reply/state.
        applyLingqiMascotPose(currentLingqiMascotState(lingqiMascotOverride));
        lingqiMascotTimer = window.setTimeout(() => {
            lingqiMascotOverride = '';
            applyLingqiMascotPose(currentLingqiMascotState());
        }, duration);
    }
    let publicOpinionActionBusy = false;
    let publicOpinionSandboxActionBusy = false;
    let memorySearchTimer = null;
    let memoryFilter = 'active';
    let memoryClueRelationFilter = 'all';
    let memoryQuery = '';
    let memoryVisibleCount = 12;
    let memorySelectedKeys = new Set();
    let peopleSelectionMode = false;
    let peopleSelectedIds = new Set();
    let memoryEditor = null;
    let personEditor = null;
    let worldEditorOpen = false;
    let recordEditor = null;
    let settingsScrollTop = 0;
    let openSettingsGroups = new Set();
    let openSettingsSubgroups = new Set();
    let openContentFolds = new Set();
    const viewFoldStates = new Map();
    let eventFormDraft = null;
    let clockFormDraft = null;
    let apiFormDraft = null;
    let tagFilterDraftRules = null; // null = use settings; array may include empty draft cards
    let tagFilterCandidates = [];
    let worldbookQuery = '';
    let worldbookOnlyPeople = false;
    let worldbookOnlyEnabled = false;
    let worldbookSelectedIds = new Set();
    let worldbookDraftToken = '';
    let worldbookDraftSkipped = new Set();
    let worldbookDraftDroppedFields = new Set();
    let worldbookDraftPickedFields = new Set();
    let worldbookDraftTargets = new Map();
    let worldbookListScrollTop = 0;
    let worldbookSearchTimer = null;
    let skipApiDraftCapture = false;
    let skipTagFilterDraftCapture = false;
    const viewScrollTop = new Map();
    let orbDrag = null;
    let suppressOrbClick = false;
    let renderedRevision = Math.max(0, Number(getState()?.revision) || 0);
    let lastSeenRevision = renderedRevision;
    let dismissedNarrativePromptKey = '';
    let freshOpenCheckFrame = 0;

    function notify(message, tone = 'normal') {
        toast = String(message || '');
        root.dataset.toastTone = tone;
        window.clearTimeout(toastTimer);
        toastTimer = window.setTimeout(() => {
            toast = '';
            render();
        }, tone === 'error' ? 7600 : 5200);
        render();
    }

    function readApiForm(form) {
        const data = Object.fromEntries(new FormData(form).entries());
        apiFormDraft = { ...data };
        return data;
    }

    function apiSettingsFromDraft(data) {
        const replacementKey = String(data.customApiCredential || '').trim();
        return {
            customApiUrl: data.customApiUrl,
            customApiKey: replacementKey || getSettings().customApiKey,
            customApiModel: data.customApiModel,
            customApiTransport: data.customApiTransport,
        };
    }

    function apiRequestFromDraft(data, { requireModel = true } = {}) {
        const settings = getSettings();
        const profileId = String(data.profileId || '').trim();
        const existingProfile = (settings.apiProfiles || []).find(item => item.id === profileId);
        const key = String(data.customApiCredential || '').trim()
            || existingProfile?.key
            || (!profileId ? settings.customApiKey : '');
        const model = String(data.customApiModel || '').trim();
        if (!key) throw new Error('API này còn thiếu API Key đó～');
        if (requireModel && !model) throw new Error('Chọn model trước rồi hãy thử nhé～');
        return {
            url: data.customApiUrl,
            key,
            model,
            transport: data.customApiTransport,
            label: String(data.profileName || existingProfile?.name || 'API này').trim() || 'API này',
        };
    }

    function forgetApiKeyDraft(data) {
        apiFormDraft = { ...data, customApiCredential: '' };
        skipApiDraftCapture = true;
    }

    async function invokeAction(action, payload = {}) {
        try {
            const result = await onAction(action, payload);
            return result === undefined ? true : result;
        } catch (error) {
            const message = String(error?.message || error || 'Lỗi không xác định');
            console.warn('[世界背面] Thao tác giao diện chưa hoàn tất', error);
            notify(`Thao tác chưa hoàn tất: ${message}`, 'error');
            return false;
        }
    }

    function visibleTagFilterRules(settings) {
        if (Array.isArray(tagFilterDraftRules)) return tagFilterDraftRules;
        return Array.isArray(settings.tagFilterRules)
            ? settings.tagFilterRules.map(rule => ({ open: rule.open, close: rule.close }))
            : [];
    }

    async function persistTagFilterRules(rules) {
        const persisted = rules
            .map(rule => ({
                open: String(rule.open || '').trim().slice(0, 80),
                close: String(rule.close || '').trim().slice(0, 80),
            }))
            .filter(rule => rule.open || rule.close)
            .slice(0, 30);
        tagFilterDraftRules = rules.map(rule => ({
            open: String(rule.open || ''),
            close: String(rule.close || ''),
        }));
        skipTagFilterDraftCapture = true;
        await invokeAction('update-settings', { tagFilterRules: persisted });
    }

    function setBusy(value) {
        busy = Boolean(value);
        render();
    }

    function open() {
        window.clearTimeout(closeTimer);
        closing = false;
        panelEntrancePending = !isOpen;
        isOpen = true;
        render();
        window.cancelAnimationFrame?.(freshOpenCheckFrame);
        freshOpenCheckFrame = window.requestAnimationFrame?.(() => {
            freshOpenCheckFrame = 0;
            const latestRevision = Math.max(0, Number(getState()?.revision) || 0);
            if (latestRevision !== renderedRevision) render();
        }) || 0;
    }

    function openEvent(eventId = '') {
        const id = String(eventId || '');
        activeView = 'currents';
        open();
        window.requestAnimationFrame?.(() => {
            const safeId = globalThis.CSS?.escape?.(`currents:${id}`) || `currents:${id}`.replace(/["\\]/g, '\\$&');
            const card = root.querySelector(`[data-fold-key="${safeId}"]`);
            if (card instanceof HTMLDetailsElement) card.open = true;
            card?.scrollIntoView?.({ block: 'center', behavior: 'smooth' });
            card?.animate?.([
                { boxShadow: '0 0 0 0 rgba(121,111,174,0)' },
                { boxShadow: '0 0 0 4px rgba(121,111,174,.18)' },
                { boxShadow: '0 0 0 0 rgba(121,111,174,0)' },
            ], { duration: 900, easing: 'ease-out' });
        });
    }

    function close() {
        if (!isOpen || closing) return;
        closing = true;
        root.querySelector('.wb-panel-scrim')?.classList.add('is-closing');
        const closeDelay = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
            ? 0
            : 145;
        closeTimer = window.setTimeout(() => {
            isOpen = false;
            closing = false;
            settingsOpen = false;
            eventFormOpen = false;
            eventEditorId = '';
            eventFormDraft = null;
            clockFormDraft = null;
            tagFilterDraftRules = null;
            memoryEditor = null;
            memorySelectedKeys = new Set();
            personEditor = null;
            worldEditorOpen = false;
            recordEditor = null;
            selectedPersonId = null;
            personObservation = null;
            render();
        }, closeDelay);
    }

    function resetContext() {
        eventFormOpen = false;
        eventEditorId = '';
        eventFormDraft = null;
        clockFormDraft = null;
        selectedPersonId = null;
        personObservation = null;
        personEditor = null;
        memoryEditor = null;
        memorySelectedKeys = new Set();
        peopleSelectionMode = false;
        peopleSelectedIds = new Set();
        memoryQuery = '';
        memoryFilter = 'active';
        memoryClueRelationFilter = 'all';
        memoryVisibleCount = 12;
        worldEditorOpen = false;
        recordEditor = null;
        worldbookSelectedIds = new Set();
        worldbookQuery = '';
        worldbookListScrollTop = 0;
        lingqiDraft = '';
        lingqiChatScrollState = { top: 0, atBottom: true, initialized: false };
        lingqiNotesScrollTop = 0;
        lingqiReadableOpenKeys = new Set();
        viewFoldStates.clear();
        viewScrollTop.clear();
        openContentFolds = new Set();
        render();
    }

    function render() {
        // New drafts reset choices. Ambiguous people and low-coverage fields require explicit selection.
        const worldbook = getSyncStatus()?.worldbook || {};
        const draftToken = String(getSyncStatus()?.worldbook?.aiImport?.token || '');
        if (draftToken !== worldbookDraftToken) {
            worldbookDraftToken = draftToken;
            worldbookDraftSkipped = new Set((worldbook.aiImport?.people || []).filter(person => person.ambiguous || person.nameConflict).map(person => person.reference));
            worldbookDraftTargets = new Map((worldbook.aiImport?.people || []).map(person => [person.reference, person.ambiguous || person.nameConflict ? 'new' : '']));
            worldbookDraftDroppedFields = new Set();
            worldbookDraftPickedFields = new Set();
        }
        const viewChanged = activeView !== renderedView;
        const animatePanelEntrance = Boolean(isOpen && panelEntrancePending);
        const previousContent = root.querySelector('.wb-view-content');
        if (previousContent) viewScrollTop.set(renderedView, previousContent.scrollTop);

        // Full UI renders can still happen for real data/status changes. Preserve every
        // user-controlled Lingqi <details> fold across those legitimate rebuilds.
        const previousLingqiReadables = root.querySelectorAll(
            'details[data-lingqi-readable-key]',
        );
        for (const detail of previousLingqiReadables) {
            const key = String(detail.dataset.lingqiReadableKey || '');
            if (!key) continue;
            if (detail.open) lingqiReadableOpenKeys.add(key);
            else lingqiReadableOpenKeys.delete(key);
        }

        const previousContentFolds = root.querySelectorAll('.wb-fold[data-fold-key]');
        if (previousContentFolds.length) {
            viewFoldStates.set(renderedView, new Set(
                [...previousContentFolds]
                    .filter(item => item.open)
                    .map(item => item.dataset.foldKey)
                    .filter(Boolean),
            ));
        }
        openContentFolds = new Set(viewFoldStates.get(activeView) || []);
        const previousSettings = root.querySelector('.wb-settings-popover');
        if (previousSettings) settingsScrollTop = previousSettings.scrollTop;
        const previousWorldbookList = root.querySelector('.wb-worldbook-entry-list');
        if (previousWorldbookList) worldbookListScrollTop = previousWorldbookList.scrollTop;
        const previousSettingGroups = root.querySelectorAll('.wb-settings-group[data-settings-group]');
        if (previousSettingGroups.length) {
            openSettingsGroups = new Set(
                [...previousSettingGroups]
                    .filter(group => group.open)
                    .map(group => group.dataset.settingsGroup),
            );
        }
        const previousSettingSubgroups = root.querySelectorAll('[data-settings-subgroup]');
        if (previousSettingSubgroups.length) {
            openSettingsSubgroups = new Set(
                [...previousSettingSubgroups]
                    .filter(group => group.open)
                    .map(group => group.dataset.settingsSubgroup),
            );
        }
        const previousEventForm = root.querySelector('[data-wb-form="event"]');
        if (previousEventForm && eventFormOpen) {
            eventFormDraft = Object.fromEntries(new FormData(previousEventForm).entries());
        }
        const previousClockForm = root.querySelector('[data-wb-form="clock"]');
        if (previousClockForm && (settingsOpen || moduleSettingsView)) {
            clockFormDraft = Object.fromEntries(new FormData(previousClockForm).entries());
        }
        const previousApiForm = root.querySelector('[data-wb-form="api"]');
        if (previousApiForm && !skipApiDraftCapture) {
            readApiForm(previousApiForm);
        }
        const previousLingqiInput = root.querySelector('[data-wb-form="lingqi-chat"] textarea[name="text"]');
        if (previousLingqiInput) lingqiDraft = previousLingqiInput.value;
        const previousSocialInput = root.querySelector('[data-wb-form="social-message"] textarea[name="text"]');
        if (previousSocialInput) socialDraft = previousSocialInput.value;
        const previousSocialChat = root.querySelector('.wb-social-log');
        if (previousSocialChat) {
            const bottomGap = previousSocialChat.scrollHeight
                - previousSocialChat.scrollTop
                - previousSocialChat.clientHeight;
            socialChatScrollState = {
                top: previousSocialChat.scrollTop,
                atBottom: bottomGap <= 28,
                initialized: true,
            };
        }
        const previousSocialGroup = root.querySelector('[data-wb-form="social-group"]');
        if (previousSocialGroup) {
            socialGroupSelectedIds = new Set(
                [...previousSocialGroup.querySelectorAll('input[name="memberIds"]:checked')]
                    .map(input => String(input.value || ''))
                    .filter(Boolean),
            );
        }

        const previousLingqiChat = root.querySelector('.wb-lingqi-chat-log');
        if (previousLingqiChat) {
            const bottomGap = previousLingqiChat.scrollHeight
                - previousLingqiChat.scrollTop
                - previousLingqiChat.clientHeight;
            lingqiChatScrollState = {
                top: previousLingqiChat.scrollTop,
                atBottom: bottomGap <= 28,
                initialized: true,
            };
        }
        const previousLingqiNotes = root.querySelector('.wb-lingqi-notes-scroll');
        if (previousLingqiNotes) lingqiNotesScrollTop = previousLingqiNotes.scrollTop;

        skipApiDraftCapture = false;
        if (settingsOpen && !skipTagFilterDraftCapture) {
            const previousTagFilterRules = root.querySelectorAll('.wb-tag-filter-rule');
            if (previousTagFilterRules.length) {
                tagFilterDraftRules = [...previousTagFilterRules].map(card => ({
                    open: String(card.querySelector('[data-wb-tag-filter-field="open"]')?.value || ''),
                    close: String(card.querySelector('[data-wb-tag-filter-field="close"]')?.value || ''),
                }));
            }
        }
        skipTagFilterDraftCapture = false;
        const previousFocus = root.contains(document.activeElement)
            ? {
                id: document.activeElement.id || '',
                name: document.activeElement.getAttribute?.('name') || '',
                selectionStart: document.activeElement.selectionStart,
                selectionEnd: document.activeElement.selectionEnd,
            }
            : null;

        const state = getState();
        const settings = getSettings();
        const syncStatus = getSyncStatus();
        const tavernProfilesRaw = settingsOpen ? getTavernProfiles?.() : [];
        const tavernProfiles = Array.isArray(tavernProfilesRaw) ? tavernProfilesRaw : [];
        const canCancelSimulation = Boolean(syncStatus.canCancelSimulation);
        const manualSimulationQueued = Boolean(syncStatus.manualSimulationQueued);
        const canCancelBackgroundTask = Boolean(syncStatus.canCancelBackgroundTask);
        const activeBackgroundTasks = Array.isArray(syncStatus.activeBackgroundTasks)
            ? syncStatus.activeBackgroundTasks
            : [];
        const memoryPhase = syncStatus.memory?.phase;
        if (['running', 'error'].includes(memoryPhase)) {
            openSettingsGroups.add('memory');
            openSettingsSubgroups.add('memory-history');
        }
        const memoryTakesFocus = ['running', 'error'].includes(memoryPhase);
        const displayPhase = memoryTakesFocus ? memoryPhase : syncStatus.phase;
        const displayPhaseLabel = memoryTakesFocus
            ? (memoryPhase === 'error' ? 'Ký ức lỗi' : 'Đang sắp xếp ký ức')
            : `${syncPhaseLabel(syncStatus.phase)}${syncStatus.queue?.waitingTurns > 0
                ? ` · chờ ${syncStatus.queue.waitingTurns} lượt`
                : ''}`;
        const theme = themeFor(state, settings);
        const clock = formatWorldCalendar(state);
        const clockAnchored = Boolean(state.clock?.anchored);
        const clockMinuteKnown = state.clock?.precision === 'minute';
        const clockEstimatedMinutes = estimatedClockProgress(state);
        const clockTimeLabel = clockMinuteKnown
            ? `${clockEstimatedMinutes > 0 ? 'khoảng ' : ''}${clock.time}`
            : state.clock?.precision === 'daypart' && state.clock?.daypart
                ? state.clock.daypart
                : clockAnchored ? 'Chưa xác định giờ' : `# ${clock.day}`;
        const clockProgressLabel = !clockMinuteKnown && clockEstimatedMinutes > 0
            ? `+khoảng ${formatDuration(clockEstimatedMinutes)}`
            : clockTimeLabel;
        const clockDateTime = clockAnchored
            ? `${clock.year}-${String(clock.month).padStart(2, '0')}-${String(clock.dayOfMonth).padStart(2, '0')}${clockMinuteKnown ? `T${clock.time}` : ''}`
            : '';
        const clockLabel = worldClockLabel(state);
        const orbStyles = orbInlineStyles(settings.orbPosition);
        const currentView = VIEWS.find(view => view.id === activeView) || VIEWS[0];
        const userName = String(syncStatus.userName || '').toLocaleLowerCase();
        const displayPeople = state.people
            .map(person => {
                const isUser = Boolean(
                    person.isUser
                    || (userName && person.name?.toLocaleLowerCase() === userName)
                );
                return { ...person, isUser, innerVoice: isUser ? '' : person.innerVoice };
            })
            .filter(person => settings.recordPlayerCharacter !== false || !person.isUser);
        const candidatePeople = observerMode === 'backstage'
            ? displayPeople
            : displayPeople.filter(person => person.knowledge === 'known');
        const visibleEvents = observerMode === 'backstage'
            ? state.events
            : state.events.filter(event => event.visibility !== 'hidden');
        const presentPersonIds = new Set(syncStatus.presentPersonIds || []);
        const presentPeople = candidatePeople.filter(person => presentPersonIds.has(person.id));
        const activeEvents = sortEventsForDisplay(visibleEvents.filter(isActiveEvent), state, presentPeople);
        const visiblePeople = sortPeopleForDisplay(
            candidatePeople,
            activeEvents,
            presentPersonIds,
            state.clock?.absoluteMinute,
        );
        const outcomes = visibleEvents
            .filter(event => (event.status === 'ready' || isTerminalEvent(event)) && event.delivery?.state !== 'expired')
            .sort((a, b) => echoOutcomeMinute(b) - echoOutcomeMinute(a));
        const person = displayPeople.find(item => item.id === selectedPersonId);
        const canObservePerson = Boolean(
            person
            && observerMode === 'backstage'
            && !person.isUser
        );
        const pendingDeliveries = state.events.filter(event => event.delivery?.state === 'pending').length;
        const narrativeSync = syncStatus.narrative || {};
        const narrativeNeedsSimulation = Boolean(narrativeSync.needsSimulation);
        const orbProcessing = (
            ['queued', 'running', 'cancelling'].includes(syncStatus.phase)
            || syncStatus.memory?.phase === 'running'
        );
        const stateRevision = Math.max(0, Number(state.revision) || 0);
        const unreadWorldRevision = !isOpen && stateRevision > lastSeenRevision;
        const narrativePromptVisible = Boolean(
            narrativeNeedsSimulation
            && (settings.pendingSimulationPromptEnabled || syncStatus.phase === 'error')
        );
        const narrativeNeedsAttention = Boolean(
            narrativePromptVisible
            || syncStatus.editDecision?.available
            || syncStatus.phase === 'error'
            || memoryPhase === 'error'
        );
        const worldHasUnreadUpdate = Boolean(
            !narrativeNeedsAttention
            && (unreadWorldRevision || pendingDeliveries)
        );
        const needsAttention = narrativeNeedsAttention || worldHasUnreadUpdate;
        const narrativePromptKey = narrativeNeedsSimulation
            ? `${String(narrativeSync.sourceKey || narrativeSync.latestMessageId || 'latest')}:${syncStatus.phase === 'error' ? 'error' : 'pending'}`
            : '';
        const captionCanSimulate = Boolean(
            narrativePromptVisible
            && !isOpen
            && !orbProcessing
            && settings.enabled
            && settings.worldSimulationEnabled
            && narrativePromptKey !== dismissedNarrativePromptKey
        );
        const captionText = memoryPhase === 'error'
            ? syncStatus.memory?.message || 'Sắp xếp ký ức vừa vấp một chút QAQ, bấm vào xem nguyên nhân nhé～'
            : memoryPhase === 'running'
                ? syncStatus.memory.message || 'Ký ức đang được lặng lẽ dọn dẹp～ (｡•̀ᴗ-)✧'
                : orbProcessing
                    ? syncStatus.message || 'Thế giới ngoài ống kính đang lặng lẽ vận hành… ( •̀ ω •́ )✧'
                    : syncStatus.phase === 'error'
                        ? 'Ư, chính văn lượt này suy diễn chưa thành công QAQ, có thể thử lại ở đây nhé～'
                        : narrativePromptVisible
                            ? `${Math.max(1, Number(narrativeSync.pendingTurns) || 1)} lượt chính văn mới chưa được suy diễn, có muốn bắt kịp ngay không?`
                            : pendingDeliveries > 0
                                ? `${pendingDeliveries} thay đổi đang từ từ tiến lại gần ống kính～`
                                : unreadWorldRevision
                                    ? 'Thế giới vừa có thay đổi mới, bấm vào xem nhé～ (｡•̀ᴗ-)✧'
                                    : 'Ngoài ống kính tạm thời yên ắng～ (˘ω˘)';
        const orbEdgeSide = nearestOrbEdgeSide(settings.orbPosition);
        const orbEdgeHidden = Boolean(settings.orbEdgeHide && !isOpen);
        const renderedOrbStyle = orbEdgeHidden
            ? halfDockOrbInlineStyle(settings.orbPosition, orbEdgeSide)
            : orbStyles.orb;
        const socialNotices = (Array.isArray(syncStatus.social?.notices) ? syncStatus.social.notices : [])
            .filter(item => !item?.readAt)
            .reverse();
        if (socialNoticeVisibleId && !socialNotices.some(item => item.id === socialNoticeVisibleId)) {
            socialNoticeVisibleId = '';
            window.clearTimeout(socialNoticeTimer);
            socialNoticeTimer = null;
        }
        const newestSocialNotice = socialNotices[0] || null;
        if (!socialNoticeVisibleId && newestSocialNotice && !socialNoticeShownIds.has(newestSocialNotice.id)) {
            socialNoticeVisibleId = newestSocialNotice.id;
            socialNotices.forEach(item => socialNoticeShownIds.add(item.id));
            window.clearTimeout(socialNoticeTimer);
            socialNoticeTimer = window.setTimeout(() => {
                if (socialNoticeVisibleId === newestSocialNotice.id) {
                    socialNoticeVisibleId = '';
                    socialNoticeTimer = null;
                    render();
                }
            }, 6000);
        }
        const socialNotice = socialNotices.find(item => item.id === socialNoticeVisibleId) || null;
        const socialNoticePerson = socialNotice
            ? state.people.find(item => String(item?.id || '') === String(socialNotice.personId || ''))
            : null;
        const socialNoticePage = socialNotice?.kind === 'message'
            ? 'messages'
            : socialNotice?.kind === 'moment'
                ? 'moments'
                : 'contacts';
        const socialNoticeLabel = socialNotice?.kind === 'message'
            ? 'Tin nhắn mới'
            : socialNotice?.kind === 'friend_request'
                ? 'lời mời kết bạn'
                : socialNotice?.kind === 'friend_removed'
                    ? 'Thay đổi quan hệ'
                    : 'Động thái mới';

        let content = '';
        if (activeView === 'now') content = renderNowView(state, observerMode, visiblePeople, activeEvents, narrativeSync);
        if (activeView === 'lingqi') content = renderLingqiView(
            syncStatus.lingqi || {},
            lingqiDraft,
            lingqiMascotOverride,
            lingqiReadableOpenKeys,
        );
        if (activeView === 'social') content = renderSocialView(state, syncStatus.social || {}, settings, {
            draft: socialDraft,
            groupOpen: socialGroupOpen,
            groupSelectedIds: socialGroupSelectedIds,
            page: socialPage,
            searchQuery: socialSearchQuery,
        });
        if (activeView === 'people') {
            const validPeopleIds = new Set(state.people.map(person => person.id));
            peopleSelectedIds = new Set([...peopleSelectedIds].filter(id => validPeopleIds.has(id)));
            content = renderPeopleView(state, observerMode, visiblePeople, openContentFolds, {
                selectionMode: peopleSelectionMode,
                selectedIds: peopleSelectedIds,
            });
        }
        if (activeView === 'currents') content = renderCurrentsView(state, activeEvents, openContentFolds, settings);
        if (activeView === 'echoes') content = renderEchoesView(state, outcomes, openContentFolds);
        if (activeView === 'opinion') content = renderPublicOpinionView(
            state,
            {
                ...(syncStatus.publicOpinion || {}),
                interactionBusy: publicOpinionActionBusy,
                sandboxInteractionBusy: publicOpinionSandboxActionBusy,
            },
            publicOpinionMode,
            settings,
        );
        if (activeView === 'memory') content = renderMemoryView(state, observerMode, {
            query: memoryQuery,
            filter: memoryFilter,
            visibleCount: memoryVisibleCount,
            openFolds: openContentFolds,
            selectedKeys: memorySelectedKeys,
            clueRelationFilter: memoryClueRelationFilter,
        });
        if (activeView === 'archive') content = renderArchiveView(state, openContentFolds);

        root.className = `wb-root theme-${theme} wb-size-${settings.uiScale} ${settings.enabled ? 'is-enabled' : 'is-disabled'}`;
        root.innerHTML = `
            ${settings.orbEnabled !== false ? `
            <button class="wb-world-orb ${isOpen ? 'is-open' : ''} ${orbProcessing ? 'is-processing' : ''} ${settings.orbPosition ? 'has-custom-position' : ''} ${orbEdgeHidden ? `is-edge-hidden is-edge-${orbEdgeSide}` : ''}" type="button"
                style="${renderedOrbStyle}" data-wb-action="toggle-panel"
                aria-label="${isOpen ? 'Thu gọn 世界背面' : 'Mở 世界背面'}">
                <span class="wb-orb-halo"></span>
                <span class="wb-orb-ring ring-one"></span>
                <span class="wb-orb-ring ring-two"></span>
                <span class="wb-orb-core"></span>
                ${narrativeNeedsAttention
                    ? '<i class="wb-orb-notice" aria-hidden="true"></i>'
                    : worldHasUnreadUpdate
                        ? '<i class="wb-orb-update" aria-hidden="true"></i>'
                        : ''}
            </button>
            <div class="wb-orb-caption ${!isOpen && needsAttention && !orbEdgeHidden ? 'is-visible' : ''} ${captionCanSimulate ? 'has-action' : ''}"
                style="${orbStyles.caption}" role="${captionCanSimulate ? 'dialog' : 'status'}" aria-live="polite"
                ${captionCanSimulate ? 'aria-label="Phát hiện chính văn chưa suy diễn"' : ''}>
                <div class="wb-orb-caption-copy">
                    <strong>世界背面</strong>
                    <span>${escapeHtml(captionText)}</span>
                </div>
                ${captionCanSimulate ? `
                    <div class="wb-orb-caption-actions">
                        <button type="button" class="wb-orb-caption-later" data-wb-action="dismiss-narrative-prompt"
                            data-prompt-key="${escapeAttr(narrativePromptKey)}">Để sau</button>
                        <button type="button" class="wb-orb-caption-sync" data-wb-action="manual-sync">
                            ${syncStatus.phase === 'error' ? 'Suy diễn lại' : 'Suy diễn'}
                        </button>
                    </div>
                ` : ''}
            </div>
            ` : ''}

            ${isOpen ? `
                <div class="wb-panel-scrim ${animatePanelEntrance ? 'is-opening' : ''}" data-wb-action="close-panel">
                    <section class="wb-window" role="dialog" aria-modal="true" aria-label="世界背面">
                        <header class="wb-window-header">
                            <div class="wb-brand">
                                ${renderBrandMark()}
                                <div>
                            <span class="wb-brand-line"><h1>世界背面</h1><i>${escapeHtml(pluginDisplayVersion(pluginVersion))}</i></span>
                                    <p>Ngoài ống kính, thế giới vẫn tiếp diễn</p>
                                </div>
                            </div>
                            <time class="wb-mobile-clock-time"
                                ${clockDateTime ? `datetime="${escapeAttr(clockDateTime)}"` : ''}
                                aria-label="${escapeAttr(clockLabel)}">
                                ${escapeHtml(clockProgressLabel)}
                            </time>
                            <div class="wb-header-center">
                                <time class="wb-world-calendar" ${clockDateTime ? `datetime="${escapeAttr(clockDateTime)}"` : ''} aria-label="${escapeAttr(clockLabel)}">
                                    ${clockAnchored ? `
                                        <span class="wb-calendar-page" aria-hidden="true">
                                            <small>${escapeHtml(`${clock.month}月`)}</small>
                                            <strong>${escapeHtml(String(clock.dayOfMonth).padStart(2, '0'))}</strong>
                                        </span>
                                        <span class="wb-calendar-copy">
                                            <small>${escapeHtml(`${state.world.name} · ${clock.calendarName}`)}</small>
                                            <strong>${escapeHtml(`${clock.year} · Tháng ${clock.month}`)}</strong>
                                            <em>${escapeHtml(clockProgressLabel)}</em>
                                        </span>
                                    ` : `
                                        <span class="wb-calendar-page" aria-hidden="true">
                                            <small>Ngày truyện</small>
                                            <strong>${escapeHtml(String(clock.day))}</strong>
                                        </span>
                                        <span class="wb-calendar-copy">
                                            <small>${escapeHtml(`${state.world.name} · Đồng hồ thế giới chính`)}</small>
                                            <strong>Ngày thứ ${escapeHtml(String(clock.day))}</strong>
                                            <em>${escapeHtml(clockProgressLabel)}</em>
                                        </span>
                                    `}
                                </time>
                                <span class="wb-live-status is-${escapeAttr(displayPhase)}">
                                    <i></i>${escapeHtml(displayPhaseLabel)}
                                </span>
                            </div>
                            <div class="wb-header-actions">
                                <button type="button" class="wb-round-action" data-wb-action="cycle-theme"
                                    aria-label="Chuyển ngày/đêm"><span class="wb-theme-glyph"></span></button>
                                <button type="button" class="wb-round-action ${settingsOpen ? 'is-active' : ''}"
                                    data-wb-action="toggle-settings" aria-label="Cài đặt chung">
                                    <span class="wb-settings-glyph"></span>
                                </button>
                                <button type="button" class="wb-round-action" data-wb-action="toggle-panel"
                                    aria-label="Thu gọn">—</button>
                            </div>
                        </header>

                        <div class="wb-window-body">
                            <nav class="wb-side-nav">
                                ${VIEWS.map(view => `
                                    <button type="button" data-wb-action="set-view" data-view="${view.id}"
                                        aria-current="${activeView === view.id ? 'page' : 'false'}"
                                        class="${activeView === view.id ? 'is-active' : ''}">
                                        <i></i><span><small>${view.eyebrow}</small><strong>${view.label}</strong></span>
                                    </button>
                                `).join('')}
                                <button class="wb-side-sync wb-sim-action ${canCancelSimulation ? 'is-cancel' : manualSimulationQueued ? 'is-queued' : ''}"
                                    type="button" data-wb-action="${canCancelSimulation ? 'cancel-simulation' : 'manual-sync'}"
                                    ${manualSimulationQueued ? 'disabled' : ''}
                                    title="${canCancelSimulation
                                        ? 'Chỉ dừng suy diễn thế giới hiện tại, không ảnh hưởng các tác vụ nền khác'
                                        : manualSimulationQueued
                                            ? 'Đã xếp hàng; sẽ tự động bắt đầu sau khi tác vụ nền hiện tại kết thúc an toàn'
                                            : busy
                                                ? 'Đang có tác vụ nền chạy; bấm để xếp hàng an toàn, sẽ không ghi trạng thái thế giới song song'
                                                : 'Suy diễn chính văn mới nhất'}">
                                    <i aria-hidden="true"></i><span>${canCancelSimulation ? 'dừng suy diễn' : manualSimulationQueued ? 'Đã xếp hàng suy diễn' : 'Suy diễn thế giới'}</span>
                                </button>
                            </nav>

                            <div class="wb-content-column ${activeView === 'lingqi' ? 'is-lingqi-column' : ''} ${activeView === 'social' ? 'is-social-column' : ''}">
                                <div class="wb-view-header">
                                    <div><span>${currentView.eyebrow}</span><h2>${currentView.label}</h2></div>
                                    <div class="wb-view-header-tools">
                                        ${activeView === 'opinion' ? `
                                            <div class="wb-public-readonly-badge wb-public-mode-badge ${settings.publicOpinionRevealMode === 'relevant' ? 'is-relevant' : 'is-observe'}"
                                                aria-live="polite" title="Chế độ hé lộ dư luận hiện tại">
                                                <i></i>${settings.publicOpinionRevealMode === 'relevant' ? 'Hé lộ khi liên quan' : 'Chỉ quan sát'}
                                            </div>
                                        ` : activeView === 'lingqi' ? `
                                            <div class="wb-lingqi-header-badge" aria-label="玲七">₍^. .^₎⟆</div>
                                        ` : activeView === 'social' ? `
                                            <div class="wb-social-header-badge" aria-label="Liên lạc tích hợp">Lớp hội thoại độc lập</div>
                                        ` : `
                                            <div class="wb-observer-switch">
                                                <button type="button" data-wb-action="set-observer" data-mode="backstage"
                                                    aria-pressed="${observerMode === 'backstage'}"
                                                    class="${observerMode === 'backstage' ? 'is-active' : ''}">Góc nhìn hậu trường</button>
                                                <button type="button" data-wb-action="set-observer" data-mode="known"
                                                    aria-pressed="${observerMode === 'known'}"
                                                    class="${observerMode === 'known' ? 'is-active' : ''}">Nhân vật biết</button>
                                            </div>
                                        `}
                                        ${['now', 'people', 'currents', 'opinion', 'memory'].includes(activeView) ? `
                                            <button type="button"
                                                class="wb-view-settings-action ${moduleSettingsView === activeView ? 'is-active' : ''}"
                                                data-wb-action="toggle-module-settings" data-view="${activeView}"
                                                aria-label="${escapeAttr(currentView.label)} · Cài đặt" title="${escapeAttr(currentView.label)} · Cài đặt">
                                                <span class="wb-settings-glyph" aria-hidden="true"></span>
                                            </button>
                                        ` : ''}
                                    </div>
                                </div>
                                ${renderSyncStrip(syncStatus)}
                                <div class="wb-view-content ${activeView === 'lingqi' ? 'is-lingqi-view' : ''} ${activeView === 'social' ? 'is-social-view' : ''} ${viewChanged ? 'is-entering' : ''}">${content}</div>
                                <footer class="wb-window-footer">
                                    <div class="wb-footer-world-meta">
                                        <span>Thế giới chính ${escapeHtml(clockLabel)}</span><i></i>
                                        <span>AI trả lời: Đồng hồ thế giới kết toán thời gian thực tế</span><i></i>
                                        <span>Độc thoại: chỉ hậu trường thấy</span>
                                    </div>
                                    <div class="wb-footer-task-controls">
                                        <button class="wb-sim-action wb-footer-sim-mobile ${canCancelSimulation ? 'is-cancel' : manualSimulationQueued ? 'is-queued' : ''}"
                                            type="button" data-wb-action="${canCancelSimulation ? 'cancel-simulation' : 'manual-sync'}"
                                            ${manualSimulationQueued ? 'disabled' : ''}
                                            title="${canCancelSimulation
                                                ? 'Chỉ dừng suy diễn thế giới hiện tại, không ảnh hưởng các tác vụ nền khác'
                                                : manualSimulationQueued
                                                    ? 'Đã xếp hàng; sẽ tự động bắt đầu sau khi tác vụ nền hiện tại kết thúc an toàn'
                                                    : busy
                                                        ? 'Đang có tác vụ nền chạy; bấm để xếp hàng an toàn, sẽ không ghi trạng thái thế giới song song'
                                                        : 'Suy diễn chính văn mới nhất'}">
                                            <i aria-hidden="true"></i>
                                            <span>${canCancelSimulation ? 'dừng suy diễn' : manualSimulationQueued ? 'Đã xếp hàng suy diễn' : 'Suy diễn thế giới'}</span>
                                        </button>
                                        <button class="wb-sim-action wb-global-stop ${canCancelBackgroundTask ? 'is-cancel' : ''}" type="button"
                                            data-wb-action="cancel-background-tasks"
                                            ${canCancelBackgroundTask ? '' : 'disabled'}
                                            title="${canCancelBackgroundTask
                                                ? `Đang chạy: ${escapeAttr(activeBackgroundTasks.join('、'))}. Bấm để dừng toàn bộ tác vụ nền`
                                                : 'Hiện không có tác vụ nền nào đang chạy hoặc xếp hàng'}">
                                            <i aria-hidden="true"></i><span>Dừng toàn bộ tác vụ nền</span>
                                        </button>
                                    </div>
                                </footer>
                            </div>
                        </div>

                    </section>
                    ${settingsOpen ? `
                        <div class="wb-settings-layer">
                            ${renderSettings(
                                state,
                                settings,
                                syncStatus,
                                openSettingsGroups,
                                openSettingsSubgroups,
                                apiFormDraft,
                                visibleTagFilterRules(settings),
                                tagFilterCandidates,
                                {
                                    query: worldbookQuery,
                                    onlyPeople: worldbookOnlyPeople,
                                    onlyEnabled: worldbookOnlyEnabled,
                                    selectedIds: worldbookSelectedIds,
                                    draft: { skipped: worldbookDraftSkipped, droppedFields: worldbookDraftDroppedFields, pickedFields: worldbookDraftPickedFields, targets: worldbookDraftTargets },
                                },
                                tavernProfiles,
                                settingsSection,
                            )}
                        </div>
                    ` : ''}
                    ${moduleSettingsView ? `
                        <div class="wb-settings-layer wb-module-settings-layer">
                            ${renderModuleSettings(
                                state,
                                settings,
                                syncStatus,
                                moduleSettingsView,
                                openSettingsSubgroups,
                                {
                                    query: worldbookQuery,
                                    onlyPeople: worldbookOnlyPeople,
                                    onlyEnabled: worldbookOnlyEnabled,
                                    selectedIds: worldbookSelectedIds,
                                    draft: {
                                        skipped: worldbookDraftSkipped,
                                        droppedFields: worldbookDraftDroppedFields,
                                        pickedFields: worldbookDraftPickedFields, targets: worldbookDraftTargets,
                                    },
                                },
                            )}
                        </div>
                    ` : ''}
                </div>
            ` : ''}

            ${eventFormOpen ? renderEventModal(state, eventEditorId) : ''}
            ${memoryEditor ? renderMemoryEditorModal(state, memoryEditor) : ''}
            ${personEditor ? renderPersonEditorModal(state, personEditor) : ''}
            ${worldEditorOpen ? renderWorldEditorModal(state) : ''}
            ${recordEditor ? renderRecordEditorModal(state, recordEditor) : ''}
            ${person ? renderPersonDrawer(person, observerMode, state.clock.absoluteMinute, {
                canObserve: canObservePerson,
                observation: personObservation,
                busy,
            }) : ''}
            ${syncStatus.editDecision?.available ? `
                <div class="wb-edit-choice" role="alertdialog" aria-modal="false"
                    aria-labelledby="wb-edit-choice-title" aria-describedby="wb-edit-choice-detail">
                    <span class="wb-edit-choice-face" aria-hidden="true">${escapeHtml(TOAST_FACES.warning)}</span>
                    <div class="wb-edit-choice-copy">
                        <strong id="wb-edit-choice-title">Phát hiện chính văn đã suy diễn bị sửa</strong>
                        <p id="wb-edit-choice-detail">Khi cốt truyện, thời gian hoặc hành động nhân vật thay đổi thì nên suy diễn lại; nếu chỉ sửa lỗi chính tả, dấu câu hoặc câu chữ thì có thể giữ suy diễn cũ.</p>
                    </div>
                    <div class="wb-edit-choice-actions">
                        <button type="button" class="is-rerun" data-wb-action="resolve-message-edit" data-mode="rerun">Suy diễn lại theo chính văn đã sửa</button>
                        <button type="button" data-wb-action="resolve-message-edit" data-mode="keep">Giữ suy diễn cũ</button>
                    </div>
                </div>
            ` : ''}
            ${settings.enabled && socialNotice ? `
                <aside class="wb-social-notice" role="status" aria-live="polite">
                    <button class="wb-social-notice-main" type="button" data-wb-action="social-open-notice"
                        data-notice-id="${escapeAttr(socialNotice.id)}"
                        data-page="${escapeAttr(socialNoticePage)}"
                        data-conversation-id="${escapeAttr(socialNotice.conversationId || '')}">
                        ${socialNoticePerson ? renderPersonAvatar(socialNoticePerson, 'is-social') : '<span class="wb-social-notice-avatar">Tin</span>'}
                        <span><small>${escapeHtml(socialNoticeLabel)}${socialNotices.length > 1 ? ` · còn ${socialNotices.length - 1} mục` : ''}</small><strong>${escapeHtml(socialNoticePerson?.name || 'Liên lạc 世界背面')}</strong><em>${escapeHtml(socialNotice.text || 'Bấm để xem')}</em></span>
                    </button>
                    <button class="wb-social-notice-close" type="button" data-wb-action="social-dismiss-notice" data-notice-id="${escapeAttr(socialNotice.id)}" aria-label="Xem sau">×</button>
                </aside>
            ` : ''}
            ${toast ? `
                <div class="wb-toast" role="${root.dataset.toastTone === 'error' ? 'alert' : 'status'}" aria-live="polite">
                    <span aria-hidden="true">${escapeHtml(TOAST_FACES[root.dataset.toastTone] || TOAST_FACES.info)}</span>
                    <div><strong>${escapeHtml(TOAST_LABELS[root.dataset.toastTone] || TOAST_LABELS.info)}</strong><p>${escapeHtml(toast)}</p></div>
                </div>
            ` : ''}
            ${syncStatus.manualUndo?.available ? `
                <div class="wb-undo-toast" role="status">
                    <span>${escapeHtml(syncStatus.manualUndo.label)}</span>
                    <button type="button" data-wb-action="undo-manual">Hoàn tác</button>
                </div>
            ` : ''}
        `;
        panelEntrancePending = false;

        const currentContent = root.querySelector('.wb-view-content');
        if (currentContent) {
            // A module switch is a new reading context. Reusing another visit's
            // scroll offset made the first row look clipped beneath the status bar.
            currentContent.scrollTop = viewChanged ? 0 : (viewScrollTop.get(activeView) || 0);
        }
        const currentLingqiChat = root.querySelector('.wb-lingqi-chat-log');
        if (currentLingqiChat) {
            if (!lingqiChatScrollState.initialized || lingqiChatScrollState.atBottom) {
                currentLingqiChat.scrollTop = currentLingqiChat.scrollHeight;
            } else {
                currentLingqiChat.scrollTop = Math.min(
                    lingqiChatScrollState.top,
                    Math.max(0, currentLingqiChat.scrollHeight - currentLingqiChat.clientHeight),
                );
            }
            lingqiChatScrollState = {
                top: currentLingqiChat.scrollTop,
                atBottom: (
                    currentLingqiChat.scrollHeight
                    - currentLingqiChat.scrollTop
                    - currentLingqiChat.clientHeight
                ) <= 28,
                initialized: true,
            };
        }
        const currentLingqiNotes = root.querySelector('.wb-lingqi-notes-scroll');
        if (currentLingqiNotes) {
            currentLingqiNotes.scrollTop = Math.min(
                lingqiNotesScrollTop,
                Math.max(0, currentLingqiNotes.scrollHeight - currentLingqiNotes.clientHeight),
            );
        }
        const currentSettings = root.querySelector('.wb-settings-popover');
        if (currentSettings) currentSettings.scrollTop = settingsScrollTop;
        const currentWorldbookList = root.querySelector('.wb-worldbook-entry-list');
        if (currentWorldbookList) {
            currentWorldbookList.scrollTop = Math.min(
                worldbookListScrollTop,
                Math.max(0, currentWorldbookList.scrollHeight - currentWorldbookList.clientHeight),
            );
        }
        const currentSocialChat = root.querySelector('.wb-social-log');
        if (currentSocialChat) {
            if (!socialChatScrollState.initialized || socialChatScrollState.atBottom) {
                currentSocialChat.scrollTop = currentSocialChat.scrollHeight;
            } else {
                currentSocialChat.scrollTop = Math.min(
                    socialChatScrollState.top,
                    Math.max(0, currentSocialChat.scrollHeight - currentSocialChat.clientHeight),
                );
            }
            socialChatScrollState = {
                top: currentSocialChat.scrollTop,
                atBottom: (
                    currentSocialChat.scrollHeight
                    - currentSocialChat.scrollTop
                    - currentSocialChat.clientHeight
                ) <= 28,
                initialized: true,
            };
        }
        const currentEventForm = root.querySelector('[data-wb-form="event"]');
        if (currentEventForm && eventFormDraft) {
            for (const [name, value] of Object.entries(eventFormDraft)) {
                const field = currentEventForm.elements.namedItem(name);
                if (field && 'value' in field) field.value = value;
            }
        }
        const currentClockForm = root.querySelector('[data-wb-form="clock"]');
        if (currentClockForm && clockFormDraft) {
            for (const [name, value] of Object.entries(clockFormDraft)) {
                const field = currentClockForm.elements.namedItem(name);
                if (field && 'value' in field) field.value = value;
            }
        }
        if (previousFocus) {
            const selector = previousFocus.id
                ? `#${globalThis.CSS?.escape?.(previousFocus.id) || previousFocus.id}`
                : previousFocus.name
                    ? `[name="${globalThis.CSS?.escape?.(previousFocus.name) || previousFocus.name}"]`
                    : '';
            const field = selector ? root.querySelector(selector) : null;
            if (field) {
                field.focus({ preventScroll: true });
                if (
                    typeof field.setSelectionRange === 'function'
                    && Number.isInteger(previousFocus.selectionStart)
                ) {
                    field.setSelectionRange(previousFocus.selectionStart, previousFocus.selectionEnd);
                }
            }
        }
        renderedView = activeView;
        renderedRevision = stateRevision;
        if (isOpen) lastSeenRevision = Math.max(lastSeenRevision, stateRevision);
    }

    function positionOrbElements(x, y) {
        const placed = clampOrbPosition({ x, y });
        if (!placed) return null;
        const orb = root.querySelector('.wb-world-orb');
        const caption = root.querySelector('.wb-orb-caption');
        if (orb) {
            orb.style.left = `${placed.x}px`;
            orb.style.top = `${placed.y}px`;
            orb.style.right = 'auto';
            orb.style.bottom = 'auto';
        }
        if (caption) {
            const captionWidth = 238;
            const captionX = placed.x > captionWidth + 28
                ? placed.x - captionWidth - 10
                : placed.x + placed.size + 10;
            caption.style.left = `${Math.max(8, Math.min(window.innerWidth - captionWidth - 8, captionX))}px`;
            caption.style.top = `${placed.y + 5}px`;
            caption.style.right = 'auto';
            caption.style.bottom = 'auto';
        }
        return placed;
    }

    function positionOrbFromSettings(settings = getSettings()) {
        const position = settings?.orbPosition;
        if (!position) return null;
        if (settings.orbEdgeHide && !isOpen) {
            const orb = root.querySelector('.wb-world-orb');
            if (!orb) return null;
            const placed = halfDockOrbPosition(position, nearestOrbEdgeSide(position));
            orb.style.left = `${placed.x}px`;
            orb.style.top = `${placed.y}px`;
            orb.style.right = 'auto';
            orb.style.bottom = 'auto';
            return placed;
        }
        return positionOrbElements(position.x, position.y);
    }

    root.addEventListener('pointerdown', event => {
        const orb = event.target.closest('.wb-world-orb');
        if (!orb || event.button !== 0) return;
        if (orb.classList.contains('is-edge-hidden')) {
            const side = orb.classList.contains('is-edge-left') ? 'left' : 'right';
            orb.classList.remove('is-edge-hidden', 'is-edge-left', 'is-edge-right');
            const saved = getSettings().orbPosition;
            const visible = saved || defaultVisibleOrbPosition(side);
            positionOrbElements(visible.x, visible.y);
        }
        const rect = orb.getBoundingClientRect();
        orb.style.setProperty('left', `${rect.left}px`, 'important');
        orb.style.setProperty('top', `${rect.top}px`, 'important');
        orb.style.setProperty('right', 'auto', 'important');
        orb.style.setProperty('bottom', 'auto', 'important');
        orb.classList.add('has-custom-position');
        orbDrag = {
            pointerId: event.pointerId,
            startX: event.clientX,
            startY: event.clientY,
            originX: rect.left,
            originY: rect.top,
            moved: false,
            x: rect.left,
            y: rect.top,
        };
        orb.setPointerCapture?.(event.pointerId);
        orb.classList.add('is-dragging');
    });

    root.addEventListener('pointermove', event => {
        if (!orbDrag || event.pointerId !== orbDrag.pointerId) return;
        const deltaX = event.clientX - orbDrag.startX;
        const deltaY = event.clientY - orbDrag.startY;
        if (Math.hypot(deltaX, deltaY) > 5) orbDrag.moved = true;
        if (!orbDrag.moved) return;
        const placed = positionOrbElements(orbDrag.originX + deltaX, orbDrag.originY + deltaY);
        if (placed) {
            orbDrag.x = placed.x;
            orbDrag.y = placed.y;
        }
        event.preventDefault();
    });

    const finishOrbDrag = async event => {
        if (!orbDrag || event.pointerId !== orbDrag.pointerId) return;
        const orb = root.querySelector('.wb-world-orb');
        orb?.classList.remove('is-dragging');
        orb?.releasePointerCapture?.(event.pointerId);
        const completed = orbDrag;
        orbDrag = null;
        if (!completed.moved) return;

        const viewport = visualViewportBounds();
        const orbSize = responsiveOrbSize(viewport.width, viewport.height);
        const margin = 12;
        const snappedX = completed.x + orbSize / 2 < viewport.left + viewport.width / 2
            ? viewport.left + margin
            : viewport.right - orbSize - margin;
        const placed = positionOrbElements(snappedX, completed.y);
        suppressOrbClick = true;
        window.setTimeout(() => {
            suppressOrbClick = false;
        }, 260);
        if (placed) {
            await invokeAction('update-settings', {
                orbPosition: { x: placed.x, y: placed.y },
            });
        }
    };
    root.addEventListener('pointerup', finishOrbDrag);
    root.addEventListener('pointercancel', finishOrbDrag);

    root.addEventListener('click', async event => {
        const target = event.target.closest('[data-wb-action]');
        if (!target) return;
        if (
            target.classList.contains('wb-drawer-scrim')
            && event.target.closest('.wb-event-form, .wb-person-drawer')
        ) {
            return;
        }
        const action = target.dataset.wbAction;

        if (action === 'close-panel') {
            if (event.target === target) close();
            return;
        }
        if (action === 'toggle-panel') {
            if (target.classList.contains('wb-world-orb') && suppressOrbClick) {
                suppressOrbClick = false;
                event.preventDefault();
                return;
            }
            isOpen ? close() : open();
            return;
        }
        if (action === 'dismiss-narrative-prompt') {
            dismissedNarrativePromptKey = String(target.dataset.promptKey || '');
            render();
            return;
        }
        if (action === 'set-view') {
            const nextView = target.dataset.view || 'now';
            if (activeView === 'memory' && nextView !== 'memory') memorySelectedKeys = new Set();
            if (nextView !== 'lingqi') {
                lingqiMascotOverride = '';
                window.clearTimeout(lingqiMascotTimer);
            }
            activeView = nextView;
            moduleSettingsView = '';
            render();
            return;
        }
        if (action === 'lingqi-pet') {
            const now = Date.now();
            if (now - lingqiPetWindowAt < 1800) lingqiPetCount += 1;
            else lingqiPetCount = 1;
            lingqiPetWindowAt = now;

            const nextState = lingqiPetCount >= 4
                ? 'hold'
                : lingqiPetCount === 3
                    ? 'happy'
                    : 'watch';
            showLingqiMascotReaction(nextState, nextState === 'hold' ? 1550 : 1050);
            if (lingqiPetCount >= 4) lingqiPetCount = 0;
            return;
        }

        if (action === 'lingqi-copy-support-pack') {
            const copied = await invokeAction('lingqi-copy-support-pack', {
                messageId: target.dataset.messageId || '',
            });
            if (copied) showLingqiMascotReaction('watch', 900);
            return;
        }

        if (action === 'lingqi-confirm-note') {
            const completed = await invokeAction('lingqi-confirm-note');
            if (completed) {
                notify('ฅ  Dính rồi', 'success');
                showLingqiMascotReaction('happy', 1250);
            } else {
                render();
            }
            return;
        }
        if (action === 'lingqi-dismiss-note') {
            await invokeAction('lingqi-dismiss-note');
            showLingqiMascotReaction('hold', 900);
            return;
        }
        if (action === 'lingqi-pause-note') {
            await invokeAction('lingqi-pause-note', { noteId: target.dataset.noteId || '' });
            showLingqiMascotReaction('hold', 1000);
            return;
        }
        if (action === 'lingqi-resume-note') {
            await invokeAction('lingqi-resume-note', { noteId: target.dataset.noteId || '' });
            showLingqiMascotReaction('note', 900);
            return;
        }
        if (action === 'lingqi-cancel-note') {
            await invokeAction('lingqi-cancel-note', { noteId: target.dataset.noteId || '' });
            showLingqiMascotReaction('hold', 900);
            return;
        }

        if (action === 'open-world-editor') {
            worldEditorOpen = true;
            render();
            return;
        }
        if (action === 'close-world-editor') {
            worldEditorOpen = false;
            render();
            return;
        }
        if (action === 'open-record-editor') {
            recordEditor = {
                kind: target.dataset.recordKind === 'archive' ? 'archive' : 'echo',
                id: target.dataset.recordId || '',
            };
            render();
            return;
        }
        if (action === 'close-record-editor') {
            recordEditor = null;
            render();
            return;
        }
        if (action === 'delete-record') {
            const kind = target.dataset.recordKind === 'archive' ? 'archive' : 'echo';
            const confirmed = globalThis.confirm?.(`(・_・;)  Chắc chắn xóa mục ${kind === 'echo' ? 'Tiếng vọng' : 'Biên niên'} này không? Sau khi xóa vẫn có thể khôi phục bằng nút Hoàn tác ở dưới cùng.`);
            if (confirmed === false) return;
            const completed = await invokeAction('delete-record', {
                kind,
                id: target.dataset.recordId || '',
            });
            if (completed && recordEditor?.id === (target.dataset.recordId || '')) recordEditor = null;
            render();
            return;
        }
        if (action === 'expand-folds' || action === 'collapse-folds') {
            const prefix = target.dataset.foldPrefix || '';
            const shouldOpen = action === 'expand-folds';
            [...root.querySelectorAll('.wb-fold[data-fold-key]')]
                .filter(item => !prefix || String(item.dataset.foldKey || '').startsWith(prefix))
                .forEach(item => {
                    item.open = shouldOpen;
                    const key = item.dataset.foldKey;
                    if (!key) return;
                    if (shouldOpen) openContentFolds.add(key);
                    else openContentFolds.delete(key);
                });
            return;
        }
        if (action === 'set-memory-filter') {
            memoryFilter = target.dataset.filter || 'active';
            memoryVisibleCount = 12;
            memorySelectedKeys = new Set();
            render();
            return;
        }
        if (action === 'open-memory-editor') {
            memoryEditor = {
                kind: target.dataset.memoryKind || 'fact',
                id: target.dataset.memoryId || '',
            };
            render();
            return;
        }
        if (action === 'close-memory-editor') {
            memoryEditor = null;
            render();
            return;
        }
        if (action === 'set-clue-archive-state') {
            const archived = target.dataset.archived === 'true';
            const completed = await invokeAction('set-clue-archive-state', {
                id: target.dataset.clueId || '',
                archived,
            });
            if (completed !== false && archived && memoryFilter === 'resolved-clues') {
                memorySelectedKeys = new Set();
            }
            render();
            return;
        }
        if (action === 'toggle-memory-flag') {
            await invokeAction('toggle-memory-flag', {
                kind: target.dataset.memoryKind || 'fact',
                id: target.dataset.memoryId || '',
                field: target.dataset.memoryField || 'important',
            });
            render();
            return;
        }
        if (action === 'select-visible-memory') {
            let items = [];
            try {
                items = JSON.parse(target.dataset.memoryItems || '[]');
            } catch {
                items = [];
            }
            memorySelectedKeys = new Set(
                items.map(item => `${item.kind}:${item.id}`),
            );
            render();
            return;
        }
        if (action === 'clear-memory-selection') {
            memorySelectedKeys = new Set();
            render();
            return;
        }
        if (action === 'bulk-delete-memory') {
            const items = [...memorySelectedKeys].map(key => {
                const separator = key.indexOf(':');
                return {
                    kind: separator >= 0 ? key.slice(0, separator) : 'fact',
                    id: separator >= 0 ? key.slice(separator + 1) : key,
                };
            });
            if (!items.length) return;
            const confirmed = globalThis.confirm?.(
                `(・_・;)  Chắc chắn xóa ${items.length} ký ức đã chọn không?\nTrước khi xóa sẽ tự động tạo điểm khôi phục, ký ức đã khóa sẽ không bị xóa.`,
            );
            if (confirmed === false) return;
            const completed = await invokeAction('bulk-delete-memory', { items });
            if (completed !== false) memorySelectedKeys = new Set();
            render();
            return;
        }
        if (action === 'clear-filtered-memory') {
            const state = getState();
            const memory = state.storyMemory || { facts: [], clues: [], summaries: [] };
            const normalizedFilter = ['active', 'facts', 'clues', 'resolved-clues', 'archived-clues', 'episodes', 'all'].includes(memoryFilter)
                ? memoryFilter
                : 'active';
            const visibleFact = fact => (
                (observerMode === 'backstage' || fact.visibility !== 'hidden')
                && !fact.locked
                && memoryItemMatches(fact, memoryQuery)
                && (
                    normalizedFilter === 'all'
                    || normalizedFilter === 'facts'
                    || (normalizedFilter === 'active' && ['active', 'disputed'].includes(fact.status))
                )
            );
            const visibleClue = clue => (
                (observerMode === 'backstage' || clue.visibility !== 'hidden')
                && !clue.locked
                && memoryItemMatches(clue, memoryQuery)
                && memoryClueRelationMatches(clue, memoryClueRelationFilter, state)
                && (
                    normalizedFilter === 'all'
                    || (normalizedFilter === 'clues' && !clue.archived)
                    || (normalizedFilter === 'resolved-clues' && !clue.archived && ['resolved', 'discarded'].includes(clue.status))
                    || (normalizedFilter === 'archived-clues' && clue.archived)
                    || (
                        normalizedFilter === 'active'
                        && !clue.archived
                        && ['open', 'developing', 'echoed', 'triggered'].includes(clue.status)
                    )
                )
            );
            const visibleSummary = summary => (
                observerMode === 'backstage'
                && !summary.locked
                && memoryItemMatches(summary, memoryQuery)
                && ['all', 'episodes'].includes(normalizedFilter)
            );
            const items = [
                ...(memory.facts || []).filter(visibleFact).map(item => ({ kind: 'fact', id: item.id })),
                ...(memory.clues || []).filter(visibleClue).map(item => ({ kind: 'clue', id: item.id })),
                ...(memory.summaries || []).filter(visibleSummary).map(item => ({ kind: 'summary', id: item.id })),
            ];
            if (!items.length) {
                notify('Bộ lọc này không có ký ức chưa khóa nào để xóa～', 'info');
                return;
            }
            const confirmed = globalThis.confirm?.(
                `(・_・;)  Sẽ dọn ${items.length} ký ức chưa khóa trong phạm vi hiện tại.\nKý ức đã khóa sẽ được giữ lại, trước khi dọn sẽ tự động tạo điểm khôi phục.`,
            );
            if (confirmed === false) return;
            const completed = await invokeAction('bulk-delete-memory', { items });
            if (completed !== false) memorySelectedKeys = new Set();
            render();
            return;
        }

        if (action === 'delete-memory-item') {
            const confirmed = globalThis.confirm?.('(・_・;)  Chắc chắn xóa ký ức này không? Thao tác này có thể khôi phục bằng nút Hoàn tác ở dưới cùng.');
            if (confirmed === false) return;
            await invokeAction('delete-memory-item', {
                kind: target.dataset.memoryKind || 'fact',
                id: target.dataset.memoryId || '',
            });
            render();
            return;
        }
        if (action === 'load-more-memory') {
            memoryVisibleCount += 12;
            render();
            return;
        }
        if (action === 'toggle-settings') {
            const opening = !settingsOpen;
            settingsOpen = opening;
            if (opening) {
                moduleSettingsView = '';
                if (!['common', 'injection', 'connection', 'advanced'].includes(settingsSection)) {
                    settingsSection = 'common';
                }
                openSettingsGroups = new Set();
                openSettingsSubgroups = new Set();
                settingsScrollTop = 0;
            } else {
                clockFormDraft = null;
                tagFilterDraftRules = null;
                tagFilterCandidates = [];
            }
            render();
            return;
        }
        if (action === 'settings-section') {
            const requested = String(target.dataset.section || 'common');
            settingsSection = ['common', 'injection', 'connection', 'advanced'].includes(requested)
                ? requested
                : 'common';
            settingsScrollTop = 0;
            render();
            return;
        }
        if (action === 'open-global-settings-section') {
            const requested = String(target.dataset.section || 'common');
            settingsSection = ['common', 'injection', 'connection', 'advanced'].includes(requested)
                ? requested
                : 'common';
            moduleSettingsView = '';
            settingsOpen = true;
            openSettingsGroups = new Set();
            openSettingsSubgroups = new Set();
            settingsScrollTop = 0;
            render();
            return;
        }
        if (action === 'toggle-module-settings') {
            const requestedView = target.dataset.view || moduleSettingsView || activeView;
            const opening = moduleSettingsView !== requestedView;
            moduleSettingsView = opening ? requestedView : '';
            if (opening) {
                settingsOpen = false;
                settingsScrollTop = 0;
                // 板块设置已经是扁平结构～不再为了旧总设置层级预展开一堆套娃。
                openSettingsGroups = new Set();
                openSettingsSubgroups = new Set();
            } else {
                clockFormDraft = null;
            }
            render();
            return;
        }
        if (action === 'add-tag-filter-rule') {
            const settings = getSettings();
            const current = visibleTagFilterRules(settings);
            tagFilterDraftRules = [...current, { open: '', close: '' }];
            skipTagFilterDraftCapture = true;
            render();
            return;
        }
        if (action === 'remove-tag-filter-rule') {
            const index = Number(target.dataset.index);
            const settings = getSettings();
            const current = visibleTagFilterRules(settings).filter((_, i) => i !== index);
            skipTagFilterDraftCapture = true;
            await persistTagFilterRules(current);
            render();
            return;
        }
        if (action === 'scan-tag-candidates') {
            const result = await invokeAction('scan-tag-candidates', {
                count: Number(target.dataset.count) || 1,
            });
            tagFilterCandidates = Array.isArray(result) ? result : [];
            openSettingsGroups.add('advanced');
            openSettingsSubgroups.add('advanced-tagfilter');
            render();
            return;
        }
        if (action === 'apply-tag-candidates') {
            const settings = getSettings();
            const current = visibleTagFilterRules(settings).map(rule => ({ ...rule }));
            const selected = [...root.querySelectorAll('[data-wb-tag-candidate-index]:checked')]
                .map(input => tagFilterCandidates[Number(input.dataset.wbTagCandidateIndex)])
                .filter(Boolean)
                .filter(item => !item.alreadyAdded);
            const seen = new Set(current.map(rule => `${String(rule.open || '').trim()}\u0000${String(rule.close || '').trim()}`));
            let added = 0;
            for (const item of selected) {
                const key = `${item.open}\u0000${item.close}`;
                if (seen.has(key) || current.length >= 30) continue;
                current.push({ open: item.open, close: item.close });
                seen.add(key);
                added += 1;
            }
            await persistTagFilterRules(current);
            tagFilterCandidates = tagFilterCandidates.map(item => ({
                ...item,
                alreadyAdded: item.alreadyAdded || seen.has(`${item.open}\u0000${item.close}`),
                recommended: false,
            }));
            notify(added ? `Đã thêm ${added} quy tắc lọc.` : 'Không có ứng viên mới nào cần thêm vào.', added ? 'success' : 'info');
            render();
            return;
        }
        if (action === 'set-public-opinion-mode') {
            publicOpinionMode = ['forum', 'sandbox'].includes(target.dataset.mode) ? target.dataset.mode : 'news';
            render();
            return;
        }
        if (action === 'generate-public-opinion') {
            if (publicOpinionActionBusy) return;
            publicOpinionActionBusy = true;
            render();
            try {
                const result = await invokeAction('generate-public-opinion');
                if (result) {
                    notify('Kiểm tra dư luận thế giới hoàn tất～', 'success');
                }
            } finally {
                publicOpinionActionBusy = false;
                render();
            }
            return;
        }
        if (action === 'generate-public-opinion-sandbox') {
            if (publicOpinionSandboxActionBusy) return;
            publicOpinionSandboxActionBusy = true;
            render();
            try {
                const result = await invokeAction('generate-public-opinion-sandbox');
                if (result) {
                    publicOpinionMode = 'sandbox';
                    notify('Dạo bừa mà hóng được một nồi drama mới toanh～ Yên tâm, mấy cái này không tính là chính sử `(≧▽≦)`', 'success');
                }
            } finally {
                publicOpinionSandboxActionBusy = false;
                render();
            }
            return;
        }
        if (action === 'clear-public-opinion-sandbox') {
            await invokeAction('clear-public-opinion-sandbox');
            render();
            return;
        }
        if (action === 'clear-public-opinion') {
            const confirmed = globalThis.confirm?.('(・_・;)  Xóa sạch ảnh chụp dư luận hiện tại không? Trạng thái thế giới sẽ không bị ảnh hưởng.');
            if (confirmed === false) return;
            await invokeAction('clear-public-opinion');
            render();
            return;
        }
        if (action === 'dismiss-public-opinion-item') {
            await invokeAction('dismiss-public-opinion-item', {
                kind: target.dataset.opinionKind === 'forum' ? 'forum' : 'news',
                itemId: target.dataset.itemId || '',
            });
            render();
            return;
        }
        if (action === 'set-observer') {
            observerMode = target.dataset.mode === 'known' ? 'known' : 'backstage';
            selectedPersonId = null;
            render();
            return;
        }
        if (action === 'select-person') {
            if (selectedPersonId !== (target.dataset.personId || null)) {
                personObservation = null;
            }
            selectedPersonId = target.dataset.personId || null;
            if (selectedPersonId) {
                personObservation = await invokeAction('get-person-observation', {
                    personId: selectedPersonId,
                }) || null;
            }
            render();
            return;
        }
        if (action === 'close-person') {
            selectedPersonId = null;
            personObservation = null;
            render();
            return;
        }
        if (action === 'open-person-editor') {
            personEditor = { id: target.dataset.personId || '', name: target.dataset.personName || '' };
            selectedPersonId = null;
            personObservation = null;
            render();
            return;
        }
        if (action === 'social-toggle-group') {
            socialGroupOpen = !socialGroupOpen;
            if (!socialGroupOpen) socialGroupSelectedIds = new Set();
            render();
            return;
        }
        if (action === 'social-open-notice') {
            const page = String(target.dataset.page || 'contacts');
            const conversationId = String(target.dataset.conversationId || '');
            socialNoticeVisibleId = '';
            window.clearTimeout(socialNoticeTimer);
            socialNoticeTimer = null;
            target.closest('.wb-social-notice')?.remove();
            await invokeAction('social-read-notice', { noticeId: target.dataset.noticeId || '' });
            if (conversationId) {
                await invokeAction('social-select-conversation', { conversationId });
            }
            activeView = 'social';
            socialPage = ['messages', 'contacts', 'moments'].includes(page) ? page : 'contacts';
            socialChatScrollState = { top: 0, atBottom: true, initialized: false };
            open();
            return;
        }
        if (action === 'social-dismiss-notice') {
            socialNoticeVisibleId = '';
            window.clearTimeout(socialNoticeTimer);
            socialNoticeTimer = null;
            target.closest('.wb-social-notice')?.remove();
            await invokeAction('social-read-notice', { noticeId: target.dataset.noticeId || '' });
            render();
            return;
        }
        if (action === 'social-set-page') {
            const nextPage = String(target.dataset.page || 'messages');
            socialPage = ['messages', 'contacts', 'moments'].includes(nextPage) ? nextPage : 'messages';
            socialGroupOpen = false;
            render();
            return;
        }
        if (action === 'social-go-people') {
            activeView = 'people';
            moduleSettingsView = '';
            render();
            return;
        }
        if (action === 'social-import-people') {
            activeView = 'people';
            settingsOpen = false;
            moduleSettingsView = 'people';
            openSettingsSubgroups = new Set(['people-worldbook']);
            settingsScrollTop = 0;
            render();
            return;
        }
        if (action === 'social-open-person') {
            const completed = await invokeAction('social-open-person', {
                personId: target.dataset.personId || '',
            });
            if (completed) {
                activeView = 'social';
                socialPage = 'messages';
                selectedPersonId = null;
                socialDraft = '';
                socialChatScrollState = { top: 0, atBottom: true, initialized: false };
            }
            render();
            return;
        }
        if (action === 'social-respond-friend-request') {
            const accept = target.dataset.accept === 'true';
            if (!accept) {
                const confirmed = globalThis.confirm?.('(・_・;)  Từ chối lời mời kết bạn này không? Đối phương sẽ giữ phản ứng của mình, nhưng sẽ không vào danh bạ.');
                if (confirmed === false) return;
            }
            const result = await invokeAction('social-respond-friend-request', {
                personId: target.dataset.personId || '',
                accept,
            });
            if (result) notify(accept ? `Đã chấp nhận lời mời kết bạn của ${result.personName}.` : `Đã từ chối lời mời kết bạn của ${result.personName}.`, accept ? 'success' : 'info');
            render();
            return;
        }
        if (action === 'social-remove-friend') {
            const personName = String(target.dataset.personName || 'người bạn này');
            const confirmed = globalThis.confirm?.(
                `(・_・;)  Chắc chắn xóa ${personName}?\nLịch sử chat riêng sẽ được giữ lại nhưng không thể gửi tiếp; các nhóm chat chung sẽ không tự động rời. Sau này vẫn có thể gửi lại lời mời kết bạn.`,
            );
            if (confirmed === false) return;
            const result = await invokeAction('social-remove-friend', { personId: target.dataset.personId || '' });
            if (result) notify(`Đã xóa khỏi danh bạ: ${result.personName}。`, 'info');
            render();
            return;
        }
        if (action === 'social-refresh-moments') {
            const result = await invokeAction('social-refresh-moments');
            if (result && typeof result === 'object') {
                notify(result.postCount
                    ? `Khoảnh khắc có thêm ${result.postCount} bài đăng${result.imageCount ? ', có 1 ảnh minh họa' : ''}。`
                    : 'Lần này không có người bạn nào muốn đăng bài.', result.postCount ? 'success' : 'info');
            }
            render();
            return;
        }
        if (action === 'social-toggle-moment-like') {
            await invokeAction('social-toggle-moment-like', { momentId: target.dataset.momentId || '' });
            render();
            return;
        }
        if (action === 'social-request-reply') {
            const conversationId = String(target.dataset.conversationId || '');
            if (!conversationId) return;
            await invokeAction('social-request-reply', { conversationId });
            render();
            return;
        }
        if (action === 'social-select-conversation') {
            await invokeAction('social-select-conversation', {
                conversationId: target.dataset.conversationId || '',
            });
            socialDraft = '';
            socialChatScrollState = { top: 0, atBottom: true, initialized: false };
            render();
            return;
        }
        if (action === 'toggle-people-batch') {
            peopleSelectionMode = !peopleSelectionMode;
            peopleSelectedIds = new Set();
            render();
            return;
        }
        if (action === 'select-all-people') {
            peopleSelectedIds = new Set(
                [...root.querySelectorAll('[data-wb-person-select]:not(:disabled)')]
                    .map(input => String(input.value || ''))
                    .filter(Boolean),
            );
            render();
            return;
        }
        if (action === 'clear-people-selection') {
            peopleSelectedIds = new Set();
            render();
            return;
        }
        if (action === 'delete-selected-people') {
            const ids = [...peopleSelectedIds];
            const selected = getState().people.filter(person => ids.includes(person.id));
            if (!selected.length) return;
            const preview = selected.slice(0, 10).map(person => `• ${person.name}`).join('\n');
            const remainder = selected.length > 10 ? `\n……và còn ${selected.length - 10} người` : '';
            const confirmed = globalThis.confirm?.(
                `(・_・;)  Chắc chắn xóa hàng loạt ${selected.length} nhân vật này?\n\n${preview}${remainder}\n\nSẽ đồng thời xóa bộ nhớ đệm quan sát tức thời của các nhân vật này; không xóa chính văn trò chuyện hay ký ức thế giới chính thức. Sau khi xóa vẫn có thể khôi phục bằng nút “Hoàn tác” ở dưới cùng.`,
            );
            if (confirmed === false) return;
            const completed = await invokeAction('delete-manual-people', { ids });
            if (completed) {
                peopleSelectedIds = new Set();
                peopleSelectionMode = false;
            }
            render();
            return;
        }
        if (action === 'close-person-editor') {
            personEditor = null;
            render();
            return;
        }
        if (action === 'clear-person-avatar') {
            const completed = await invokeAction('clear-person-avatar', {
                id: target.dataset.personId || '',
            });
            if (completed) notify('Avatar đã cất đi rồi～ lại trở về avatar chữ (｡•̀ᴗ-)✧', 'success');
            render();
            return;
        }
        if (action === 'delete-manual-person') {
            const confirmed = globalThis.confirm?.('(・_・;)  Chắc chắn xóa NPC này khỏi danh sách nhân vật nền không?');
            if (confirmed === false) return;
            const completed = await invokeAction('delete-manual-person', {
                id: target.dataset.personId || '',
            });
            if (completed) personEditor = null;
            render();
            return;
        }
        if (action === 'open-event-form') {
            eventEditorId = '';
            eventFormDraft = null;
            eventFormOpen = true;
            render();
            return;
        }
        if (action === 'open-terminal-person') {
            const completed = await invokeAction('social-open-person', {
                personId: target.dataset.personId || '',
            });
            if (completed) {
                activeView = 'social';
                selectedPersonId = null;
                socialDraft = '';
                socialChatScrollState = { top: 0, atBottom: true, initialized: false };
                render();
            }
            return;
        }
        if (action === 'open-terminal-event') {
            globalThis.worldTerminalHost?.openEventDiscussion?.(target.dataset.eventId || '');
            return;
        }
        if (action === 'open-event-editor') {
            eventEditorId = target.dataset.eventId || '';
            eventFormDraft = null;
            eventFormOpen = Boolean(eventEditorId);
            render();
            return;
        }
        if (action === 'delete-event') {
            const eventId = target.dataset.eventId || '';
            const confirmed = globalThis.confirm?.('(・_・;)  Chắc chắn xóa Mạch ngầm này không? Sau khi xóa vẫn có thể khôi phục bằng nút Hoàn tác ở dưới cùng.');
            if (confirmed === false) return;
            const completed = await invokeAction('delete-event', { eventId });
            if (completed && eventEditorId === eventId) {
                eventEditorId = '';
                eventFormOpen = false;
                eventFormDraft = null;
            }
            render();
            return;
        }
        if (action === 'close-event-form') {
            eventEditorId = '';
            eventFormDraft = null;
            eventFormOpen = false;
            render();
            return;
        }
        if (action === 'setting-button') {
            const setting = target.dataset.setting;
            const value = target.dataset.value;
            await invokeAction('update-settings', {
                [setting]: value,
            });
            render();
            // 选择“独立接口”后立即展开填写区，恢复一键进入配置的填写体验。
            // 用户之后仍可手动收起；普通重渲染不会强制再次展开。
            if (setting === 'apiMode' && value === 'tavern-profile') {
                settingsSection = 'connection';
                openSettingsGroups.add('connection');
                render();
                window.setTimeout(() => {
                    root.querySelector('[data-wb-tavern-profile-select]')?.focus();
                }, 0);
            }
            if (setting === 'apiMode' && value === 'custom') {
                settingsSection = 'connection';
                window.setTimeout(() => {
                    const connectionGroup = root.querySelector('.wb-settings-group[data-settings-group="connection"]');
                    const customGroup = root.querySelector('.wb-settings-subgroup[data-settings-subgroup="connection-custom"]');
                    if (connectionGroup) connectionGroup.open = true;
                    if (customGroup) customGroup.open = true;
                    openSettingsGroups.add('connection');
                    openSettingsSubgroups.add('connection-custom');
                    const form = root.querySelector('[data-wb-form="api"]');
                    if (!form) return;
                    const url = form.elements?.customApiUrl;
                    const key = form.elements?.customApiCredential;
                    const model = form.elements?.customApiModel;
                    if (!String(url?.value || '').trim()) url?.focus();
                    else if (!getSettings().customApiKey && !String(key?.value || '').trim()) key?.focus();
                    else if (!String(model?.value || '').trim()) model?.focus();
                }, 0);
            }
            return;
        }
        if (action === 'cycle-theme') {
            const settings = getSettings();
            const state = getState();
            // 顶栏快捷键只做“日间 ↔ 夜间”直切；自动模式仍可在设置页选择。
            // 旧逻辑会经过 auto，若 auto 恰好解析成当前主题，视觉上像按钮失灵。
            const currentTheme = themeFor(state, settings);
            const next = currentTheme === 'day' ? 'night' : 'day';
            await invokeAction('update-settings', { theme: next });
            render();
            return;
        }
        if (action === 'sync-clock-from-story') {
            clockFormDraft = null;
            await invokeAction('sync-clock-from-story');
            render();
            return;
        }
        if (action === 'advance-clock') {
            clockFormDraft = null;
            await invokeAction('advance-clock', { minutes: Number(target.dataset.minutes) || 0 });
            render();
            return;
        }
        if (action === 'smart-import-worldbook-people') {
            const form = target.closest('[data-wb-form="worldbook"]');
            worldbookSelectedIds = new Set();
            worldbookListScrollTop = 0;
            const result = await invokeAction('smart-import-worldbook-people', {
                bookName: form?.elements?.bookName?.value || '',
            });
            if (result && typeof result === 'object') {
                const imported = Number(result.created || 0) + Number(result.updated || 0);
                if (result.needsReview) {
                    worldbookOnlyPeople = true;
                    notify(`Nhập tự động chưa dám ra tay bừa～ Còn ${Number(result.reviewCount) || 0} ứng viên nhân vật cần bạn xác nhận.`, 'info');
                } else {
                    const tail = Number(result.reviewCount) > 0
                        ? `, còn ${result.reviewCount} ứng viên chưa chắc chắn được để lại bên dưới`
                        : '';
                    notify(`Nhập nhân vật từ World Info hoàn tất: đã xử lý ${imported} người${tail}。`, 'success');
                    worldbookOnlyPeople = Number(result.reviewCount) > 0;
                }
            }
            render();
            return;
        }
        if (action === 'scan-worldbook') {
            const form = target.closest('[data-wb-form="worldbook"]');
            worldbookSelectedIds = new Set();
            worldbookListScrollTop = 0;
            const result = await invokeAction('scan-worldbook', {
                bookName: form?.elements?.bookName?.value || '',
            });
            // 高级手动挑选必须先展示完整条目。旧逻辑自动切到“只看疑似人物”，
            // 一旦识别漏人，用户连漏掉的条目都看不到，更不可能手动纠正。
            if (result && Array.isArray(result.entries)) worldbookOnlyPeople = false;
            render();
            return;
        }
        if (action === 'commit-worldbook-drafts') {
            const people = getSyncStatus()?.worldbook?.aiImport?.people || [];
            const selections = people
                .filter(person => !worldbookDraftSkipped.has(person.reference))
                .map(person => {
                    const lowFields = new Set((person.review || []).map(item => item.field));
                    return {
                        reference: person.reference,
                        target: worldbookDraftTargets.get(person.reference) || '',
                        // 与审校台的勾选状态保持一致：命中率偏低的栏位默认不写入，
                        // 必须用户主动勾上。
                        fields: Object.keys(person.values || {}).filter(field => {
                            const key = `${person.reference}::${field}`;
                            if (worldbookDraftDroppedFields.has(key)) return false;
                            return !lowFields.has(field) || worldbookDraftPickedFields.has(key);
                        }),
                    };
                })
                .filter(item => item.fields.length);
            const report = getSyncStatus()?.worldbook?.aiImport || {};
            const done = await invokeAction('commit-worldbook-drafts', {
                selections,
                token: report.token || '',
                bookName: report.bookName || '',
            });
            if (done) {
                worldbookSelectedIds = new Set();
                worldbookDraftSkipped = new Set();
                worldbookDraftDroppedFields = new Set();
                worldbookDraftPickedFields = new Set();
            }
            render();
            return;
        }
        if (action === 'discard-worldbook-drafts') {
            await invokeAction('discard-worldbook-drafts', {});
            render();
            return;
        }
        if (action === 'ai-import-worldbook') {
            const form = target.closest('[data-wb-form="worldbook"]');
            // 整理完只是产出待确认草稿，勾选要留到写入之后再清。
            await invokeAction('ai-import-worldbook-people', {
                bookName: form?.elements?.bookName?.value || '',
                entryIds: [...worldbookSelectedIds],
            });
            render();
            return;
        }
        if (action === 'select-worldbook-visible' || action === 'clear-worldbook-visible') {
            const entries = Array.isArray(getSyncStatus()?.worldbook?.entries)
                ? getSyncStatus().worldbook.entries
                : [];
            const visible = filterWorldbookEntries(entries, {
                query: worldbookQuery,
                onlyPeople: worldbookOnlyPeople,
                onlyEnabled: worldbookOnlyEnabled,
            });
            const next = new Set(worldbookSelectedIds);
            for (const entry of visible) {
                if (action === 'select-worldbook-visible') {
                    if (entry.importablePerson ?? entry.likelyPerson) next.add(String(entry.uid));
                } else {
                    next.delete(String(entry.uid));
                }
            }
            worldbookSelectedIds = next;
            render();
            return;
        }
        if (action === 'toggle-event-delivery') {
            await invokeAction('toggle-event-delivery', {
                eventId: target.dataset.eventId || '',
            });
            render();
            return;
        }
        if (action === 'import-state') {
            root.querySelector('.wb-import-input')?.click();
            return;
        }
        if (action === 'catch-up-person') {
            await invokeAction('catch-up-person', {
                personId: target.dataset.personId || '',
            });
            render();
            return;
        }
        if (action === 'prioritize-person') {
            await invokeAction('prioritize-person', {
                personId: target.dataset.personId || '',
                enabled: target.dataset.enabled !== 'false',
            });
            render();
            return;
        }
        if (action === 'observe-person') {
            const result = await invokeAction('observe-person', {
                personId: target.dataset.personId || '',
                force: target.dataset.force === 'true',
            });
            if (result && typeof result === 'object' && result.text) {
                personObservation = result;
            }
            render();
            return;
        }
        if (action === 'queue-person-observation') {
            const result = await invokeAction('queue-person-observation', {
                personId: target.dataset.personId || '',
            });
            if (result && typeof result === 'object') personObservation = result;
            render();
            return;
        }
        if (action === 'resolve-message-edit') {
            await invokeAction('resolve-message-edit', {
                mode: target.dataset.mode === 'keep' ? 'keep' : 'rerun',
            });
            render();
            return;
        }
        if (action === 'save-api-profile-from-form') {
            const form = target.closest('[data-wb-form="api"]');
            if (!form) return;
            const urlField = form.elements?.customApiUrl;
            const modelField = form.elements?.customApiModel;
            if (urlField && !urlField.checkValidity()) {
                urlField.reportValidity();
                return;
            }
            if (modelField && !String(modelField.value || '').trim()) {
                modelField.focus();
                notify('Chọn model trước rồi hãy lưu cấu hình nhé～', 'error');
                return;
            }
            const data = readApiForm(form);
            const profileId = String(data.profileId || '').trim();
            const existingProfile = (getSettings().apiProfiles || []).find(item => item.id === profileId);
            const key = String(data.customApiCredential || '').trim()
                || existingProfile?.key
                || (!profileId ? getSettings().customApiKey : '');
            if (!key) {
                notify('Cấu hình này còn thiếu API Key đó～', 'error');
                form.elements?.customApiCredential?.focus();
                return;
            }
            const name = String(data.profileName || '').trim()
                || String(data.customApiModel || '').trim()
                || 'API độc lập của tôi';
            const completed = await invokeAction('save-api-profile', {
                id: profileId,
                name,
                url: data.customApiUrl,
                key: String(data.customApiCredential || '').trim(),
                model: data.customApiModel,
                transport: data.customApiTransport,
            });
            if (completed) {
                forgetApiKeyDraft(data);
                openSettingsSubgroups.add('connection-profiles');
            }
            render();
            return;
        }
        if (action === 'edit-api-profile') {
            const profileId = String(target.dataset.profileId || '');
            const profile = (getSettings().apiProfiles || []).find(item => item.id === profileId);
            if (!profile) {
                notify('Cấu hình API này hình như không còn nữa rồi～', 'error');
                return;
            }
            apiFormDraft = {
                profileId: profile.id,
                profileName: profile.name || '',
                customApiUrl: profile.url || '',
                customApiCredential: '',
                customApiModel: profile.model || '',
                customApiTransport: profile.transport || 'proxy',
            };
            skipApiDraftCapture = true;
            settingsSection = 'connection';
            openSettingsGroups.add('connection');
            openSettingsSubgroups.add('connection-custom');
            render();
            window.setTimeout(() => {
                const group = root.querySelector('.wb-settings-group[data-settings-group="connection"]');
                const subgroup = root.querySelector('.wb-settings-subgroup[data-settings-subgroup="connection-custom"]');
                if (group) group.open = true;
                if (subgroup) subgroup.open = true;
                root.querySelector('[data-wb-form="api"] [name="profileName"]')?.focus();
            }, 0);
            return;
        }
        if (action === 'test-api-profile') {
            await invokeAction('test-api-profile', { profileId: target.dataset.profileId || '' });
            render();
            return;
        }
        if (action === 'pull-api-profile-models') {
            const profileId = String(target.dataset.profileId || '');
            const profile = (getSettings().apiProfiles || []).find(item => item.id === profileId);
            if (profile) {
                apiFormDraft = {
                    profileId: profile.id,
                    profileName: profile.name || '',
                    customApiUrl: profile.url || '',
                    customApiCredential: '',
                    customApiModel: profile.model || '',
                    customApiTransport: profile.transport || 'proxy',
                };
                skipApiDraftCapture = true;
                settingsSection = 'connection';
                openSettingsGroups.add('connection');
                openSettingsSubgroups.add('connection-custom');
            }
            await invokeAction('pull-api-profile-models', { profileId });
            render();
            window.setTimeout(() => {
                const picker = root.querySelector('[data-wb-api-model-picker]');
                picker?.scrollIntoView?.({ block: 'center', behavior: 'smooth' });
                picker?.focus();
            }, 0);
            return;
        }
        if (action === 'duplicate-api-profile') {
            await invokeAction('duplicate-api-profile', { profileId: target.dataset.profileId || '' });
            openSettingsSubgroups.add('connection-profiles');
            render();
            return;
        }
        if (action === 'delete-api-profile') {
            const settings = getSettings();
            const profile = (settings.apiProfiles || []).find(item => item.id === String(target.dataset.profileId || ''));
            const confirmed = globalThis.confirm?.(`(・_・;)  Muốn xóa cấu hình API “${profile?.name || 'cấu hình này'}” không?\nCác mô-đun đang dùng nó sẽ tự động quay về “Theo mặc định”.`);
            if (confirmed === false) return;
            await invokeAction('delete-api-profile', { profileId: target.dataset.profileId || '' });
            render();
            return;
        }
        if (action === 'test-image-api') {
            const form = target.closest('[data-wb-form="image-api"]');
            if (!form) return;
            const confirmed = globalThis.confirm?.('(・_・;)  Lần thử sẽ thật sự tạo một ảnh 512×512, có thể tốn phí API một lần. Tiếp tục chứ?');
            if (confirmed === false) return;
            const data = Object.fromEntries(new FormData(form).entries());
            const key = String(data.imageApiCredential || '').trim() || getSettings().imageApiKey;
            if (!String(data.imageApiUrl || '').trim() || !key || !String(data.imageApiModel || '').trim()) {
                notify('Hãy điền đầy đủ địa chỉ tạo ảnh, Key và model trước.', 'error');
                return;
            }
            const completed = await invokeAction('test-image-api', {
                imageApiUrl: data.imageApiUrl,
                imageApiKey: key,
                imageApiModel: data.imageApiModel,
            });
            if (completed) notify('Tạo ảnh thử thành công, API dùng được.', 'success');
            return;
        }
        if (action === 'test-api') {
            const form = target.closest('[data-wb-form="api"]');
            if (!form) return;
            const urlField = form.elements?.customApiUrl;
            const modelField = form.elements?.customApiModel;
            if (urlField && !urlField.checkValidity()) {
                urlField.reportValidity();
                return;
            }
            if (modelField && !String(modelField.value || '').trim()) {
                modelField.focus();
                notify('Chọn model trước rồi hãy thử nhé～', 'error');
                return;
            }
            const data = readApiForm(form);
            let request;
            try {
                request = apiRequestFromDraft(data, { requireModel: true });
            } catch (error) {
                notify(String(error?.message || error), 'error');
                return;
            }
            await invokeAction('test-api-draft', request);
            render();
            return;
        }
        if (action === 'pull-api-models') {
            const form = target.closest('[data-wb-form="api"]');
            if (!form) return;
            // 拉模型只读取当前草稿，不再偷偷改默认独立接口。编辑已保存方案时，
            // Key 留空会安全沿用该方案自己的 Key，而不是串到默认配置。
            const urlField = form.elements?.customApiUrl;
            const keyField = form.elements?.customApiCredential;
            if (urlField && !urlField.checkValidity()) {
                urlField.reportValidity();
                return;
            }
            const data = readApiForm(form);
            let request;
            try {
                request = apiRequestFromDraft(data, { requireModel: false });
            } catch (error) {
                notify(String(error?.message || error), 'error');
                keyField?.focus();
                return;
            }
            const models = await invokeAction('pull-api-draft-models', request);
            if (Array.isArray(models) && models.length === 1 && !String(form.elements?.customApiModel?.value || '').trim()) {
                form.elements.customApiModel.value = models[0];
                readApiForm(form);
                notify(`Chỉ tìm thấy một model, đã chọn sẵn cho bạn: ${models[0]}`, 'success');
            }
            render();
            window.setTimeout(() => {
                root.querySelector('[data-wb-api-model-picker]')?.focus();
            }, 0);
            return;
        }
        if (action === 'reset-api-draft') {
            apiFormDraft = {
                customApiUrl: '',
                customApiCredential: '',
                customApiModel: '',
                customApiTransport: getSettings().customApiTransport,
                profileName: '',
                profileId: '',
            };
            skipApiDraftCapture = true;
            render();
            window.setTimeout(() => {
                root.querySelector('[data-wb-form="api"] [name="customApiUrl"]')?.focus();
            }, 0);
            return;
        }
        if (action === 'toggle-api-key-visibility') {
            const field = target.closest('.wb-api-secret-field')?.querySelector('.wb-secret-input');
            if (!field) return;
            const visible = field.classList.toggle('is-visible');
            target.setAttribute('aria-pressed', String(visible));
            target.textContent = visible ? 'Ẩn' : 'Hiện';
            field.focus();
            return;
        }

        if (action === 'clear-current-chat-cache') {
            const completed = await invokeAction('clear-current-chat-cache');
            if (completed) {
                personObservation = null;
                worldbookSelectedIds = new Set();
                notify('Bộ nhớ đệm có thể dựng lại của cuộc chat hiện tại đã được dọn sạch rồi～ Dữ liệu thế giới và API đều không bị động đến.', 'success');
            }
            render();
            return;
        }

        if (action === 'check-correct-world-state') {
            const result = await invokeAction('check-correct-world-state');
            if (result) {
                const corrected = Number(result.applied?.length || 0);
                const removed = Number(result.removedEventIds?.length || 0);
                const skipped = Number(result.skipped || 0);
                notify(
                    corrected || removed
                        ? `Kiểm tra xong: đã sửa ${corrected} mục${removed ? `, hủy ${removed} mục phái sinh chưa xảy ra` : ''}。`
                        : skipped
                            ? `Kiểm tra xong: ${skipped} mục không đủ bằng chứng, đã thận trọng bỏ qua, không sửa bừa.`
                            : 'Kiểm tra hoàn tất: không phát hiện mâu thuẫn rõ ràng nào cần sửa.',
                    corrected || removed ? 'success' : 'info',
                );
            }
            render();
            return;
        }

        if (action === 'reset-current-chat-data') {
            const first = globalThis.confirm?.(
                'Chắc chắn muốn đặt lại toàn bộ dữ liệu 世界背面 của “cuộc chat hiện tại” không?\n\n'
                + 'Sẽ xóa nhân vật, sự kiện, Mạch ngầm, Tiếng vọng, ký ức, dư luận, quan sát, điểm khôi phục và ảnh chụp nhánh.\n'
                + 'Chính văn trò chuyện và cấu hình API / model sẽ không bị xóa.',
            );
            if (first === false) return;
            const second = globalThis.confirm?.(
                'Xác nhận lần cuối: lần đặt lại này sẽ không tạo điểm khôi phục, dữ liệu thế giới cũ sẽ không thể khôi phục từ 世界背面.\n\nChắc chắn tiếp tục chứ?',
            );
            if (second === false) return;

            const result = await invokeAction('reset-current-chat-data');
            if (result) {
                selectedPersonId = null;
                personObservation = null;
                memorySelectedKeys = new Set();
                memoryEditor = null;
                personEditor = null;
                recordEditor = null;
                eventFormOpen = false;
                eventEditorId = '';
                worldEditorOpen = false;
                worldbookSelectedIds = new Set();
                worldbookQuery = '';
                worldbookOnlyPeople = false;
                worldbookOnlyEnabled = false;
                notify(
                    `Cuộc chat hiện tại đã được đặt lại thành thế giới trống${Number(result.removedSnapshots) > 0 ? `, đồng thời xóa ${result.removedSnapshots} ảnh chụp nhánh cũ` : ''}. Cấu hình API và chính văn trò chuyện đều được giữ lại.`,
                    'success',
                );
            }
            render();
            return;
        }

        await invokeAction(action, {});
        render();
    });

    root.addEventListener('change', async event => {
        if (event.target.matches?.('[data-wb-form="worldbook"] select[name="bookName"]')) {
            worldbookSelectedIds = new Set();
            await invokeAction('select-worldbook', { bookName: event.target.value });
            render();
            return;
        }
        const apiForm = event.target.closest?.('[data-wb-form="api"]');
        if (apiForm) {
            if (event.target.matches?.('[data-wb-api-model-picker]')) {
                const model = String(event.target.value || '').trim();
                const modelField = apiForm.elements?.customApiModel;
                if (model && modelField) {
                    modelField.value = model;
                    readApiForm(apiForm);
                    notify(`Đã chọn model nhưng chưa lưu: ${model}`, 'info');
                }
                return;
            }
            readApiForm(apiForm);
            return;
        }
        if (event.target.matches?.('[data-wb-person-select]')) {
            const id = String(event.target.value || '');
            const next = new Set(peopleSelectedIds);
            if (event.target.checked) next.add(id);
            else next.delete(id);
            peopleSelectedIds = next;
            render();
            return;
        }

        if (event.target.matches?.('[data-wb-clue-relation-filter]')) {
            memoryClueRelationFilter = String(event.target.value || 'all');
            memoryVisibleCount = 12;
            memorySelectedKeys = new Set();
            render();
            return;
        }

        if (event.target.matches?.('[data-wb-memory-select]')) {
            const kind = String(event.target.dataset.memoryKind || 'fact');
            const id = String(event.target.dataset.memoryId || '');
            const key = `${kind}:${id}`;
            const next = new Set(memorySelectedKeys);
            if (event.target.checked) next.add(key);
            else next.delete(key);
            memorySelectedKeys = next;
            const deleteButton = root.querySelector('[data-wb-memory-selected-count]');
            if (deleteButton) {
                deleteButton.disabled = memorySelectedKeys.size === 0;
                deleteButton.textContent = `Xóa mục đã chọn${memorySelectedKeys.size ? ` · ${memorySelectedKeys.size}` : ''}`;
            }
            const clearButton = root.querySelector('[data-wb-action="clear-memory-selection"]');
            if (clearButton) clearButton.disabled = memorySelectedKeys.size === 0;
            return;
        }

        if (event.target.matches?.('[data-wb-draft-target]')) {
            worldbookDraftTargets = new Map(worldbookDraftTargets).set(event.target.dataset.wbDraftTarget, event.target.value);
            render();
            return;
        }

        if (event.target.matches?.('[data-wb-draft-person]')) {
            const reference = String(event.target.dataset.wbDraftPerson || '');
            const next = new Set(worldbookDraftSkipped);
            if (event.target.checked) next.delete(reference);
            else next.add(reference);
            worldbookDraftSkipped = next;
            render();
            return;
        }

        if (event.target.matches?.('[data-wb-draft-field]')) {
            const key = String(event.target.dataset.wbDraftField || '');
            const dropped = new Set(worldbookDraftDroppedFields);
            const picked = new Set(worldbookDraftPickedFields);
            if (event.target.checked) {
                dropped.delete(key);
                picked.add(key);
            } else {
                dropped.add(key);
                picked.delete(key);
            }
            worldbookDraftDroppedFields = dropped;
            worldbookDraftPickedFields = picked;
            render();
            return;
        }

        if (event.target.matches?.('[data-wb-worldbook-entry-id]')) {
            const uid = String(event.target.dataset.wbWorldbookEntryId || '');
            const next = new Set(worldbookSelectedIds);
            if (event.target.checked) next.add(uid);
            else next.delete(uid);
            worldbookSelectedIds = next;
            render();
            return;
        }
        const worldbookFilter = event.target.dataset?.wbWorldbookFilter;
        if (worldbookFilter === 'people' || worldbookFilter === 'enabled') {
            if (worldbookFilter === 'people') worldbookOnlyPeople = Boolean(event.target.checked);
            if (worldbookFilter === 'enabled') worldbookOnlyEnabled = Boolean(event.target.checked);
            render();
            return;
        }

        if (event.target.matches?.('[data-wb-tavern-profile-select]')) {
            await invokeAction('update-settings', {
                tavernApiProfileId: String(event.target.value || ''),
            });
            notify(event.target.value ? 'Đã nhớ thẻ cấu hình Tavern rồi nè～' : 'Tạm không gắn cấu hình Tavern nữa～', event.target.value ? 'success' : 'info');
            render();
            return;
        }

        const apiRouteKey = event.target.dataset?.wbApiRoute;
        if (apiRouteKey && ['simulation', 'observation', 'history', 'opinion'].includes(apiRouteKey)) {
            const settings = getSettings();
            const routes = {
                ...(settings.apiModuleRoutes || {}),
                [apiRouteKey]: String(event.target.value || 'default'),
            };
            await invokeAction('update-settings', { apiModuleRoutes: routes });
            notify('Đã ghi nhớ tuyến API của mục này rồi～', 'success');
            render();
            return;
        }

        const tagField = event.target.dataset?.wbTagFilterField;
        if (tagField === 'open' || tagField === 'close') {
            const index = Number(event.target.dataset.index);
            const settings = getSettings();
            const current = visibleTagFilterRules(settings).map(rule => ({ ...rule }));
            if (!current[index]) return;
            current[index] = {
                ...current[index],
                [tagField]: String(event.target.value || '').slice(0, 80),
            };
            await persistTagFilterRules(current);
            render();
            return;
        }

        const settingSeconds = event.target.dataset.wbSettingSeconds;
        if (settingSeconds) {
            const seconds = Math.max(0, Number(event.target.value) || 0);
            await invokeAction('update-settings', {
                [settingSeconds]: seconds > 0 ? Math.round(seconds * 1000) : 0,
            });
            render();
            return;
        }

        const generationLimitField = event.target.dataset.wbGenerationLimit;
        const generationLimitModule = event.target.dataset.module;
        if (
            generationLimitField
            && ['simulation', 'observation', 'history', 'opinion'].includes(generationLimitModule)
        ) {
            const settings = getSettings();
            const current = settings.generationModuleLimits && typeof settings.generationModuleLimits === 'object'
                ? settings.generationModuleLimits
                : {};
            const moduleLimit = {
                ...(current[generationLimitModule] || { maxTokens: 0, timeoutMs: 0 }),
            };
            if (generationLimitField === 'maxTokens') {
                moduleLimit.maxTokens = Math.max(0, Number.parseInt(event.target.value, 10) || 0);
            } else if (generationLimitField === 'timeoutSeconds') {
                const seconds = Math.max(0, Number(event.target.value) || 0);
                moduleLimit.timeoutMs = seconds > 0 ? Math.round(seconds * 1000) : 0;
            } else {
                return;
            }
            await invokeAction('update-settings', {
                generationModuleLimits: {
                    ...current,
                    [generationLimitModule]: moduleLimit,
                },
            });
            render();
            return;
        }

        const setting = event.target.dataset.wbSetting;
        if (setting) {
            const value = event.target.type === 'checkbox'
                ? event.target.checked
                : event.target.value;
            await invokeAction('update-settings', { [setting]: value });
            render();
            return;
        }

        if (event.target.classList.contains('wb-import-input')) {
            const file = event.target.files?.[0];
            if (!file) return;
            await invokeAction('import-state-data', {
                name: file.name,
                text: await file.text(),
            });
            event.target.value = '';
            render();
        }
    });

    root.addEventListener('input', event => {
        if (event.target.matches?.('[data-wb-form="social-message"] textarea[name="text"]')) {
            socialDraft = String(event.target.value || '').slice(0, 1600);
            return;
        }
        if (event.target.matches?.('[data-wb-social-search]')) {
            socialSearchQuery = String(event.target.value || '').slice(0, 80);
            window.clearTimeout(socialSearchTimer);
            socialSearchTimer = window.setTimeout(render, 120);
            return;
        }
        const apiForm = event.target.closest?.('[data-wb-form="api"]');
        if (apiForm) {
            readApiForm(apiForm);
            return;
        }

        if (event.target.matches?.('[data-wb-worldbook-search]')) {
            worldbookQuery = String(event.target.value || '').slice(0, 120);
            window.clearTimeout(worldbookSearchTimer);
            worldbookSearchTimer = window.setTimeout(render, 100);
            return;
        }
        if (!event.target.matches?.('[data-wb-memory-search]')) return;
        const nextMemoryQuery = String(event.target.value || '').slice(0, 80);
        if (nextMemoryQuery !== memoryQuery) memorySelectedKeys = new Set();
        memoryQuery = nextMemoryQuery;
        memoryVisibleCount = 12;
        window.clearTimeout(memorySearchTimer);
        memorySearchTimer = window.setTimeout(render, 120);
    });

    root.addEventListener('submit', async event => {
        const form = event.target.closest('[data-wb-form]');
        if (!form) return;
        event.preventDefault();
        const data = Object.fromEntries(new FormData(form).entries());

        if (form.dataset.wbForm === 'lingqi-chat') {
            const text = String(data.text || '').trim();
            if (!text) return;
            if (form.elements.text) form.elements.text.value = '';
            lingqiDraft = '';
            const completed = await invokeAction('lingqi-send-message', { text });
            if (completed === false) lingqiDraft = text;
        }
        if (form.dataset.wbForm === 'social-message') {
            const text = String(data.text || '').trim();
            const conversationId = String(data.conversationId || '').trim();
            if (!text || !conversationId) return;
            socialDraft = '';
            if (form.elements.text) form.elements.text.value = '';
            const completed = await invokeAction('social-send-message', { conversationId, text });
            if (completed === false) socialDraft = text;
        }
        if (form.dataset.wbForm === 'social-group') {
            const memberIds = new FormData(form).getAll('memberIds').map(String).filter(Boolean);
            socialGroupSelectedIds = new Set(memberIds);
            const completed = await invokeAction('social-create-group', {
                title: String(data.title || ''),
                memberIds,
            });
            if (completed) {
                socialGroupOpen = false;
                socialGroupSelectedIds = new Set();
                socialDraft = '';
            }
        }
        if (form.dataset.wbForm === 'social-friend-request') {
            const personId = String(data.personId || '').trim();
            if (!personId) return;
            const result = await invokeAction('social-request-friend', {
                personId,
                message: String(data.message || '').trim(),
            });
            if (result && typeof result === 'object') {
                const visible = result.reply ? `：${result.reply}` : '';
                notify(
                    result.decision === 'accepted'
                        ? `${result.personName} đã chấp nhận lời mời kết bạn${visible}`
                        : result.decision === 'declined'
                            ? `${result.personName} không chấp nhận lời mời${visible}`
                            : `${result.personName} tạm thời chưa xử lý lời mời${visible}`,
                    result.decision === 'accepted' ? 'success' : 'info',
                );
            }
            render();
        }
        if (form.dataset.wbForm === 'clock') {
            clockFormDraft = { ...data };
            const completed = await invokeAction('set-clock', data);
            if (completed) clockFormDraft = null;
        }
        if (form.dataset.wbForm === 'api') {
            apiFormDraft = { ...data };
            const completed = await invokeAction('update-settings', apiSettingsFromDraft(data));
            if (completed) {
                forgetApiKeyDraft(data);
                notify('Đã lưu API độc lập rồi～ Key cũ vẫn sẽ không lén điền lại đâu nhé.', 'success');
            }
        }
        if (form.dataset.wbForm === 'image-api') {
            const replacementKey = String(data.imageApiCredential || '').trim();
            const enabled = Boolean(form.elements.imageApiEnabled?.checked);
            const patch = {
                imageApiEnabled: enabled,
                imageApiUrl: String(data.imageApiUrl || '').trim(),
                imageApiKey: replacementKey || getSettings().imageApiKey,
                imageApiModel: String(data.imageApiModel || '').trim(),
                imageApiSize: String(data.imageApiSize || '1024x1024'),
            };
            if (enabled && (!patch.imageApiUrl || !patch.imageApiKey || !patch.imageApiModel)) {
                notify('Muốn bật tạo ảnh thì phải điền đầy đủ địa chỉ, Key và model.', 'error');
            } else {
                const completed = await invokeAction('update-settings', patch);
                if (completed) {
                    form.elements.imageApiCredential.value = '';
                    notify(enabled ? 'Đã bật API tạo ảnh cho Khoảnh khắc.' : 'Đã lưu cấu hình tạo ảnh, hiện vẫn đang tắt.', 'success');
                }
            }
        }
        if (form.dataset.wbForm === 'world') {
            const completed = await invokeAction('save-world-summary', {
                title: data.title || '',
                detail: data.detail || '',
                background: data.background || '',
            });
            if (completed) worldEditorOpen = false;
        }
        if (form.dataset.wbForm === 'record') {
            const completed = await invokeAction('save-record', {
                kind: data.kind || 'echo',
                id: data.id || '',
                title: data.title || '',
                text: data.text || '',
                place: data.place || '',
                visibility: data.visibility || 'hidden',
                deliveryState: data.deliveryState || 'none',
            });
            if (completed) recordEditor = null;
        }
        if (form.dataset.wbForm === 'event') {
            const completed = await invokeAction(data.id ? 'update-event' : 'add-event', data);
            if (completed) {
                eventFormOpen = false;
                eventEditorId = '';
                eventFormDraft = null;
            }
        }
        if (form.dataset.wbForm === 'memory') {
            const parseRelationList = value => [...new Set(
                String(value || '')
                    .split(/[、,，;；\n]+/)
                    .map(item => item.trim())
                    .filter(Boolean),
            )];
            const completed = await invokeAction('save-memory-item', {
                id: data.id || '',
                kind: data.kind || 'fact',
                title: data.title || '',
                relation: data.relation || '',
                content: data.content || '',
                people: parseRelationList(data.people),
                events: parseRelationList(data.events),
                locations: parseRelationList(data.locations),
                important: form.elements.important?.checked || false,
                locked: form.elements.locked?.checked || false,
            });
            if (completed) memoryEditor = null;
        }
        if (form.dataset.wbForm === 'person') {
            const avatarFile = form.elements.avatarFile?.files?.[0] || null;
            let avatarDataUrl = null;
            if (avatarFile) {
                notify('Đang thu nhỏ avatar thành một bé xíu～', 'info');
                try {
                    avatarDataUrl = await readPersonAvatarFile(avatarFile);
                } catch (error) {
                    notify(String(error?.message || error || 'Xử lý avatar không thành công～'), 'error');
                    return;
                }
            }
            const completed = await invokeAction('save-manual-person', {
                id: data.id || '',
                originalName: data.originalName || '',
                name: data.name || '',
                avatarDataUrl,
                location: data.location || '',
                action: data.action || '',
                intent: data.intent || '',
                longTermGoal: data.longTermGoal || '',
                innerVoice: data.innerVoice || '',
                identityAnchor: data.identityAnchor || '',
                personalityAnchor: data.personalityAnchor || '',
                appearanceProfile: data.appearanceProfile || '',
                backgroundProfile: data.backgroundProfile || '',
                abilityProfile: data.abilityProfile || '',
                speakingStyle: data.speakingStyle || '',
                behaviorBoundaries: data.behaviorBoundaries || '',
                knowledge: data.knowledge || 'backstage',
                relevance: data.relevance || 2,
                simulationEnabled: form.elements.simulationEnabled?.checked || false,
                locked: form.elements.locked?.checked || false,
            });
            if (completed) personEditor = null;
        }
        if (form.dataset.wbForm === 'worldbook') {
            const formData = new FormData(form);
            const completed = await invokeAction('import-worldbook-people', {
                bookName: String(formData.get('bookName') || ''),
                entryIds: [...worldbookSelectedIds],
            });
            if (completed) worldbookSelectedIds = new Set();
        }
        render();
    });

    const onKeydown = event => {
        const lingqiTextarea = event.target.matches?.('[data-wb-form="lingqi-chat"] textarea[name="text"]')
            ? event.target
            : null;
        if (
            lingqiTextarea
            && event.key === 'Enter'
            && !event.shiftKey
            && !event.ctrlKey
            && !event.altKey
            && !event.metaKey
            && !event.isComposing
            && event.keyCode !== 229
        ) {
            event.preventDefault();
            lingqiTextarea.form?.requestSubmit();
            return;
        }
        if (
            ['Enter', ' '].includes(event.key)
            && event.target.matches?.('[role="button"][data-wb-action]')
        ) {
            event.preventDefault();
            event.target.click();
            return;
        }
        if (event.key !== 'Escape') return;
        if (recordEditor) recordEditor = null;
        else if (worldEditorOpen) worldEditorOpen = false;
        else if (selectedPersonId) selectedPersonId = null;
        else if (eventFormOpen) {
            eventFormOpen = false;
            eventEditorId = '';
            eventFormDraft = null;
        }
        else if (moduleSettingsView) {
            moduleSettingsView = '';
            clockFormDraft = null;
        }
        else if (settingsOpen) {
            settingsOpen = false;
            clockFormDraft = null;
            tagFilterDraftRules = null;
        }
        else if (isOpen) {
            close();
            return;
        }
        render();
    };
    const onResize = () => {
        syncVisualViewportInsets();
        positionOrbFromSettings();
    };
    function getDiagnosticDraftStatus() {
        const settings = getSettings();
        const draft = apiFormDraft && typeof apiFormDraft === 'object' ? apiFormDraft : null;
        const changedFields = [];
        if (draft) {
            if (String(draft.customApiUrl || '').trim() !== String(settings.customApiUrl || '').trim()) {
                changedFields.push('customApiUrl');
            }
            if (String(draft.customApiModel || '').trim() !== String(settings.customApiModel || '').trim()) {
                changedFields.push('customApiModel');
            }
            if (String(draft.customApiTransport || 'proxy') !== String(settings.customApiTransport || 'proxy')) {
                changedFields.push('customApiTransport');
            }
            if (String(draft.customApiCredential || '').trim()) changedFields.push('customApiKey');
        }
        const savedTagRules = Array.isArray(settings.tagFilterRules) ? settings.tagFilterRules : [];
        return {
            api: {
                draftPresent: Boolean(draft),
                unsavedChanges: changedFields.length > 0,
                changedFields,
                replacementCredentialEntered: Boolean(String(draft?.customApiCredential || '').trim()),
            },
            tagFilters: {
                draftPresent: Array.isArray(tagFilterDraftRules),
                unsavedChanges: Array.isArray(tagFilterDraftRules)
                    && JSON.stringify(tagFilterDraftRules) !== JSON.stringify(savedTagRules),
                draftRuleCount: Array.isArray(tagFilterDraftRules) ? tagFilterDraftRules.length : 0,
                savedRuleCount: savedTagRules.length,
            },
        };
    }
    const selfHealTimer = window.setInterval(ensureMounted, 1800);
    const onPageVisible = () => ensureMounted();
    document.addEventListener('keydown', onKeydown);
    document.addEventListener('visibilitychange', onPageVisible);
    window.addEventListener('focus', onPageVisible);
    window.addEventListener('pageshow', onPageVisible);
    window.addEventListener('resize', onResize);
    window.visualViewport?.addEventListener('resize', onResize);
    window.visualViewport?.addEventListener('scroll', onResize);

    render();
    return {
        render,
        ensureMounted,
        notify,
        setBusy,
        open,
        openEvent,
        close,
        resetContext,
        getDiagnosticDraftStatus,
        destroy() {
            window.clearTimeout(toastTimer);
            window.clearTimeout(memorySearchTimer);
            window.clearTimeout(closeTimer);
            window.clearTimeout(lingqiMascotTimer);
            window.clearTimeout(socialNoticeTimer);
            window.cancelAnimationFrame?.(freshOpenCheckFrame);
            window.clearInterval(selfHealTimer);
            document.removeEventListener('keydown', onKeydown);
            document.removeEventListener('visibilitychange', onPageVisible);
            window.removeEventListener('focus', onPageVisible);
            window.removeEventListener('pageshow', onPageVisible);
            window.removeEventListener('resize', onResize);
            window.visualViewport?.removeEventListener('resize', onResize);
            window.visualViewport?.removeEventListener('scroll', onResize);
            root.remove();
        },
    };
}
