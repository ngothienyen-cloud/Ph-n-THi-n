import {
    buildHistoryArchaeologyPrompt,
    mergeChronologicalHistoryArtifacts,
    planHistoryArchaeologyWindows,
    runHistoryArchaeologyPool,
} from './history-parallel-lab.js';

const MODULE_ID = 'world_backstage';
const BUTTON_ID = 'wb-history-parallel-lab-button';
const STATUS_ID = 'wb-history-parallel-lab-status';
let activeRun = null;

function context() {
    try {
        return globalThis.SillyTavern?.getContext?.() || null;
    } catch {
        return null;
    }
}

function normalizeText(value = '') {
    return String(value || '').replace(/\s+/g, '').trim();
}

function chatMessages(ctx) {
    return (Array.isArray(ctx?.chat) ? ctx.chat : [])
        .map((message, index) => {
            if (!message || message.is_system) return null;
            const swipeId = message.is_user ? 0 : Number(message.swipe_id ?? 0);
            const content = message.is_user
                ? String(message.mes || '')
                : String(message.swipes?.[swipeId] ?? message.mes ?? '');
            if (!content.trim()) return null;
            return {
                id: index,
                swipe: swipeId,
                role: message.is_user ? 'user' : 'assistant',
                content: content.trim(),
            };
        })
        .filter(Boolean);
}

function resolveSavedHistoryProfile(ctx) {
    const settings = ctx?.extensionSettings?.[MODULE_ID] || {};
    const route = String(settings.apiModuleRoutes?.history || 'default');
    let profileId = '';
    if (route.startsWith('tavern-profile:')) profileId = route.slice('tavern-profile:'.length).trim();
    else if (route === 'default' && settings.apiMode === 'tavern-profile') {
        profileId = String(settings.tavernApiProfileId || '').trim();
    }
    if (!profileId) {
        throw new Error('Lần thử nghiệm song song đầu tiên chỉ dùng “Cấu hình đã lưu của Tavern”. Quiet generation (tạo ngầm) hiện tại của Tavern là kênh toàn cục, không thể vì đo tốc độ mà vượt qua cách ly an toàn.');
    }
    const profiles = ctx?.extensionSettings?.connectionManager?.profiles || [];
    const profile = profiles.find(item => String(item?.id || '') === profileId);
    if (!profile) throw new Error('Cấu hình đã lưu của Tavern mà module ký ức tham chiếu không còn tồn tại, vui lòng chọn lại trước.');
    const service = ctx?.ConnectionManagerRequestService;
    if (typeof service?.sendRequest !== 'function') {
        throw new Error('SillyTavern hiện tại không cung cấp dịch vụ yêu cầu qua cấu hình kết nối độc lập.');
    }
    return { profileId, profile, service };
}

function extractResponseText(result) {
    if (typeof result === 'string') return result;
    if (typeof result?.content === 'string') return result.content;
    if (typeof result?.text === 'string') return result.text;
    if (typeof result?.message?.content === 'string') return result.message.content;
    return '';
}

function balancedJsonCandidates(source = '') {
    const text = String(source || '');
    const candidates = [];
    for (let start = 0; start < text.length; start += 1) {
        if (text[start] !== '{') continue;
        let depth = 0;
        let quoted = false;
        let escaped = false;
        for (let index = start; index < text.length; index += 1) {
            const char = text[index];
            if (quoted) {
                if (escaped) escaped = false;
                else if (char === '\\') escaped = true;
                else if (char === '"') quoted = false;
                continue;
            }
            if (char === '"') {
                quoted = true;
                continue;
            }
            if (char === '{') depth += 1;
            else if (char === '}') {
                depth -= 1;
                if (depth === 0) {
                    candidates.push(text.slice(start, index + 1));
                    break;
                }
            }
        }
    }
    return candidates;
}

function parseJsonObject(raw) {
    const source = String(raw || '').replace(/^\uFEFF/, '').trim();
    if (!source) return null;
    const fenced = [...source.matchAll(/```(?:json)?\s*([\s\S]*?)```/gi)]
        .map(match => match[1]?.trim())
        .filter(Boolean);
    const strippedThink = source.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
    const candidates = [source, strippedThink, ...fenced];
    for (const candidate of candidates) {
        try {
            const parsed = JSON.parse(candidate);
            if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
        } catch { /* scan balanced objects below */ }
        for (const objectText of balancedJsonCandidates(candidate)) {
            try {
                const parsed = JSON.parse(objectText);
                if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
            } catch { /* keep looking */ }
        }
    }
    return null;
}

function validateWindowPayload(window, payload) {
    if (!payload || typeof payload !== 'object') throw new Error(`Cửa sổ ${window.startMessageId}—${window.endMessageId} không trả về đối tượng JSON`);
    const assistantIds = window.messages
        .filter(message => message.role === 'assistant')
        .map(message => Number(message.id));
    const summaries = Array.isArray(payload.turn_summaries)
        ? payload.turn_summaries
        : Array.isArray(payload.turnSummaries) ? payload.turnSummaries : [];
    const summaryIds = new Set(summaries
        .map(item => Number(item?.source_message_id ?? item?.sourceMessageId ?? item?.message_id ?? item?.messageId))
        .filter(Number.isFinite));
    const missing = assistantIds.filter(id => !summaryIds.has(id));
    if (missing.length) throw new Error(`Cửa sổ ${window.startMessageId}—${window.endMessageId} thiếu tóm tắt L0: ${missing.join(', ')}`);

    const sourceById = new Map(window.messages.map(message => [Number(message.id), normalizeText(message.content)]));
    const checks = [];
    const addEvidenceChecks = (items, evidenceField) => {
        for (const item of Array.isArray(items) ? items : []) {
            const messageId = Number(item?.source_message_id ?? item?.sourceMessageId ?? item?.message_id ?? item?.messageId);
            const evidence = normalizeText(item?.[evidenceField] || '');
            if (!Number.isFinite(messageId) || !evidence) continue;
            checks.push(Boolean(sourceById.get(messageId)?.includes(evidence)));
        }
    };
    addEvidenceChecks(payload.facts_upsert, 'source_excerpt');
    addEvidenceChecks(payload.event_fragments, 'evidence');
    addEvidenceChecks(payload.person_observations, 'evidence');
    addEvidenceChecks(payload.clue_fragments, 'evidence');

    return {
        payload: {
            turn_summaries: summaries,
            facts_upsert: Array.isArray(payload.facts_upsert) ? payload.facts_upsert : [],
            event_fragments: Array.isArray(payload.event_fragments) ? payload.event_fragments : [],
            person_observations: Array.isArray(payload.person_observations) ? payload.person_observations : [],
            clue_fragments: Array.isArray(payload.clue_fragments) ? payload.clue_fragments : [],
        },
        evidenceChecked: checks.length,
        evidenceAnchored: checks.filter(Boolean).length,
    };
}

function setStatus(text, tone = '') {
    const node = document.getElementById(STATUS_ID);
    if (!node) return;
    node.textContent = text;
    node.dataset.tone = tone;
}

function setButtonRunning(running) {
    const button = document.getElementById(BUTTON_ID);
    if (!button) return;
    button.disabled = Boolean(running);
    button.textContent = running
        ? 'Đang đo tốc độ khảo cổ song song……'
        : '🧪 Thử nghiệm truy hồi song song (không ghi vào thế giới)';
}

function compactRetryPrompt(basePrompt, window) {
    const assistantIds = window.messages
        .filter(message => message.role === 'assistant')
        .map(message => Number(message.id));
    return [
        basePrompt,
        '',
        '【Thử lại để sửa định dạng】Bản xuất trước không vượt qua kiểm tra máy.',
        'Lần này cấm giải thích, lời mở đầu, lời kết, khối mã Markdown và quá trình suy nghĩ; chỉ trả về một đối tượng JSON.',
        `turn_summaries phải bao phủ lần lượt từng assistant source_message_id sau: ${assistantIds.join(', ')}。`,
        'Để ổn định: facts_upsert tối đa 4 mục, event_fragments tối đa 4 mục, person_observations tối đa 4 mục, clue_fragments tối đa 3 mục; không có nội dung thì trả về mảng rỗng.',
        'evidence/source_excerpt phải chép trực tiếp câu ngắn từ nguyên văn của cửa sổ này, không được viết lại.',
    ].join('\n');
}

async function requestWindowWithRetry({
    service,
    profileId,
    window,
    basePrompt,
    signal,
    onRetry,
}) {
    const attempts = [
        { prompt: basePrompt, maxTokens: 3200, temperature: 0.05 },
        { prompt: compactRetryPrompt(basePrompt, window), maxTokens: 3600, temperature: 0.02 },
    ];
    let lastError = null;
    let lastRaw = '';
    let totalMs = 0;

    for (let attempt = 0; attempt < attempts.length; attempt += 1) {
        if (signal?.aborted) {
            const error = new Error('Thử nghiệm lịch sử song song đã dừng');
            error.name = 'AbortError';
            throw error;
        }
        const config = attempts[attempt];
        const started = performance.now();
        const result = await service.sendRequest(
            profileId,
            [
                { role: 'system', content: 'Thực hiện trích xuất bằng chứng lịch sử có cấu trúc. Đầu ra cuối cùng phải là một đối tượng JSON hợp lệ duy nhất. Không xuất Markdown, giải thích hay quá trình suy nghĩ. Viết các trường mô tả bằng tiếng Việt.' },
                { role: 'user', content: config.prompt },
            ],
            config.maxTokens,
            {
                stream: false,
                signal,
                extractData: true,
                includePreset: false,
                includeInstruct: true,
            },
            {
                temperature: config.temperature,
                include_reasoning: false,
            },
        );
        totalMs += Math.max(0, performance.now() - started);
        lastRaw = extractResponseText(result);
        try {
            const parsed = parseJsonObject(lastRaw);
            if (!parsed) throw new Error(`Cửa sổ ${window.startMessageId}—${window.endMessageId} trả về định dạng không phân tích được`);
            const checked = validateWindowPayload(window, parsed);
            return {
                ...checked,
                attempts: attempt + 1,
                durationMs: totalMs,
            };
        } catch (error) {
            lastError = error;
            if (attempt + 1 < attempts.length) {
                onRetry?.({ attempt: attempt + 2, error, raw: lastRaw });
                continue;
            }
        }
    }

    globalThis.__WB_HISTORY_PARALLEL_LAB_LAST_FAILURE__ = {
        window: {
            startMessageId: window.startMessageId,
            endMessageId: window.endMessageId,
        },
        error: String(lastError?.message || lastError || ''),
        responsePreview: String(lastRaw || '').slice(0, 1800),
    };
    const error = new Error(
        `Cửa sổ ${window.startMessageId}—${window.endMessageId} hai lần liên tiếp không vượt qua kiểm tra JSON/L0`
        + (lastError?.message ? `：${lastError.message}` : ''),
    );
    error.cause = lastError;
    throw error;
}

async function runLab() {
    if (activeRun) return;
    const ctx = context();
    if (!ctx) throw new Error('Chưa lấy được ngữ cảnh SillyTavern.');
    const messages = chatMessages(ctx);
    const assistantCount = messages.filter(message => message.role === 'assistant').length;
    if (assistantCount < 6) throw new Error('Đoạn chat này quá ngắn, cần ít nhất 6 chính văn AI thì thử song song mới có ý nghĩa.');
    const { profileId, profile, service } = resolveSavedHistoryProfile(ctx);
    const windows = planHistoryArchaeologyWindows(messages, {
        assistantTurnsPerWindow: 4,
        overlapAssistantTurns: 1,
        maximumCharacters: 22000,
    });
    if (windows.length < 2) throw new Error('Lịch sử hiện tại chỉ chia được một cửa sổ, không cần chạy song song.');

    const controller = new AbortController();
    const durations = new Array(windows.length).fill(0);
    const evidence = new Array(windows.length).fill(null);
    const attempts = new Array(windows.length).fill(0);
    activeRun = { controller };
    setButtonRunning(true);
    setStatus(`Chuẩn bị ${windows.length} cửa sổ chồng lấn, đồng thời tối đa 2; chỉ trích xuất bằng chứng, không đụng vào thế giới chính thức.`);

    try {
        const run = await runHistoryArchaeologyPool(windows, {
            concurrency: 2,
            signal: controller.signal,
            onProgress: progress => {
                if (progress.phase === 'complete') {
                    setStatus(`Khảo cổ song song ${progress.completed}/${progress.total}; hiện chạy cùng lúc tối đa 2 phần, không gửi trạng thái thế giới.`);
                }
            },
            extract: async (window, { slot, index, signal }) => {
                const prompt = buildHistoryArchaeologyPrompt(window, {
                    userName: String(ctx.name1 || ''),
                    playerIdentityAnchor: String(ctx.extensionSettings?.[MODULE_ID]?.playerIdentityAnchor || ''),
                    recordPlayerCharacter: ctx.extensionSettings?.[MODULE_ID]?.recordPlayerCharacter !== false,
                });
                const checked = await requestWindowWithRetry({
                    service,
                    profileId,
                    window,
                    basePrompt: prompt,
                    signal,
                    onRetry: () => {
                        setStatus(`Cửa sổ ${window.startMessageId}—${window.endMessageId} bị lệch định dạng, đang tự động siết định dạng và thử lại; thế giới vẫn chưa bị ghi.`);
                    },
                });
                durations[index] = checked.durationMs;
                attempts[index] = checked.attempts;
                evidence[index] = {
                    checked: checked.evidenceChecked,
                    anchored: checked.evidenceAnchored,
                    slot,
                };
                return checked.payload;
            },
        });

        const merged = mergeChronologicalHistoryArtifacts(run.results);
        const serialEstimateMs = durations.reduce((sum, value) => sum + value, 0);
        const speedup = run.elapsedMs > 0 ? serialEstimateMs / run.elapsedMs : 0;
        const evidenceChecked = evidence.reduce((sum, item) => sum + Number(item?.checked || 0), 0);
        const evidenceAnchored = evidence.reduce((sum, item) => sum + Number(item?.anchored || 0), 0);
        const evidenceRate = evidenceChecked > 0 ? evidenceAnchored / evidenceChecked : 1;
        const assistantIds = new Set(messages.filter(message => message.role === 'assistant').map(message => Number(message.id)));
        const summaryIds = new Set(merged.turn_summaries
            .map(item => Number(item?.source_message_id ?? item?.sourceMessageId ?? item?.message_id ?? item?.messageId))
            .filter(Number.isFinite));
        const summaryCoverage = assistantIds.size
            ? [...assistantIds].filter(id => summaryIds.has(id)).length / assistantIds.size
            : 1;
        const retryWindows = attempts.filter(value => value > 1).length;

        const metrics = {
            at: new Date().toISOString(),
            profileName: String(profile?.name || 'Cấu hình đã lưu').slice(0, 100),
            windows: windows.length,
            concurrency: 2,
            maxActive: run.maxActive,
            wallMs: Math.round(run.elapsedMs),
            serialEstimateMs: Math.round(serialEstimateMs),
            speedup: Number(speedup.toFixed(2)),
            retryWindows,
            totalRequests: attempts.reduce((sum, value) => sum + Number(value || 0), 0),
            summaryCoverage: Number(summaryCoverage.toFixed(4)),
            evidenceRate: Number(evidenceRate.toFixed(4)),
            artifacts: {
                summaries: merged.turn_summaries.length,
                facts: merged.facts_upsert.length,
                events: merged.event_fragments.length,
                people: merged.person_observations.length,
                clues: merged.clue_fragments.length,
            },
            committedWorldState: false,
        };
        globalThis.__WB_HISTORY_PARALLEL_LAB_RESULT__ = metrics;

        const coverageLabel = `${Math.round(summaryCoverage * 100)}%`;
        const evidenceLabel = evidenceChecked ? `${Math.round(evidenceRate * 100)}%` : 'Không có mục để đối chứng';
        setStatus(
            `Hoàn tất: ${windows.length} cửa sổ｜đồng thời tối đa ${run.maxActive}｜thực tế ${(run.elapsedMs / 1000).toFixed(1)}s｜`
            + `Nếu chạy tuần tự cùng đợt khoảng ${(serialEstimateMs / 1000).toFixed(1)}s｜khoảng ${speedup.toFixed(2)}×｜`
            + `Thử lại định dạng ${retryWindows} cửa sổ｜độ phủ L0 ${coverageLabel}｜tỷ lệ khớp bằng chứng nguyên văn ${evidenceLabel}. Không ghi vào thế giới.`,
            summaryCoverage === 1 && evidenceRate >= 0.95 && retryWindows <= Math.max(1, Math.floor(windows.length * 0.15))
                ? 'success'
                : 'warning',
        );
    } catch (error) {
        const message = String(error?.cause?.message || error?.message || error || 'Lỗi không xác định');
        const rateLimited = /429|rate.?limit|too many requests|限流|giới hạn tốc độ|quá nhiều yêu cầu/i.test(message);
        setStatus(
            rateLimited
                ? 'Thử nghiệm song song bị giới hạn tốc độ, toàn bộ ứng viên lượt này đã bị loại bỏ, thế giới chính thức không bị động đến. API này hiện chưa hợp để chạy song song.'
                : `Thử nghiệm song song dừng lại: ${message.slice(0, 300)}. Toàn bộ kết quả ứng viên đã bị loại bỏ, thế giới chính thức không bị động đến.`,
            'error',
        );
        throw error;
    } finally {
        activeRun = null;
        setButtonRunning(false);
    }
}

function mount() {
    const host = document.querySelector('#world-backstage-root .wb-world-bootstrap-settings');
    if (!host || document.getElementById(BUTTON_ID)) return;
    const wrap = document.createElement('div');
    wrap.className = 'wb-history-parallel-lab';
    wrap.innerHTML = `
        <button type="button" id="${BUTTON_ID}">🧪 Thử nghiệm truy hồi song song (không ghi vào thế giới)</button>
        <p id="${STATUS_ID}">Lối vào thử nghiệm của kho test: dùng hai cửa sổ yêu cầu độc lập để đo thời gian thực và độ ổn định của bằng chứng; không sửa nhân vật, ký ức, Mạch ngầm hay thời gian thế giới.</p>
    `;
    host.appendChild(wrap);
    wrap.querySelector(`#${BUTTON_ID}`)?.addEventListener('click', () => {
        void runLab().catch(error => console.warn('[世界背面] Thử nghiệm lịch sử song song chưa hoàn tất', error));
    });
}

function start() {
    mount();
    const observer = new MutationObserver(mount);
    observer.observe(document.documentElement, { childList: true, subtree: true });
    window.addEventListener('pagehide', () => {
        activeRun?.controller?.abort?.();
        observer.disconnect();
    }, { once: true });
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
else start();
