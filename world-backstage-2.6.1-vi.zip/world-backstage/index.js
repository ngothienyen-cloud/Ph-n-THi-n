import { PLUGIN_VERSION } from './version.js';
import { CHARACTER_PROFILE_FIELDS, readCharacterProfile, applyImportedCharacterValues, appendWorldbookProvenance } from './character-profiles.js';
import {
    MODULE_ID,
    SCHEMA_VERSION,
    SNAPSHOT_KEY,
    STATE_KEY,
    addRecoveryPoint,
    addManualEvent,
    advanceWorldClock,
    applySimulationResult,
    applyHistoryIndexResult,
    applyWorldBootstrapResult,
    applyPublicImpactResult,
    applyMemoryRollupResult,
    buildInjectionPackage,
    buildHistoryIndexPrompt,
    buildWorldBootstrapPrompt,
    buildWorldPulsePrompt,
    buildPublicImpactPrompt,
    buildMemoryRollupPrompt,
    buildPersonObservationPrompt,
    buildSimulationPrompt,
    buildStateCorrectionPrompt,
    applyStateCorrectionResult,
    createInitialState,
    createCompactSnapshot,
    DEFAULT_TAG_FILTER_RULES,
    extractJsonObject,
    extractTagFilterCandidates,
    extractNarrativeTimeAnchor,
    filterNarrativeText,
    formatWorldCalendar,
    formatWorldClockFactLabel,
    isPersonObservationEligible,
    personObservationSceneRelation,
    countSurvivingNewAssistantTurns,
    hashText,
    selectPendingAssistantMessageIds,
    listRecoveryPoints,
    listDueBackgroundPeople,
    listRecoveryPointHeaders,
    markPendingSync,
    markCurrentPublicImpactsProcessed,
    markWorldCoverageChecked,
    pendingPublicImpactEvents,
    publicWorldCoverageDue,
    normalizeTagFilterRules,
    planMemoryRollup,
    recordDeliveryOffers,
    restoreCompactSnapshot,
    restoreRecoveryPoint,
    setWorldCalendar,
    settlePersonWorldState,
    selectWorldCoverageTargets,
    trimState,
} from './core.js';
import {
    getLastCustomApiOperation,
    getRetryControlStatus,
    isAbortError,
    requestCustomCompletion,
    requestCustomModels,
    requestImageGeneration,
    resetLastCustomApiOperation,
    resetRetryControl,
    runWithRetries,
} from './api.js';
import { createWorldBackstageUI } from './ui.js';
import { compactBranchDataMemory, compactSnapshotMemory, compactSnapshotMemoryLedgers } from './snapshot-memory-dedupe.js';
import { branchRecordMatchesSource, committedBranchMatchesSource, readBranchRecord } from './branch-history.js';
import {
    branchSurfaceKeyFromState,
    captureBranchSurface,
    ensureBranchSurfaceHistory,
    hasBranchSurface,
    inheritBranchSurface,
    rebindBranchSurface,
    restoreBranchSurface,
} from './branch-surface-history.js';
import {
    appendUserSocialMessage,
    applyFriendDecisionPayload,
    applyMomentsPayload,
    applySocialPulsePayload,
    applySocialReplyPayload,
    attachMomentImage,
    buildFriendRequestPrompt,
    buildMomentsPrompt,
    buildSocialPulsePrompt,
    buildSocialReplyPrompt,
    createGroupConversation,
    emptySocialState,
    markSocialNoticeRead,
    normalizeSocialState,
    pendingSocialConversations,
    openDirectConversation,
    reconcileSocialRelationships,
    removeSocialFriend,
    respondIncomingFriendRequest,
    selectSocialConversation,
    setSocialConversationError,
    settleSocialConversations,
    toggleMomentLike,
} from './social-terminal.js';
import { buildBackstageMessages } from './prompt-bridge.js';
import { normalizeClueTiming, resolveFutureTimeExpression } from './world-clock-authority.js';
import { INTERNAL_COMPAT_SYSTEM_PROMPT } from './internal-compat.js';
import {
    buildWorldbookImportPrompt,
    matchImportTarget,
    mergeImportedDrafts,
    normalizeImportedPeople,
    planImportWrites,
    planReviewedImportWrites,
    groupWorldbookPersonEntries,
    resolveWorldbookPersonName,
    planWorldbookImportBatches,
    splitLongEntries,
    summarizeUntouchedEntries,
    detectWorldbookCharacter,
    detectWorldbookTechnicalEntry,
    extractWorldbookCharacterCandidates,
    extractWorldbookCharacterProfile,
    isWorldbookEntryManuallySelectable,
    planSmartWorldbookImport,
} from './worldbook.js';
import {
    buildPublicOpinionPrompt,
    buildPublicOpinionSandboxPrompt,
    eligiblePublicOpinionEvents,
    emptyPublicOpinionCache,
    emptyPublicOpinionSandbox,
    normalizePublicOpinionCache,
    normalizePublicOpinionPayload,
    mergePublicOpinionStream,
    planPublicOpinionRefresh,
    publicOpinionSourceSignature,
    normalizePublicOpinionSandbox,
    normalizePublicOpinionSandboxPayload,
} from './public-opinion.js';
import {
    activeLingqiNotes,
    addLingqiMessage,
    applyLingqiDirectorResult,
    buildLingqiChatPrompt,
    buildLingqiDirectorInjection,
    confirmLingqiProposal,
    consumeLingqiDirectorOffer,
    dismissLingqiProposal,
    emptyLingqiState,
    normalizeLingqiAssistantPayload,
    normalizeLingqiState,
    setLingqiNoteStatus,
    shouldAutoConfirmLingqiProposal,
} from './lingqi.js';
import {
    LINGQI_SAFE_SETTING_KEYS,
    buildLingqiHelpContext,
} from './lingqi-help.js';
import {
    findLingqiChatMatches,
    lingqiChatSnapshotSignature,
    parseLingqiLocalChatDeleteRequest,
    resolveLingqiChatDeletionPlan as buildLingqiChatDeletionPlan,
} from './lingqi-chat.js';
import {
    LINGQI_SETTING_GUIDES,
    buildLingqiSkillMenuText,
    parseLingqiLocalQueryRequest,
} from './lingqi-skills.js';
import { LINGQI_MASCOT_DATA_URLS } from './lingqi-assets.js';
import {
    AUTO_HIDE_KEEP_RECENT_MESSAGES,
    markAutoHiddenMessages,
    restoreAutoHiddenMessages,
} from './auto-hide.js';

const PROMPT_KEY = 'world_backstage_authoritative_state';
const SUPPORT_PROMPT_KEY = 'world_backstage_context_support';
const DEFAULT_SETTINGS = Object.freeze({
    settingsVersion: 32,
    enabled: true,
    promptInjection: true,
    worldSimulationEnabled: true,
    worldPromptInjection: true,
    injectionTimeMode: 'full',
    injectionWorldBackground: true,
    injectionPeople: true,
    injectionEvents: true,
    injectionEchoes: true,
    injectionFacts: true,
    injectionMemory: true,
    injectionPublicOpinion: true,
    // Social messages are conversation records, not settled world facts.
    // Keep narrative influence opt-in even when the main injection switch is on.
    injectionSocial: false,
    socialAutoEnabled: true,
    socialInstantReply: true,
    memorySystemEnabled: true,
    memoryPromptInjection: true,
    autoSync: true,
    worldAutoEnabled: true,
    autoSimulationMode: 'balanced',
    worldPulseActivity: 'natural',
    autoSimulationInterval: 1,
    pendingSimulationPromptEnabled: false,
    autoRetryCount: 1,
    memoryAutoIndexInterval: 10,
    autoHideArchivedFloors: false,
    backgroundNpcBudget: 4,
    enhancedBackgroundSimulation: false,
    customSimulationInstruction: '',
    playerIdentityAnchor: '',
    theme: 'auto',
    deliveryDensity: 'restrained',
    sceneTiming: 'strict',
    orbPosition: null,
    orbEnabled: true,
    orbEdgeHide: false,
    recordPlayerCharacter: true,
    includeUserInnerVoice: false,
    uiScale: 'comfortable',
    contextTurns: 5,
    customContextTurns: 8,
    timePolicy: 'world',
    apiMode: 'tavern',
    tavernApiProfileId: '',
    customApiUrl: '',
    customApiKey: '',
    customApiModel: '',
    customApiTransport: 'proxy',
    customApiTimeoutMs: 120000,
    imageApiEnabled: false,
    imageApiUrl: '',
    imageApiKey: '',
    imageApiModel: '',
    imageApiSize: '1024x1024',
    imageApiTimeoutMs: 180000,
    apiProfiles: [],
    apiModuleRoutes: {
        simulation: 'default',
        observation: 'default',
        history: 'default',
        opinion: 'default',
    },
    publicOpinionRevealMode: 'observe',
    publicOpinionAutoEnabled: true,
    // 0 = automatic task budget. A positive value is a global upper cap.
    maxOutputTokens: 0,
    // 0 = module-aware automatic timeout. This counts active request time only.
    generationTimeoutMs: 0,
    generationModuleLimits: {
        simulation: { maxTokens: 0, timeoutMs: 0 },
        observation: { maxTokens: 0, timeoutMs: 0 },
        history: { maxTokens: 0, timeoutMs: 0 },
        opinion: { maxTokens: 0, timeoutMs: 0 },
    },
    tagFilterEnabled: true,
    tagFilterRules: DEFAULT_TAG_FILTER_RULES.map(rule => ({ ...rule })),
    narrativeIncludeTag: '',
    narrativeRegexFilters: '',
});

const runtime = {
    initialized: false,
    ui: null,
    transientStore: null,
    preparedStores: new WeakSet(),
    injection: { text: '', eventIds: [], directorNoteIds: [] },
    generationOffer: { eventIds: [], directorNoteIds: [], at: 0, rerollBase: false },
    simulationChain: Promise.resolve(),
    simulationCount: 0,
    dataEpoch: 0,
    activeSimulation: null,
    autoCatchUpSuppressedThroughMessageId: -1,
    activeHistoryScan: null,
    activeWorldPulse: null,
    activePublicImpact: null,
    activeCorrection: null,
    pendingPublicImpact: false,
    activePublicOpinion: null,
    publicOpinionRefreshTransaction: null,
    activePublicOpinionSandbox: null,
    pendingPublicOpinion: false,
    activeObservation: null,
    activeLingqi: null,
    lingqiStatus: { phase: 'idle', message: '', error: '' },
    activeSocial: null,
    socialStatus: { phase: 'idle', message: '', error: '', conversationId: '' },
    activeFriendRequest: null,
    friendRequestStatus: { phase: 'idle', message: '', error: '', personId: '' },
    activeMoments: null,
    momentsStatus: { phase: 'idle', message: '', error: '' },
    activeSocialPulse: null,
    socialPulseTimer: null,
    pendingLingqiAction: null,
    inBackgroundGeneration: false,
    consistencyBarrierRunning: false,
    activeChatToken: '',
    contextEpoch: 0,
    queuedSimulations: new Map(),
    connectionLanes: new Map(),
    apiRequestTimeline: [],
    lastRequestShape: null,
    settingsPersistence: {
        saveRequests: 0,
        lastSaveRequestedAt: '',
        lastSaveFields: [],
    },
    installationDiagnostics: null,
    pendingManualSimulation: null,
    manualSimulationTimer: null,
    autoMemoryTimer: null,
    autoHideTimer: null,
    publicImpactTimer: null,
    publicOpinionTimer: null,
    manualUndo: null,
    manualUndoTimer: null,
    editDecision: null,
    customModels: [],
    modelPullStatus: { phase: 'idle', message: '' },
    lastPromptBridge: null,
    lastTaskConnection: null,
    lastTaskTrace: null,
    publicOpinionStatus: {
        phase: 'idle',
        message: 'Dư luận còn chưa mở hàng đâu～',
        error: '',
    },
    publicOpinionSandboxStatus: {
        phase: 'idle',
        message: '',
        error: '',
    },
    worldbookScan: {
        phase: 'idle',
        message: '',
        bookName: '',
        entries: [],
    },
    worldbookImport: emptyWorldbookImportReport(),
    worldbookImportDrafts: [],
    worldbookImportSession: null,
    worldbookImportRunning: false,
    worldbookImportController: null,
    historyProgress: {
        kind: 'memory',
        phase: 'idle',
        processed: 0,
        total: 0,
        message: '',
    },
    syncStatus: {
        phase: 'idle',
        message: 'Chưa suy diễn lần nào～thế giới đang đợi bạn ở đây',
        error: '',
        attemptedAt: '',
        succeededAt: '',
        method: '',
        summary: null,
    },
};

function clone(value) {
    if (typeof structuredClone === 'function') return structuredClone(value);
    return JSON.parse(JSON.stringify(value));
}

function getContext() {
    return globalThis.SillyTavern?.getContext?.() || null;
}

function recentNarrativeForSocial(context = getContext(), limit = 12) {
    return (Array.isArray(context?.chat) ? context.chat : [])
        .filter(message => message && !message.is_system)
        .slice(-Math.max(2, Number(limit) || 12))
        .map(message => {
            if (message.is_user) return String(message.mes || '').trim();
            const swipeId = Number(message.swipe_id ?? 0);
            return String(message.swipes?.[swipeId] ?? message.mes ?? '').trim();
        })
        .filter(Boolean)
        .join('\n')
        .slice(-18000);
}
function getWorldbookNames() {
    const names = getContext()?.getWorldInfoNames?.();
    return Array.isArray(names)
        ? [...new Set(names.map(name => String(name || '').trim()).filter(Boolean))]
            .sort((a, b) => a.localeCompare(b, 'zh-CN'))
        : [];
}

function worldbookEntryLabel(entry) {
    const keys = Array.isArray(entry?.key)
        ? entry.key
        : typeof entry?.key === 'string' ? [entry.key] : [];
    return String(entry?.comment || keys[0] || `Mục ${entry?.uid ?? ''}`)
        .trim()
        .slice(0, 80);
}

async function scanWorldbook(bookName) {
    const name = String(bookName || '').trim();
    const context = getContext();
    if (!name) throw new Error('Chọn một cuốn World Info cho mình xem đi mà～');
    if (typeof context?.loadWorldInfo !== 'function') {
        throw new Error('Phiên bản Tavern hiện tại không mở API đọc World Info');
    }
    discardWorldbookDrafts();
    const chatToken = currentChatToken();
    const scanToken = {};
    runtime.worldbookScanToken = scanToken;
    runtime.worldbookScan = {
        phase: 'running',
        message: `Đang lật xem《${name}》～đợi chút xíu nhé`,
        bookName: name,
        entries: [],
    };
    runtime.worldbookImport = emptyWorldbookImportReport();
    runtime.worldbookImportDrafts = [];
    runtime.worldbookImportSession = null;
    runtime.ui?.render();

    try {
        const data = await context.loadWorldInfo(name);
        if (currentChatToken() !== chatToken || runtime.worldbookScanToken !== scanToken) throw Object.assign(new Error('Lượt quét World Info đã bị hủy, hãy quét lại'), { name: 'AbortError' });
        const sourceEntries = Object.values(data?.entries || {})
            .filter(entry => entry && String(entry.content || '').trim())
            .map(entry => {
                const entryName = worldbookEntryLabel(entry);
                const content = String(entry.content || '').trim();
                const keys = [...new Set([
                    ...(Array.isArray(entry.key) ? entry.key : [entry.key]),
                    ...(Array.isArray(entry.keysecondary) ? entry.keysecondary : [entry.keysecondary]),
                ].map(key => String(key || '').trim()).filter(Boolean))].slice(0, 12);
                const tags = [...new Set([
                    entry.group,
                    entry.position,
                    entry.role,
                ].map(tag => String(tag || '').trim()).filter(Boolean))].slice(0, 8);
                const formatHints = [...new Set(
                    [...content.matchAll(/<\s*([a-zA-Z][\w:-]*)\b/g)]
                        .map(match => String(match[1] || '').toLocaleLowerCase())
                        .filter(Boolean),
                )].slice(0, 12);
                const profile = extractWorldbookCharacterProfile(content, entryName);
                const identity = resolveWorldbookPersonName({ name: entryName, keys }, profile);
                profile.name = identity.name;
                const detection = detectWorldbookCharacter({
                    name: entryName,
                    content,
                    keys,
                    tags,
                    formatHints,
                }, profile);
                const technical = detectWorldbookTechnicalEntry({
                    name: entryName,
                    content,
                    keys,
                    tags,
                });
                const embedded = extractWorldbookCharacterCandidates({
                    name: entryName,
                    content,
                    keys,
                    tags,
                });

                return {
                    uid: String(entry.uid ?? ''),
                    name: entryName,
                    parsedName: profile.name !== entryName || profile.explicitName ? profile.name : '',
                    content,
                    keys,
                    tags,
                    formatHints,
                    disabled: Boolean(entry.disable),
                    order: Number(entry.order) || 0,
                    profile,
                    ...detection,
                    ...technical,
                    embedded,
                };
            })
            .sort((a, b) => Number(a.disabled) - Number(b.disabled) || b.order - a.order)
            .slice(0, 1000);

        const entries = [];
        for (const source of sourceEntries) {
            const embeddedPeople = source.embedded.filter(item => !item.technicalEntry);
            const shouldSplitEmbedded = embeddedPeople.length >= 2
                || (embeddedPeople.length === 1 && (!source.likelyPerson || source.technicalEntry || embeddedPeople[0].name !== source.profile.name));

            if (!shouldSplitEmbedded) {
                const importablePerson = Boolean(
                    source.likelyPerson
                    && !source.technicalEntry
                    && !source.disabled
                );
                entries.push({
                    ...source,
                    embedded: undefined,
                    importablePerson,
                    manualSelectablePerson: true,
                    smartAuto: importablePerson,
                    sourceUid: source.uid,
                    sourceEntryName: source.name,
                });
                continue;
            }

            // Keep the parent setting entry visible for context/search, but it is not a selectable person.
            entries.push({
                ...source,
                embedded: undefined,
                likelyPerson: false,
                importablePerson: false,
                manualSelectablePerson: false,
                smartAuto: false,
                mixedSource: true,
                sourceUid: source.uid,
                sourceEntryName: source.name,
                characterSignals: [
                    `Chứa ${embeddedPeople.length} nhân vật`,
                    ...(source.characterSignals || []),
                ].slice(0, 4),
            });

            embeddedPeople.forEach((candidate, index) => {
                const stableNameKey = hashText(candidate.name.toLocaleLowerCase());
                entries.push({
                    uid: `${source.uid}::person::${stableNameKey}`,
                    sourceUid: source.uid,
                    sourceEntryName: source.name,
                    name: candidate.name,
                    parsedName: candidate.name,
                    content: candidate.content,
                    originalContent: source.content,
                    keys: source.keys,
                    tags: [...new Set([...(source.tags || []), 'Nhân vật trong mục'])].slice(0, 8),
                    formatHints: source.formatHints,
                    disabled: source.disabled,
                    order: source.order - (index + 1) / 1000,
                    profile: candidate.profile,
                    likelyPerson: true,
                    importablePerson: true,
                    manualSelectablePerson: true,
                    smartAuto: candidate.confidence === 'high',
                    embeddedPerson: true,
                    characterScore: candidate.characterScore,
                    characterSignals: [
                        `Tách ra từ “${source.name}”`,
                        candidate.confidence === 'high' ? 'Thông tin nhân vật khá đầy đủ' : 'Thông tin nhân vật cần xác nhận',
                    ],
                    technicalEntry: false,
                    technicalScore: 0,
                    technicalSignals: [],
                });
            });
        }

        const plan = planSmartWorldbookImport(entries);
        const embeddedCount = entries.filter(entry => entry.embeddedPerson).length;
        runtime.worldbookScan = {
            phase: 'success',
            message: entries.length
                ? [
                    `Đã lật được ${sourceEntries.length} mục World Info`,
                    `Nhận diện được ${entries.filter(entry => entry.importablePerson).length} ứng viên nhân vật`,
                    embeddedCount ? `Trong đó ${embeddedCount} mục được tách ra từ mục hỗn hợp` : '',
                    plan.skippedTechnical.length ? `Bỏ qua ${plan.skippedTechnical.length} mục kỹ thuật/MVU` : '',
                ].filter(Boolean).join(' · ')
                : 'Cuốn World Info này tạm thời chưa lục ra được nội dung đọc được nè～',
            bookName: name,
            entries,
            smartPlan: {
                autoCount: plan.auto.length,
                reviewCount: plan.review.length,
                skippedTechnicalCount: plan.skippedTechnical.length,
                skippedDisabledCount: plan.skippedDisabled.length,
            },
        };
        return runtime.worldbookScan;
    } catch (error) {
        if (isAbortError(error)) throw error;
        runtime.worldbookScan = {
            phase: 'error',
            message: `Đọc không thành công QAQ: ${describeError(error)}`,
            bookName: name,
            entries: [],
        };
        throw error;
    } finally {
        runtime.ui?.render();
    }
}

const IMPORTABLE_PERSON_FIELDS = Object.freeze(CHARACTER_PROFILE_FIELDS.map(field => field.key));

// 审校台要显示这次会新建还是更新谁，以及匹配是否有歧义。
function describeImportTarget(state, draft) {
    const match = matchImportTarget(state?.people, draft);
    return {
        existing: Boolean(match.person),
        existingName: match.person?.name || '',
        matchedBy: match.matchedBy,
        ambiguous: match.ambiguous,
        targetId: match.person?.id || '',
        retainedFields: IMPORTABLE_PERSON_FIELDS.filter(field => match.person?.[field] && match.person[field] !== match.person.worldbookImportedValues?.[field]),
        candidates: (state?.people || []).filter(person => String(person.name).toLocaleLowerCase() === String(draft.name).toLocaleLowerCase()).map(person => ({ id: person.id, name: person.name, source: person.worldbookSourceEntry || person.worldbookRef || 'Thẻ nhân vật hiện có' })),
    };
}

// 规则导入与 AI 整理导入共用的写入口。默认只补空栏位，绝不覆盖作者已经写好的
// 设定；只有仍与导入记录一致的栏位才能继续拼接。
function upsertImportedPerson(next, {
    name,
    reference,
    // 上游的智能拆分会把一条世界书拆成多个候选，sourceReference / sourceEntryName
    // 记的是拆分前那条原始条目。AI 整理没有拆分层，默认回落到 reference 本身。
    sourceReference = '',
    sourceEntryName = '',
    values = {},
    worldbookRaw = '',
    aliases = [],
    sourceContent = '',
    sources = [],
    references = [],
    targetId = '',
    createNew = false,
    allowRename = false,
    claimedIds = null,
} = {}) {
    const importedName = String(name || '').trim().slice(0, 80);
    if (!importedName) return null;
    // Ambiguous existing records require an explicit target in the review UI.
    const match = matchImportTarget(next.people, { reference, references, name: importedName, aliases, targetId, createNew }, claimedIds);
    if (match.ambiguous) throw new Error(`「${importedName}」 khớp với nhiều bản ghi hiện có, hãy dùng AI sắp xếp và duyệt để chọn vị trí ghi`);
    const existing = match.person;
    if (targetId && !existing) throw new Error('Nhân vật hiện có đã chọn đã thay đổi, hãy sắp xếp lại');
    if (existing?.locked) throw new Error(`「${existing.name}」 đã bị khóa, hãy mở khóa trước rồi mới nhập`);

    if (existing) {
        let renamed = '';
        applyImportedCharacterValues(existing, values);
        // 旧的正则导入会把「南枫 nicknames: [...] version: 4」整串当成名字。
        // 重新整理时如果认出了干净的名字，就把这条记录修回来。
        if (
            allowRename
            && existing.worldbookRef
            && existing.name !== importedName
            && existing.name.length > importedName.length
            && existing.name.includes(importedName)
        ) {
            renamed = existing.name;
            existing.name = importedName;
            existing.monogram = importedName.slice(0, 1);
        }
        appendWorldbookProvenance(existing, { reference, sources, raw: worldbookRaw });
        existing.worldbookRefs = [...new Set([...existing.worldbookRefs, ...references])];
        existing.worldbookRef = reference;
        existing.worldbookSourceRef = sourceReference || reference;
        existing.worldbookSourceEntry = sourceEntryName;
        existing.manual = true;
        existing.updatedAt = next.clock.absoluteMinute;
        claimedIds?.add(existing.id);
        return { outcome: 'updated', id: existing.id, name: importedName, renamedFrom: renamed };
    }

    const baseId = `person_worldbook_${hashText(reference)}`;
    let id = baseId;
    let suffix = 1;
    while (next.people.some(person => person.id === id)) id = `${baseId}_${suffix++}`;
    next.people.push({
        id,
        name: importedName,
        monogram: importedName.slice(0, 1),
        location: 'Vị trí chờ xác nhận',
        action: 'Hành động hiện tại chờ xác nhận',
        intent: 'Ý định ngắn hạn chờ xác nhận',
        longTermGoal: '',
        identityAnchor: values.identityAnchor || '',
        personalityAnchor: values.personalityAnchor || '',
        appearanceProfile: values.appearanceProfile || '',
        backgroundProfile: values.backgroundProfile || '',
        abilityProfile: values.abilityProfile || '',
        worldbookImportedValues: { ...values },
        worldbookRefs: [...new Set([reference, ...references])],
        worldbookSources: sources,
        worldbookRaw,
        speakingStyle: values.speakingStyle || '',
        behaviorBoundaries: values.behaviorBoundaries || '',
        trace: '',
        innerVoice: '',
        innerVoiceAt: next.clock.absoluteMinute,
        knowledge: 'hidden',
        relevance: 1,
        simulationEnabled: true,
        locked: false,
        manual: true,
        source: 'manual',
        isUser: false,
        lastSeenMessageId: -1,
        worldbookRef: reference,
        worldbookSourceRef: sourceReference || reference,
        worldbookSourceEntry: sourceEntryName,
        updatedAt: next.clock.absoluteMinute,
    });
    claimedIds?.add(id);
    return { outcome: 'created', id, name: importedName, renamedFrom: '' };
}

// 规则导入只收智能拆分认定可导入的人物条目；AI 整理的存在意义恰恰是处理正则
// 认不出来的写法，所以那条路线不套 importablePerson，但同样不喂技术条目。
function selectedWorldbookEntries(bookName, entryIds = [], { requirePerson = true } = {}) {
    const name = String(bookName || '').trim();
    if (runtime.worldbookScan.bookName !== name) {
        throw new Error('Bản xem trước World Info đã thay đổi, hãy quét lại');
    }
    const wanted = new Set((Array.isArray(entryIds) ? entryIds : [entryIds]).map(String));
    const selected = runtime.worldbookScan.entries.filter(entry => (
        wanted.has(String(entry.uid))
        && isWorldbookEntryManuallySelectable(entry)
        && (requirePerson || !entry.technicalEntry)
    ));
    if (!selected.length) throw new Error('Hãy tích chọn ít nhất một mục nhân vật');
    return { bookName: name, selected };
}

function importWorldbookPeople(bookName, entryIds = []) {
    const { bookName: name, selected } = selectedWorldbookEntries(bookName, entryIds);
    const next = clone(getState());
    const claimedIds = new Set();
    let created = 0;
    let updated = 0;
    for (const candidate of groupWorldbookPersonEntries(selected)) {
        const reference = `${name}::${candidate.uid}`;
        const sourceReference = `${name}::${candidate.sourceUid || candidate.uid}`;
        const profile = candidate.profile || extractWorldbookCharacterProfile(candidate.content, candidate.name);
        const importedName = String(profile.name || candidate.parsedName || candidate.name || '').trim().slice(0, 80);
        const result = upsertImportedPerson(next, {
            name: importedName,
            reference,
            sourceReference,
            sourceEntryName: candidate.sourceEntryName || candidate.name || '',
            values: readCharacterProfile(profile),
            references: candidate.members.map(member => `${name}::${member.uid}`),
            sources: candidate.members.map(member => ({ reference: `${name}::${member.sourceUid || member.uid}`, entryName: member.sourceEntryName || member.name, content: member.originalContent || member.content })),
            worldbookRaw: [...new Set(candidate.members.map(member => member.originalContent || member.content))].join('\n\n'),
            aliases: candidate.members.map(member => member.name),
            sourceContent: candidate.content,
            claimedIds,
        });
        if (result?.outcome === 'created') created += 1;
        if (result?.outcome === 'updated') updated += 1;
    }
    const importedPeople = next.people.filter(person => (
        person.worldbookRef
        && selected.some(candidate => `${name}::${candidate.uid}` === person.worldbookRef)
    ));
    commitManualState(
        next,
        `Đã nhập nhân vật từ World Info: thêm mới ${created} người, cập nhật ${updated} người.`,
        {
            mutateStore: store => {
                for (const person of importedPeople) clearPersonDeletionTombstone(store, person);
            },
        },
    );
    return { created, updated };
}

async function smartImportWorldbookPeople(bookName) {
    const name = String(bookName || '').trim();
    if (!name) throw new Error('Chọn một cuốn World Info cho mình xem đi mà～');

    let scan = runtime.worldbookScan;
    if (scan.bookName !== name || scan.phase !== 'success' || !Array.isArray(scan.entries)) {
        scan = await scanWorldbook(name);
    }

    const plan = planSmartWorldbookImport(scan.entries);
    if (!plan.auto.length) {
        if (plan.review.length) {
            return {
                created: 0,
                updated: 0,
                reviewCount: plan.review.length,
                skippedTechnicalCount: plan.skippedTechnical.length,
                needsReview: true,
            };
        }
        throw new Error('Cuốn World Info này tạm thời chưa nhận diện được nhân vật nào có thể tự động nhập an toàn');
    }

    const result = importWorldbookPeople(
        name,
        plan.auto.map(entry => entry.uid),
    );
    return {
        ...result,
        reviewCount: plan.review.length,
        skippedTechnicalCount: plan.skippedTechnical.length,
        importedCount: plan.auto.length,
    };
}

function emptyWorldbookImportReport() {
    return {
        phase: 'idle',
        message: '',
        bookName: '',
        created: 0,
        updated: 0,
        token: '',
        people: [],
        skipped: [],
        untouched: [],
        failures: [],
        renamed: [],
    };
}

function discardWorldbookDrafts() {
    runtime.worldbookImportController?.abort();
    runtime.worldbookImportController = null;
    runtime.worldbookImportRunning = false;
    runtime.worldbookImportDrafts = [];
    runtime.worldbookImportSession = null;
    runtime.worldbookImport = emptyWorldbookImportReport();
    runtime.ui?.render();
    return true;
}

// 审校台按「确认」后才走到这里。selections 只带人物与栏位的取舍，值本身仍然
// 取自 runtime 里那份已经过原文回查的草稿，不接受界面回传的正文。
function commitWorldbookDrafts(selections = [], { token = '', bookName = '' } = {}) {
    const pending = Array.isArray(runtime.worldbookImportDrafts) ? runtime.worldbookImportDrafts : [];
    if (!pending.length) throw new Error('Không có kết quả sắp xếp nào chờ xác nhận, hãy sắp xếp lại một lần');

    // 草稿绑定在生成它的聊天与世界书上。三者任一对不上就作废，绝不把上一个
    // 聊天整理出来的人物写进当前世界。
    const session = runtime.worldbookImportSession;
    const mismatch = !session
        || !token || !bookName
        || runtime.worldbookScan.bookName !== session.bookName
        || session.contextEpoch !== runtime.contextEpoch
        || session.chatToken !== currentChatToken()
        || (token && session.token !== String(token))
        || (bookName && session.bookName !== String(bookName));
    if (mismatch) {
        discardWorldbookDrafts();
        throw new Error('Bản nháp sắp xếp này không thuộc cuộc trò chuyện hoặc World Info hiện tại, đã bị hủy; hãy sắp xếp lại một lần');
    }

    const next = clone(getState());
    const claimedIds = new Set();
    const renamed = [];
    const changedIds = new Set();
    let created = 0;
    let updated = 0;
    const writes = planReviewedImportWrites(pending, selections);
    const skippedByUser = pending.length - (Array.isArray(selections) ? selections.length : 0);
    for (const draft of writes) {
        const result = upsertImportedPerson(next, {
            ...draft,
            worldbookRaw: draft.sourceContent,
            sourceReference: draft.sources?.[0]?.reference || draft.reference,
            sourceEntryName: [...new Set((draft.sources || []).map(source => source.entryName))].join('、'),
            allowRename: true,
            claimedIds,
        });
        if (result?.outcome === 'created') created += 1;
        if (result?.outcome === 'updated') updated += 1;
        if (result?.id) changedIds.add(result.id);
        if (result?.renamedFrom) renamed.push({ from: result.renamedFrom, to: result.name });
    }

    if (!created && !updated) throw new Error('Chưa tích chọn nội dung nào để ghi');

    const previous = runtime.worldbookImport || emptyWorldbookImportReport();
    runtime.worldbookImportDrafts = [];
    runtime.worldbookImportSession = null;
    runtime.worldbookImport = {
        ...previous,
        phase: 'success',
        people: [],
        token: '',
        created,
        updated,
        renamed,
        message: [
            `Đã ghi: thêm mới ${created} người, cập nhật ${updated} người`,
            skippedByUser ? `${skippedByUser} người đã bị bạn hủy` : '',
        ].filter(Boolean).join('；'),
    };
    commitManualState(next, `AI sắp xếp nhập: thêm mới ${created} người, cập nhật ${updated} người.`, { mutateStore: store => {
        for (const person of next.people) if (changedIds.has(person.id)) clearPersonDeletionTombstone(store, person);
    } });
    return { created, updated, skippedByUser };
}

// Re-read selected source IDs before generation. A missing or changed embedded
// person requires a fresh scan; never silently fall back to a truncated preview.
async function loadFullWorldbookEntries(bookName, selected) {
    const context = getContext();
    if (typeof context?.loadWorldInfo !== 'function') throw new Error('Tavern hiện tại không mở API đọc World Info');
    const data = await context.loadWorldInfo(bookName);
    const byUid = new Map(Object.values(data?.entries || {}).filter(Boolean).map(entry => [String(entry.uid ?? ''), entry]));
    return selected.map(entry => {
        const source = byUid.get(String(entry.sourceUid || entry.uid));
        if (!source) throw new Error(`Nguồn「${entry.sourceEntryName || entry.name}」 đã thay đổi, hãy quét lại`);
        const originalContent = String(source.content || '').trim();
        if (!originalContent) throw new Error(`Nguồn「${entry.name}」 đã bị xóa trống, hãy quét lại`);
        if (entry.embeddedPerson) {
            const candidate = extractWorldbookCharacterCandidates({ ...entry, name: entry.sourceEntryName, content: originalContent })
                .find(person => person.name === entry.parsedName);
            if (!candidate) throw new Error(`「${entry.name}」 có cấu trúc nguồn đã thay đổi, hãy quét lại`);
            return { ...entry, content: candidate.content, originalContent, profile: candidate.profile };
        }
        return { ...entry, content: originalContent, originalContent };
    });
}

async function runWorldbookAiImport(bookName, entryIds = []) {
    const { bookName: name, selected: scanned } = selectedWorldbookEntries(bookName, entryIds, {
        requirePerson: false,
    });
    if (runtime.worldbookImportRunning) throw new Error('Lần AI sắp xếp trước vẫn đang chạy～đợi nó xong rồi hẵng làm');

    const chatToken = currentChatToken();
    const contextEpoch = runtime.contextEpoch;
    const controller = new AbortController();
    runtime.worldbookImportController = controller;
    runtime.worldbookImportDrafts = [];
    runtime.worldbookImportSession = null;
    runtime.worldbookImportRunning = true;
    runtime.worldbookImport = { ...emptyWorldbookImportReport(), phase: 'running', bookName: name, message: 'Đang đọc toàn bộ nguồn…' };
    runtime.ui?.render();
    const abortIfChatChanged = () => {
        if (!controller.signal.aborted && runtime.worldbookImportController === controller && runtime.contextEpoch === contextEpoch && currentChatToken() === chatToken && runtime.worldbookScan.bookName === name) return;
        const error = new Error('Cuộc trò chuyện đã chuyển, lần sắp xếp này bị hủy');
        error.name = 'AbortError';
        throw error;
    };

    try {
        const selected = await loadFullWorldbookEntries(name, scanned);
        abortIfChatChanged();
        const batches = planWorldbookImportBatches(splitLongEntries(selected));
        const userName = String(getContext()?.name1 || '');
        const drafts = [];
        const skipped = [];
        const failures = [];

        runtime.worldbookImportRunning = true;
        runtime.worldbookImportDrafts = [];
        runtime.worldbookImportSession = null;
        runtime.worldbookImport = {
            ...emptyWorldbookImportReport(),
            phase: 'running',
            bookName: name,
            message: `Chuẩn bị sắp xếp ${selected.length} mục, chia thành ${batches.length} đợt～`,
        };
        runtime.ui?.render();

        for (let index = 0; index < batches.length; index += 1) {
            abortIfChatChanged();
            const batch = batches[index];
            runtime.worldbookImport.message = `Đang sắp xếp đợt ${index + 1}/${batches.length} (${batch.length} mục)～`;
            runtime.ui?.render();
            const sourceChars = batch.reduce((sum, entry) => sum + String(entry.content || '').length, 0);
            const baseMaxTokens = Math.min(4000, Math.max(1200, Math.round(sourceChars * 1.2)));
            try {
                const payload = await runWithRetries(async attempt => {
                    const prompt = buildWorldbookImportPrompt(batch, { userName });
                    const raw = await backgroundSimulation(retryJsonPrompt(prompt, attempt), {
                        maxTokens: retryTokenBudget(baseMaxTokens, attempt),
                        temperature: 0.05,
                        taskKind: 'worldbook-import',
                        signal: controller.signal,
                        rejectTruncated: true,
                    });
                    const parsed = extractJsonObject(raw);
                    if (parsed) return parsed;
                    throw unreadableJsonError(raw, 'Model sắp xếp World Info');
                }, {
                    signal: controller.signal,
                    retries: getSettings().autoRetryCount,
                    shouldRetry: error => !(
                        /请先填写独立 API|HTTP 40[0134]|没有提供安静生成接口|hãy điền.{0,40}API độc lập|chưa điền.{0,40}API độc lập|không (?:cung cấp|có|hỗ trợ).{0,30}(?:quiet|tạo ngầm|tạo im lặng|tạo yên lặng)|sinh yên lặng/i
                            .test(describeError(error))
                    ),
                    onRetry: ({ attempt, total, delayMs, rateLimited }) => {
                        runtime.worldbookImport.message = rateLimited
                            ? `Tuyến nhân vật bị giới hạn tốc độ rồi～chờ hồi ${cooldownSeconds(delayMs)} giây nữa sẽ tiếp tục đợt ${index + 1}`
                            : `# ${index + 1} — đợt này chưa ổn, đang thử lại ${attempt}/${total}`;
                        runtime.ui?.render();
                    },
                    ...retryTaskOptions(
                        'worldbook-import',
                        `worldbook-import:${name}:${batch.map(entry => entry.uid).join(',')}`,
                        {
                            onCooldown: ({ delayMs }) => {
                                runtime.worldbookImport.message = `API nhân vật đang chờ hồi～còn khoảng ${cooldownSeconds(delayMs)} giây`;
                                runtime.ui?.render();
                            },
                        },
                    ),
                });
                abortIfChatChanged();
                const result = normalizeImportedPeople(payload, batch, { userName });
                drafts.push(...result.people);
                skipped.push(...result.skipped);
            } catch (error) {
                if (isAbortError(error) || controller.signal.aborted) throw error;
                // 单批失败不拖垮其它批，最后一起回报。
                failures.push({
                    batch: index + 1,
                    entries: batch.map(entry => entry.name).slice(0, 3),
                    uids: batch.map(entry => String(entry.uid ?? '')),
                    reason: describeError(error),
                });
            }
        }

        abortIfChatChanged();
        const merged = mergeImportedDrafts(drafts);
        const failedUids = failures.flatMap(failure => failure.uids || []);
        const untouched = summarizeUntouchedEntries(selected, {
            people: merged,
            skipped,
            failedUids,
        });
        if (!merged.length) {
            const report = {
                ...emptyWorldbookImportReport(),
                phase: failures.length ? 'error' : 'success',
                bookName: name,
                message: failures.length
                    ? 'Lần sắp xếp này không có đợt nào thành công, có thể thử lại hoặc chuyển sang nhập theo quy tắc'
                    : 'Trong các mục này không sắp xếp ra được nhân vật nào để nhập',
                skipped,
                untouched,
                failures,
            };
            runtime.worldbookImport = report;
            return report;
        }

        // 整理结果先落成待确认草稿，不直接改世界状态：整理错了的话，用户是在
        // 数据已经被改之后才发现的，事后编辑并不等于没发生过。
        abortIfChatChanged();
        const writes = planImportWrites(merged, selected, { bookName: name });
        const state = getState();
        const needsReview = writes.filter(draft => draft.review.length || draft.nameConflict).length;
        const reviewToken = `${chatToken}:${Date.now().toString(36)}-${writes.length}`;
        const report = {
            ...emptyWorldbookImportReport(),
            phase: 'review',
            bookName: name,
            token: reviewToken,
            message: [
                `Đã sắp xếp ra ${writes.length} người, xác nhận xong mới ghi vào thế giới`,
                needsReview ? `Trong đó ${needsReview} người cần bạn xem qua` : '',
                untouched.length ? `${untouched.length} mục đã tích chọn không cho ra nhân vật` : '',
                failures.length ? `${failures.length} đợt chạy không thành công` : '',
            ].filter(Boolean).join('；'),
            people: writes.map(draft => ({
                reference: draft.reference,
                name: draft.name,
                values: { ...draft.values },
                review: draft.review,
                dropped: draft.dropped,
                lengthFuse: draft.lengthFuse,
                nameConflict: Boolean(draft.nameConflict),
                sourceNames: draft.sourceUids
                    .map(uid => selected.find(entry => String(entry.uid) === uid)?.name)
                    .filter(Boolean),
                ...describeImportTarget(state, draft),
            })),
            skipped,
            untouched,
            failures,
        };
        runtime.worldbookImportDrafts = writes;
        runtime.worldbookImportSession = { chatToken, contextEpoch, bookName: name, token: reviewToken };
        runtime.worldbookImport = report;
        return report;
    } finally {
        if (runtime.worldbookImportController === controller) {
            runtime.worldbookImportController = null;
            runtime.worldbookImportRunning = false;
            // 中途抛错（比如切了聊天）时别把面板永远停在“正在整理”。
            if (runtime.worldbookImport?.phase === 'running') {
                runtime.worldbookImport = {
                    ...emptyWorldbookImportReport(),
                    phase: 'error',
                    bookName: name,
                    message: controller.signal.aborted ? 'Đã hủy sắp xếp, không ghi nhân vật nào' : 'Lần sắp xếp này chưa hoàn tất',
                };
            }
        }
        runtime.ui?.render();
    }
}

function toast(message, tone = 'info') {
    if (runtime.ui?.notify) {
        runtime.ui.notify(message, tone);
        return;
    }
    if (!globalThis.toastr) return;
    const method = ['success', 'warning', 'error', 'info'].includes(tone) ? tone : 'info';
    globalThis.toastr[method](message, '世界背面', { preventDuplicates: true });
}

function normalizeOrbPosition(value) {
    const x = Number(value?.x);
    const y = Number(value?.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
    return {
        x: Math.max(0, Math.round(x)),
        y: Math.max(0, Math.round(y)),
    };
}

function normalizeApiProfiles(value) {
    const seen = new Set();
    const result = [];
    for (const raw of Array.isArray(value) ? value : []) {
        if (!raw || typeof raw !== 'object') continue;
        const id = String(raw.id || '').trim().slice(0, 80);
        if (!id || seen.has(id)) continue;
        seen.add(id);
        const name = String(raw.name || 'Cấu hình chưa đặt tên').trim().slice(0, 80) || 'Cấu hình chưa đặt tên';
        const url = String(raw.url || raw.customApiUrl || '').trim().slice(0, 500);
        const key = String(raw.key || raw.customApiKey || '').trim().slice(0, 1000);
        const model = String(raw.model || raw.customApiModel || '').trim().slice(0, 180);
        const transport = ['proxy', 'direct'].includes(raw.transport || raw.customApiTransport)
            ? (raw.transport || raw.customApiTransport)
            : 'proxy';
        result.push({ id, name, url, key, model, transport });
        if (result.length >= 20) break;
    }
    return result;
}

function normalizeApiModuleRoutes(value, profiles = []) {
    const validProfiles = new Set(profiles.map(profile => `profile:${profile.id}`));
    const normalizeRoute = route => {
        const text = String(route || 'default');
        if (text === 'default' || text === 'tavern') return text;
        if (/^tavern-profile:[^\s:][^\s]*$/.test(text)) return text.slice(0, 220);
        return validProfiles.has(text) ? text : 'default';
    };
    const raw = value && typeof value === 'object' ? value : {};
    return {
        simulation: normalizeRoute(raw.simulation),
        observation: normalizeRoute(raw.observation),
        history: normalizeRoute(raw.history),
        opinion: normalizeRoute(raw.opinion),
    };
}


const AUTO_GENERATION_TIMEOUT_MS = Object.freeze({
    simulation: 180000,
    observation: 120000,
    history: 300000,
    opinion: 150000,
});

function normalizeGenerationTokenLimit(value) {
    const numeric = Number.parseInt(value, 10);
    if (!Number.isFinite(numeric) || numeric <= 0) return 0;
    // Do not impose a product-level token ceiling. Providers/models may still
    // reject values above their own output/context capabilities.
    return Math.min(Number.MAX_SAFE_INTEGER, Math.max(1000, numeric));
}

function normalizeGenerationTimeoutMs(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric <= 0) return 0;
    return Math.min(600000, Math.max(15000, Math.round(numeric)));
}

function normalizeGenerationModuleLimits(value) {
    const raw = value && typeof value === 'object' ? value : {};
    const result = {};
    for (const key of ['simulation', 'observation', 'history', 'opinion']) {
        const item = raw[key] && typeof raw[key] === 'object' ? raw[key] : {};
        result[key] = {
            maxTokens: normalizeGenerationTokenLimit(item.maxTokens),
            timeoutMs: normalizeGenerationTimeoutMs(item.timeoutMs),
        };
    }
    return result;
}

function resolveGenerationLimits(settings, taskKind, requestedMaxTokens = 2200) {
    const routeKey = taskRouteKey(taskKind);
    const moduleLimit = settings.generationModuleLimits?.[routeKey] || {};
    const tokenCap = Number(moduleLimit.maxTokens) > 0
        ? Number(moduleLimit.maxTokens)
        : Number(settings.maxOutputTokens) > 0
            ? Number(settings.maxOutputTokens)
            : 0;
    const requested = Math.max(64, Number.parseInt(requestedMaxTokens, 10) || 2200);
    // A task's requestedMaxTokens is only a sizing hint. In automatic mode the
    // plugin must not turn that hint into a hard response cap. Only an explicit
    // user-configured positive limit is sent as a token ceiling.
    const maxTokens = tokenCap > 0
        ? Math.max(64, Math.round(tokenCap))
        : 0;

    const timeoutMs = Number(moduleLimit.timeoutMs) > 0
        ? Number(moduleLimit.timeoutMs)
        : Number(settings.generationTimeoutMs) > 0
            ? Number(settings.generationTimeoutMs)
            : (AUTO_GENERATION_TIMEOUT_MS[routeKey] || 180000);

    return {
        routeKey,
        requestedMaxTokens: requested,
        tokenCap,
        maxTokens,
        timeoutMs,
        timeoutSource: Number(moduleLimit.timeoutMs) > 0
            ? 'module'
            : Number(settings.generationTimeoutMs) > 0
                ? 'global'
                : 'auto',
        tokenSource: Number(moduleLimit.maxTokens) > 0
            ? 'module'
            : Number(settings.maxOutputTokens) > 0
                ? 'global'
                : 'auto',
    };
}

function primarySimulationRequestBudget(settings, automaticBudget) {
    const moduleLimit = settings.generationModuleLimits?.simulation || {};
    const moduleBudget = Number(moduleLimit.maxTokens) > 0
        ? Number(moduleLimit.maxTokens)
        : 0;
    if (moduleBudget > 0) return moduleBudget;

    // 世界主推演的 0 = 继承，应该真的继承用户给的全局可用上限。
    // max_tokens 只是 ceiling；模型写完会自己停，不会被强迫吐满。
    const globalBudget = Number(settings.maxOutputTokens) > 0
        ? Number(settings.maxOutputTokens)
        : 0;
    if (globalBudget > 0) return globalBudget;

    return Math.max(64, Number.parseInt(automaticBudget, 10) || 2200);
}

function makeApiProfileId() {
    return `api_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function getSettings() {
    const context = getContext();
    if (!context?.extensionSettings) return { ...DEFAULT_SETTINGS };

    const previous = context.extensionSettings[MODULE_ID];
    const previousSettingsVersion = Number(previous?.settingsVersion) || 0;
    const legacySimulationPaused = previousSettingsVersion < 11
        && Boolean(previous?.simulationPaused);
    const settings = {
        ...DEFAULT_SETTINGS,
        ...(previous && typeof previous === 'object' ? previous : {}),
    };
    settings.enabled = Boolean(settings.enabled);
    if (previousSettingsVersion < 9) {
        settings.worldPromptInjection = previous?.promptInjection !== false;
        settings.memoryPromptInjection = previous?.promptInjection !== false;
    }
    // Kept only as a migration field. World continuity is mandatory while the world engine is enabled;
    // worldPromptInjection now controls proactive reveal candidates only.
    settings.promptInjection = true;
    settings.worldSimulationEnabled = Boolean(settings.worldSimulationEnabled);
    settings.worldPromptInjection = Boolean(settings.worldPromptInjection);
    if (previousSettingsVersion < 26) {
        settings.injectionTimeMode = 'full';
        settings.injectionWorldBackground = true;
        settings.injectionPeople = true;
        settings.injectionEvents = true;
        settings.injectionEchoes = true;
        settings.injectionFacts = true;
        settings.injectionMemory = previous?.memoryPromptInjection !== false;
        settings.injectionPublicOpinion = true;
    }
    if (!['full', 'anchor', 'off'].includes(settings.injectionTimeMode)) {
        settings.injectionTimeMode = 'full';
    }
    settings.injectionWorldBackground = settings.injectionWorldBackground !== false;
    settings.injectionPeople = settings.injectionPeople !== false;
    settings.injectionEvents = settings.injectionEvents !== false;
    settings.injectionEchoes = settings.injectionEchoes !== false;
    settings.injectionFacts = settings.injectionFacts !== false;
    settings.injectionMemory = settings.injectionMemory !== false;
    settings.injectionPublicOpinion = settings.injectionPublicOpinion !== false;
    settings.injectionSocial = Boolean(settings.injectionSocial);
    settings.memorySystemEnabled = Boolean(settings.memorySystemEnabled);
    // Legacy alias retained for older exports; the actual injection switch is injectionMemory.
    settings.memoryPromptInjection = settings.injectionMemory;
    settings.autoSync = Boolean(settings.autoSync);
    settings.worldAutoEnabled = previousSettingsVersion < 19
        ? (
            previous?.worldAutoEnabled !== undefined
                ? Boolean(previous.worldAutoEnabled)
                : previous?.autoSync !== false && previous?.autoSimulationMode !== 'manual'
        )
        : settings.worldAutoEnabled !== false;
    settings.recordPlayerCharacter = previousSettingsVersion < 25
        ? (previous?.recordPlayerCharacter !== undefined
            ? Boolean(previous.recordPlayerCharacter)
            : true)
        : settings.recordPlayerCharacter !== false;
    // 1.7.3-dev.5 removes player inner-thought recording from the user-facing feature.
    // Player actions may be recorded when enabled, but inner_voice is always author-owned.
    settings.includeUserInnerVoice = false;
    if (!['auto', 'day', 'night'].includes(settings.theme)) settings.theme = 'auto';
    if (!['restrained', 'balanced', 'active'].includes(settings.deliveryDensity)) {
        settings.deliveryDensity = 'restrained';
    }
    if (!['strict', 'smart', 'open'].includes(settings.sceneTiming)) settings.sceneTiming = 'strict';
    if (!['compact', 'comfortable', 'large'].includes(settings.uiScale)) {
        settings.uiScale = 'comfortable';
    }
    settings.contextTurns = Math.min(
        30,
        Math.max(1, Number.parseInt(settings.contextTurns, 10) || 5),
    );
    settings.customContextTurns = Math.min(
        30,
        Math.max(1, Number.parseInt(settings.customContextTurns, 10) || 8),
    );
    if (![1, 3, 5].includes(settings.contextTurns)) {
        settings.customContextTurns = settings.contextTurns;
    }
    if (previousSettingsVersion < 4) settings.contextTurns = 5;
    if (previousSettingsVersion < 8) settings.orbPosition = null;
    if (previousSettingsVersion < 5) {
        settings.autoSimulationMode = 'balanced';
    }
    if (settings.autoSimulationMode === 'manual') {
        settings.worldAutoEnabled = false;
        settings.autoSimulationMode = 'balanced';
    }
    if (!['light', 'balanced', 'deep'].includes(settings.autoSimulationMode)) {
        settings.autoSimulationMode = 'balanced';
    }
    if (!['quiet', 'natural', 'busy'].includes(settings.worldPulseActivity)) {
        settings.worldPulseActivity = 'natural';
    }
    if (legacySimulationPaused) {
        settings.worldAutoEnabled = false;
    }
    delete settings.simulationPaused;
    settings.autoSync = settings.worldAutoEnabled; // legacy alias
    settings.autoSimulationInterval = Math.min(
        20,
        Math.max(1, Number.parseInt(settings.autoSimulationInterval, 10) || 1),
    );
    settings.pendingSimulationPromptEnabled = Boolean(settings.pendingSimulationPromptEnabled);
    settings.autoRetryCount = Math.min(
        5,
        Math.max(0, Number.parseInt(settings.autoRetryCount, 10) || 0),
    );
    settings.memoryAutoIndexInterval = Math.min(
        50,
        Math.max(0, Number.parseInt(settings.memoryAutoIndexInterval, 10) || 0),
    );
    settings.autoHideArchivedFloors = Boolean(settings.autoHideArchivedFloors);
    settings.backgroundNpcBudget = Math.max(
        0,
        Number.parseInt(settings.backgroundNpcBudget, 10) || 0,
    );
    settings.enhancedBackgroundSimulation = Boolean(settings.enhancedBackgroundSimulation);
    settings.customSimulationInstruction = String(
        settings.customSimulationInstruction || '',
    ).trim().slice(0, 1000);
    // 0.9.6 removes foreground preset bridging entirely. World Backstage now
    // always uses its own internal compatibility layer plus task-specific system.
    delete settings.presetBridgeEnabled;
    delete settings.presetBridgeAdditionalPrompt;
    settings.playerIdentityAnchor = String(
        settings.playerIdentityAnchor || '',
    ).trim().slice(0, 400);
    settings.tagFilterEnabled = settings.tagFilterEnabled !== false;
    if (!Array.isArray(settings.tagFilterRules)) {
        settings.tagFilterRules = DEFAULT_TAG_FILTER_RULES.map(rule => ({ ...rule }));
    } else {
        settings.tagFilterRules = normalizeTagFilterRules(settings.tagFilterRules);
    }
    settings.narrativeIncludeTag = String(settings.narrativeIncludeTag || '')
        .trim().replace(/[<>]/g, '').slice(0, 80);
    settings.narrativeRegexFilters = String(settings.narrativeRegexFilters || '')
        .split(/\r?\n/).map(line => line.trim()).filter(Boolean).slice(0, 8).join('\n').slice(0, 2200);
    if (previousSettingsVersion < 15) {
        settings.timePolicy = 'world';
    }
    settings.settingsVersion = 32;
    if (!['world', 'explicit', 'cautious', 'open'].includes(settings.timePolicy)) {
        settings.timePolicy = 'world';
    }
    if (!['tavern', 'tavern-profile', 'custom'].includes(settings.apiMode)) settings.apiMode = 'tavern';
    settings.tavernApiProfileId = String(settings.tavernApiProfileId || '').trim().slice(0, 120);
    settings.customApiUrl = String(settings.customApiUrl || '').trim().slice(0, 500);
    settings.customApiKey = String(settings.customApiKey || '').trim().slice(0, 1000);
    settings.customApiModel = String(settings.customApiModel || '').trim().slice(0, 180);
    if (!['proxy', 'direct'].includes(settings.customApiTransport)) {
        settings.customApiTransport = 'proxy';
    }
    settings.customApiTimeoutMs = Math.min(
        300000,
        Math.max(15000, Number(settings.customApiTimeoutMs) || 120000),
    );
    settings.imageApiEnabled = Boolean(settings.imageApiEnabled);
    settings.imageApiUrl = String(settings.imageApiUrl || '').trim().slice(0, 500);
    settings.imageApiKey = String(settings.imageApiKey || '').trim().slice(0, 1000);
    settings.imageApiModel = String(settings.imageApiModel || '').trim().slice(0, 180);
    if (!['512x512', '768x768', '1024x1024', '1024x1536', '1536x1024'].includes(settings.imageApiSize)) {
        settings.imageApiSize = '1024x1024';
    }
    settings.imageApiTimeoutMs = Math.min(
        600000,
        Math.max(30000, Number(settings.imageApiTimeoutMs) || 180000),
    );
    settings.socialAutoEnabled = settings.socialAutoEnabled !== false;
    settings.apiProfiles = normalizeApiProfiles(settings.apiProfiles);
    settings.apiModuleRoutes = normalizeApiModuleRoutes(settings.apiModuleRoutes, settings.apiProfiles);
    if (!['observe', 'relevant'].includes(settings.publicOpinionRevealMode)) {
        settings.publicOpinionRevealMode = 'observe';
    }
    settings.publicOpinionAutoEnabled = settings.publicOpinionAutoEnabled !== false;
    settings.maxOutputTokens = normalizeGenerationTokenLimit(settings.maxOutputTokens);
    settings.generationTimeoutMs = normalizeGenerationTimeoutMs(settings.generationTimeoutMs);
    settings.generationModuleLimits = normalizeGenerationModuleLimits(settings.generationModuleLimits);
    settings.orbPosition = normalizeOrbPosition(settings.orbPosition);
    settings.orbEnabled = previousSettingsVersion < 22
        ? (previous?.orbEnabled !== undefined ? Boolean(previous.orbEnabled) : true)
        : settings.orbEnabled !== false;
    settings.orbEdgeHide = Boolean(settings.orbEdgeHide);
    context.extensionSettings[MODULE_ID] = settings;
    if (previousSettingsVersion < 32) context.saveSettingsDebounced?.();
    return settings;
}

function saveSettings(fields = []) {
    const context = getContext();
    runtime.settingsPersistence = {
        saveRequests: Number(runtime.settingsPersistence?.saveRequests || 0) + 1,
        lastSaveRequestedAt: new Date().toISOString(),
        lastSaveFields: [...new Set((Array.isArray(fields) ? fields : []).map(String))].slice(0, 40),
    };
    context?.saveSettingsDebounced?.();
}

function makeStore() {
    const initialState = createInitialState({ worldName: 'Thế giới chính' });
    return {
        schemaVersion: SCHEMA_VERSION,
        initialState,
        currentState: clone(initialState),
        branchOverrides: {},
        branchSurfaceHistory: null,
        memorySummaryArchive: [],
        historyBootstrapCheckpoint: null,
        personObservations: {},
        lingqi: emptyLingqiState(),
        social: emptySocialState(),
        publicOpinion: emptyPublicOpinionCache(),
        publicOpinionListHidden: false,
        publicOpinionDismissed: { news: [], forums: [] },
        publicOpinionSandbox: emptyPublicOpinionSandbox(),
        manualDeletions: {
            eventIds: [],
            events: [],
            people: [],
            memory: { factIds: [], clueIds: [], summaryIds: [] },
        },
        recoveryPoints: [],
        updatedAt: new Date().toISOString(),
    };
}

function mergeMemorySummaryArchive(store, state = store?.currentState) {
    if (!store || typeof store !== 'object') return [];
    const existing = Array.isArray(store.memorySummaryArchive) ? store.memorySummaryArchive : [];
    const current = Array.isArray(state?.storyMemory?.summaries) ? state.storyMemory.summaries : [];
    const byId = new Map();
    for (const summary of [...existing, ...current]) {
        const id = String(summary?.id || '').trim();
        if (!id) continue;
        byId.set(id, clone(summary));
    }
    const merged = [...byId.values()]
        .sort((a, b) => Number(a?.endMessageId || 0) - Number(b?.endMessageId || 0));
    // Keep one chat-level reservoir instead of duplicating the whole hierarchy
    // in every message/swipe snapshot. The live state already applies its own
    // retention policy; this extra headroom mainly preserves alternate swipes.
    if (merged.length > 3600) {
        const protectedItems = merged.filter(item => (
            item?.locked || item?.important || item?.manual || Number(item?.level || 0) >= 2
        ));
        const protectedIds = new Set(protectedItems.map(item => item.id));
        const remainder = merged.filter(item => !protectedIds.has(item.id)).slice(-Math.max(0, 3600 - protectedItems.length));
        store.memorySummaryArchive = [...protectedItems, ...remainder]
            .sort((a, b) => Number(a?.endMessageId || 0) - Number(b?.endMessageId || 0));
    } else {
        store.memorySummaryArchive = merged;
    }
    return store.memorySummaryArchive;
}

function createBranchSnapshot(state, meta = {}, store = getStore()) {
    mergeMemorySummaryArchive(store, state);
    const snapshot = createCompactSnapshot(state, meta);
    compactSnapshotMemory(snapshot, store);
    saveStore(store);
    return snapshot;
}

function restoreBranchSnapshot(snapshot, fallback = null, store = getStore()) {
    compactSnapshotMemory(snapshot, store);
    const restored = restoreCompactSnapshot(
        snapshot,
        fallback || store?.initialState || null,
        store?.memorySummaryArchive || [],
    );
    return applyPlayerCharacterRecordingPolicy(
        applyManualDeletionFilters(restored, store),
        getSettings(),
    );
}

function currentChatToken() {
    const context = getContext();
    if (!context) return 'no-context';
    return String(context.chatId ?? context.groupId ?? context.characterId ?? 'no-chat');
}

function hasChatContext() {
    const context = getContext();
    return Boolean(
        context
        && Array.isArray(context.chat)
        && (
            context.chatId
            || context.groupId
            || context.characterId !== undefined
        )
    );
}

function isStoredPlayerCharacter(person, userName = getContext()?.name1 || '') {
    const normalizedUserName = String(userName || '').trim().toLocaleLowerCase();
    const name = String(person?.name || '').trim().toLocaleLowerCase();
    return Boolean(
        person?.isUser
        || person?.is_user
        || person?.role === 'user'
        || (normalizedUserName && name && normalizedUserName === name)
    );
}

function applyPlayerCharacterRecordingPolicy(inputState, settings = getSettings()) {
    const state = trimState(inputState);
    const userName = getContext()?.name1 || '';
    if (settings.recordPlayerCharacter === false) {
        state.people = (state.people || []).filter(person => !isStoredPlayerCharacter(person, userName));
        return trimState(state);
    }
    // Even when the player card is recorded, player inner thoughts are never stored.
    state.people = (state.people || []).map(person => (
        isStoredPlayerCharacter(person, userName)
            ? { ...person, isUser: true, innerVoice: '' }
            : person
    ));
    return trimState(state);
}

function findPlayerPerson(state, userName = getContext()?.name1 || '') {
    const people = Array.isArray(state?.people) ? state.people : [];
    const normalizedUserName = String(userName || '').trim().toLocaleLowerCase();
    return people.find(person => person?.isUser)
        || people.find(person => (
            normalizedUserName
            && String(person?.name || '').trim().toLocaleLowerCase() === normalizedUserName
        ))
        || null;
}

function getPlayerIdentityAnchor(state = null) {
    if (getSettings().recordPlayerCharacter === false) return '';
    const resolvedState = state || getState();
    const player = findPlayerPerson(resolvedState);
    if (player) return String(player.identityAnchor || '').trim().slice(0, 500);
    return String(getSettings().playerIdentityAnchor || '').trim().slice(0, 400);
}


function normalizePublicOpinionDismissed(value) {
    const raw = value && typeof value === 'object' ? value : {};
    const normalize = items => [...new Set(
        (Array.isArray(items) ? items : [])
            .map(item => String(item || '').trim())
            .filter(Boolean),
    )].slice(-160);
    return {
        news: normalize(raw.news),
        forums: normalize(raw.forums),
    };
}

function publicOpinionDismissKey(kind, item) {
    const related = String(item?.relatedEventId || '').trim();
    if (kind === 'forum') {
        return `forum:${related}:${String(item?.board || '').trim()}:${String(item?.title || '').trim()}`;
    }
    return `news:${related}:${String(item?.headline || '').trim()}`;
}

function filterDismissedPublicOpinion(cache, dismissedRaw) {
    const cacheValue = normalizePublicOpinionCache(cache || emptyPublicOpinionCache());
    const dismissed = normalizePublicOpinionDismissed(dismissedRaw);
    const newsKeys = new Set(dismissed.news);
    const forumKeys = new Set(dismissed.forums);
    return {
        ...cacheValue,
        news: cacheValue.news.filter(item => !newsKeys.has(publicOpinionDismissKey('news', item))),
        forums: cacheValue.forums.filter(item => !forumKeys.has(publicOpinionDismissKey('forum', item))),
    };
}

function dismissPublicOpinionItem(kind, itemId) {
    const normalizedKind = kind === 'forum' ? 'forum' : 'news';
    const store = getStore();
    const cache = normalizePublicOpinionCache(store.publicOpinion || emptyPublicOpinionCache());
    const list = normalizedKind === 'forum' ? cache.forums : cache.news;
    const item = list.find(entry => String(entry?.id || '') === String(itemId || ''));
    if (!item) throw new Error('Mục dư luận này không còn trong danh sách nữa rồi～');

    const dismissed = normalizePublicOpinionDismissed(store.publicOpinionDismissed);
    const bucket = normalizedKind === 'forum' ? 'forums' : 'news';
    const key = publicOpinionDismissKey(normalizedKind, item);
    dismissed[bucket] = [...new Set([...dismissed[bucket], key])].slice(-160);
    store.publicOpinionDismissed = dismissed;
    store.publicOpinion = filterDismissedPublicOpinion(cache, dismissed);
    saveStore(store);
    runtime.ui?.render();
    return true;
}


function normalizeManualDeletions(value) {
    const raw = value && typeof value === 'object' ? value : {};
    const eventIds = [...new Set(
        (Array.isArray(raw.eventIds) ? raw.eventIds : [])
            .map(item => String(item || '').trim())
            .filter(Boolean),
    )].slice(-240);

    const seenEvents = new Set();
    const events = [];
    for (const item of Array.isArray(raw.events) ? raw.events : []) {
        if (!item || typeof item !== 'object') continue;
        const entry = {
            id: String(item.id || '').trim(),
            title: String(item.title || '').trim().slice(0, 140),
            place: String(item.place || '').trim().slice(0, 140),
            summary: String(item.summary || '').trim().slice(0, 420),
            actors: (Array.isArray(item.actors) ? item.actors : [])
                .map(actor => String(actor || '').trim())
                .filter(Boolean)
                .slice(0, 16),
        };
        if (!entry.id && !entry.title) continue;
        const key = `${entry.id.toLocaleLowerCase()}\u0000${entry.title.toLocaleLowerCase()}\u0000${entry.place.toLocaleLowerCase()}`;
        if (seenEvents.has(key)) continue;
        seenEvents.add(key);
        events.push(entry);
    }

    const memoryRaw = raw.memory && typeof raw.memory === 'object' ? raw.memory : {};
    const memory = {
        factIds: [...new Set((Array.isArray(memoryRaw.factIds) ? memoryRaw.factIds : [])
            .map(item => String(item || '').trim()).filter(Boolean))].slice(-480),
        clueIds: [...new Set((Array.isArray(memoryRaw.clueIds) ? memoryRaw.clueIds : [])
            .map(item => String(item || '').trim()).filter(Boolean))].slice(-480),
        summaryIds: [...new Set((Array.isArray(memoryRaw.summaryIds) ? memoryRaw.summaryIds : [])
            .map(item => String(item || '').trim()).filter(Boolean))].slice(-480),
    };

    const seenPeople = new Set();
    const people = [];
    for (const item of Array.isArray(raw.people) ? raw.people : []) {
        if (!item || typeof item !== 'object') continue;
        const entry = {
            id: String(item.id || '').trim(),
            name: String(item.name || '').trim(),
            worldbookRef: String(item.worldbookRef || '').trim(),
        };
        if (!entry.id && !entry.name && !entry.worldbookRef) continue;
        const key = `${entry.id.toLocaleLowerCase()}\u0000${entry.name.toLocaleLowerCase()}\u0000${entry.worldbookRef.toLocaleLowerCase()}`;
        if (seenPeople.has(key)) continue;
        seenPeople.add(key);
        people.push(entry);
    }
    return { eventIds, events: events.slice(-240), people: people.slice(-240), memory };
}

function normalizedEventDeletionText(value) {
    return String(value || '')
        .normalize('NFKC')
        .toLocaleLowerCase()
        .replace(/[\s\p{P}\p{S}]+/gu, '');
}

function eventDeletionSimilarity(left, right) {
    const a = normalizedEventDeletionText(left);
    const b = normalizedEventDeletionText(right);
    if (!a || !b) return 0;
    if (a === b) return 1;
    const shorter = a.length <= b.length ? a : b;
    const longer = a.length > b.length ? a : b;
    if (shorter.length >= 6 && longer.includes(shorter)) return shorter.length / longer.length;
    if (a.length < 4 || b.length < 4) return 0;
    const grams = text => {
        const values = new Set();
        for (let index = 0; index < text.length - 1; index += 1) values.add(text.slice(index, index + 2));
        return values;
    };
    const leftGrams = grams(a);
    const rightGrams = grams(b);
    let overlap = 0;
    for (const gram of leftGrams) if (rightGrams.has(gram)) overlap += 1;
    return (2 * overlap) / Math.max(1, leftGrams.size + rightGrams.size);
}

function eventMatchesDeletion(event, deletion) {
    const eventId = String(event?.id || '').trim();
    const deletionId = String(deletion?.id || '').trim();
    if (eventId && deletionId && eventId === deletionId) return true;
    const titleScore = eventDeletionSimilarity(event?.title, deletion?.title);
    if (titleScore >= 0.86) return true;
    if (titleScore < 0.68) return false;
    const contextScore = eventDeletionSimilarity(
        [event?.place, ...(event?.actors || []), event?.summary].filter(Boolean).join(' '),
        [deletion?.place, ...(deletion?.actors || []), deletion?.summary].filter(Boolean).join(' '),
    );
    return contextScore >= 0.58;
}

function personMatchesDeletion(person, deletion) {
    const id = String(person?.id || '').trim().toLocaleLowerCase();
    const name = String(person?.name || '').trim().toLocaleLowerCase();
    const worldbookRef = String(person?.worldbookRef || '').trim().toLocaleLowerCase();
    const deletedId = String(deletion?.id || '').trim().toLocaleLowerCase();
    const deletedName = String(deletion?.name || '').trim().toLocaleLowerCase();
    const deletedWorldbookRef = String(deletion?.worldbookRef || '').trim().toLocaleLowerCase();
    return Boolean(
        (deletedId && id && deletedId === id)
        || (deletedWorldbookRef && worldbookRef && deletedWorldbookRef === worldbookRef)
        || (deletedName && name && deletedName === name)
    );
}

function applyManualDeletionFilters(inputState, store) {
    const state = trimState(inputState);
    const deletions = normalizeManualDeletions(store?.manualDeletions);
    const deletedEvents = new Set(deletions.eventIds);

    if (deletedEvents.size || deletions.events.length) {
        const rejectedEventIds = new Set(deletedEvents);
        state.events = (state.events || []).filter(event => {
            const rejected = deletedEvents.has(String(event?.id || ''))
                || deletions.events.some(deletion => eventMatchesDeletion(event, deletion));
            if (rejected && event?.id) rejectedEventIds.add(String(event.id));
            return !rejected;
        });
        state.echoes = (state.echoes || []).filter(echo => !rejectedEventIds.has(String(echo?.eventId || '')));
        state.archive = (state.archive || []).filter(entry => !rejectedEventIds.has(String(entry?.eventId || '')));
    }
    if (deletions.people.length) {
        state.people = (state.people || []).filter(person => (
            person?.isUser || !deletions.people.some(deletion => personMatchesDeletion(person, deletion))
        ));
    }
    state.storyMemory ||= { facts: [], clues: [], summaries: [] };
    const deletedFacts = new Set(deletions.memory.factIds);
    const deletedClues = new Set(deletions.memory.clueIds);
    const deletedSummaries = new Set(deletions.memory.summaryIds);
    if (deletedFacts.size) {
        state.storyMemory.facts = (state.storyMemory.facts || []).filter(
            item => !deletedFacts.has(String(item?.id || '')),
        );
    }
    if (deletedClues.size) {
        state.storyMemory.clues = (state.storyMemory.clues || []).filter(
            item => !deletedClues.has(String(item?.id || '')),
        );
    }
    if (deletedSummaries.size) {
        state.storyMemory.summaries = (state.storyMemory.summaries || []).filter(
            item => !deletedSummaries.has(String(item?.id || '')),
        );
    }
    return trimState(state);
}

function addEventDeletionTombstone(store, event) {
    store.manualDeletions = normalizeManualDeletions(store.manualDeletions);
    const id = String(event?.id || '').trim();
    if (id) {
        store.manualDeletions.eventIds = [...new Set([
            ...store.manualDeletions.eventIds,
            id,
        ])].slice(-240);
    }
    store.manualDeletions.events = normalizeManualDeletions({
        ...store.manualDeletions,
        events: [...store.manualDeletions.events, {
            id,
            title: event?.title,
            place: event?.place,
            summary: event?.summary,
            actors: event?.actors,
        }],
    }).events;
}

function clearEventDeletionTombstone(store, event) {
    store.manualDeletions = normalizeManualDeletions(store.manualDeletions);
    const id = String(event?.id || '').trim();
    store.manualDeletions.eventIds = store.manualDeletions.eventIds.filter(item => item !== id);
    store.manualDeletions.events = store.manualDeletions.events.filter(
        deletion => !eventMatchesDeletion(event, deletion),
    );
}

function addMemoryDeletionTombstone(store, kind, item) {
    store.manualDeletions = normalizeManualDeletions(store.manualDeletions);
    const id = String(item?.id || '').trim();
    if (!id) return;
    const key = kind === 'clue'
        ? 'clueIds'
        : kind === 'summary'
            ? 'summaryIds'
            : 'factIds';
    store.manualDeletions.memory[key] = [...new Set([
        ...store.manualDeletions.memory[key],
        id,
    ])].slice(-480);
}

function addPersonDeletionTombstone(store, person) {
    store.manualDeletions = normalizeManualDeletions(store.manualDeletions);
    const entry = {
        id: String(person?.id || '').trim(),
        name: String(person?.name || '').trim(),
        worldbookRef: String(person?.worldbookRef || '').trim(),
    };
    store.manualDeletions.people = normalizeManualDeletions({
        ...store.manualDeletions,
        people: [...store.manualDeletions.people, entry],
    }).people;
    if (store.personObservations && entry.id) delete store.personObservations[entry.id];
}

function clearPersonDeletionTombstone(store, person) {
    store.manualDeletions = normalizeManualDeletions(store.manualDeletions);
    store.manualDeletions.people = store.manualDeletions.people.filter(
        deletion => !personMatchesDeletion(person, deletion),
    );
}

function prepareStore(rawStore, context = getContext()) {
    let store = rawStore && typeof rawStore === 'object' ? rawStore : makeStore();
    if (runtime.preparedStores.has(store)) return store;

    const previousSchemaVersion = Number(
        store.schemaVersion
        ?? store.currentState?.schemaVersion
        ?? 0,
    );
    const migrationReason = `before-schema-${SCHEMA_VERSION}`;
    let createdMigrationRecovery = false;
    const recoveryHeaders = listRecoveryPointHeaders(store);
    if (
        previousSchemaVersion > 0
        && previousSchemaVersion < SCHEMA_VERSION
        && store.currentState
        && !recoveryHeaders.some(point => point.reason === migrationReason)
    ) {
        store = addRecoveryPoint(store, {
            reason: migrationReason,
            label: `Nâng cấp lên cấu trúc dữ liệu ${SCHEMA_VERSION} (tự động lưu trước đó)`,
        });
        createdMigrationRecovery = true;
    }

    // Normalize persisted data exactly once per loaded store object. Repeating
    // trimState() on every read deep-clones thousands of memory items and makes
    // innocuous UI actions (such as checking a box) unexpectedly expensive.
    store.schemaVersion = SCHEMA_VERSION;
    store.manualDeletions = normalizeManualDeletions(store.manualDeletions);
    store.initialState = applyPlayerCharacterRecordingPolicy(
        store.initialState || createInitialState({ worldName: 'Thế giới chính' }),
        getSettings(),
    );
    store.currentState = applyPlayerCharacterRecordingPolicy(
        applyManualDeletionFilters(
            store.currentState || store.initialState,
            store,
        ),
        getSettings(),
    );
    store.memorySummaryArchive = Array.isArray(store.memorySummaryArchive)
        ? store.memorySummaryArchive
        : [];
    store.historyBootstrapCheckpoint = store.historyBootstrapCheckpoint
        && typeof store.historyBootstrapCheckpoint === 'object'
        ? store.historyBootstrapCheckpoint
        : null;
    mergeMemorySummaryArchive(store, store.currentState);

    const settings = getSettings();
    const legacyPlayerIdentityAnchor = String(settings.playerIdentityAnchor || '').trim().slice(0, 400);
    const player = findPlayerPerson(store.currentState, context?.name1 || '');
    let migratedLegacyPlayerIdentity = false;
    if (player && legacyPlayerIdentityAnchor) {
        if (!String(player.identityAnchor || '').trim()) {
            player.identityAnchor = legacyPlayerIdentityAnchor;
        }
        settings.playerIdentityAnchor = '';
        saveSettings(['playerIdentityAnchor']);
        migratedLegacyPlayerIdentity = true;
    }
    store.branchOverrides = store.branchOverrides && typeof store.branchOverrides === 'object'
        ? store.branchOverrides
        : {};
    store.personObservations = store.personObservations && typeof store.personObservations === 'object'
        ? store.personObservations
        : {};
    store.lingqi = normalizeLingqiState(store.lingqi || emptyLingqiState());
    store.social = reconcileSocialRelationships(
        store.social || emptySocialState(),
        store.currentState,
        {
            userName: context?.name1 || '',
            recentNarrative: recentNarrativeForSocial(context),
        },
    );
    store.publicOpinionDismissed = normalizePublicOpinionDismissed(store.publicOpinionDismissed);
    store.publicOpinion = filterDismissedPublicOpinion(
        store.publicOpinion || emptyPublicOpinionCache(),
        store.publicOpinionDismissed,
    );
    store.publicOpinionListHidden = Boolean(store.publicOpinionListHidden);
    store.publicOpinionSandbox = normalizePublicOpinionSandbox(store.publicOpinionSandbox || emptyPublicOpinionSandbox());
    ensureBranchSurfaceHistory(store);
    captureBranchSurface(store, branchSurfaceKeyFromState(store.currentState));
    store.recoveryPoints = Array.isArray(store.recoveryPoints) ? store.recoveryPoints.slice(-3) : [];

    runtime.preparedStores.add(store);
    if ((createdMigrationRecovery || migratedLegacyPlayerIdentity) && context?.chatMetadata && hasChatContext()) {
        context.chatMetadata[STATE_KEY] = store;
        context.saveMetadataDebounced?.();
    }
    return store;
}

function getStore({ create = true } = {}) {
    const context = getContext();
    const metadata = context?.chatMetadata;

    if (!metadata || typeof metadata !== 'object' || !hasChatContext()) {
        runtime.transientStore ||= makeStore();
        runtime.transientStore = prepareStore(runtime.transientStore, context);
        return runtime.transientStore;
    }

    if (!metadata[STATE_KEY] && create) {
        metadata[STATE_KEY] = makeStore();
        context.saveMetadataDebounced?.();
    }

    const rawStore = metadata[STATE_KEY] || runtime.transientStore || makeStore();
    const prepared = prepareStore(rawStore, context);
    if (prepared !== metadata[STATE_KEY] && metadata[STATE_KEY]) {
        metadata[STATE_KEY] = prepared;
    }
    return prepared;
}

function saveStore(store, { immediate = false } = {}) {
    const context = getContext();
    store.manualDeletions = normalizeManualDeletions(store.manualDeletions);
    store.currentState = applyPlayerCharacterRecordingPolicy(
        applyManualDeletionFilters(store.currentState, store),
        getSettings(),
    );
    mergeMemorySummaryArchive(store, store.currentState);
    store.social = reconcileSocialRelationships(
        store.social || emptySocialState(),
        store.currentState,
        {
            userName: context?.name1 || '',
            recentNarrative: recentNarrativeForSocial(context),
        },
    );
    captureBranchSurface(store, branchSurfaceKeyFromState(store.currentState));
    // 舆情/新闻只能通过自己的时间 + 公开事件调度器更新。普通世界状态保存
    // 绝不能顺手把 public event 直接塞进新闻，否则会绕过新闻时间门槛。
    store.updatedAt = new Date().toISOString();

    if (!context?.chatMetadata || !hasChatContext()) {
        runtime.transientStore = store;
        return Promise.resolve();
    }

    context.chatMetadata[STATE_KEY] = store;
    scheduleAutoHideArchivedFloors();
    if (immediate && typeof context.saveMetadata === 'function') {
        return Promise.resolve(context.saveMetadata());
    } else {
        context.saveMetadataDebounced?.();
        return Promise.resolve();
    }
}

function getState() {
    return getStore().currentState;
}

function setMessageHiddenDomState(messageId, hidden) {
    const messageBlock = globalThis.document?.querySelector?.(`.mes[mesid="${Number(messageId)}"]`);
    if (messageBlock) messageBlock.setAttribute('is_system', String(Boolean(hidden)));
}

async function applyAutoHideArchivedFloors({
    quiet = true,
    expectedChatToken = currentChatToken(),
} = {}) {
    const settings = getSettings();
    const context = getContext();
    if (
        !settings.enabled
        || !settings.memorySystemEnabled
        || !settings.injectionMemory
        || !settings.autoHideArchivedFloors
        || !context
        || expectedChatToken !== currentChatToken()
        || !Array.isArray(context.chat)
    ) {
        return { hiddenCount: 0, messageIds: [] };
    }

    const indexedThroughMessageId = Number(getState()?.storyMemory?.indexedThroughMessageId ?? -1);
    const summaries = getState()?.storyMemory?.summaries || [];
    const messageIds = markAutoHiddenMessages(context.chat, indexedThroughMessageId, {
        keepRecent: AUTO_HIDE_KEEP_RECENT_MESSAGES,
        summaries,
    });
    if (!messageIds.length) return { hiddenCount: 0, messageIds: [] };

    for (const messageId of messageIds) {
        setMessageHiddenDomState(messageId, true);
    }

    await context.saveChat?.();
    if (!quiet) {
        toast(
            `Đã tự động ẩn ${messageIds.length} tầng chính văn cũ, ${AUTO_HIDE_KEEP_RECENT_MESSAGES} tầng chính văn đã lưu trữ gần nhất vẫn được giữ trong ngữ cảnh.`,
            'success',
        );
    }
    return { hiddenCount: messageIds.length, messageIds };
}

function scheduleAutoHideArchivedFloors(delay = 140, expectedChatToken = currentChatToken()) {
    const settings = getSettings();
    if (!settings.enabled || !settings.memorySystemEnabled || !settings.injectionMemory || !settings.autoHideArchivedFloors) return false;
    if (runtime.autoHideTimer !== null) window.clearTimeout(runtime.autoHideTimer);
    runtime.autoHideTimer = window.setTimeout(() => {
        runtime.autoHideTimer = null;
        if (expectedChatToken !== currentChatToken()) return;
        void applyAutoHideArchivedFloors({ expectedChatToken }).catch(error => {
            console.warn('[世界背面] Tự động ẩn tầng cũ thất bại', error);
        });
    }, Math.max(0, Number(delay) || 0));
    return true;
}

async function restoreAutoHiddenFloors({ quiet = false } = {}) {
    const context = getContext();
    if (!context || !Array.isArray(context.chat)) return { restoredCount: 0, messageIds: [] };
    const messageIds = restoreAutoHiddenMessages(context.chat);
    if (!messageIds.length) {
        if (!quiet) toast('Cuộc trò chuyện hiện tại không có tầng nào do 世界背面 tự động ẩn.', 'info');
        return { restoredCount: 0, messageIds: [] };
    }

    for (const messageId of messageIds) {
        setMessageHiddenDomState(messageId, false);
    }

    await context.saveChat?.();
    if (!quiet) toast(`Đã khôi phục ${messageIds.length} tầng chính văn do 世界背面 tự động ẩn.`, 'success');
    return { restoredCount: messageIds.length, messageIds };
}

async function reconcileAutoHidePrerequisites(expectedChatToken = currentChatToken()) {
    const context = getContext();
    if (
        !context
        || !Array.isArray(context.chat)
        || expectedChatToken !== currentChatToken()
    ) {
        return { restoredCount: 0, messageIds: [] };
    }

    const settings = getSettings();
    if (settings.enabled && settings.memorySystemEnabled && settings.injectionMemory) {
        return { restoredCount: 0, messageIds: [] };
    }

    if (settings.autoHideArchivedFloors) {
        settings.autoHideArchivedFloors = false;
        context.extensionSettings[MODULE_ID] = settings;
        saveSettings(['autoHideArchivedFloors']);
        syncSettingsEntry();
        runtime.ui?.render();
    }

    return restoreAutoHiddenFloors({ quiet: true });
}

function branchSourceKey(messageId, message, swipeId = message?.swipe_id ?? 0) {
    const text = message?.swipes?.[swipeId] ?? message?.mes ?? '';
    return `${messageId}:${swipeId}:${hashText(text)}`;
}

function branchDataFromMessage(message, swipeId = message?.swipe_id ?? 0) {
    return readBranchRecord(message, swipeId, SNAPSHOT_KEY);
}

function latestAssistantEntry() {
    const chat = getContext()?.chat || [];
    for (let index = chat.length - 1; index >= 0; index -= 1) {
        const message = chat[index];
        if (hasUsableAssistantText(message)) return { message, index };
    }
    return null;
}

function taskRouteKey(taskKind = 'simulation') {
    if (taskKind === 'person-observation' || taskKind === 'worldbook-import' || taskKind === 'lingqi' || taskKind === 'social') return 'observation';
    if (taskKind === 'public-opinion' || taskKind === 'public-opinion-sandbox') return 'opinion';
    if (taskKind === 'history' || taskKind === 'history-index' || taskKind === 'memory') return 'history';
    return 'simulation';
}

function tavernConnectionManagerDisabled(context = getContext()) {
    const disabled = context?.extensionSettings?.disabledExtensions;
    return Array.isArray(disabled) && disabled.includes('connection-manager');
}

function rawTavernConnectionProfiles(context = getContext()) {
    const profiles = context?.extensionSettings?.connectionManager?.profiles;
    return Array.isArray(profiles) ? profiles : [];
}

function tavernConnectionProfileById(profileId, context = getContext()) {
    const id = String(profileId || '').trim();
    if (!id) return null;
    return rawTavernConnectionProfiles(context).find(profile => String(profile?.id || '') === id) || null;
}

function listTavernConnectionProfiles() {
    const context = getContext();
    if (tavernConnectionManagerDisabled(context)) return [];
    let profiles = [];
    try {
        const service = context?.ConnectionManagerRequestService;
        profiles = typeof service?.getSupportedProfiles === 'function'
            ? service.getSupportedProfiles()
            : rawTavernConnectionProfiles(context);
    } catch (error) {
        console.warn('[世界背面] Đọc cấu hình kết nối Tavern thất bại, tạm thời chỉ hiển thị danh sách cấu hình gốc', error);
        profiles = rawTavernConnectionProfiles(context);
    }
    const seen = new Set();
    return (Array.isArray(profiles) ? profiles : [])
        .filter(profile => profile && typeof profile === 'object')
        .map(profile => {
            const id = String(profile.id || '').trim().slice(0, 120);
            if (!id || seen.has(id)) return null;
            seen.add(id);
            return {
                id,
                name: String(profile.name || 'Cấu hình Tavern chưa đặt tên').trim().slice(0, 120) || 'Cấu hình Tavern chưa đặt tên',
                api: String(profile.api || '').trim().slice(0, 80),
                model: String(profile.model || '').trim().slice(0, 180),
                mode: String(profile.mode || '').trim().slice(0, 20),
            };
        })
        .filter(Boolean)
        .slice(0, 100);
}

function tavernProfileRoute(profileId, {
    route = 'default',
    routeKey = 'simulation',
    settings = getSettings(),
} = {}) {
    const id = String(profileId || '').trim();
    const profile = tavernConnectionProfileById(id);
    return {
        mode: 'tavern-profile',
        route,
        routeKey,
        label: profile?.name || 'Cấu hình đã lưu của Tavern',
        profileId: id,
        profile,
        settings,
    };
}

function settingsForApiProfile(baseSettings, profile) {
    return {
        ...baseSettings,
        apiMode: 'custom',
        customApiUrl: String(profile?.url || ''),
        customApiKey: String(profile?.key || ''),
        customApiModel: String(profile?.model || ''),
        customApiTransport: ['proxy', 'direct'].includes(profile?.transport) ? profile.transport : 'proxy',
    };
}

function resolveTaskConnection(settings, taskKind = 'simulation') {
    const routeKey = taskRouteKey(taskKind);
    const route = String(settings.apiModuleRoutes?.[routeKey] || 'default');
    if (route === 'tavern') {
        return { mode: 'tavern', route, routeKey, label: 'Theo Tavern hiện tại', settings };
    }
    if (route.startsWith('tavern-profile:')) {
        return tavernProfileRoute(route.slice('tavern-profile:'.length), {
            route,
            routeKey,
            settings,
        });
    }
    if (route.startsWith('profile:')) {
        const id = route.slice('profile:'.length);
        const profile = settings.apiProfiles?.find(item => item.id === id);
        if (profile) {
            return {
                mode: 'custom',
                route,
                routeKey,
                label: profile.name || 'Cấu hình đã lưu',
                profile,
                settings: settingsForApiProfile(settings, profile),
            };
        }
    }
    if (settings.apiMode === 'custom') {
        return {
            mode: 'custom',
            route: 'default',
            routeKey,
            label: 'API độc lập mặc định',
            settings,
        };
    }
    if (settings.apiMode === 'tavern-profile') {
        return tavernProfileRoute(settings.tavernApiProfileId, {
            route: 'default',
            routeKey,
            settings,
        });
    }
    return { mode: 'tavern', route: 'default', routeKey, label: 'Theo Tavern hiện tại', settings };
}

function physicalConnectionKey(taskKind = 'simulation') {
    const settings = getSettings();
    const route = resolveTaskConnection(settings, taskKind);
    if (route.mode === 'tavern-profile') {
        return [
            'tavern-profile-physical',
            String(route.profileId || 'missing'),
        ].join(':');
    }
    if (route.mode === 'custom') {
        const requestSettings = route.settings;
        return [
            'custom-physical',
            requestSettings.customApiTransport || 'proxy',
            hashText(String(requestSettings.customApiUrl || '')),
            hashText(String(requestSettings.customApiKey || '')),
            String(requestSettings.customApiModel || ''),
        ].join(':');
    }
    const connection = getConnectionInfo();
    return [
        'tavern-physical',
        String(connection?.source || 'tavern'),
        String(connection?.model || ''),
    ].join(':');
}

function retryConnectionKey(taskKind = 'simulation') {
    const settings = getSettings();
    const route = resolveTaskConnection(settings, taskKind);
    if (route.mode === 'tavern-profile') {
        return [
            'tavern-profile',
            route.route || 'default',
            String(route.profileId || 'missing'),
        ].join(':');
    }
    if (route.mode === 'custom') {
        const requestSettings = route.settings;
        return [
            'custom',
            route.route || 'default',
            requestSettings.customApiTransport || 'proxy',
            hashText(String(requestSettings.customApiUrl || '')),
            String(requestSettings.customApiModel || ''),
        ].join(':');
    }
    const connection = getConnectionInfo();
    return [
        'tavern',
        route.route || 'default',
        String(connection?.source || 'tavern'),
        String(connection?.model || ''),
    ].join(':');
}

function retryTaskOptions(taskKind, taskKey, {
    onCooldown = null,
} = {}) {
    return {
        cooldownKey: retryConnectionKey(taskKind),
        taskKey: String(taskKey || '').slice(0, 240),
        onCooldown,
    };
}

function pushApiRequestTimeline(entry = {}) {
    runtime.apiRequestTimeline.push({
        chatToken: String(entry.chatToken || ''),
        taskKind: String(entry.taskKind || ''),
        route: String(entry.route || '').slice(0, 120),
        model: String(entry.model || '').slice(0, 180),
        lane: String(entry.lane || '').slice(0, 180),
        queuedAt: entry.queuedAt || '',
        startedAt: entry.startedAt || '',
        finishedAt: entry.finishedAt || '',
        waitMs: Math.max(0, Number(entry.waitMs) || 0),
        durationMs: Math.max(0, Number(entry.durationMs) || 0),
        outcome: String(entry.outcome || 'unknown'),
        errorType: String(entry.errorType || 'none').slice(0, 80),
        transportStatus: Number(entry.transportStatus) || null,
        upstreamStatus: Number(entry.upstreamStatus) || null,
        retryAfterMs: Math.max(0, Number(entry.retryAfterMs) || 0),
        request: entry.request && typeof entry.request === 'object' ? { ...entry.request } : null,
    });
    if (runtime.apiRequestTimeline.length > 32) {
        runtime.apiRequestTimeline.splice(0, runtime.apiRequestTimeline.length - 32);
    }
}

function waitForPromiseOrAbort(promise, signal) {
    if (!signal) return Promise.resolve(promise);
    if (signal.aborted) {
        if (signal.reason instanceof Error) return Promise.reject(signal.reason);
        const error = new Error('Tác vụ nền đã bị hủy');
        error.name = 'AbortError';
        return Promise.reject(error);
    }
    return new Promise((resolve, reject) => {
        const onAbort = () => {
            if (signal.reason instanceof Error) {
                reject(signal.reason);
                return;
            }
            const error = new Error('Tác vụ nền đã bị hủy');
            error.name = 'AbortError';
            reject(error);
        };
        signal.addEventListener('abort', onAbort, { once: true });
        Promise.resolve(promise).then(
            value => {
                signal.removeEventListener?.('abort', onAbort);
                resolve(value);
            },
            error => {
                signal.removeEventListener?.('abort', onAbort);
                reject(error);
            },
        );
    });
}

async function runInConnectionLane(taskKind, signal, operation, requestShape = null) {
    if (requestShape && typeof requestShape === 'object') {
        runtime.lastRequestShape = { ...requestShape };
        if (runtime.lastTaskTrace?.taskKind === taskKind) {
            updateTaskTrace({ request: { ...requestShape } });
        }
    }
    const laneKey = physicalConnectionKey(taskKind);
    const routeAtQueue = resolveTaskConnection(getSettings(), taskKind);
    const timelineModel = routeAtQueue.mode === 'custom'
        ? String(routeAtQueue.settings?.customApiModel || '')
        : routeAtQueue.mode === 'tavern-profile'
            ? String(routeAtQueue.profile?.model || '')
            : String(getCurrentTavernConnectionInfo()?.model || '');
    const previousTail = runtime.connectionLanes.get(laneKey) || Promise.resolve();
    let release;
    const ownDone = new Promise(resolve => { release = resolve; });
    const waitForPrevious = Promise.resolve(previousTail).catch(() => undefined);
    const laneTail = waitForPrevious.then(() => ownDone);
    runtime.connectionLanes.set(laneKey, laneTail);

    const queuedAtMs = Date.now();
    const queuedAt = new Date(queuedAtMs).toISOString();
    const chatTokenAtQueue = currentChatToken();
    let startedAtMs = 0;
    let outcome = 'cancelled';
    let terminalError = null;
    try {
        await waitForPromiseOrAbort(waitForPrevious, signal);
        if (signal?.aborted) {
            const error = new Error('Tác vụ nền đã bị hủy');
            error.name = 'AbortError';
            throw error;
        }
        startedAtMs = Date.now();
        try {
            const result = await operation();
            outcome = 'success';
            return result;
        } catch (error) {
            terminalError = error;
            outcome = error?.errorType === 'timeout' || error?.code === 'GENERATION_TIMEOUT'
                ? 'timeout'
                : isAbortError(error) || signal?.aborted
                    ? 'cancelled'
                    : 'error';
            throw error;
        }
    } finally {
        const finishedAtMs = Date.now();
        pushApiRequestTimeline({
            chatToken: chatTokenAtQueue,
            taskKind,
            route: routeAtQueue.label || '',
            model: timelineModel,
            lane: laneKey,
            queuedAt,
            startedAt: startedAtMs ? new Date(startedAtMs).toISOString() : '',
            finishedAt: new Date(finishedAtMs).toISOString(),
            waitMs: startedAtMs ? startedAtMs - queuedAtMs : finishedAtMs - queuedAtMs,
            durationMs: startedAtMs ? finishedAtMs - startedAtMs : 0,
            outcome,
            errorType: terminalError
                ? (terminalError?.errorType || classifyDiagnosticIssue(describeError(terminalError)))
                : 'none',
            transportStatus: terminalError?.transportStatus,
            upstreamStatus: terminalError?.upstreamStatus,
            retryAfterMs: terminalError?.retryAfterMs,
            request: requestShape,
        });
        release?.();
        void laneTail.finally(() => {
            if (runtime.connectionLanes.get(laneKey) === laneTail) {
                runtime.connectionLanes.delete(laneKey);
            }
        });
    }
}

function cooldownSeconds(milliseconds) {
    return Math.max(1, Math.ceil(Math.max(0, Number(milliseconds) || 0) / 1000));
}

function rateLimitLike(error) {
    return error?.errorType === 'rate-limit'
        || error?.code === 'RATE_LIMIT'
        || Number(error?.upstreamStatus) === 429
        || /429|too many requests|rate[_\s-]*limit|限流|频率限制|请求过于频繁|giới hạn tốc độ|quá nhiều yêu cầu/i
            .test(String(error?.message || error || ''));
}

function getCurrentTavernConnectionInfo() {
    const context = getContext();
    const settings = context?.chatCompletionSettings || {};
    const mainApi = String(context?.mainApi || 'unknown');
    const source = mainApi === 'openai'
        ? String(settings.chat_completion_source || 'openai')
        : mainApi;
    const latest = latestAssistantEntry()?.message;
    const modelKeys = [
        `${source}_model`,
        'custom_model',
        'openrouter_model',
        'google_model',
        'claude_model',
        'openai_model',
        'model',
    ];
    const configuredModel = modelKeys
        .map(key => settings?.[key])
        .find(value => typeof value === 'string' && value.trim());
    const messageModel = latest?.extra?.model || latest?.model;
    const manager = context?.extensionSettings?.connectionManager || {};
    const selectedProfile = (manager.profiles || []).find(profile => (
        profile?.id === manager.selectedProfile
        || profile?.name === manager.selectedProfile
    ));
    const apiLabels = {
        openai: 'Chat Completion',
        textgenerationwebui: 'Text Completion',
        kobold: 'KoboldAI',
        koboldhorde: 'AI Horde',
        novel: 'NovelAI',
        custom: 'API tương thích tùy chỉnh',
        google: 'Google AI Studio',
        makersuite: 'Google AI Studio',
        openrouter: 'OpenRouter',
        claude: 'Anthropic Claude',
    };

    return {
        mainApi,
        source,
        apiLabel: apiLabels[source] || apiLabels[mainApi] || source || 'Không nhận diện được',
        model: String(configuredModel || selectedProfile?.model || messageModel || 'Theo model hiện tại của Tavern'),
        profile: String(selectedProfile?.name || ''),
        online: String(context?.onlineStatus || ''),
        method: typeof context?.generateRaw === 'function' ? 'Suy diễn với ngữ cảnh độc lập' : 'Chế độ tương thích suy diễn yên lặng',
        configured: true,
    };
}

function getConnectionInfo() {
    const context = getContext();
    const pluginSettings = getSettings();
    if (pluginSettings.apiMode === 'custom') {
        let host = '';
        try {
            host = new URL(pluginSettings.customApiUrl).host;
        } catch {
            host = pluginSettings.customApiUrl;
        }
        return {
            mainApi: 'custom-independent',
            source: 'custom-independent',
            apiLabel: 'API độc lập tương thích OpenAI',
            model: pluginSettings.customApiModel || 'Chưa cấu hình model',
            profile: host || 'Chưa cấu hình địa chỉ API',
            online: '',
            method: pluginSettings.customApiTransport === 'direct'
                ? 'Trình duyệt kết nối trực tiếp (không kế thừa model của Tavern)'
                : 'Chuyển tiếp qua Custom của Tavern (không kế thừa model của Tavern)',
            configured: Boolean(
                pluginSettings.customApiUrl
                && pluginSettings.customApiKey
                && pluginSettings.customApiModel
            ),
        };
    }

    if (pluginSettings.apiMode === 'tavern-profile') {
        const profile = tavernConnectionProfileById(pluginSettings.tavernApiProfileId, context);
        const supported = listTavernConnectionProfiles()
            .some(item => item.id === String(pluginSettings.tavernApiProfileId || ''));
        return {
            mainApi: 'tavern-profile',
            source: String(profile?.api || 'tavern-profile'),
            apiLabel: 'Cấu hình API đã lưu của Tavern',
            model: String(profile?.model || 'Model của cấu hình không khả dụng'),
            profile: String(profile?.name || (pluginSettings.tavernApiProfileId ? 'Cấu hình được tham chiếu không còn tồn tại' : 'Chưa chọn cấu hình')),
            online: String(context?.onlineStatus || ''),
            method: 'Tham chiếu cấu hình kết nối Tavern (Key / URL vẫn do Tavern quản lý)',
            configured: Boolean(
                profile
                && supported
                && !tavernConnectionManagerDisabled(context)
                && typeof context?.ConnectionManagerRequestService?.sendRequest === 'function'
            ),
        };
    }

    return getCurrentTavernConnectionInfo();
}


function activeBackgroundTaskLabels() {
    const labels = [];
    if (runtime.worldbookImportRunning && !runtime.worldbookImportController?.signal?.aborted) labels.push('Sắp xếp World Info');
    const currentToken = currentChatToken();
    const activeSimulation = runtime.activeSimulation?.chatToken === currentToken
        && !runtime.activeSimulation?.controller?.signal?.aborted;
    if (activeSimulation) labels.push('Suy diễn thế giới');
    if (runtime.activeHistoryScan && !runtime.activeHistoryScan.signal?.aborted) {
        labels.push(runtime.historyProgress?.kind === 'world-bootstrap' ? 'Truy hồi lịch sử' : 'Sắp xếp ký ức');
    }
    if (runtime.activeWorldPulse?.controller && !runtime.activeWorldPulse.controller.signal.aborted) labels.push('Nhịp đập thế giới');
    if (runtime.activePublicImpact?.controller && !runtime.activePublicImpact.controller.signal.aborted) labels.push('Ảnh hưởng công cộng');
    if (runtime.activeCorrection?.controller && !runtime.activeCorrection.controller.signal.aborted) labels.push('Sửa lỗi sự thật');
    if (
        runtime.publicOpinionRefreshTransaction?.controller
        && !runtime.publicOpinionRefreshTransaction.controller.signal.aborted
    ) labels.push('Làm mới dư luận');
    else if (
        runtime.activePublicOpinion?.controller
        && !runtime.activePublicOpinion.controller.signal.aborted
    ) labels.push('Làm mới dư luận');
    if (
        runtime.activePublicOpinionSandbox?.controller
        && !runtime.activePublicOpinionSandbox.controller.signal.aborted
    ) labels.push('Dạo chơi tùy ý');
    if (
        runtime.activeObservation?.controller
        && !runtime.activeObservation.controller.signal.aborted
    ) labels.push('Quan sát nhân vật');
    if (
        runtime.activeLingqi?.controller
        && !runtime.activeLingqi.controller.signal.aborted
    ) labels.push('玲七');
    if (
        runtime.activeSocial?.controller
        && !runtime.activeSocial.controller.signal.aborted
    ) labels.push('Mạng xã hội tích hợp');
    if (
        runtime.activeFriendRequest?.controller
        && !runtime.activeFriendRequest.controller.signal.aborted
    ) labels.push('lời mời kết bạn');
    if (
        runtime.activeMoments?.controller
        && !runtime.activeMoments.controller.signal.aborted
    ) labels.push('Khoảnh khắc');
    if (
        runtime.activeSocialPulse?.controller
        && !runtime.activeSocialPulse.controller.signal.aborted
    ) labels.push('Liên lạc đời thường');
    else if (runtime.socialPulseTimer !== null) labels.push('Liên lạc đời thường chờ chạy');
    if (runtime.queuedSimulations.size > 0 || runtime.pendingManualSimulation) {
        labels.push('Suy diễn thế giới đang xếp hàng');
    }
    return [...new Set(labels)];
}

function latestNarrativeSyncSnapshot() {
    const latest = latestAssistantEntry();
    if (!latest) {
        return {
            hasLatest: false,
            latestMessageId: null,
            pendingTurns: 0,
            committed: true,
            needsSimulation: false,
            active: false,
            queued: false,
            status: 'empty',
        };
    }

    const swipeId = Number(latest.message?.swipe_id ?? 0);
    const sourceKey = branchSourceKey(latest.index, latest.message, swipeId);
    const branch = branchDataFromMessage(latest.message, swipeId);
    const branchMatchesSource = Boolean(branch?.sourceKey === sourceKey);
    const branchCommitted = Boolean(
        branchMatchesSource
        && branch.status === 'committed'
        && branch.result
        && !branch.stale
    );
    const stateCommit = getState()?.lastCommit;
    // 历史回溯可能只建立当前状态锚点而没有逐楼层快照；只有不存在当前
    // source 的分支记录时，才允许精确匹配的状态锚点作为完成证据。
    const stateCommitted = Boolean(
        !branchMatchesSource
        && stateCommit?.sourceKey === sourceKey
        && Number(stateCommit?.messageId) === Number(latest.index)
        && Number(stateCommit?.swipeId ?? 0) === swipeId
    );
    const committed = branchCommitted || stateCommitted;
    const chatToken = currentChatToken();
    const active = Boolean(
        runtime.activeSimulation?.chatToken === chatToken
        && runtime.activeSimulation?.sourceKey === sourceKey
        && !runtime.activeSimulation?.controller?.signal?.aborted
    );
    const queued = Boolean(
        runtime.queuedSimulations.has(`${chatToken}:${sourceKey}`)
        || (
            runtime.pendingManualSimulation
            && runtime.pendingManualSimulation.chatToken === chatToken
        )
    );
    const pendingTurns = committed ? 0 : Math.max(
        pendingAssistantEntriesThrough(latest.index).length,
        1,
    );
    const branchError = branchMatchesSource && branch?.status === 'error'
        ? String(branch.error || '')
        : '';
    const status = active
        ? 'running'
        : queued
            ? 'queued'
            : committed
                ? 'committed'
                : branchError
                    ? 'error'
                    : 'pending';

    return {
        hasLatest: true,
        latestMessageId: latest.index,
        latestSwipeId: swipeId,
        sourceKey,
        pendingTurns,
        committed,
        needsSimulation: !committed,
        active,
        queued,
        status,
        error: branchError,
    };
}

function getSyncStatus() {
    const latest = latestAssistantEntry();
    const store = getStore();
    const state = store.currentState;
    const recoveryPoints = listRecoveryPointHeaders(store);
    const latestRecovery = recoveryPoints.at(-1) || null;
    const chatToken = currentChatToken();
    const narrative = latestNarrativeSyncSnapshot();
    const pendingTurns = narrative.pendingTurns;
    const activeForCurrentChat = runtime.activeSimulation?.chatToken === chatToken
        ? runtime.activeSimulation
        : null;
    const activeTurns = activeForCurrentChat
        ? Math.max(1, Number(activeForCurrentChat.newAssistantCount) || 1)
        : 0;
    let derived = {};

    const liveSimulationPhase = narrative.active
        || narrative.queued
        || ['running', 'queued', 'cancelling'].includes(runtime.syncStatus.phase);
    if (!liveSimulationPhase && narrative.hasLatest) {
        if (
            narrative.status === 'error'
            || (narrative.needsSimulation && runtime.syncStatus.phase === 'error')
        ) {
            derived = {
                phase: 'error',
                message: 'Lần suy diễn thế giới trước thất bại',
                error: narrative.error || runtime.syncStatus.error || 'API suy diễn không cung cấp lỗi cụ thể',
            };
        } else if (narrative.needsSimulation) {
            derived = {
                phase: 'pending',
                message: 'Chính văn mới nhất vẫn đang chờ suy diễn',
                error: '',
            };
        } else if (narrative.committed) {
            derived = {
                phase: 'success',
                message: 'Chính văn mới nhất đã suy diễn xong',
                error: '',
                summary: branchDataFromMessage(latest.message)?.summary || runtime.syncStatus.summary || null,
            };
        }
    }

    return {
        ...runtime.syncStatus,
        ...derived,
        connection: getConnectionInfo(),
        lastConnection: runtime.lastTaskConnection ? { ...runtime.lastTaskConnection } : null,
        pluginVersion: PLUGIN_VERSION,
        userName: String(getContext()?.name1 || ''),
        memory: {
            indexedThroughMessageId: Number(state.storyMemory?.indexedThroughMessageId ?? -1),
            facts: state.storyMemory?.facts?.length || 0,
            summaries: state.storyMemory?.summaries?.length || 0,
            summaryLevels: [0, 1, 2, 3].map(level => (
                (state.storyMemory?.summaries || []).filter(summary => (
                    summary?.hierarchyManaged && Number(summary?.level || 0) === level
                )).length
            )),
            pendingRollup: Boolean(planMemoryRollup(state)),
            latestSummaryMessageId: Math.max(
                -1,
                ...(state.storyMemory?.summaries || []).map(summary => Number(summary?.endMessageId ?? -1)),
            ),
            summaryBehind: (() => {
                const indexedThrough = Number(state.storyMemory?.indexedThroughMessageId ?? -1);
                const latestSummaryMessageId = Math.max(
                    -1,
                    ...(state.storyMemory?.summaries || []).map(summary => Number(summary?.endMessageId ?? -1)),
                );
                return indexedThrough >= 0 && latestSummaryMessageId < indexedThrough;
            })(),
            clues: state.storyMemory?.clues?.length || 0,
            hasDigest: Boolean(state.storyMemory?.digest?.text),
            pendingAssistantResponses: unindexedAssistantCount(),
            totalMessages: getContext()?.chat?.length || 0,
            ...runtime.historyProgress,
        },
        manualUndo: {
            available: Boolean(
                runtime.manualUndo
                && runtime.manualUndo.expiresAt > Date.now()
                && runtime.manualUndo.chatToken === currentChatToken()
                && runtime.manualUndo.key === currentAnchorKey()
            ),
            label: runtime.manualUndo?.label || 'Hoàn tác thay đổi thủ công vừa rồi',
        },
        editDecision: {
            available: Boolean(
                runtime.editDecision
                && runtime.editDecision.chatToken === currentChatToken()
                && runtime.editDecision.messageId === latestAssistantEntry()?.index
            ),
            messageId: runtime.editDecision?.messageId ?? null,
        },
        presentPersonIds: currentTurnPresentPersonIds(),
        availableModels: runtime.customModels,
        modelPull: runtime.modelPullStatus,
        promptBridge: runtime.lastPromptBridge || {
            enabled: false,
            promptCount: 0,
            available: false,
            truncated: false,
            internalCompatChars: String(INTERNAL_COMPAT_SYSTEM_PROMPT || '').trim().length,
            at: '',
        },
        publicOpinion: (() => {
            const opinionStore = store;
            const storedOpinion = normalizePublicOpinionCache(
                opinionStore.publicOpinion || emptyPublicOpinionCache(),
            );
            const displayOpinion = storedOpinion;
            return {
                ...displayOpinion,
                ...runtime.publicOpinionStatus,
                sandbox: opinionStore.publicOpinionSandbox || emptyPublicOpinionSandbox(),
                sandboxStatus: { ...runtime.publicOpinionSandboxStatus },
                canonRunning: Boolean(
                    runtime.publicOpinionRefreshTransaction
                    || (runtime.activePublicOpinion && !runtime.activePublicOpinion?.controller?.signal?.aborted)
                ),
                sandboxRunning: Boolean(runtime.activePublicOpinionSandbox && !runtime.activePublicOpinionSandbox?.controller?.signal?.aborted),
                stale: planPublicOpinionRefresh(state, storedOpinion).due,
            };
        })(),
        lingqi: {
            ...normalizeLingqiState(store.lingqi || emptyLingqiState()),
            ...runtime.lingqiStatus,
            pendingAction: (
                runtime.pendingLingqiAction?.chatToken === chatToken
                && runtime.pendingLingqiAction?.contextEpoch === runtime.contextEpoch
            ) ? { ...runtime.pendingLingqiAction } : null,
            running: Boolean(runtime.activeLingqi && runtime.activeLingqi.chatToken === chatToken && !runtime.activeLingqi.controller?.signal?.aborted),
        },
        social: {
            ...normalizeSocialState(store.social || emptySocialState(), state.people),
            ...runtime.socialStatus,
            running: Boolean(runtime.activeSocial && runtime.activeSocial.chatToken === chatToken && !runtime.activeSocial.controller?.signal?.aborted),
            friendRequest: {
                ...runtime.friendRequestStatus,
                running: Boolean(runtime.activeFriendRequest && runtime.activeFriendRequest.chatToken === chatToken && !runtime.activeFriendRequest.controller?.signal?.aborted),
            },
            momentsStatus: {
                ...runtime.momentsStatus,
                running: Boolean(runtime.activeMoments && runtime.activeMoments.chatToken === chatToken && !runtime.activeMoments.controller?.signal?.aborted),
            },
        },
        worldbook: {
            ...runtime.worldbookScan,
            books: getWorldbookNames(),
            aiImport: {
                ...runtime.worldbookImport,
                running: Boolean(runtime.worldbookImportRunning),
            },
        },
        recovery: {
            count: recoveryPoints.length,
            latest: latestRecovery ? {
                id: latestRecovery.id,
                createdAt: latestRecovery.createdAt,
                label: latestRecovery.label,
                worldName: latestRecovery.worldName,
                worldMinute: latestRecovery.worldMinute,
                revision: latestRecovery.revision,
            } : null,
        },
        queue: {
            pendingTurns,
            waitingTurns: Math.max(0, pendingTurns - activeTurns),
            activeMessageId: activeForCurrentChat?.messageId ?? null,
        },
        narrative,
        canCancelSimulation: Boolean(
            activeForCurrentChat
            && !activeForCurrentChat.controller.signal.aborted
        ),
        manualSimulationQueued: Boolean(
            runtime.pendingManualSimulation
            && runtime.pendingManualSimulation.chatToken === chatToken
        ),
        activeBackgroundTasks: activeBackgroundTaskLabels(),
        canCancelBackgroundTask: activeBackgroundTaskLabels().length > 0,
    };
}

function setSyncStatus(patch) {
    const phaseChanged = Object.hasOwn(patch || {}, 'phase');
    runtime.syncStatus = {
        ...runtime.syncStatus,
        ...patch,
        ...(phaseChanged && !Object.hasOwn(patch || {}, 'summary') ? { summary: null } : {}),
    };
    runtime.ui?.render();
}

function beginTaskTrace(taskKind, details = {}) {
    const attemptedAt = new Date().toISOString();
    runtime.lastTaskTrace = {
        taskKind: String(taskKind || 'unknown'),
        phase: 'running',
        stage: 'preparing',
        attempt: 0,
        responseOutcome: 'none',
        parseOutcome: 'none',
        validationOutcome: 'none',
        commitOutcome: 'none',
        responseCharacters: 0,
        errorType: 'none',
        errorSummary: '',
        attemptHistory: [],
        attemptedAt,
        responseAt: '',
        parsedAt: '',
        committedAt: '',
        finishedAt: '',
        ...details,
    };
    return runtime.lastTaskTrace;
}

function updateTaskTrace(patch = {}) {
    if (!runtime.lastTaskTrace) return null;
    runtime.lastTaskTrace = { ...runtime.lastTaskTrace, ...patch };
    return runtime.lastTaskTrace;
}

function finishTaskTrace(phase, patch = {}) {
    return updateTaskTrace({ phase, finishedAt: new Date().toISOString(), ...patch });
}

function recordTaskAttemptFailure({ attempt, total, delayMs, error, rateLimited }) {
    if (!runtime.lastTaskTrace) return;
    const issueType = error?.errorType || classifyDiagnosticIssue(describeError(error));
    const previous = Array.isArray(runtime.lastTaskTrace.attemptHistory)
        ? runtime.lastTaskTrace.attemptHistory
        : [];
    updateTaskTrace({
        attemptHistory: [...previous, {
            attempt: Number(attempt) || 0,
            total: Number(total) || 0,
            stage: runtime.lastTaskTrace.stage,
            errorType: issueType,
            errorSummary: describeError(error),
            retryDelayMs: Math.max(0, Number(delayMs) || 0),
            rateLimited: Boolean(rateLimited),
            failedAt: new Date().toISOString(),
        }].slice(-6),
    });
}

function shouldRetryWorldGeneration(error) {
    if (isAbortError(error)) return false;
    const status = Number(error?.upstreamStatus ?? error?.transportStatus ?? error?.status) || 0;
    if (status >= 400 && status < 500 && ![408, 409, 425, 429].includes(status)) return false;
    const issueType = error?.errorType || classifyDiagnosticIssue(describeError(error));
    return !['authorization', 'quota-exhausted'].includes(issueType)
        && !/请先填写独立 API|没有找到可以推演|没有提供安静生成接口|hãy điền.{0,40}API độc lập|chưa điền.{0,40}API độc lập|không tìm thấy.{0,40}(?:để|có thể) suy diễn|không (?:cung cấp|có|hỗ trợ).{0,30}(?:quiet|tạo ngầm|tạo im lặng|tạo yên lặng)|sinh yên lặng/i.test(describeError(error));
}

function describeError(error) {
    const candidates = [
        error?.message,
        error?.error?.message,
        error?.response,
        typeof error === 'string' ? error : '',
    ];
    let message = candidates
        .map(value => String(value || '').trim())
        .find(Boolean) || '';

    if (!message || message === '<none>' || message === '[object Object]') {
        try {
            const serialized = JSON.stringify(error);
            if (serialized && serialized !== '{}' && serialized !== '"<none>"') message = serialized;
        } catch {
            // Ignore serialization errors and use the actionable fallback below.
        }
    }
    if (!message || message === '<none>' || message === '[object Object]') {
        return 'API suy diễn không trả về lỗi cụ thể; hãy kiểm tra kết nối của 世界背面 trước, rồi thử lại chính văn mới nhất';
    }
    return message.slice(0, 420);
}

function retryJsonPrompt(prompt, attempt) {
    if (!(attempt > 0)) return prompt;
    return `${prompt}\n\n<json_retry>\nĐây là lần thứ ${attempt} thử lại định dạng. Lần trước kết quả trả về không phân tích được hoặc đã chạm giới hạn đầu ra. Hãy tạo lại một đối tượng JSON hoàn chỉnh, nghiêm ngặt, đóng đủ; không tiếp nối câu bị cắt cụt, không dùng khối mã hay giải thích. Ưu tiên lược bỏ các mục tùy chọn không thay đổi, tuyệt đối không được lược bỏ dấu ngoặc đóng cuối cùng.\n</json_retry>`;
}

function retrySimulationPrompt(prompt, attempt) {
    if (!(attempt > 0)) return prompt;
    return `${prompt}\n\n<json_retry>\nĐây là lần thứ ${attempt} thử lại định dạng suy diễn thế giới. Lần trước kết quả quá dài hoặc không đóng đủ, lần này bắt buộc chuyển sang JSON gia tăng tinh gọn, không được viết lại nguyên dạng. Chỉ trả về những thay đổi thật sự của lượt này; trường không đổi thì dùng mảng rỗng hoặc bỏ hẳn, cấm thuật lại trạng thái có thẩm quyền, nhân vật cũ, sự kiện cũ và các mục giữ chỗ trong ví dụ. Giới hạn cứng: people_upsert 8 mục, events_create 4 mục, events_update 8 mục, world_facts_upsert 10 mục, world_pulse_upsert 6 mục, memory_update mỗi loại 8 mục. Mỗi trường mô tả chỉ viết một câu ngắn hoàn chỉnh (bằng tiếng Việt). Thà bớt thay đổi tùy chọn, cũng phải đóng hết mọi chuỗi, mảng và đối tượng trước. Chỉ xuất một đối tượng JSON hợp lệ.\n</json_retry>`;
}

function retryTokenBudget(base, attempt) {
    return Math.max(64, Number(base) || 3200) + Math.max(0, attempt) * 1800;
}

function approximateTokens(text) {
    const value = String(text || '');
    const cjkCharacters = (value.match(/[\u3400-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]/g) || []).length;
    const remainingCharacters = Math.max(0, value.length - cjkCharacters);
    return Math.max(0, Math.ceil(cjkCharacters + remainingCharacters / 4));
}

function changedItems(beforeItems = [], afterItems = [], fields = []) {
    const beforeById = new Map(beforeItems.map(item => [item.id, item]));
    const added = [];
    const updated = [];
    for (const item of afterItems) {
        const previous = beforeById.get(item.id);
        if (!previous) {
            added.push(item);
            continue;
        }
        const beforeShape = fields.map(field => previous?.[field]);
        const afterShape = fields.map(field => item?.[field]);
        if (JSON.stringify(beforeShape) !== JSON.stringify(afterShape)) updated.push(item);
    }
    return { added, updated };
}

function simulationSummary(before, after, {
    prompt = '',
    raw = '',
    attempts = 1,
    tokenBudget = 0,
    injection = { text: '', eventIds: [], omittedLines: 0 },
} = {}) {
    const people = changedItems(before.people, after.people, [
        'name', 'location', 'action', 'intent', 'longTermGoal', 'trace', 'innerVoice',
    ]);
    const events = changedItems(before.events, after.events, [
        'title', 'summary', 'status', 'result', 'consequence', 'visibility', 'delivery',
    ]);
    const beforeMemory = before.storyMemory || {};
    const afterMemory = after.storyMemory || {};
    const facts = changedItems(beforeMemory.facts, afterMemory.facts, [
        'subject', 'predicate', 'value', 'status', 'importance', 'locked', 'important',
    ]);
    const clues = changedItems(beforeMemory.clues, afterMemory.clues, [
        'title', 'text', 'status', 'importance', 'locked', 'important',
    ]);
    const summaries = changedItems(beforeMemory.summaries, afterMemory.summaries, [
        'title', 'summary', 'startMessageId', 'endMessageId',
    ]);
    return {
        elapsedMinutes: Math.max(0, Number(after.clock?.absoluteMinute) - Number(before.clock?.absoluteMinute)),
        peopleChanged: people.added.length + people.updated.length,
        peopleNames: [...people.added, ...people.updated].map(item => item.name).filter(Boolean).slice(0, 6),
        eventsAdded: events.added.length,
        eventsUpdated: events.updated.length,
        eventTitles: [...events.added, ...events.updated].map(item => item.title).filter(Boolean).slice(0, 6),
        memoryAdded: facts.added.length + clues.added.length + summaries.added.length,
        memoryUpdated: facts.updated.length + clues.updated.length + summaries.updated.length,
        promptCharacters: String(prompt || '').length,
        promptTokens: approximateTokens(prompt),
        outputCharacters: String(raw || '').length,
        outputTokens: approximateTokens(raw),
        outputBudget: Number(tokenBudget) || 0,
        attempts: Math.max(1, Number(attempts) || 1),
        injectionCharacters: String(injection.text || '').length,
        injectionLines: String(injection.text || '').split('\n').filter(Boolean).length,
        injectionEvents: injection.eventIds?.length || 0,
        omittedInjectionLines: Number(injection.omittedLines) || 0,
    };
}

function unreadableJsonError(raw, subject = 'Model') {
    const text = String(raw || '').trim();
    if (!text) {
        const error = new Error(`${subject} không trả về trạng thái JSON đọc được`);
        error.errorType = 'empty-response';
        return error;
    }
    const compact = text.replace(/\s+/g, ' ');
    const structural = compact
        .replace(/^```(?:json)?\s*/i, '')
        .replace(/\s*```$/, '')
        .trim();
    const beginning = compact.slice(0, 90);
    const ending = compact.length > 140 ? compact.slice(-70) : '';
    const likelyTruncated = /^[\[{]/.test(structural) && !/[}\]]\s*$/.test(structural);
    const detail = ending ? `Phần đầu: ${beginning}; phần cuối: ${ending}` : beginning;
    const error = new Error(
        `${subject} trả về JSON ${likelyTruncated ? 'chưa đóng, nghi bị cắt do giới hạn đầu ra' : 'không hợp lệ'}`
        + `（${text.length} ký tự): ${detail}`,
    );
    error.errorType = likelyTruncated ? 'output-limit' : 'invalid-json';
    if (likelyTruncated) {
        error.code = 'OUTPUT_TRUNCATED';
        error.partialText = text;
    }
    return error;
}

function attachBranchData(message, swipeId, data) {
    if (!message || typeof message !== 'object') return;
    const storedData = clone(data);
    compactBranchDataMemory(storedData, getStore());
    message.extra ||= {};

    const swipeInfo = message.swipe_info?.[swipeId];
    if (swipeInfo && typeof swipeInfo === 'object') {
        swipeInfo.extra ||= {};
        swipeInfo.extra[SNAPSHOT_KEY] = storedData;

        // Keep exactly one full copy. branchDataFromMessage reads swipe_info first.
        if (Number(message.swipe_id ?? 0) === Number(swipeId)) {
            delete message.extra[SNAPSHOT_KEY];
        }
        return;
    }

    // Some ST message shapes do not expose swipe_info. Fall back to message.extra.
    if (Number(message.swipe_id ?? 0) === Number(swipeId)) {
        message.extra[SNAPSHOT_KEY] = storedData;
    }
}

function compactBranchSnapshotStorage({
    keepRecentAssistant = 50,
} = {}) {
    const context = getContext();
    const chat = context?.chat || [];
    const snapshotStore = getStore();
    const memorySnapshotsCompacted = compactSnapshotMemoryLedgers(snapshotStore, chat, SNAPSHOT_KEY);
    if (memorySnapshotsCompacted) saveStore(snapshotStore);
    const assistantIndexes = chat
        .map((message, index) => (!message?.is_user && !message?.is_system ? index : -1))
        .filter(index => index >= 0);
    const recentStart = assistantIndexes.length > keepRecentAssistant
        ? assistantIndexes[assistantIndexes.length - keepRecentAssistant]
        : -1;

    let changed = memorySnapshotsCompacted;
    const compactCommitted = (data, historical = false) => {
        if (!data || typeof data !== 'object' || data.status !== 'committed') return;
        if (data.base) {
            data.base = null;
            changed = true;
        }
        if (historical) {
            if (data.summary) {
                delete data.summary;
                changed = true;
            }
            if (Array.isArray(data.offeredEventIds) && data.offeredEventIds.length) {
                data.offeredEventIds = [];
                changed = true;
            }
            if (data.error) {
                data.error = '';
                changed = true;
            }
            data.storageCompacted = true;
        }
    };

    for (let index = 0; index < chat.length; index += 1) {
        const message = chat[index];
        if (!message || message.is_user || message.is_system) continue;
        const currentSwipe = Number(message.swipe_id ?? 0);
        const historical = recentStart >= 0 && index < recentStart;

        // Canonicalize current swipe into swipe_info and remove the duplicate
        // message.extra full state left by older versions.
        const currentSwipeData = message.swipe_info?.[currentSwipe]?.extra?.[SNAPSHOT_KEY];
        if (currentSwipeData && message.extra?.[SNAPSHOT_KEY]) {
            delete message.extra[SNAPSHOT_KEY];
            changed = true;
        }

        if (!currentSwipeData) {
            compactCommitted(message.extra?.[SNAPSHOT_KEY], historical);
        }

        for (let swipeId = 0; swipeId < (message.swipe_info?.length || 0); swipeId += 1) {
            const swipeInfo = message.swipe_info?.[swipeId];
            const data = swipeInfo?.extra?.[SNAPSHOT_KEY];
            if (!data) continue;
            // Historical alternate swipes are real branches, not disposable cache.
            // Long-memory payloads are already deduplicated, so keep every committed
            // branch and compact it instead of deleting the user's alternate history.
            compactCommitted(data, historical);
        }
    }
    return changed;
}


function findLatestResultSnapshot(beforeIndex = Infinity) {
    const context = getContext();
    const chat = context?.chat || [];
    const start = Math.min(chat.length - 1, Number(beforeIndex) - 1);

    for (let index = start; index >= 0; index -= 1) {
        const message = chat[index];
        if (!message || message.is_user) continue;
        const swipeId = Number(message.swipe_id ?? 0);
        const data = branchDataFromMessage(message, swipeId);
        const sourceKey = branchSourceKey(index, message, swipeId);
        if (committedBranchMatchesSource(data, sourceKey)) {
            return { snapshot: data.result, messageId: index, data };
        }
    }
    return null;
}

function stateWithBranchOverride(snapshot, store = getStore()) {
    const restored = restoreBranchSnapshot(snapshot, store.initialState);
    const sourceKey = snapshot?.meta?.sourceKey || '';
    const override = sourceKey ? store.branchOverrides[sourceKey] : null;
    return override ? restoreBranchSnapshot(override, restored) : restored;
}

function currentAnchorKey() {
    const state = getState();
    return state.lastCommit?.sourceKey || 'root';
}

function restoreSurfaceForState(store, state, { seedFallback = true } = {}) {
    const restored = restoreBranchSurface(store, branchSurfaceKeyFromState(state), {
        fallbackSocial: emptySocialState(),
        fallbackPublicOpinion: emptyPublicOpinionCache(),
        seedFallback,
    });
    // Dismissed news/forum items are a global presentation choice, not branch
    // history. Reapply that filter after restoring a historical feed so a user-
    // hidden item cannot reappear merely because they switched swipes.
    store.publicOpinionDismissed = normalizePublicOpinionDismissed(store.publicOpinionDismissed);
    store.publicOpinion = filterDismissedPublicOpinion(
        store.publicOpinion || emptyPublicOpinionCache(),
        store.publicOpinionDismissed,
    );
    return restored;
}

function ensureResultBranchSurface(store, targetSourceKey, baseState) {
    const baseKey = branchSurfaceKeyFromState(baseState);
    if (!hasBranchSurface(store, baseKey) && branchSurfaceKeyFromState(store.currentState) === baseKey) {
        captureBranchSurface(store, baseKey);
    }
    if (!inheritBranchSurface(store, targetSourceKey, baseKey)) {
        inheritBranchSurface(store, targetSourceKey, baseKey, {
            fallbackSocial: emptySocialState(),
            fallbackPublicOpinion: emptyPublicOpinionCache(),
        });
    }
}

function settleResultBranchSurface(store, targetSourceKey, baseState, resultState, {
    settledSocialMessages = null,
    narrativeText = '',
} = {}) {
    ensureResultBranchSurface(store, targetSourceKey, baseState);
    const settings = getSettings();
    if (settings.worldPromptInjection === false || settings.injectionSocial !== true) return;

    // A simulation may finish after a newer assistant reply has already appeared.
    // Its core result is still a real historical branch, so settle the social
    // messages into that branch sidecar even though it must not overwrite the
    // currently active world's social state.
    const activeSocial = store.social;
    const activePublicOpinion = store.publicOpinion;
    restoreBranchSurface(store, targetSourceKey, {
        fallbackSocial: emptySocialState(),
        fallbackPublicOpinion: emptyPublicOpinionCache(),
    });
    store.social = settleSocialConversations(
        store.social,
        resultState,
        settledSocialMessages,
        narrativeText,
    );
    captureBranchSurface(store, targetSourceKey);
    store.social = activeSocial;
    store.publicOpinion = activePublicOpinion;
}

function ensureMonotonicRevision(nextState, previousState = null) {
    const next = trimState(nextState);
    const previousRevision = Math.max(0, Number(previousState?.revision) || 0);
    const proposedRevision = Math.max(0, Number(next?.revision) || 0);
    next.revision = Math.max(proposedRevision, previousRevision + 1);
    next.updatedAt = new Date().toISOString();
    return next;
}

function setCurrentState(nextState, {
    save = true,
    overrideKey = null,
    immediate = false,
} = {}) {
    const store = getStore();
    const monotonicState = ensureMonotonicRevision(nextState, store.currentState);
    store.currentState = applyPlayerCharacterRecordingPolicy(
        applyManualDeletionFilters(monotonicState, store),
        getSettings(),
    );

    if (overrideKey) {
        store.branchOverrides[overrideKey] = createBranchSnapshot(store.currentState, {
            sourceKey: overrideKey,
            kind: 'manual-override',
        });
    }

    if (save) saveStore(store, { immediate });
    refreshInjection();
    runtime.ui?.render();
    return store.currentState;
}

function restoreLatestBranch({ pending = false } = {}) {
    const store = getStore();
    captureBranchSurface(store, branchSurfaceKeyFromState(store.currentState));
    const latest = findLatestResultSnapshot();
    let state = latest
        ? stateWithBranchOverride(latest.snapshot, store)
        : (
            store.branchOverrides.root
                ? restoreBranchSnapshot(store.branchOverrides.root, store.initialState)
                : clone(store.initialState)
        );
    if (pending) state = markPendingSync(state, true);
    store.currentState = trimState(state);
    restoreSurfaceForState(store, store.currentState);
    saveStore(store);
    refreshInjection();
    runtime.ui?.render();
    return store.currentState;
}

function recentChatText(maximum = 8, beforeIndex = Infinity) {
    const chat = getContext()?.chat || [];
    const end = Number.isFinite(Number(beforeIndex))
        ? Math.max(0, Math.min(chat.length, Number(beforeIndex)))
        : chat.length;
    return chat
        .slice(0, end)
        .slice(-maximum)
        .map(message => narrativeMessageText(message))
        .join('\n')
        .slice(-9000);
}

function recentForegroundIntentText(beforeIndex = Infinity) {
    const fullChat = getContext()?.chat || [];
    const end = Number.isFinite(Number(beforeIndex))
        ? Math.max(0, Math.min(fullChat.length, Number(beforeIndex)))
        : fullChat.length;
    const chat = fullChat.slice(0, end);
    if (!chat.length) return '';

    let latestUserIndex = -1;
    for (let index = chat.length - 1; index >= 0; index -= 1) {
        const message = chat[index];
        if (message?.is_user && !message?.is_system) {
            latestUserIndex = index;
            break;
        }
    }

    let nearestAssistantIndex = -1;
    if (latestUserIndex >= 0) {
        for (let distance = 1; distance <= 2; distance += 1) {
            for (const candidate of [latestUserIndex - distance, latestUserIndex + distance]) {
                const message = chat[candidate];
                if (
                    candidate >= 0
                    && candidate < chat.length
                    && message
                    && !message.is_user
                    && !message.is_system
                ) {
                    nearestAssistantIndex = candidate;
                    break;
                }
            }
            if (nearestAssistantIndex >= 0) break;
        }
    } else {
        for (let index = chat.length - 1; index >= 0; index -= 1) {
            const message = chat[index];
            if (message && !message.is_user && !message.is_system) {
                nearestAssistantIndex = index;
                break;
            }
        }
    }

    const selected = [];
    if (nearestAssistantIndex >= 0) {
        selected.push({
            index: nearestAssistantIndex,
            text: narrativeMessageText(chat[nearestAssistantIndex]),
        });
    }
    if (latestUserIndex >= 0) {
        selected.push({
            index: latestUserIndex,
            text: narrativeMessageText(chat[latestUserIndex]),
        });
    }

    return selected
        .sort((a, b) => a.index - b.index)
        .map(item => item.text)
        .filter(Boolean)
        .join('\n')
        .slice(-4500);
}

function selectedMessageText(message) {
    if (!message) return '';
    if (message.is_user) return String(message.mes || '');
    const swipeId = Number(message.swipe_id ?? 0);
    return String(message.swipes?.[swipeId] ?? message.mes ?? '');
}

function narrativeMessageText(message) {
    return filterNarrativeText(selectedMessageText(message), getSettings());
}

function hasUsableAssistantText(message) {
    if (!message || message.is_user || message.is_system) return false;
    if (message.is_error || message.error || message.extra?.generation_error || message.extra?.api_error) {
        return false;
    }
    const text = selectedMessageText(message).trim();
    return Boolean(text && !/^(?:\.{3}|…+|（?空回复）?|[（(]?(?:phản hồi trống|trả lời trống)[）)]?)$/iu.test(text));
}

function narrativeContext(messageId, maximumTurns = 3) {
    const chat = getContext()?.chat || [];
    const assistant = chat[Number(messageId)];
    let userText = '';
    for (let index = Number(messageId) - 1; index >= 0; index -= 1) {
        if (chat[index]?.is_user) {
            userText = narrativeMessageText(chat[index]);
            break;
        }
    }
    const assistantText = narrativeMessageText(assistant);

    let startIndex = 0;
    let userTurns = 0;
    for (let index = Number(messageId); index >= 0; index -= 1) {
        if (chat[index]?.is_user) {
            userTurns += 1;
            if (userTurns >= maximumTurns) {
                startIndex = index;
                break;
            }
        }
    }
    const turns = chat
        .slice(startIndex, Number(messageId) + 1)
        .map((message, offset) => ({ message, messageId: startIndex + offset }))
        .filter(entry => entry.message && !entry.message.is_system)
        .map(({ message, messageId: turnMessageId }) => ({
            messageId: turnMessageId,
            swipeId: message.is_user ? 0 : Number(message.swipe_id ?? 0),
            role: message.is_user ? 'user' : 'assistant',
            content: narrativeMessageText(message),
        }))
        .filter(turn => turn.content);

    return {
        latestTurn: {
            user: userText,
            assistant: assistantText,
        },
        turns,
        assistant: String(assistantText),
    };
}

function currentTurnPresentPersonIds() {
    const latest = latestAssistantEntry();
    if (!latest) return [];
    return getState().people
        .filter(person => Number(person.presentInSceneMessageId) === Number(latest.index))
        .map(person => person.id);
}

function pendingAssistantEntriesThrough(messageId) {
    const target = Number(messageId);
    const chat = getContext()?.chat || [];
    const previous = findLatestResultSnapshot(target + 1);
    const start = previous ? previous.messageId + 1 : 0;
    const entries = [];
    for (let index = start; index <= target; index += 1) {
        const message = chat[index];
        if (!hasUsableAssistantText(message)) continue;
        const swipeId = Number(message.swipe_id ?? 0);
        const branch = branchDataFromMessage(message, swipeId);
        if (!branch) continue;
        const sourceKey = branchSourceKey(index, message, swipeId);
        if (committedBranchMatchesSource(branch, sourceKey)) continue;
        entries.push({ message, index });
    }
    return entries;
}

const HISTORY_BATCH_TARGET_ASSISTANT_TURNS = 10;

function nextHistoryBatch(cursor, {
    maximumCharacters = 24000,
    maximumUserTurns = 8,
    maximumAssistantTurns = 6,
} = {}) {
    const chat = getContext()?.chat || [];
    const messages = [];
    let characters = 0;
    let userTurns = 0;
    let assistantTurns = 0;
    let endMessageId = Math.max(-1, Number(cursor) - 1);

    for (let index = Math.max(0, Number(cursor) || 0); index < chat.length; index += 1) {
        if (messages.length && assistantTurns >= maximumAssistantTurns) {
            endMessageId = index - 1;
            break;
        }
        const message = chat[index];
        endMessageId = index;
        if (!message || message.is_system) continue;
        const role = message.is_user ? 'user' : 'assistant';
        const maximum = role === 'user' ? 4000 : 7000;
        const content = narrativeMessageText(message).slice(0, maximum);
        if (!content) continue;
        const nextCharacters = characters + content.length;
        const nextUserTurns = userTurns + (role === 'user' ? 1 : 0);
        if (
            messages.length
            && (
                nextCharacters > maximumCharacters
                || nextUserTurns > maximumUserTurns
            )
        ) {
            endMessageId = index - 1;
            break;
        }
        messages.push({
            id: index,
            swipe: message.is_user ? 0 : Number(message.swipe_id ?? 0),
            role,
            content,
        });
        characters = nextCharacters;
        userTurns = nextUserTurns;
        if (role === 'assistant') assistantTurns += 1;
    }

    return {
        messages,
        startMessageId: messages[0]?.id ?? Math.max(0, Number(cursor) || 0),
        endMessageId: messages.at(-1)?.id ?? endMessageId,
        nextCursor: Math.max(Number(cursor) + 1, endMessageId + 1),
        totalMessages: chat.length,
    };
}


function publicOpinionEventSignature(state) {
    // 只签公开表面，不把事件内部 updatedAt / 幕后 status 的每轮变化算成“新舆情”。
    return publicOpinionSourceSignature(state);
}

function publicWorldNeedsRefresh(state, _candidates = eligiblePublicOpinionEvents(state)) {
    return publicWorldCoverageDue(state, {
        customInstruction: getSettings().customSimulationInstruction,
        minimumIntervalMinutes: 180,
    });
}

function scheduleAutoPublicOpinion(state = getState(), delay = 260) {
    const settings = getSettings();
    if (!settings.enabled || !settings.publicOpinionAutoEnabled) return false;
    const store = getStore();
    const plan = planPublicOpinionRefresh(state, store.publicOpinion || emptyPublicOpinionCache());
    // 正文每次成功同步都会来“敲门”，但只有公开来源真的变化，或世界时间走到
    // 舆情/新闻自己的演化节点，才排一次 AI。没到点就完全不调用模型。
    if (!plan.due) {
        runtime.pendingPublicOpinion = false;
        return false;
    }
    runtime.pendingPublicOpinion = true;
    const chatToken = currentChatToken();
    if (runtime.publicOpinionTimer !== null) window.clearTimeout(runtime.publicOpinionTimer);
    runtime.publicOpinionTimer = window.setTimeout(
        () => scheduleDeferredPublicOpinion(Math.max(220, Number(delay) || 260), chatToken),
        Math.max(120, Number(delay) || 260),
    );
    return true;
}

function schedulePublicImpactPropagation(state = getState(), delay = 160) {
    const settings = getSettings();
    if (
        !settings.enabled
        || !settings.worldSimulationEnabled
        || !settings.worldAutoEnabled
        || !pendingPublicImpactEvents(state, { maximum: 8 }).length
    ) return false;

    runtime.pendingPublicImpact = true;
    const chatToken = currentChatToken();
    if (runtime.publicImpactTimer !== null) window.clearTimeout(runtime.publicImpactTimer);
    runtime.publicImpactTimer = window.setTimeout(
        () => scheduleDeferredPublicImpact(Math.max(180, Number(delay) || 160), chatToken),
        Math.max(120, Number(delay) || 160),
    );
    return true;
}

function schedulePublicPostProcessing(state = getState(), {
    impactDelay = 160,
    opinionDelay = 520,
} = {}) {
    const impactScheduled = schedulePublicImpactPropagation(state, impactDelay);
    if (!impactScheduled) {
        scheduleAutoPublicOpinion(state, opinionDelay);
    }
    scheduleSocialPulse(Math.max(900, Number(opinionDelay) + 420));
    return impactScheduled;
}

function historyBootstrapPrefixSignature(endExclusive, context = getContext()) {
    const limit = Math.max(0, Math.min(
        context?.chat?.length || 0,
        Number.parseInt(endExclusive, 10) || 0,
    ));
    const parts = [];
    for (let index = 0; index < limit; index += 1) {
        const message = context?.chat?.[index];
        if (!message || message.is_system) continue;
        parts.push([
            index,
            message.is_user ? 'u' : 'a',
            message.is_user ? 0 : Number(message.swipe_id ?? 0),
            hashText(narrativeMessageText(message)),
        ].join(':'));
    }
    return hashText(parts.join('|'));
}

function validHistoryBootstrapCheckpoint(store, {
    chatToken = currentChatToken(),
    chatLength = getContext()?.chat?.length || 0,
    baseRevision = Math.max(0, Number(getState()?.revision) || 0),
} = {}) {
    const checkpoint = store?.historyBootstrapCheckpoint;
    if (!checkpoint || typeof checkpoint !== 'object') return null;
    const cursor = Math.max(0, Number.parseInt(checkpoint.cursor, 10) || 0);
    const valid = (
        Number(checkpoint.version) === 1
        && String(checkpoint.chatToken || '') === String(chatToken || '')
        && cursor > 0
        && cursor <= chatLength
        && Math.max(0, Number(checkpoint.baseRevision) || 0) === baseRevision
        && Boolean(checkpoint.stagedState && typeof checkpoint.stagedState === 'object')
        && Boolean(checkpoint.prefixSignature)
        && checkpoint.prefixSignature === historyBootstrapPrefixSignature(cursor)
        && Boolean(checkpoint.recordPlayerCharacter) === Boolean(getSettings().recordPlayerCharacter)
    );
    return valid ? { ...checkpoint, cursor } : null;
}

async function saveHistoryBootstrapCheckpoint({
    chatToken,
    cursor,
    chatLength,
    baseRevision,
    stagedState,
    assistantBatchLimit,
} = {}) {
    if (!(cursor > 0) || !stagedState) return false;
    const store = getStore();
    store.historyBootstrapCheckpoint = {
        version: 1,
        chatToken: String(chatToken || ''),
        cursor: Math.max(0, Number.parseInt(cursor, 10) || 0),
        totalAtStart: Math.max(0, Number.parseInt(chatLength, 10) || 0),
        baseRevision: Math.max(0, Number(baseRevision) || 0),
        prefixSignature: historyBootstrapPrefixSignature(cursor),
        recordPlayerCharacter: Boolean(getSettings().recordPlayerCharacter),
        assistantBatchLimit: Math.max(1, Number.parseInt(assistantBatchLimit, 10) || 1),
        stagedState: trimState(stagedState),
        updatedAt: new Date().toISOString(),
    };
    await saveStore(store, { immediate: true });
    return true;
}

function clearHistoryBootstrapCheckpoint({ immediate = true } = {}) {
    const store = getStore();
    if (!store.historyBootstrapCheckpoint) return false;
    store.historyBootstrapCheckpoint = null;
    saveStore(store, { immediate });
    return true;
}

function socialPulseRelationSignature(social = {}) {
    const rows = (Array.isArray(social?.connections) ? social.connections : [])
        .map(item => [String(item?.personId || ''), String(item?.status || '')].join(':'))
        .filter(Boolean)
        .sort();
    return hashText(rows.join('|'));
}

function scheduleSocialPulse(delay = 1200) {
    const settings = getSettings();
    const latestMessageId = Number(latestAssistantEntry()?.index ?? -1);
    const store = getStore();
    const social = normalizeSocialState(store.social || emptySocialState(), store.currentState.people);
    const currentWorldMinute = Math.max(0, Number(store.currentState?.clock?.absoluteMinute) || 0);
    const relationSignature = socialPulseRelationSignature(social);
    const relationChanged = relationSignature !== String(social.lastPulseRelationSignature || '');
    const lastPulseWorldMinute = Number(social.lastPulseWorldMinute ?? -1);
    const worldTimeDue = lastPulseWorldMinute < 0
        ? relationChanged
        : currentWorldMinute - lastPulseWorldMinute >= 60;
    if (
        !settings.enabled
        || !settings.socialAutoEnabled
        || latestMessageId < 0
        || latestMessageId <= Number(social.lastPulseMessageId ?? -1)
        || (!relationChanged && !worldTimeDue)
    ) return false;
    const chatToken = currentChatToken();
    if (runtime.socialPulseTimer !== null) window.clearTimeout(runtime.socialPulseTimer);
    runtime.socialPulseTimer = window.setTimeout(() => {
        runtime.socialPulseTimer = null;
        if (chatToken !== currentChatToken()) return;
        const blocked = Boolean(
            runtime.activeSimulation
            || runtime.activeWorldPulse
            || runtime.activeHistoryScan
            || runtime.activePublicImpact
            || runtime.activeCorrection
            || runtime.activeSocialPulse
            || runtime.queuedSimulations.size > 0
        );
        if (blocked) {
            scheduleSocialPulse(Math.max(900, Number(delay) || 1200));
            return;
        }
        void runSocialPulse(latestMessageId).catch(error => {
            if (!isAbortError(error)) console.warn('[世界背面] Nhịp liên lạc đời thường thất bại', error);
        });
    }, Math.max(700, Number(delay) || 1200));
    return true;
}

async function runSocialPulse(messageId = Number(latestAssistantEntry()?.index ?? -1)) {
    if (runtime.activeSocialPulse && !runtime.activeSocialPulse.controller?.signal?.aborted) return null;
    const chatToken = currentChatToken();
    const contextEpoch = runtime.contextEpoch;
    const controller = new AbortController();
    let store = getStore();
    const normalized = normalizeSocialState(store.social || emptySocialState(), store.currentState.people);
    if (Number(messageId) <= Number(normalized.lastPulseMessageId ?? -1)) return null;
    const prompt = buildSocialPulsePrompt(normalized, store.currentState, {
        userName: String(getContext()?.name1 || 'Bạn'),
    });
    if (!prompt) {
        normalized.lastPulseMessageId = Number(messageId);
        normalized.lastPulseWorldMinute = Math.max(0, Number(store.currentState?.clock?.absoluteMinute) || 0);
        normalized.lastPulseRelationSignature = socialPulseRelationSignature(normalized);
        store.social = normalized;
        saveStore(store, { immediate: true });
        return { messageCount: 0, requestCount: 0, removalCount: 0, momentCount: 0 };
    }
    runtime.activeSocialPulse = { controller, chatToken, contextEpoch, messageId: Number(messageId) };
    runtime.ui?.render();
    try {
        const raw = await backgroundSimulation(prompt, {
            maxTokens: 1600,
            temperature: 0.45,
            signal: controller.signal,
            taskKind: 'social',
            rejectTruncated: true,
        });
        const parsed = extractJsonObject(raw);
        if (!parsed) throw unreadableJsonError(raw, 'Model liên lạc đời thường');
        if (controller.signal.aborted || chatToken !== currentChatToken() || contextEpoch !== runtime.contextEpoch) return null;
        store = getStore();
        const applied = applySocialPulsePayload(store.social, store.currentState, parsed);
        applied.social.lastPulseMessageId = Number(messageId);
        applied.social.lastPulseWorldMinute = Math.max(0, Number(store.currentState?.clock?.absoluteMinute) || 0);
        applied.social.lastPulseRelationSignature = socialPulseRelationSignature(applied.social);
        store.social = applied.social;
        saveStore(store, { immediate: true });
        refreshInjection();
        runtime.ui?.render();
        return applied;
    } finally {
        if (runtime.activeSocialPulse?.controller === controller) runtime.activeSocialPulse = null;
        runtime.ui?.render();
    }
}


function publicOpinionRevealInjection(state, cache, settings, recentText = '') {
    if (
        settings.worldPromptInjection === false
        || settings.injectionPublicOpinion === false
        || settings.publicOpinionRevealMode !== 'relevant'
    ) return '';
    const normalized = normalizePublicOpinionCache(cache || {});
    const stale = String(normalized.sourceEventSignature || '') !== publicOpinionEventSignature(state);
    // 注入只消费已经由舆情调度器确认过的缓存，不能在这里临时从世界事件
    // “补造”新闻。来源变了时先丢掉过期论坛，新闻历史保留到新快照接上。
    const opinion = stale
        ? { ...normalized, forums: [] }
        : normalized;
    if (!opinion.news.length && !opinion.forums.length) return '';
    const text = String(recentText || '').toLocaleLowerCase();
    const events = new Map((state.events || []).map(event => [String(event.id), event]));
    const peopleNames = (state.people || []).map(person => String(person.name || '').trim()).filter(Boolean);
    const isRelevant = item => {
        const event = events.get(String(item.relatedEventId || ''));
        if (!event) return false;
        const terms = [
            event.title,
            event.place,
            ...(item.audienceTags || []),
            ...peopleNames.filter(name => (
                String(event.summary || '').includes(name)
                || String(event.expectedResult || '').includes(name)
                || String(event.result || '').includes(name)
            )),
        ]
            .map(value => String(value || '').trim().toLocaleLowerCase())
            .filter(value => value.length >= 2);
        return terms.some(term => text.includes(term));
    };
    const news = (opinion.news || []).filter(isRelevant).slice(0, 2);
    const forums = (opinion.forums || []).filter(isRelevant).slice(0, 2);
    if (!news.length && !forums.length) return '';
    const lines = [
        '<world_public_opinion>',
        'Dưới đây là các bản ghi thông tin công khai thực sự liên quan đến ống kính hiện tại, không phải yêu cầu để cốt truyện xảy ra lại trong lượt này. Sự kiện được tin tức đưa tin đã xảy ra, đang tiếp diễn, hoặc theo đúng chữ trong mục là dự báo tương lai rõ ràng; nhân vật xem tin tức chỉ được thêm phần “biết tin và phản ứng”, không được diễn lại bản thân sự kiện hay sửa thời điểm xảy ra của nó. Chỉ khi nhân vật có kênh tiếp xúc tự nhiên (điện thoại, TV, người qua đường bàn tán, tin nhắn công việc, v.v.) mới được tiện thể để lộ ra; không được cắt ngang cốt truyện hiện tại chỉ để phát tin, cũng không được coi suy đoán trên diễn đàn là sự thật của thế giới. Viết bằng tiếng Việt.',
    ];
    for (const item of news) {
        const audience = (item.audienceTags || []).slice(0, 4).join('、');
        lines.push(`Tin tức (tiếp nối việc biết tin/hệ quả, không diễn lại đối tượng được đưa tin)｜${item.headline}｜${item.summary}｜nguồn: ${item.source || 'Thông tin công khai'}｜cấp nguồn: ${item.sourceType || 'official'}${audience ? `｜có thể quan tâm: ${audience}` : ''}`);
    }
    for (const item of forums) {
        const audience = (item.audienceTags || []).slice(0, 4).join('、');
        lines.push(`Diễn đàn｜${item.title}｜${item.summary}｜tính chất: ${item.claimStatus || 'mixed'}｜cấp nguồn: ${item.sourceType || 'unofficial'}${audience ? `｜có thể quan tâm: ${audience}` : ''}`);
    }
    lines.push('</world_public_opinion>');
    return lines.join('\n');
}

function socialConversationInjection(social, state, settings) {
    if (settings.worldPromptInjection === false || settings.injectionSocial !== true) return '';
    const conversations = pendingSocialConversations(social || emptySocialState(), state);
    if (!conversations.length) return '';
    const lines = conversations.flatMap(conversation => {
        const messages = conversation.messages.map(message => (
            `- [${message.id}] ${message.senderId === 'user' ? 'Người chơi' : message.senderName}：${String(message.text || '').trim()}`
        ));
        return [`[Liên lạc｜id=${conversation.conversationId}｜${conversation.title}｜thành viên: ${conversation.members.join('、') || 'Không rõ'}]`, ...messages];
    });
    return [
        '<world_backstage_social_context>',
        'Dưới đây là toàn bộ bản ghi liên lạc xã hội chưa được chính văn tiếp nối, chỉ thể hiện nội dung nhân vật đã nói hoặc đã nhận, không phải sự thật thế giới đã được kết toán.',
        'Có thể dùng nó để giữ ngôn ngữ và quan hệ liền mạch; không được vì trong chat có lời hứa, kế hoạch, vị trí hay kết quả mà coi như việc đó đã xảy ra.',
        'Chỉ tiếp nối khi cảnh, nhân vật và chủ đề hiện tại liên quan một cách tự nhiên; không phù hợp thì tạm thời đừng nhắc, cấm thuật lại chat một cách máy móc chỉ để xóa bản ghi.',
        ...lines,
        '</world_backstage_social_context>',
    ].join('\n');
}

function refreshInjection({
    stateOverride = null,
    chatBeforeIndex = Infinity,
} = {}) {
    const context = getContext();
    if (!context?.setExtensionPrompt) return;

    const settings = getSettings();
    const state = stateOverride || getState();
    const recentText = recentChatText(8, chatBeforeIndex);
    const packet = buildInjectionPackage(state, settings, recentText, {
        contextText: recentForegroundIntentText(chatBeforeIndex),
    });
    const store = getStore();
    const opinionInjection = publicOpinionRevealInjection(
        state,
        store.publicOpinion,
        settings,
        recentText,
    );
    const socialInjection = socialConversationInjection(store.social, state, settings);
    const directorInjection = buildLingqiDirectorInjection(store.lingqi || emptyLingqiState());
    const authorityText = String(packet.authorityText ?? packet.text ?? '');
    const supportText = [directorInjection.text, packet.supportText, opinionInjection, socialInjection].filter(Boolean).join('\n\n');
    const text = [supportText, authorityText].filter(Boolean).join('\n\n');
    runtime.injection = {
        ...packet,
        authorityText,
        supportText,
        text,
        directorNoteIds: directorInjection.noteIds,
    };

    // World facts stay at depth 0 as the continuity contract. Optional reveal,
    // memory and public-opinion context sits deeper so it can help without
    // competing with the newest user turn or authoritative state.
    context.setExtensionPrompt(PROMPT_KEY, authorityText, 1, 0, false, 0);
    context.setExtensionPrompt(SUPPORT_PROMPT_KEY, supportText, 1, 2, false, 0);
}

function rerollInjectionBase(type) {
    if (!/(?:swipe|regenerate|reroll)/i.test(String(type || ''))) return null;
    const chat = getContext()?.chat || [];
    let target = null;
    for (let index = chat.length - 1; index >= 0; index -= 1) {
        const message = chat[index];
        if (!message || message.is_user || message.is_system) continue;
        target = { message, index };
        break;
    }
    if (!target) return null;

    const swipeId = Number(target.message?.swipe_id ?? 0);
    const branch = branchDataFromMessage(target.message, swipeId);
    const sourceKey = branchSourceKey(target.index, target.message, swipeId);
    if (branchRecordMatchesSource(branch, sourceKey) && branch?.base) {
        return {
            state: restoreBranchSnapshot(branch.base, getStore().initialState),
            chatBeforeIndex: target.index,
        };
    }

    const previous = findLatestResultSnapshot(target.index);
    return {
        state: previous
            ? stateWithBranchOverride(previous.snapshot)
            : clone(getStore().initialState),
        chatBeforeIndex: target.index,
    };
}

function offerGenerationInjection(type) {
    const rerollBase = rerollInjectionBase(type);
    refreshInjection(rerollBase
        ? {
            stateOverride: rerollBase.state,
            chatBeforeIndex: rerollBase.chatBeforeIndex,
        }
        : undefined);
    runtime.generationOffer = {
        eventIds: clone(runtime.injection.eventIds || []),
        directorNoteIds: clone(runtime.injection.directorNoteIds || []),
        at: Date.now(),
        rerollBase: Boolean(rerollBase),
    };
    return runtime.generationOffer;
}

function clearOwnInjection() {
    const context = getContext();
    context?.setExtensionPrompt?.(PROMPT_KEY, '', 1, 0, false, 0);
    context?.setExtensionPrompt?.(SUPPORT_PROMPT_KEY, '', 1, 2, false, 0);
}

function setBusy(value) {
    runtime.simulationCount += value ? 1 : -1;
    runtime.simulationCount = Math.max(0, runtime.simulationCount);
    runtime.ui?.setBusy(runtime.simulationCount > 0);
}

function coreSimulationBusy() {
    return Boolean(
        runtime.activeSimulation
        || runtime.activeWorldPulse
        || runtime.activePublicImpact
        || runtime.activeCorrection
        || runtime.activeHistoryScan
        || runtime.activePublicOpinion
        || runtime.queuedSimulations.size > 0
    );
}

function coreStateWriterBusyForSimulation() {
    return Boolean(
        runtime.activeHistoryScan
        || runtime.activeWorldPulse
        || runtime.activePublicImpact
        || runtime.activeCorrection
        || runtime.activePublicOpinion
    );
}

async function waitForCoreStateWritersToSettle({
    chatToken,
    dataEpoch,
    contextEpoch,
} = {}) {
    let announced = false;
    while (coreStateWriterBusyForSimulation()) {
        if (
            (chatToken && currentChatToken() !== chatToken)
            || (dataEpoch !== undefined && runtime.dataEpoch !== dataEpoch)
            || (contextEpoch !== undefined && runtime.contextEpoch !== contextEpoch)
        ) return false;
        if (!announced) {
            announced = true;
            setSyncStatus({
                phase: 'queued',
                message: 'Đợt nền trước đã được gửi đi～đợi nó xong rồi mới suy diễn chính văn mới nhất, không cắt ngang giữa chừng để gửi lại nữa',
                error: '',
            });
        }
        await new Promise(resolve => window.setTimeout(resolve, 80));
    }
    return true;
}

function latestAssistantSourceStamp() {
    const latest = latestAssistantEntry();
    if (!latest) return '';
    const swipeId = Number(latest.message?.swipe_id ?? 0);
    return branchSourceKey(latest.index, latest.message, swipeId);
}

function preemptLowPriorityTasksForCore({
    includeWorldWriters = false,
    hardAbort = false,
} = {}) {
    if (!hardAbort) {
        // A request that has already reached an upstream proxy may keep consuming
        // RPM/TPM even if the browser aborts fetch(). For normal new正文, do not
        // create “abort old request → immediately fire new request” bursts.
        if (runtime.activePublicOpinion && !runtime.activePublicOpinion.controller.signal.aborted) {
            runtime.pendingPublicOpinion = true;
        }
        if (runtime.activeHistoryScan && !runtime.activeHistoryScan.signal.aborted) {
            runtime.historyProgress = {
                ...runtime.historyProgress,
                message: 'Chính văn mới đã vào hàng đợi～mình thu xếp xong đợt hiện tại rồi sẽ nhường đường cho suy diễn thế giới',
            };
            runtime.ui?.render();
        }
        return;
    }

    if (runtime.activePublicOpinion && !runtime.activePublicOpinion.controller.signal.aborted) {
        runtime.pendingPublicOpinion = true;
        runtime.activePublicOpinion.controller.abort();
    }
    if (runtime.activeObservation && !runtime.activeObservation.controller.signal.aborted) {
        runtime.activeObservation.controller.abort();
    }
    if (runtime.activeHistoryScan && !runtime.activeHistoryScan.signal.aborted) {
        runtime.activeHistoryScan.abort();
        runtime.historyProgress = {
            ...runtime.historyProgress,
            message: runtime.historyProgress.kind === 'world-bootstrap'
                ? 'Ngữ cảnh đã mất hiệu lực～lần truy hồi lịch sử này dừng lại, thế giới hiện có sẽ không bị ghi bán thành phẩm'
                : 'Ngữ cảnh đã mất hiệu lực～ký ức dừng ở đợt đã lưu gần nhất',
        };
        runtime.ui?.render();
    }
    if (includeWorldWriters) {
        runtime.activeWorldPulse?.controller?.abort?.();
        if (runtime.activePublicImpact && !runtime.activePublicImpact.controller.signal.aborted) {
            runtime.pendingPublicImpact = true;
            runtime.activePublicImpact.controller.abort();
        }
    }
}

function invalidateAsyncWorldContext() {
    if (runtime.worldbookImportController || runtime.worldbookImportDrafts.length) discardWorldbookDrafts();
    runtime.contextEpoch += 1;
    runtime.pendingLingqiAction = null;
    runtime.activeSimulation?.controller?.abort?.();
    runtime.queuedSimulations.clear();
    clearDeferredManualSimulation();
    preemptLowPriorityTasksForCore({ includeWorldWriters: true, hardAbort: true });
}

function scheduleDeferredPublicImpact(delay = 180, expectedChatToken = currentChatToken()) {
    if (!runtime.pendingPublicImpact || expectedChatToken !== currentChatToken()) return;
    if (runtime.publicImpactTimer !== null) window.clearTimeout(runtime.publicImpactTimer);
    runtime.publicImpactTimer = window.setTimeout(() => {
        runtime.publicImpactTimer = null;
        if (!runtime.pendingPublicImpact || expectedChatToken !== currentChatToken()) return;
        const coreBlocked = Boolean(
            runtime.activeSimulation
            || runtime.activeWorldPulse
            || runtime.activePublicImpact
            || runtime.activeHistoryScan
            || runtime.queuedSimulations.size > 0
        );
        if (coreBlocked) {
            scheduleDeferredPublicImpact(Math.max(220, Number(delay) || 180), expectedChatToken);
            return;
        }
        runtime.pendingPublicImpact = false;
        void runPublicImpactPropagation({ quiet: true }).catch(error => {
            if (!isAbortError(error)) console.warn('[世界背面] Lan truyền ảnh hưởng sự kiện công cộng thất bại', error);
        });
    }, delay);
}

function scheduleDeferredPublicOpinion(delay = 220, expectedChatToken = currentChatToken()) {
    if (!runtime.pendingPublicOpinion || expectedChatToken !== currentChatToken()) return;
    if (runtime.publicOpinionTimer !== null) window.clearTimeout(runtime.publicOpinionTimer);
    runtime.publicOpinionTimer = window.setTimeout(() => {
        runtime.publicOpinionTimer = null;
        if (!runtime.pendingPublicOpinion || expectedChatToken !== currentChatToken()) return;
        if (coreSimulationBusy()) {
            scheduleDeferredPublicOpinion(Math.max(260, Number(delay) || 220), expectedChatToken);
            return;
        }
        runtime.pendingPublicOpinion = false;
        void generatePublicOpinionSnapshot({ allowDefer: true }).catch(error => {
            if (!isAbortError(error)) console.warn('[世界背面] Tạo dư luận bị hoãn thất bại', error);
        });
    }, delay);
}

function hasNewerAssistantReply(messageId) {
    const latest = latestAssistantEntry();
    return Boolean(latest && Number(latest.index) > Number(messageId));
}

function cancelActiveSimulation() {
    const active = runtime.activeSimulation;
    if (!active || active.controller.signal.aborted) return false;
    runtime.autoCatchUpSuppressedThroughMessageId = Math.max(
        runtime.autoCatchUpSuppressedThroughMessageId,
        Number(latestAssistantEntry()?.index ?? active.messageId ?? -1),
    );
    active.cancelled = true;
    active.controller.abort();
    if (active.apiMode === 'tavern') {
        try {
            getContext()?.stopGeneration?.();
        } catch (error) {
            console.warn('[世界背面] Không thể yêu cầu Tavern dừng sinh yên lặng', error);
        }
    }
    setSyncStatus({
        phase: 'cancelling',
        message: 'Đang dừng lần suy diễn này, sẽ không áp dụng bất kỳ thay đổi thế giới nào',
        error: '',
    });
    return true;
}


function cancelActiveBackgroundTasks({ preserveLingqi = false } = {}) {
    const labels = activeBackgroundTaskLabels()
        .filter(label => !(preserveLingqi && label === '玲七'));
    const queuedWorldWork = runtime.queuedSimulations.size > 0 || Boolean(runtime.pendingManualSimulation);
    if (!labels.length && !queuedWorldWork) return { cancelled: false, labels: [] };
    const cancelledLabels = queuedWorldWork && !labels.includes('Suy diễn thế giới')
        ? [...labels, 'Hàng đợi suy diễn thế giới']
        : labels;

    runtime.autoCatchUpSuppressedThroughMessageId = Math.max(
        runtime.autoCatchUpSuppressedThroughMessageId,
        Number(latestAssistantEntry()?.index ?? -1),
    );

    // Invalidate queued world-simulation jobs without changing any world data.
    // Their branch records remain pending, so a later manual sync/new reply can catch up.
    runtime.dataEpoch += 1;
    runtime.pendingPublicImpact = false;
    runtime.pendingPublicOpinion = false;
    clearDeferredManualSimulation();
    if (runtime.autoMemoryTimer !== null) {
        window.clearTimeout(runtime.autoMemoryTimer);
        runtime.autoMemoryTimer = null;
    }
    if (runtime.socialPulseTimer !== null) {
        window.clearTimeout(runtime.socialPulseTimer);
        runtime.socialPulseTimer = null;
    }

    // Main simulation needs its existing special stop path for Tavern quiet generation.
    if (
        runtime.activeSimulation
        && !runtime.activeSimulation.controller.signal.aborted
    ) {
        cancelActiveSimulation();
    }

    const abortables = [
        runtime.activeHistoryScan,
        runtime.activeWorldPulse?.controller,
        runtime.activePublicImpact?.controller,
        runtime.activeCorrection?.controller,
        runtime.activePublicOpinion?.controller,
        runtime.publicOpinionRefreshTransaction?.controller,
        runtime.activePublicOpinionSandbox?.controller,
        runtime.activeObservation?.controller,
        preserveLingqi ? null : runtime.activeLingqi?.controller,
        runtime.worldbookImportController,
        runtime.activeSocial?.controller,
        runtime.activeFriendRequest?.controller,
        runtime.activeMoments?.controller,
        runtime.activeSocialPulse?.controller,
    ];
    for (const controller of abortables) {
        try {
            if (controller && !controller.signal?.aborted) controller.abort();
        } catch (error) {
            console.warn('[世界背面] Khi dừng tác vụ nền có một bộ điều khiển không hủy được bình thường', error);
        }
    }

    runtime.queuedSimulations.clear();
    runtime.simulationChain = Promise.resolve();

    if (runtime.historyProgress?.phase === 'running') {
        runtime.historyProgress = {
            ...runtime.historyProgress,
            phase: 'idle',
            message: 'Đã dừng thủ công tác vụ ký ức/lịch sử lần này; các đợt đã lưu thành công sẽ được giữ, đợt đang sinh sẽ không được áp dụng',
        };
    }
    if (runtime.publicOpinionStatus?.phase === 'running') {
        runtime.publicOpinionStatus = {
            phase: 'idle',
            message: 'Đã dừng thủ công lần làm mới dư luận này, dư luận hiện có sẽ không bị xóa',
            error: '',
        };
    }
    if (runtime.publicOpinionSandboxStatus?.phase === 'running') {
        runtime.publicOpinionSandboxStatus = {
            phase: 'idle',
            message: 'Đã dừng thủ công lần dạo chơi này',
            error: '',
        };
    }
    if (runtime.lingqiStatus?.phase === 'running') {
        runtime.lingqiStatus = {
            phase: 'idle',
            message: '……',
            error: '',
        };
    }
    if (runtime.socialStatus?.phase === 'running') {
        runtime.socialStatus = {
            phase: 'idle',
            message: 'Đã dừng lần trả lời xã hội này, tin nhắn gốc bạn gửi vẫn được giữ',
            error: '',
            conversationId: runtime.socialStatus.conversationId || '',
        };
    }

    setSyncStatus({
        phase: 'pending',
        message: `Đã dừng tác vụ nền hiện tại: ${labels.join('、')}. Kết quả chưa hoàn tất sẽ không được áp dụng.`,
        error: '',
    });
    runtime.ui?.render();
    return { cancelled: true, labels: cancelledLabels };
}

function markMessagePending(messageId, {
    trigger = 'reply',
    offeredEventIds = runtime.generationOffer.eventIds,
    offeredDirectorNoteIds = runtime.generationOffer.directorNoteIds,
    deferBase = false,
} = {}) {
    const context = getContext();
    const message = context?.chat?.[messageId];
    if (!hasUsableAssistantText(message)) return null;
    const swipeId = Number(message.swipe_id ?? 0);
    const sourceKey = branchSourceKey(messageId, message, swipeId);
    const existing = branchDataFromMessage(message, swipeId);

    let baseState = null;
    if (!deferBase) {
        if (existing?.base && !existing.stale) {
            baseState = restoreBranchSnapshot(existing.base, getStore().initialState);
        } else {
            const previous = findLatestResultSnapshot(messageId);
            baseState = previous
                ? stateWithBranchOverride(previous.snapshot)
                : clone(getState());
        }
    }

    const data = {
        schemaVersion: SCHEMA_VERSION,
        status: 'pending',
        sourceKey,
        trigger,
        offeredEventIds: [...new Set(offeredEventIds || [])],
        offeredDirectorNoteIds: [...new Set(offeredDirectorNoteIds || [])],
        base: baseState ? createBranchSnapshot(baseState, {
            messageId,
            swipeId,
            sourceKey,
            kind: 'base',
        }) : null,
        result: null,
        error: '',
        stale: false,
    };

    attachBranchData(message, swipeId, data);
    void context?.saveChat?.();
    const store = getStore();
    if (baseState && currentChatToken() === runtime.activeChatToken) {
        store.currentState = markPendingSync(baseState, true);
        saveStore(store);
        refreshInjection();
        runtime.ui?.render();
    }
    return { data, message, messageId, swipeId, sourceKey, baseState };
}

function locateTargetBranch(messageId, swipeId, expectedHash) {
    const context = getContext();
    const message = context?.chat?.[messageId];
    if (!message) return null;
    const text = message.swipes?.[swipeId] ?? (
        Number(message.swipe_id ?? 0) === Number(swipeId) ? message.mes : ''
    );
    if (hashText(text) !== expectedHash) return null;
    return { context, message };
}

function backgroundRequestMessages(prompt, settings = getSettings(), {
    taskKind = 'simulation',
    rejectTruncated = false,
} = {}) {
    const messages = buildBackstageMessages(prompt);
    runtime.lastPromptBridge = {
        enabled: false,
        removed: true,
        taskKind,
        promptCount: 0,
        available: false,
        truncated: false,
        internalCompatChars: String(INTERNAL_COMPAT_SYSTEM_PROMPT || '').trim().length,
        systemChars: String(messages[0]?.content || '').length,
        userChars: String(messages[1]?.content || '').length,
        at: new Date().toISOString(),
    };
    return messages;
}


function generationTimeoutError(timeoutMs, taskKind = 'simulation') {
    const seconds = Math.max(1, Math.ceil(Number(timeoutMs || 0) / 1000));
    const error = new Error(`Tác vụ nền chờ quá thời gian (${seconds} giây · ${taskRouteKey(taskKind)}）`);
    error.code = 'GENERATION_TIMEOUT';
    error.errorType = 'timeout';
    error.timeoutMs = Number(timeoutMs) || 0;
    return error;
}

function createActiveGenerationGuard(timeoutMs, externalSignal, taskKind = 'simulation') {
    const controller = new AbortController();
    const documentRef = globalThis.document;
    const canWatchVisibility = Boolean(
        documentRef
        && typeof documentRef.addEventListener === 'function'
        && typeof documentRef.removeEventListener === 'function'
    );
    const now = () => globalThis.performance?.now?.() ?? Date.now();
    let remainingMs = Math.max(1, Number(timeoutMs) || 1);
    let activeSince = 0;
    let timer = null;
    let timedOut = false;
    let rejectGuard = null;

    const guardPromise = new Promise((_, reject) => {
        rejectGuard = reject;
    });

    const pageHidden = () => canWatchVisibility && Boolean(documentRef.hidden);
    const pause = () => {
        if (timer !== null) {
            clearTimeout(timer);
            timer = null;
        }
        if (activeSince > 0) {
            remainingMs = Math.max(0, remainingMs - Math.max(0, now() - activeSince));
            activeSince = 0;
        }
    };
    const fireTimeout = () => {
        if (controller.signal.aborted) return;
        timedOut = true;
        const error = generationTimeoutError(timeoutMs, taskKind);
        // Reject our guard before aborting the native request. Some adapters turn
        // signal.abort() into a generic AbortError synchronously; ordering this way
        // guarantees Promise.race reports a real timeout instead of misclassifying
        // it as a user cancellation.
        rejectGuard?.(error);
        controller.abort(error);
    };
    const resume = () => {
        if (controller.signal.aborted || pageHidden() || timer !== null) return;
        if (remainingMs <= 0) {
            fireTimeout();
            return;
        }
        activeSince = now();
        timer = setTimeout(() => {
            timer = null;
            activeSince = 0;
            fireTimeout();
        }, remainingMs);
    };
    const onVisibility = () => {
        if (pageHidden()) pause();
        else resume();
    };
    const onExternalAbort = () => {
        if (controller.signal.aborted) return;
        const error = new Error('Người dùng đã hủy suy diễn (aborted)');
        error.name = 'AbortError';
        rejectGuard?.(error);
        controller.abort(error);
    };

    if (canWatchVisibility) documentRef.addEventListener('visibilitychange', onVisibility);
    if (externalSignal) {
        if (externalSignal.aborted) onExternalAbort();
        else externalSignal.addEventListener('abort', onExternalAbort, { once: true });
    }
    resume();

    return {
        signal: controller.signal,
        guardPromise,
        timedOut: () => timedOut,
        cleanup() {
            pause();
            if (canWatchVisibility) documentRef.removeEventListener('visibilitychange', onVisibility);
            externalSignal?.removeEventListener?.('abort', onExternalAbort);
            rejectGuard = null;
        },
    };
}

async function backgroundSimulation(prompt, {
    maxTokens = 2200,
    temperature = 0.2,
    signal = null,
    taskKind = 'simulation',
    rejectTruncated = false,
} = {}) {
    const context = getContext();
    const settings = getSettings();
    const route = resolveTaskConnection(settings, taskKind);
    const requestSettings = route.settings;
    const limits = resolveGenerationLimits(settings, taskKind, maxTokens);
    const effectiveMaxTokens = limits.maxTokens;
    const effectiveTimeoutMs = limits.timeoutMs;
    const tavernConnection = route.mode === 'tavern' ? getCurrentTavernConnectionInfo() : null;
    runtime.lastTaskConnection = {
        taskKind,
        routeKey: route.routeKey,
        route: route.route,
        apiLabel: route.mode === 'custom'
            ? route.label
            : route.mode === 'tavern-profile'
                ? route.label
                : 'Theo Tavern hiện tại',
        model: route.mode === 'custom'
            ? String(requestSettings.customApiModel || 'Chưa cấu hình model')
            : route.mode === 'tavern-profile'
                ? String(route.profile?.model || 'Model của cấu hình không khả dụng')
                : String(tavernConnection?.model || 'Theo model hiện tại của Tavern'),
        method: route.mode === 'custom'
            ? (requestSettings.customApiTransport === 'direct' ? 'Trình duyệt kết nối trực tiếp' : 'Tavern chuyển tiếp Custom')
            : route.mode === 'tavern-profile'
                ? 'Cấu hình đã lưu của Tavern'
                : 'Ngữ cảnh độc lập của Tavern',
        source: route.mode === 'custom'
            ? 'custom-independent'
            : route.mode === 'tavern-profile'
                ? String(route.profile?.api || 'tavern-profile')
                : tavernConnection?.source || 'tavern',
        requestedMaxTokens: limits.requestedMaxTokens,
        maxTokens: effectiveMaxTokens,
        tokenLimitSource: limits.tokenSource,
        timeoutMs: effectiveTimeoutMs,
        timeoutLimitSource: limits.timeoutSource,
    };
    const messages = backgroundRequestMessages(prompt, settings, { taskKind });
    const requestShape = {
        taskKind,
        routeKey: route.routeKey,
        routeMode: route.mode,
        messageCount: messages.length,
        messageCharacters: messages.reduce((total, item) => (
            total + String(item?.content || '').length
        ), 0),
        temperature: Number(temperature) || 0,
        stream: false,
        requestedMaxTokens: limits.requestedMaxTokens,
        maxTokensSent: effectiveMaxTokens,
        tokenLimitSource: limits.tokenSource,
        timeoutMs: effectiveTimeoutMs,
        timeoutLimitSource: limits.timeoutSource,
        rejectTruncated: Boolean(rejectTruncated),
    };
    runtime.lastRequestShape = { ...requestShape };
    if (signal?.aborted) {
        const error = new Error('Người dùng đã hủy suy diễn (aborted)');
        error.name = 'AbortError';
        throw error;
    }
    const foregroundNeutralTask = ['public-opinion-sandbox', 'lingqi', 'social', 'worldbook-import'].includes(taskKind);

    if (route.mode === 'tavern-profile') {
        const profileId = String(route.profileId || '');
        if (!profileId) throw new Error('Chưa chọn cấu hình API đã lưu của Tavern');
        if (tavernConnectionManagerDisabled(context)) {
            throw new Error('Connection Manager của SillyTavern hiện không khả dụng, không thể đọc cấu hình API đã lưu');
        }
        if (!route.profile) {
            throw new Error(`Cấu hình đã lưu của Tavern không còn tồn tại (ID: ${profileId}). Mình không lén đổi sang kết nối khác đâu, hãy chọn lại.`);
        }
        const service = context?.ConnectionManagerRequestService;
        if (typeof service?.sendRequest !== 'function') {
            throw new Error('SillyTavern hiện tại không cung cấp dịch vụ gửi yêu cầu theo cấu hình kết nối; hãy cập nhật SillyTavern hoặc dùng cách kết nối khác');
        }

        if (!foregroundNeutralTask) runtime.inBackgroundGeneration = true;
        const guard = createActiveGenerationGuard(effectiveTimeoutMs, signal, taskKind);
        try {
            runtime.syncStatus.method = `${route.label} · Cấu hình đã lưu của Tavern`;
            resetLastCustomApiOperation();
            const result = await runInConnectionLane(
                taskKind,
                guard.signal,
                () => service.sendRequest(
                    profileId,
                    messages,
                    effectiveMaxTokens > 0 ? effectiveMaxTokens : undefined,
                    {
                        stream: false,
                        signal: guard.signal,
                        extractData: true,
                        includePreset: false,
                        includeInstruct: true,
                    },
                    {
                        temperature,
                        include_reasoning: false,
                    },
                ),
                {
                    ...requestShape,
                    apiSurface: 'connection-manager',
                    extractData: true,
                    includePreset: false,
                    includeInstruct: true,
                    includeReasoning: false,
                    statusVisibility: 'connection-manager-error-only',
                },
            );
            const text = typeof result === 'string'
                ? result
                : typeof result?.content === 'string'
                    ? result.content
                    : '';
            if (!String(text || '').trim()) {
                throw new Error(`Cấu hình Tavern “${route.label}” không trả về chính văn dùng được`);
            }
            return String(text).trim();
        } catch (error) {
            if (guard.timedOut()) {
                const timeoutError = new Error(`Cấu hình Tavern “${route.label}” yêu cầu quá thời gian (${Math.ceil(effectiveTimeoutMs / 1000)} giây)`);
                timeoutError.code = 'GENERATION_TIMEOUT';
                timeoutError.errorType = 'timeout';
                throw timeoutError;
            }
            const cause = error?.cause;
            if (cause && String(error?.message || '') === 'API request failed') {
                const wrapped = new Error(`Cấu hình Tavern “${route.label}” yêu cầu thất bại: ${String(cause?.message || cause)}`);
                wrapped.cause = error;
                wrapped.errorType = classifyDiagnosticIssue(wrapped.message);
                throw wrapped;
            }
            throw error;
        } finally {
            guard.cleanup();
            if (!foregroundNeutralTask) runtime.inBackgroundGeneration = false;
            refreshInjection();
        }
    }

    if (route.mode === 'custom') {
        if (!foregroundNeutralTask) runtime.inBackgroundGeneration = true;
        try {
            runtime.syncStatus.method = requestSettings.customApiTransport === 'direct'
                ? `${route.label} · trình duyệt kết nối trực tiếp`
                : `${route.label} · Tavern chuyển tiếp`;
            return await runInConnectionLane(
                taskKind,
                signal,
                () => requestCustomCompletion(requestSettings, messages, {
                    fetchImpl: globalThis.fetch.bind(globalThis),
                    getRequestHeaders: () => context?.getRequestHeaders?.() || {},
                    maxTokens: effectiveMaxTokens,
                    temperature,
                    timeoutMs: effectiveTimeoutMs,
                    signal,
                    rejectTruncated,
                    operation: taskKind,
                    routeLabel: route.label,
                }),
                {
                    ...requestShape,
                    apiSurface: 'custom-independent',
                    transport: requestSettings.customApiTransport === 'direct' ? 'direct' : 'proxy',
                    statusVisibility: 'full',
                },
            );
        } catch (error) {
            if (error?.code !== 'OUTPUT_TRUNCATED' && error?.errorType !== 'output-limit') throw error;
            const pluginLimited = effectiveMaxTokens > 0;
            const capHint = limits.tokenSource === 'module'
                ? 'Giới hạn Token của mô-đun hiện tại đã giới hạn yêu cầu này'
                : 'Giới hạn Token toàn cục đã giới hạn yêu cầu này';
            const wrapped = new Error(pluginLimited
                ? `${String(error?.message || error)}; giới hạn đầu ra thực tế của plugin là ${effectiveMaxTokens} Token，${capHint}. Có thể đặt giới hạn Token tương ứng về 0 (tự động) hoặc tăng lên rồi thử lại.`
                : `${String(error?.message || error)}; plugin không đặt giới hạn Token đầu ra, lần cắt cụt này đến từ giới hạn đầu ra của chính model, dịch vụ upstream hoặc kết nối hiện tại của Tavern.`);
            Object.assign(wrapped, error, {
                cause: error,
                code: error?.code || 'OUTPUT_TRUNCATED',
                errorType: 'output-limit',
                effectiveMaxTokens,
                tokenLimitSource: limits.tokenSource,
            });
            throw wrapped;
        } finally {
            if (!foregroundNeutralTask) runtime.inBackgroundGeneration = false;
            refreshInjection();
        }
    }

    if (
        typeof context?.generateRaw !== 'function'
        && typeof context?.generateQuietPrompt !== 'function'
    ) {
        throw new Error('Phiên bản Tavern hiện tại không cung cấp API sinh yên lặng');
    }
    if (['person-observation', 'worldbook-import'].includes(taskKind) && typeof context?.generateRaw !== 'function') {
        throw new Error('Phiên bản Tavern hiện tại không cung cấp API quan sát nhân vật với ngữ cảnh độc lập; hãy cập nhật SillyTavern hoặc cấu hình API độc lập cho 世界背面');
    }
    if (taskKind === 'lingqi' && typeof context?.generateRaw !== 'function') {
        throw new Error('Phiên bản Tavern hiện tại không cung cấp API trò chuyện 玲七 với ngữ cảnh độc lập; hãy cập nhật SillyTavern hoặc cấu hình API độc lập cho 世界背面');
    }
    if (taskKind === 'social' && typeof context?.generateRaw !== 'function') {
        throw new Error('Phiên bản Tavern hiện tại không cung cấp API trả lời xã hội với ngữ cảnh độc lập; hãy cập nhật SillyTavern hoặc cấu hình API độc lập cho 世界背面');
    }

    if (!foregroundNeutralTask) runtime.inBackgroundGeneration = true;
    clearOwnInjection();
    // Timeout applies to this single request attempt only. runWithRetries cooldown
    // happens outside backgroundSimulation, so a 429 wait can never consume the
    // model's active generation timeout.
    const guard = createActiveGenerationGuard(effectiveTimeoutMs, signal, taskKind);
    const requestSignal = guard.signal;
    // Sandbox is allowed to coexist with the core world task. Its AbortController
    // must therefore never call SillyTavern's global stopGeneration(), otherwise
    // closing "随便逛逛" could accidentally kill the main world simulation too.
    const allowGlobalStopOnAbort = !foregroundNeutralTask;
    const stopNativeGeneration = () => {
        if (!allowGlobalStopOnAbort) return;
        try {
            context?.stopGeneration?.();
        } catch (error) {
            console.warn('[世界背面] Yêu cầu dừng sinh yên lặng của Tavern không trả về bình thường', error);
        }
    };
    if (allowGlobalStopOnAbort) {
        requestSignal.addEventListener('abort', stopNativeGeneration, { once: true });
    }
    try {
        return await runInConnectionLane(taskKind, requestSignal, async () => {
            let request;
            if (typeof context.generateRaw === 'function') {
                runtime.syncStatus.method = 'Suy diễn với ngữ cảnh độc lập';
                request = context.generateRaw({
                    prompt: messages,
                    responseLength: effectiveMaxTokens > 0 ? effectiveMaxTokens : undefined,
                    trimNames: false,
                    signal: requestSignal,
                });
            } else {
                runtime.syncStatus.method = 'Chế độ tương thích sinh yên lặng';
                request = context.generateQuietPrompt({
                    quietPrompt: `${messages[0]?.content || ''}\n\n${messages[1]?.content || ''}`.trim(),
                    skipWIAN: true,
                    responseLength: effectiveMaxTokens > 0 ? effectiveMaxTokens : undefined,
                    removeReasoning: true,
                    signal: requestSignal,
                });
            }
            // The background request has captured its own prompt. Restore the
            // foreground injection before waiting so a newly sent user turn never
            // sees an empty World Backstage prompt.
            refreshInjection();
            return await Promise.race([request, guard.guardPromise]);
        }, {
            ...requestShape,
            apiSurface: typeof context.generateRaw === 'function' ? 'generateRaw' : 'generateQuietPrompt',
            trimNames: typeof context.generateRaw === 'function' ? false : null,
            skipWIAN: typeof context.generateRaw === 'function' ? null : true,
            removeReasoning: typeof context.generateRaw === 'function' ? null : true,
            statusVisibility: 'opaque-tavern-api',
        });
    } finally {
        if (allowGlobalStopOnAbort) {
            requestSignal.removeEventListener?.('abort', stopNativeGeneration);
        }
        guard.cleanup();
        if (!foregroundNeutralTask) runtime.inBackgroundGeneration = false;
        refreshInjection();
    }
}

async function runSimulationForMessage(messageId, {
    force = false,
    trigger = 'reply',
    newAssistantCount = 1,
    job = null,
} = {}) {
    const chatTokenAtStart = currentChatToken();
    const dataEpochAtStart = runtime.dataEpoch;
    const contextEpochAtStart = runtime.contextEpoch;
    const taskStillCurrent = () => (
        currentChatToken() === chatTokenAtStart
        && runtime.dataEpoch === dataEpochAtStart
        && runtime.contextEpoch === contextEpochAtStart
    );
    if (job?.chatToken && job.chatToken !== chatTokenAtStart) return null;
    if (job?.dataEpoch !== undefined && job.dataEpoch !== dataEpochAtStart) return null;

    const writerSettled = await waitForCoreStateWritersToSettle({
        chatToken: chatTokenAtStart,
        dataEpoch: dataEpochAtStart,
        contextEpoch: contextEpochAtStart,
    });
    if (!writerSettled) return null;

    const beforeContext = getContext();
    const beforeMessage = beforeContext?.chat?.[messageId];
    const initialSettings = getSettings();
    if (!initialSettings.enabled || !initialSettings.worldSimulationEnabled) {
        throw new Error('Mô-đun suy diễn thế giới hiện đang tắt');
    }
    if (!hasUsableAssistantText(beforeMessage)) {
        throw new Error('Không tìm thấy chính văn AI nào để suy diễn');
    }
    const beforeSwipeId = Number(beforeMessage.swipe_id ?? 0);
    const beforeSourceKey = branchSourceKey(messageId, beforeMessage, beforeSwipeId);
    if (
        job
        && (job.swipeId !== beforeSwipeId || job.sourceKey !== beforeSourceKey)
    ) {
        setSyncStatus({
            phase: 'pending',
            message: 'Chính văn đã thay đổi, tác vụ xếp hàng cũ đã bị bỏ qua; đang chờ suy diễn theo chính văn mới nhất',
            error: '',
        });
        return null;
    }
    const beforeData = branchDataFromMessage(beforeMessage, beforeSwipeId);
    if (
        !force
        && beforeData?.status === 'committed'
        && beforeData.sourceKey === beforeSourceKey
        && beforeData.result
        && !beforeData.stale
    ) {
        return stateWithBranchOverride(beforeData.result);
    }

    const prepared = markMessagePending(messageId, {
        trigger,
        offeredEventIds: job?.offeredEventIds ?? beforeData?.offeredEventIds,
        offeredDirectorNoteIds: job?.offeredDirectorNoteIds ?? beforeData?.offeredDirectorNoteIds,
    });
    if (!prepared) {
        throw new Error('Không tìm thấy chính văn AI nào để suy diễn');
    }

    const {
        message,
        swipeId,
        sourceKey,
        baseState,
    } = prepared;
    const baseRevision = Math.max(0, Number(baseState?.revision) || 0);
    const expectedHash = sourceKey.split(':').at(-1);
    const offeredEventIds = prepared.data.offeredEventIds;
    const offeredDirectorNoteIds = prepared.data.offeredDirectorNoteIds || [];
    const settings = getSettings();
    const assistantTurnsToApply = Math.min(
        20,
        Math.max(1, Number.parseInt(newAssistantCount, 10) || 1),
    );
    const anchorContextTurns = baseState?.clock?.anchored ? 0 : 20;
    const narrative = narrativeContext(
        messageId,
        Math.max(settings.contextTurns, assistantTurnsToApply, anchorContextTurns),
    );
    // Pending batch must come from raw chat ids (hasUsableAssistantText), not
    // narrative.turns — narrativeContext already drops empty-after-filter turns,
    // which would otherwise pull older assistants into the "new" slice.
    const chatForPending = beforeContext?.chat || [];
    const pendingMessageIds = selectPendingAssistantMessageIds(
        chatForPending,
        messageId,
        assistantTurnsToApply,
        hasUsableAssistantText,
    );
    const pendingFilteredTexts = pendingMessageIds.map(
        id => narrativeMessageText(chatForPending[id]),
    );
    const survivingNewCount = countSurvivingNewAssistantTurns(
        narrative.turns,
        pendingMessageIds,
    );
    const newAssistantTexts = pendingFilteredTexts
        .map(text => String(text || '').trim())
        .filter(Boolean);
    const simulationModeLabel = {
        light: 'Nhẹ',
        balanced: 'Cân bằng',
        deep: 'Sâu',
        manual: 'Thủ công',
    }[settings.autoSimulationMode] || 'Cân bằng';
    const generationMetrics = {
        raw: '',
        attempts: 1,
        tokenBudget: 0,
    };
    const controller = new AbortController();
    const activeSimulation = {
        controller,
        messageId,
        trigger,
        chatToken: chatTokenAtStart,
        sourceKey,
        newAssistantCount: assistantTurnsToApply,
        apiMode: resolveTaskConnection(settings, 'simulation').mode,
        cancelled: false,
    };
    runtime.activeSimulation = activeSimulation;
    beginTaskTrace('simulation', {
        messageId,
        sourceKey,
        chatToken: chatTokenAtStart,
    });

    setBusy(true);
    setSyncStatus({
        phase: 'running',
        message: assistantTurnsToApply > 1
            ? `Đang gộp ${assistantTurnsToApply} lượt chính văn mới gần nhất và tiến hành suy diễn${simulationModeLabel}`
            : `Đang đọc ${settings.contextTurns} lượt chính văn gần nhất và tiến hành suy diễn${simulationModeLabel}`,
        error: '',
        attemptedAt: new Date().toISOString(),
    });
    try {
        // Short-circuit when every pending (queued) assistant filters to empty —
        // not when narrative.turns' last-N assistants happen to be non-empty older turns.
        if (!newAssistantTexts.length) {
            // No valid narrative after filtering: do not consume delivery attempts
            // or expire candidates via recordDeliveryOffers.
            const resultState = markPendingSync(clone(baseState), false);
            const nextInjection = buildInjectionPackage(resultState, settings, recentChatText(), {
                contextText: recentForegroundIntentText(),
            });
            const summary = simulationSummary(baseState, resultState, {
                prompt: '',
                raw: '',
                attempts: 0,
                tokenBudget: 0,
                injection: nextInjection,
            });
            const target = locateTargetBranch(messageId, swipeId, expectedHash);
            if (!target || !taskStillCurrent()) {
                if (taskStillCurrent()) {
                    setSyncStatus({
                        phase: 'pending',
                        message: 'Nhánh chính văn đã thay đổi, kết quả cũ chưa được áp dụng; chính văn mới nhất vẫn đang chờ suy diễn',
                        error: '',
                    });
                }
                return resultState;
            }
            const committed = {
                ...prepared.data,
                status: 'committed',
                result: createBranchSnapshot(resultState, {
                    messageId,
                    swipeId,
                    sourceKey,
                    kind: 'result',
                }),
                error: '',
                summary,
            };
            ensureResultBranchSurface(getStore(), sourceKey, baseState);
            attachBranchData(target.message, swipeId, committed);
            compactBranchSnapshotStorage();
            const branchIsCurrent = (
                Number(target.message.swipe_id ?? 0) === swipeId
                && hashText(target.message.mes) === expectedHash
            );
            const supersededByNewerReply = hasNewerAssistantReply(messageId);
            if (branchIsCurrent && !supersededByNewerReply) {
                const store = getStore();
                store.currentState = trimState(resultState);
                saveStore(store, { immediate: true });
                refreshInjection();
                runtime.ui?.render();
            }
            await target.context.saveChat?.();
            finishTaskTrace(supersededByNewerReply ? 'superseded' : 'success', {
                stage: supersededByNewerReply ? 'superseded' : 'committed',
                parseOutcome: 'skipped',
                validationOutcome: 'skipped',
                commitOutcome: 'success',
                committedAt: new Date().toISOString(),
            });
            setSyncStatus({
                phase: supersededByNewerReply ? 'pending' : 'success',
                message: supersededByNewerReply
                    ? 'Kết quả lượt này đã được lưu trữ an toàn, nhưng đã có chính văn mới hơn～tạm chưa ghi vào trạng thái hiện tại, đang đuổi theo lượt mới nhất'
                    : 'Sau khi lọc không còn chính văn hợp lệ, lượt này không đẩy thế giới',
                error: '',
                succeededAt: supersededByNewerReply ? '' : new Date().toISOString(),
                method: runtime.syncStatus.method,
                summary,
            });
            return resultState;
        }

        const backgroundPersonTargets = listDueBackgroundPeople(baseState, {
            maximum: settings.backgroundNpcBudget,
            requiredOnly: !settings.enhancedBackgroundSimulation,
        });
        const worldCoverageTargets = selectWorldCoverageTargets(baseState, {
            customInstruction: settings.customSimulationInstruction,
            maximum: settings.worldPulseActivity === 'busy' ? 3 : 2,
        });
        const prompt = buildSimulationPrompt(baseState, {
            queuedEventIds: offeredEventIds,
            trigger,
            latestTurn: narrative.latestTurn,
            narrativeTurns: narrative.turns,
            userName: beforeContext?.name1 || '',
            includeUserInnerVoice: false,
            recordPlayerCharacter: settings.recordPlayerCharacter,
            timePolicy: settings.timePolicy,
            worldAuto: settings.worldAutoEnabled,
            simulationMode: settings.autoSimulationMode,
            customInstruction: settings.customSimulationInstruction,
            playerIdentityAnchor: getPlayerIdentityAnchor(baseState),
            newAssistantTurns: Math.max(1, survivingNewCount),
            backgroundNpcBudget: settings.backgroundNpcBudget,
            worldPulseActivity: settings.worldPulseActivity,
            enhancedBackgroundSimulation: settings.enhancedBackgroundSimulation,
            backgroundPersonTargets,
            worldCoverageTargets,
directorNotes: normalizeLingqiState(getStore().lingqi || emptyLingqiState()).notes
                .filter(note => offeredDirectorNoteIds.includes(note.id) && note.status !== 'cancelled')
                .map(note => ({
                    ...note,
                    consumed: Boolean(sourceKey && note.lastAppliedSourceKey === sourceKey),
                })),
            socialContext: settings.worldPromptInjection !== false && settings.injectionSocial === true
                ? pendingSocialConversations(getStore().social, baseState)
                : [],
        });

        const automaticMaxTokens = settings.autoSimulationMode === 'deep'
            ? 4600
            : settings.autoSimulationMode === 'light'
                ? 2400
                : 3400;
        const baseMaxTokens = primarySimulationRequestBudget(settings, automaticMaxTokens);
        const payload = await runWithRetries(async attempt => {
            generationMetrics.attempts = attempt + 1;
            generationMetrics.tokenBudget = resolveGenerationLimits(
                settings,
                'simulation',
                retryTokenBudget(baseMaxTokens, attempt),
            ).maxTokens;
            updateTaskTrace({
                stage: 'requesting',
                attempt: attempt + 1,
                responseOutcome: 'pending',
                parseOutcome: 'none',
                validationOutcome: 'none',
                commitOutcome: 'none',
                errorType: 'none',
                errorSummary: '',
            });
            const raw = await backgroundSimulation(retrySimulationPrompt(prompt, attempt), {
                maxTokens: generationMetrics.tokenBudget,
                temperature: attempt > 0
                    ? 0.08
                    : settings.autoSimulationMode === 'deep' ? 0.28 : 0.18,
                signal: controller.signal,
            });
            generationMetrics.raw = String(raw || '');
            updateTaskTrace({
                stage: 'parsing',
                responseOutcome: 'success',
                responseCharacters: generationMetrics.raw.length,
                responseAt: new Date().toISOString(),
            });
            const parsed = extractJsonObject(raw);
            if (parsed) {
                updateTaskTrace({
                    stage: 'parsed',
                    parseOutcome: 'success',
                    parsedAt: new Date().toISOString(),
                });
                return parsed;
            }
            const parseError = unreadableJsonError(raw);
            updateTaskTrace({
                parseOutcome: 'error',
                errorType: parseError.errorType || 'invalid-json',
                errorSummary: describeError(parseError),
            });
            throw parseError;
        }, {
            retries: settings.autoRetryCount,
            shouldRetry: shouldRetryWorldGeneration,
            onRetry: ({ attempt, total, delayMs, error, rateLimited }) => {
                recordTaskAttemptFailure({ attempt, total, delayMs, error, rateLimited });
                setSyncStatus({
                    phase: 'running',
                    message: rateLimited
                        ? `API đang bị giới hạn tốc độ～lượt suy diễn này giữ một phiên duy nhất, chuyển sang ${cooldownSeconds(delayMs)} giây chờ hồi`
                        : `Suy diễn thất bại, chuẩn bị lần ${attempt}/${total} tự động thử lại`,
                    error: rateLimited
                        ? `${describeError(error)}; hết thời gian chờ hồi sẽ chỉ thử lại đúng tác vụ hiện tại`
                        : `${describeError(error)}；${Math.ceil(delayMs / 100) / 10} giây nữa sẽ thử lại`,
                });
            },
            ...retryTaskOptions(
                'simulation',
                `simulation:${chatTokenAtStart}:${sourceKey}`,
                {
                    onCooldown: ({ delayMs }) => {
                        setSyncStatus({
                            phase: 'running',
                            message: `Tuyến API này đang chờ hồi～còn khoảng ${cooldownSeconds(delayMs)} giây`,
                            error: 'Sẽ không tạo suy diễn trùng lặp mới; hết chờ hồi sẽ tiếp tục tác vụ hiện tại.',
                        });
                    },
                },
            ),
            signal: controller.signal,
        });

        if (controller.signal.aborted) {
            const error = new Error('Người dùng đã hủy suy diễn (aborted)');
            error.name = 'AbortError';
            throw error;
        }

        // Settings may have changed while the API request was in flight. The
        // commit decision must use the current switch value, not the snapshot
        // captured when generation started.
        const memoryEnabledAtCommit = getSettings().memorySystemEnabled;
        updateTaskTrace({ stage: 'validating' });
        const applicablePayload = memoryEnabledAtCommit
            ? payload
            : {
                ...payload,
                memory_update: {
                    turn_summaries: [],
                    facts_upsert: [],
                    facts_invalidate: [],
                    clues_upsert: [],
                    clues_resolve: [],
                },
                memoryUpdate: {
                    turnSummaries: [],
                    factsUpsert: [],
                    factsInvalidate: [],
                    cluesUpsert: [],
                    cluesResolve: [],
                },
            };
        if (
            currentChatToken() === chatTokenAtStart
            && (
                runtime.contextEpoch !== contextEpochAtStart
                || Math.max(0, Number(getState()?.revision) || 0) !== baseRevision
            )
        ) {
            const target = locateTargetBranch(messageId, swipeId, expectedHash);
            if (target) {
                attachBranchData(target.message, swipeId, {
                    ...prepared.data,
                    status: 'pending',
                    error: '',
                });
                await target.context.saveChat?.();
            }
            setSyncStatus({
                phase: 'pending',
                message: 'Trạng thái thế giới bị sửa thủ công trong lúc suy diễn, kết quả cũ đã bị loại bỏ; sẽ đồng bộ lại theo trạng thái mới nhất',
                error: '',
            });
            finishTaskTrace('superseded', {
                stage: 'state-changed',
                commitOutcome: 'skipped',
            });
            return getState();
        }

        let resultState = applySimulationResult(baseState, applicablePayload, {
            messageId,
            swipeId,
            sourceKey,
            userName: beforeContext?.name1 || '',
            allowUserInnerVoice: false,
            recordPlayerCharacter: settings.recordPlayerCharacter,
            timePolicy: settings.timePolicy,
            narrativeText: newAssistantTexts.join('\n'),
            backgroundNpcBudget: settings.backgroundNpcBudget,
            lifeSettlementTargetIds: backgroundPersonTargets.map(person => person.id),
            memorySummaryMessageIds: memoryEnabledAtCommit ? pendingMessageIds : [],
        });
        updateTaskTrace({ stage: 'validated', validationOutcome: 'success' });
        // Manual deletion is an author decision, not a temporary UI filter.
        // Apply both exact-id and near-duplicate tombstones before snapshots are
        // written, so a model cannot resurrect the same current under a new id.
        resultState = applyManualDeletionFilters(resultState, getStore());
        resultState = markWorldCoverageChecked(resultState, worldCoverageTargets, {
            publicCycle: false,
            customInstruction: settings.customSimulationInstruction,
        });
        if (memoryEnabledAtCommit) {
            resultState = advanceMemoryCursorThroughSummaries(resultState, messageId);
        }
        resultState = recordDeliveryOffers(resultState, offeredEventIds, {
            messageId,
            expireAfter: 3,
        });
        const nextInjection = buildInjectionPackage(resultState, settings, recentChatText(), {
                contextText: recentForegroundIntentText(),
            });
        const summary = simulationSummary(baseState, resultState, {
            prompt,
            raw: generationMetrics.raw,
            attempts: generationMetrics.attempts,
            tokenBudget: generationMetrics.tokenBudget,
            injection: nextInjection,
        });

        const target = locateTargetBranch(messageId, swipeId, expectedHash);
        if (!target || !taskStillCurrent()) {
            finishTaskTrace('superseded', {
                stage: target ? 'context-changed' : 'branch-changed',
                commitOutcome: 'skipped',
            });
            if (taskStillCurrent()) {
                setSyncStatus({
                    phase: 'pending',
                    message: 'Nhánh chính văn đã thay đổi, kết quả cũ chưa được áp dụng; chính văn mới nhất vẫn đang chờ suy diễn',
                    error: '',
                });
            }
            return resultState;
        }

        const committed = {
            ...prepared.data,
            status: 'committed',
            result: createBranchSnapshot(resultState, {
                messageId,
                swipeId,
                sourceKey,
                kind: 'result',
            }),
            error: '',
            summary,
        };
        updateTaskTrace({ stage: 'committing', commitOutcome: 'pending' });
        settleResultBranchSurface(getStore(), sourceKey, baseState, resultState, {
            settledSocialMessages: applicablePayload?.social_messages_settled ?? applicablePayload?.socialMessagesSettled,
            narrativeText: newAssistantTexts.join('\n'),
        });
        attachBranchData(target.message, swipeId, committed);
        compactBranchSnapshotStorage();

        const branchIsCurrent = (
            Number(target.message.swipe_id ?? 0) === swipeId
            && hashText(target.message.mes) === expectedHash
        );
        const supersededByNewerReply = hasNewerAssistantReply(messageId);
        if (branchIsCurrent && !supersededByNewerReply) {
            const store = getStore();
            store.currentState = ensureMonotonicRevision(resultState, store.currentState);
            resultState = store.currentState;
            if (settings.worldPromptInjection !== false && settings.injectionSocial === true) {
                store.social = settleSocialConversations(
                    store.social,
                    resultState,
                    applicablePayload?.social_messages_settled ?? applicablePayload?.socialMessagesSettled,
                    newAssistantTexts.join('\n'),
                );
            }
            store.lingqi = applyLingqiDirectorResult(
                store.lingqi || emptyLingqiState(),
                applicablePayload.director_note_updates || applicablePayload.directorNoteUpdates || [],
                { offeredNoteIds: offeredDirectorNoteIds, sourceKey },
            );
            saveStore(store, { immediate: true });
            refreshInjection();
            runtime.ui?.render();
            schedulePublicPostProcessing(resultState, {
                impactDelay: 160,
                opinionDelay: 620,
            });
        }

        await target.context.saveChat?.();
        finishTaskTrace('success', {
            stage: 'committed',
            commitOutcome: 'success',
            committedAt: new Date().toISOString(),
        });
        setSyncStatus({
            phase: supersededByNewerReply ? 'pending' : 'success',
            message: supersededByNewerReply
                ? 'Lượt suy diễn này đã được lưu trữ an toàn～nhưng bạn đã đi tới chính văn mới hơn rồi, kết quả cũ sẽ không đè lên trạng thái hiện tại, tiếp theo sẽ đuổi thẳng theo lượt mới nhất'
                : 'Chính văn mới nhất đã suy diễn xong',
            error: '',
            succeededAt: supersededByNewerReply ? '' : new Date().toISOString(),
            method: runtime.syncStatus.method,
            summary,
        });
        return resultState;
    } catch (error) {
        if (isAbortError(error) || controller.signal.aborted) {
            finishTaskTrace('cancelled', {
                stage: 'cancelled',
                responseOutcome: 'cancelled',
                errorType: 'cancelled',
                errorSummary: describeError(error),
            });
            const target = taskStillCurrent()
                ? locateTargetBranch(messageId, swipeId, expectedHash)
                : null;
            if (target) {
                attachBranchData(target.message, swipeId, {
                    ...prepared.data,
                    status: 'pending',
                    error: '',
                });
                await target.context.saveChat?.();
            }
            if (taskStillCurrent()) {
                const store = getStore();
                store.currentState = trimState(markPendingSync(store.currentState, true));
                saveStore(store);
                refreshInjection();
                runtime.ui?.render();
            }
            if (taskStillCurrent()) {
                setSyncStatus({
                    phase: 'pending',
                    message: 'Đã hủy lần suy diễn này, chính văn vẫn ở trạng thái chờ đồng bộ',
                    error: '',
                });
                toast('Đã dừng suy diễn; thời gian, nhân vật, sự kiện và ký ức đều chưa được áp dụng.', 'info');
            }
            throw error;
        }
        const errorMessage = describeError(error);
        const issueType = error?.errorType || classifyDiagnosticIssue(errorMessage);
        finishTaskTrace('error', {
            stage: runtime.lastTaskTrace?.stage || 'failed',
            responseOutcome: runtime.lastTaskTrace?.stage === 'requesting'
                ? 'error'
                : runtime.lastTaskTrace?.responseOutcome || 'error',
            validationOutcome: runtime.lastTaskTrace?.stage === 'validating'
                ? 'error'
                : runtime.lastTaskTrace?.validationOutcome || 'none',
            commitOutcome: runtime.lastTaskTrace?.stage === 'committing'
                ? 'error'
                : runtime.lastTaskTrace?.commitOutcome || 'none',
            errorType: issueType,
            errorSummary: errorMessage,
        });
        const visibleError = issueType === 'output-limit'
            ? 'Nội dung suy diễn lần này vượt quá giới hạn đầu ra hiện tại, phản hồi của model bị cắt ngắn; lượt này chưa gửi bất kỳ trạng thái thế giới nào. Có thể tăng giới hạn Token của suy diễn thế giới trong “Giới hạn sinh” rồi thử lại.'
            : errorMessage;
        if (issueType === 'output-limit') {
            console.warn('[世界背面] Đầu ra suy diễn thế giới bị cắt cụt, đã loại bỏ kết quả chưa đóng:', errorMessage);
        }
        const target = taskStillCurrent()
            ? locateTargetBranch(messageId, swipeId, expectedHash)
            : null;
        if (target) {
            const failed = {
                ...prepared.data,
                status: 'error',
                error: visibleError,
            };
            attachBranchData(target.message, swipeId, failed);
            await target.context.saveChat?.();
        }

        if (taskStillCurrent()) {
            const store = getStore();
            store.currentState = trimState(markPendingSync(store.currentState, true));
            saveStore(store);
            refreshInjection();
            runtime.ui?.render();
        }

        if (taskStillCurrent()) {
            setSyncStatus({
                phase: 'error',
                message: issueType === 'output-limit'
                    ? 'Đầu ra suy diễn lần này quá dài, kết quả bị cắt đã được loại bỏ an toàn'
                    : 'Suy diễn thế giới chưa hoàn tất',
                error: visibleError,
                method: runtime.syncStatus.method,
            });
            toast(
                issueType === 'output-limit'
                    ? 'Đầu ra suy diễn bị cắt cụt; nhân vật, sự kiện, ký ức và thời gian thế giới của lượt này đều chưa được áp dụng.'
                    : `Suy diễn thế giới chưa hoàn tất: ${visibleError}`,
                'warning',
            );
        }
        throw error;
    } finally {
        if (runtime.activeSimulation === activeSimulation) {
            runtime.activeSimulation = null;
        }
        setBusy(false);
    }
}


function manualSimulationBlockerLabels() {
    const labels = [];
    if (runtime.activeHistoryScan && !runtime.activeHistoryScan.signal?.aborted) {
        labels.push(runtime.historyProgress?.kind === 'world-bootstrap' ? 'Truy hồi lịch sử' : 'Sắp xếp ký ức');
    }
    if (runtime.activeWorldPulse?.controller && !runtime.activeWorldPulse.controller.signal.aborted) {
        labels.push('Nhịp đập thế giới');
    }
    if (runtime.activePublicImpact?.controller && !runtime.activePublicImpact.controller.signal.aborted) {
        labels.push('Ảnh hưởng công cộng');
    }
    if (runtime.activeCorrection?.controller && !runtime.activeCorrection.controller.signal.aborted) {
        labels.push('Sửa lỗi sự thật');
    }
    if (
        runtime.publicOpinionRefreshTransaction?.controller
        && !runtime.publicOpinionRefreshTransaction.controller.signal.aborted
    ) {
        labels.push('Làm mới dư luận');
    } else if (
        runtime.activePublicOpinion?.controller
        && !runtime.activePublicOpinion.controller.signal.aborted
    ) {
        labels.push('Làm mới dư luận');
    }
    if (
        runtime.activePublicOpinionSandbox?.controller
        && !runtime.activePublicOpinionSandbox.controller.signal.aborted
    ) {
        labels.push('Dạo chơi tùy ý');
    }
    if (
        runtime.activeObservation?.controller
        && !runtime.activeObservation.controller.signal.aborted
    ) {
        labels.push('Quan sát nhân vật');
    }
    if (
        runtime.activeLingqi?.controller
        && !runtime.activeLingqi.controller.signal.aborted
    ) {
        labels.push('玲七');
    }
    // Connection tests and a few short maintenance calls only expose the shared
    // busy counter. They still should not race a manual world simulation.
    if (
        runtime.simulationCount > 0
        && !runtime.activeSimulation
        && labels.length === 0
    ) {
        labels.push('Thao tác nền hiện tại');
    }
    return [...new Set(labels)];
}

function clearDeferredManualSimulation() {
    if (runtime.manualSimulationTimer !== null) {
        window.clearTimeout(runtime.manualSimulationTimer);
        runtime.manualSimulationTimer = null;
    }
    runtime.pendingManualSimulation = null;
}

function scheduleDeferredManualSimulation(delay = 160, expectedChatToken = currentChatToken()) {
    const request = runtime.pendingManualSimulation;
    if (!request) return false;

    if (runtime.manualSimulationTimer !== null) {
        window.clearTimeout(runtime.manualSimulationTimer);
        runtime.manualSimulationTimer = null;
    }

    runtime.manualSimulationTimer = window.setTimeout(() => {
        runtime.manualSimulationTimer = null;
        const current = runtime.pendingManualSimulation;
        if (!current) return;

        if (
            current.chatToken !== expectedChatToken
            || current.chatToken !== currentChatToken()
            || current.dataEpoch !== runtime.dataEpoch
            || current.contextEpoch !== runtime.contextEpoch
        ) {
            clearDeferredManualSimulation();
            return;
        }

        const blockers = manualSimulationBlockerLabels();
        if (
            blockers.length
            || runtime.activeSimulation
            || runtime.queuedSimulations.size > 0
        ) {
            setSyncStatus({
                phase: 'queued',
                message: blockers.length
                    ? `Suy diễn đã xếp hàng, chờ${blockers.join('、')} xong sẽ tự động bắt đầu`
                    : 'Suy diễn đã xếp hàng, chờ suy diễn thế giới hiện tại xong sẽ tự động bắt đầu',
                error: '',
            });
            scheduleDeferredManualSimulation(Math.min(520, Math.max(180, Number(delay) + 80)), expectedChatToken);
            return;
        }

        const latest = latestAssistantEntry();
        const forceReplay = Boolean(current.forceReplay);
        if (!latest) {
            clearDeferredManualSimulation();
            setSyncStatus({
                phase: 'idle',
                message: 'Trong lúc xếp hàng không tìm thấy chính văn AI nào để suy diễn, lượt xếp hàng này đã bị hủy',
                error: '',
            });
            return;
        }

        const pendingNow = pendingAssistantEntriesThrough(latest.index).length;
        if (pendingNow <= 0 && !forceReplay) {
            clearDeferredManualSimulation();
            setSyncStatus({
                phase: 'success',
                message: 'Trong lúc xếp hàng thế giới đã được suy diễn khác đuổi kịp, lần này không gửi yêu cầu trùng',
                error: '',
            });
            runtime.ui?.render();
            return;
        }

        const pendingCount = Math.max(1, pendingNow);
        clearDeferredManualSimulation();
        void queueSimulation(latest.index, {
            force: forceReplay,
            trigger: 'manual-deferred',
            newAssistantCount: pendingCount,
        }).then(
            () => {
                toast(
                    pendingCount > 1
                        ? `Suy diễn trong hàng đợi đã xong, đã đuổi kịp tổng cộng ${pendingCount} lượt chính văn.`
                        : 'Suy diễn thế giới trong hàng đợi đã xong.',
                    'success',
                );
            },
            () => undefined,
        );
    }, Math.max(80, Number(delay) || 160));

    return true;
}

async function requestManualWorldSimulation() {
    const settings = getSettings();
    if (!settings.worldSimulationEnabled) {
        toast('Mô-đun suy diễn thế giới hiện đang tắt.', 'warning');
        return { queued: false, started: false };
    }

    const latest = latestAssistantEntry();
    if (!latest) {
        toast('Cuộc trò chuyện hiện tại chưa có chính văn AI nào để suy diễn.', 'warning');
        return { queued: false, started: false };
    }

    if (
        runtime.pendingManualSimulation
        && runtime.pendingManualSimulation.chatToken === currentChatToken()
    ) {
        const blockers = manualSimulationBlockerLabels();
        setSyncStatus({
            phase: 'queued',
            message: blockers.length
                ? `Suy diễn đã được xếp hàng, chờ${blockers.join('、')} xong sẽ tự động bắt đầu`
                : 'Suy diễn đã được xếp hàng, đang chờ tác vụ thế giới hiện tại kết thúc',
            error: '',
        });
        return { queued: true, started: false };
    }

    const blockers = manualSimulationBlockerLabels();
    if (
        blockers.length
        || runtime.activeSimulation
        || runtime.queuedSimulations.size > 0
    ) {
        const pendingAtRequest = pendingAssistantEntriesThrough(latest.index).length;
        runtime.pendingManualSimulation = {
            chatToken: currentChatToken(),
            dataEpoch: runtime.dataEpoch,
            contextEpoch: runtime.contextEpoch,
            requestedAt: Date.now(),
            // If there was nothing pending when the user clicked, this was an
            // intentional manual replay. Otherwise a concurrent/automatic catch-up
            // may satisfy the request while it waits, and we must not run twice.
            forceReplay: pendingAtRequest <= 0,
        };
        setSyncStatus({
            phase: 'queued',
            message: blockers.length
                ? `Suy diễn đã xếp hàng, chờ${blockers.join('、')} xong sẽ tự động bắt đầu`
                : 'Suy diễn đã xếp hàng, chờ suy diễn thế giới hiện tại xong sẽ tự động bắt đầu',
            error: '',
        });
        scheduleDeferredManualSimulation(140, currentChatToken());
        runtime.ui?.render();
        return { queued: true, started: false };
    }

    const pendingCount = Math.max(
        1,
        pendingAssistantEntriesThrough(latest.index).length,
    );
    try {
        await queueSimulation(latest.index, {
            force: true,
            trigger: 'manual',
            newAssistantCount: pendingCount,
        });
        toast(
            pendingCount > 1
                ? `Toàn bộ ${pendingCount} lượt chính văn đã suy diễn xong.`
                : 'Chính văn mới nhất đã được suy diễn lại.',
            'success',
        );
        return { queued: false, started: true };
    } catch {
        // runSimulationForMessage already recorded and displayed the detailed error.
        return { queued: false, started: false };
    }
}

function queueSimulation(messageId, options = {}) {
    // Foreground simulation is the highest-priority state writer. Any history,
    // pulse or propagation task still working from an older world must yield.
    preemptLowPriorityTasksForCore({ includeWorldWriters: true });
    const context = getContext();
    const numericMessageId = Number(messageId);
    const message = context?.chat?.[numericMessageId];
    const swipeId = Number(message?.swipe_id ?? 0);
    const sourceKey = message
        ? branchSourceKey(numericMessageId, message, swipeId)
        : `${numericMessageId}:${swipeId}:missing`;
    const branch = message ? branchDataFromMessage(message, swipeId) : null;
    const chatToken = currentChatToken();
    const queueKey = `${chatToken}:${sourceKey}`;
    const job = Object.freeze({
        chatToken,
        messageId: numericMessageId,
        swipeId,
        sourceKey,
        queueKey,
        dataEpoch: runtime.dataEpoch,
        trigger: options.trigger || 'reply',
        force: Boolean(options.force),
        newAssistantCount: Math.max(1, Number(options.newAssistantCount) || 1),
        offeredEventIds: clone(
            options.offeredEventIds
            ?? branch?.offeredEventIds
            ?? runtime.generationOffer.eventIds
            ?? [],
        ),
        offeredDirectorNoteIds: clone(
            options.offeredDirectorNoteIds
            ?? branch?.offeredDirectorNoteIds
            ?? runtime.generationOffer.directorNoteIds
            ?? [],
        ),
    });
    const existing = runtime.queuedSimulations.get(queueKey);
    if (existing) return existing;

    setSyncStatus({
        phase: 'queued',
        message: 'Đã đưa vào hàng đợi suy diễn thế giới',
        error: '',
    });
    const task = runtime.simulationChain
        .catch(() => undefined)
        .then(() => runSimulationForMessage(numericMessageId, {
            ...options,
            trigger: job.trigger,
            force: job.force,
            newAssistantCount: job.newAssistantCount,
            job,
        }));
    runtime.simulationChain = task;
    runtime.queuedSimulations.set(queueKey, task);
    void task.then(
        () => {
            if (runtime.queuedSimulations.get(queueKey) === task) {
                runtime.queuedSimulations.delete(queueKey);
            }
            window.setTimeout(schedulePendingCatchUp, 40);
            window.setTimeout(scheduleAutoMemoryIndex, 700);
        },
        error => {
            if (runtime.queuedSimulations.get(queueKey) === task) {
                runtime.queuedSimulations.delete(queueKey);
            }
            // A failed task must stay failed/pending. Do NOT construct a fresh
            // simulation 40ms later: otherwise bounded internal retries become an
            // unbounded outer retry loop, especially dangerous on 429 routes.
            if (!isAbortError(error) && rateLimitLike(error)) {
                setSyncStatus({
                    phase: 'error',
                    message: 'API bị giới hạn tốc độ, lượt suy diễn này đã ngừng tự động dựng lại',
                    error: 'Trạng thái thế giới chưa được áp dụng; chờ hết thời gian chờ hồi rồi tiếp tục ở lần kích hoạt rõ ràng tiếp theo.',
                    method: runtime.syncStatus.method,
                });
            }
        },
    );
    return task;
}

function scheduleAutoSync(messageId, type) {
    const settings = getSettings();
    const numericMessageId = Number(messageId);
    const message = getContext()?.chat?.[numericMessageId];
    if (!hasUsableAssistantText(message)) {
        setSyncStatus({
            phase: 'idle',
            message: 'Không phát hiện chính văn AI hợp lệ, lượt này không đẩy thế giới',
            error: '',
        });
        return;
    }
    if (numericMessageId > runtime.autoCatchUpSuppressedThroughMessageId) {
        runtime.autoCatchUpSuppressedThroughMessageId = -1;
    }
    if (!settings.enabled || !settings.worldSimulationEnabled) {
        setSyncStatus({
            phase: 'idle',
            message: settings.enabled ? 'Mô-đun suy diễn thế giới đã tắt' : '世界背面 hiện chưa được bật',
            error: '',
        });
        return;
    }
    const sourceKey = branchSourceKey(numericMessageId, message);
    const chatToken = currentChatToken();
    const queueKey = `${chatToken}:${sourceKey}`;
    const duplicateTask = Boolean(
        (
            runtime.activeSimulation?.chatToken === chatToken
            && runtime.activeSimulation?.sourceKey === sourceKey
        )
        || runtime.queuedSimulations.has(queueKey)
    );
    if (duplicateTask) {
        setSyncStatus({
            phase: runtime.activeSimulation?.sourceKey === sourceKey ? 'running' : 'queued',
            message: 'Lượt chính văn này đã nằm trong hàng đợi suy diễn, không cần xử lý lại',
            error: '',
        });
        return;
    }
    const workAlreadyRunning = Boolean(
        runtime.activeSimulation
        || runtime.queuedSimulations.size > 0
    );
    markMessagePending(messageId, {
        trigger: type || 'reply',
        deferBase: workAlreadyRunning,
    });
    // 新的前台正文一出现，所有仍拿旧上下文工作的低优先级任务都让路。
    preemptLowPriorityTasksForCore({ includeWorldWriters: true });
    if (!settings.worldAutoEnabled) {
        setSyncStatus({
            phase: 'pending',
            message: 'Tự động suy diễn đặt là thủ công; có thể suy diễn chính văn đã tích lũy bất cứ lúc nào',
            error: '',
        });
        return;
    }
    if (workAlreadyRunning) {
        preemptLowPriorityTasksForCore();
        const activeForCurrentChat = runtime.activeSimulation?.chatToken === chatToken
            ? runtime.activeSimulation
            : null;
        const activeTurns = activeForCurrentChat
            ? Math.max(1, Number(activeForCurrentChat.newAssistantCount) || 1)
            : 0;
        const waitingTurns = Math.max(
            1,
            pendingAssistantEntriesThrough(messageId).length - activeTurns,
        );
        setSyncStatus({
            phase: activeForCurrentChat ? 'running' : 'queued',
            message: `Chính văn mới đã vào hàng đợi an toàn, sẽ tiếp tục sau khi suy diễn hiện tại xong (đang chờ ${waitingTurns} lượt)`,
            error: '',
        });
        return;
    }

    const pending = pendingAssistantEntriesThrough(messageId);
    const interval = settings.autoSimulationInterval;
    if (pending.length < interval) {
        setSyncStatus({
            phase: 'pending',
            message: `Đã tích lũy ${pending.length}/${interval} lượt chính văn mới, đạt tần suất sẽ tự động suy diễn`,
            error: '',
        });
        return;
    }

    preemptLowPriorityTasksForCore();
    void queueSimulation(messageId, {
        trigger: type || 'reply',
        newAssistantCount: pending.length,
    }).catch(() => undefined);
}

function schedulePendingCatchUp({ afterMessageId = -1 } = {}) {
    const settings = getSettings();
    if (
        !settings.enabled
        || !settings.worldSimulationEnabled
        || !settings.worldAutoEnabled
        || runtime.simulationCount > 0
        || coreSimulationBusy()
    ) {
        return;
    }
    const latest = latestAssistantEntry();
    if (!latest) return;
    if (latest.index <= runtime.autoCatchUpSuppressedThroughMessageId) return;
    if (latest.index <= Number(afterMessageId)) return;
    const pending = pendingAssistantEntriesThrough(latest.index);
    if (pending.length < settings.autoSimulationInterval) return;
    void queueSimulation(latest.index, {
        trigger: 'interval-catch-up',
        newAssistantCount: pending.length,
    }).catch(() => undefined);
}

function hasL0SummaryForMessage(state, messageId) {
    return (state?.storyMemory?.summaries || []).some(summary => (
        Number(summary?.level) === 0
        && Number(summary?.startMessageId) === Number(messageId)
        && Number(summary?.endMessageId) === Number(messageId)
        && Boolean(String(summary?.summary || '').trim())
    ));
}

function advanceMemoryCursorThroughSummaries(state, throughMessageId) {
    if (!state?.storyMemory) return state;
    const chat = getContext()?.chat || [];
    const target = Math.min(chat.length - 1, Math.max(-1, Number(throughMessageId) || -1));
    let cursor = Math.max(-1, Number(state.storyMemory.indexedThroughMessageId ?? -1));
    for (let index = cursor + 1; index <= target; index += 1) {
        const message = chat[index];
        if (
            message && !message.is_system
            && (message.is_user || hasUsableAssistantText(message))
            && String(selectedMessageText(message)).trim()
            && !hasL0SummaryForMessage(state, index)
        ) break;
        cursor = index;
    }
    if (cursor > Number(state.storyMemory.indexedThroughMessageId ?? -1)) {
        state.storyMemory.indexedThroughMessageId = cursor;
        state.storyMemory.indexedAt = new Date().toISOString();
    }
    return state;
}

function unindexedAssistantCount() {
    const state = getState();
    const cursor = Math.max(
        0,
        Number(state.storyMemory?.indexedThroughMessageId ?? -1) + 1,
    );
    return (getContext()?.chat || [])
        .slice(cursor)
        .filter(hasUsableAssistantText)
        .length;
}

function scheduleAutoMemoryIndex() {
    const settings = getSettings();
    const interval = settings.memoryAutoIndexInterval;
    if (!settings.enabled || !settings.memorySystemEnabled || interval <= 0) return;
    const hasNewHistory = unindexedAssistantCount() >= interval;
    const hasPendingRollup = Boolean(planMemoryRollup(getState()));
    if (!hasNewHistory && !hasPendingRollup) return;
    if (runtime.autoMemoryTimer !== null) return;

    runtime.autoMemoryTimer = window.setTimeout(() => {
        runtime.autoMemoryTimer = null;
        if (
            runtime.historyProgress.phase === 'running'
            || runtime.simulationCount > 0
            || coreSimulationBusy()
        ) {
            scheduleAutoMemoryIndex();
            return;
        }
        void scanStoryMemoryHistory({
            automatic: true,
            maximumBatches: 1,
        }).catch(() => undefined);
    }, hasNewHistory ? 900 : 1600);
}

function onMessageReceived(messageId, type) {
    if (['quiet', 'impersonate', 'first_message'].includes(type)) return;
    const message = getContext()?.chat?.[Number(messageId)];
    if (!hasUsableAssistantText(message)) {
        if (!runtime.inBackgroundGeneration) {
            setSyncStatus({
                phase: 'idle',
                message: 'Phản hồi trống hoặc sinh thất bại, đã bỏ qua suy diễn và ghi ký ức',
                error: '',
            });
        }
        return;
    }
    const offeredDirectorNoteIds = clone(runtime.generationOffer.directorNoteIds || []);
    if (offeredDirectorNoteIds.length) {
        const swipeId = Number(message.swipe_id ?? 0);
        const sourceKey = branchSourceKey(Number(messageId), message, swipeId);
        const store = getStore();
        store.lingqi = consumeLingqiDirectorOffer(store.lingqi || emptyLingqiState(), {
            offeredNoteIds: offeredDirectorNoteIds,
            sourceKey,
        });
        saveStore(store, { immediate: true });
        refreshInjection();
        runtime.ui?.render();
    }
    const settings = getSettings();
    scheduleAutoSync(Number(messageId), type);
    const worldOwnsThisBatch = Boolean(
        settings.enabled
        && settings.worldSimulationEnabled
        && settings.worldAutoEnabled
        && (
            runtime.activeSimulation
            || runtime.queuedSimulations.size > 0
            || pendingAssistantEntriesThrough(Number(messageId)).length >= settings.autoSimulationInterval
        )
    );
    if (!worldOwnsThisBatch) {
        scheduleAutoMemoryIndex();
    }
}

async function runPreGenerationConsistencyBarrier(_chat, _contextSize, _abort, type) {
    const settings = getSettings();
    if (
        runtime.consistencyBarrierRunning
        || ['quiet', 'impersonate', 'first_message'].includes(type)
    ) {
        return;
    }

    const offerCurrentInjection = () => {
        offerGenerationInjection(type);
    };

    if (!settings.enabled || !settings.worldSimulationEnabled) {
        offerCurrentInjection();
        return;
    }

    const latest = latestAssistantEntry();
    if (!latest) {
        offerCurrentInjection();
        return;
    }

    const pending = pendingAssistantEntriesThrough(latest.index);
    const coreAlreadyRunning = Boolean(
        runtime.activeSimulation
        || runtime.queuedSimulations.size > 0
    );
    const pluginWorkAlreadyRunning = coreAlreadyRunning || activeBackgroundTaskLabels()
        .some(label => label !== '玲七');

    // Consistency Barrier is a gate, not a hidden auto-run trigger.
    // It may wait for work that is already due/running, but it must not bypass
    // the user's auto-run switch or configured "every N turns" interval.
    const autoTaskIsDue = Boolean(
        settings.worldAutoEnabled
        && pending.length >= settings.autoSimulationInterval
    );

    if (!pending.length && !pluginWorkAlreadyRunning) {
        if (pendingPublicImpactEvents(getState(), { maximum: 8 }).length) {
            scheduleDeferredPublicImpact(220, currentChatToken());
        }
        offerCurrentInjection();
        return;
    }

    if (pluginWorkAlreadyRunning) {
        const stopped = cancelActiveBackgroundTasks({ preserveLingqi: true });
        setSyncStatus({
            phase: 'pending',
            message: stopped.cancelled
                ? 'Ưu tiên sinh chính văn: suy diễn nền đã nhường đường, kết quả chưa xong sẽ không được áp dụng; có phản hồi mới rồi sẽ tiếp tục theo tần suất'
                : 'Ưu tiên sinh chính văn: lượt này dùng luôn trạng thái thế giới đã xác nhận gần nhất',
            error: '',
        });
        offerCurrentInjection();
        return;
    }

    if (!coreAlreadyRunning && !autoTaskIsDue) {
        setSyncStatus({
            phase: 'pending',
            message: !settings.worldAutoEnabled
                ? `Đã có ${pending.length} lượt chính văn chờ đồng bộ; tự động suy diễn đang ở chế độ thủ công, lần gửi này sẽ không lén khởi động suy diễn thay bạn`
                : `Đã tích lũy ${pending.length}/${settings.autoSimulationInterval} lượt chính văn; chưa đạt tần suất tự động, lần gửi này tiếp tục dùng trạng thái thế giới đã xác nhận gần nhất`,
            error: '',
        });
        offerCurrentInjection();
        return;
    }

    // Even when automatic simulation is due, foreground prose must never wait
    // for a plugin model call. MESSAGE_RECEIVED will schedule the accumulated
    // world work after the new assistant reply has completed.
    setSyncStatus({
        phase: 'pending',
        message: `Đã có ${pending.length} lượt chính văn đạt tần suất suy diễn; lần này sinh chính văn trước, xong rồi mới tiếp tục suy diễn nền`,
        error: '',
    });
    offerCurrentInjection();
}

globalThis.worldBackstageGenerationInterceptor = runPreGenerationConsistencyBarrier;

function onGenerationStarted(type, _options, dryRun) {
    if (dryRun || ['quiet', 'impersonate', 'first_message'].includes(type)) return;
    const offer = offerGenerationInjection(type);
    if (!String(runtime.injection.text || '').trim()) return;
    toast(
        offer.rerollBase
            ? 'Dữ liệu của nhánh reroll cũ đã được rút lại; chính văn lượt này nhận trạng thái thế giới từ trước khi reroll.'
            : 'Dữ liệu 世界背面 đã được đưa cho chính văn lượt này.',
        'success',
    );
}

function restoreExistingSwipe(messageId) {
    invalidateAsyncWorldContext();
    const context = getContext();
    const message = context?.chat?.[Number(messageId)];
    if (!message) return;
    const swipeId = Number(message.swipe_id ?? 0);
    const swipesLength = Array.isArray(message.swipes) ? message.swipes.length : 0;
    const data = branchDataFromMessage(message, swipeId);
    const sourceKey = branchSourceKey(Number(messageId), message, swipeId);
    const dataMatchesSource = branchRecordMatchesSource(data, sourceKey);
    const store = getStore();
    captureBranchSurface(store, branchSurfaceKeyFromState(store.currentState));

    if (swipeId >= swipesLength) {
        const previous = findLatestResultSnapshot(Number(messageId));
        const base = dataMatchesSource && data?.base
            ? restoreBranchSnapshot(data.base, store.initialState)
            : (previous
                ? stateWithBranchOverride(previous.snapshot, store)
                : clone(store.initialState));
        store.currentState = markPendingSync(base, true);
        const pendingSourceKey = messageId + ':' + swipeId + ':pending';
        const pending = {
            schemaVersion: SCHEMA_VERSION,
            status: 'pending',
            sourceKey: pendingSourceKey,
            trigger: 'swipe',
            offeredEventIds: clone(runtime.injection.eventIds || []),
            offeredDirectorNoteIds: clone(runtime.injection.directorNoteIds || []),
            base: createBranchSnapshot(base, {
                messageId: Number(messageId),
                swipeId,
                sourceKey: pendingSourceKey,
                kind: 'base',
            }),
            result: null,
            error: '',
            stale: false,
        };
        message.extra ||= {};
        message.extra[SNAPSHOT_KEY] = pending;
    } else if (committedBranchMatchesSource(data, sourceKey)) {
        store.currentState = stateWithBranchOverride(data.result, store);
    } else if (dataMatchesSource && data?.base) {
        store.currentState = markPendingSync(
            restoreBranchSnapshot(data.base, store.initialState),
            true,
        );
    } else {
        const previous = findLatestResultSnapshot(Number(messageId));
        store.currentState = markPendingSync(
            previous ? stateWithBranchOverride(previous.snapshot, store) : clone(store.initialState),
            true,
        );
    }

    restoreSurfaceForState(store, store.currentState);
    saveStore(store);
    refreshInjection();
    runtime.ui?.render();
}

function markSnapshotsStaleFrom(messageId, {
    preserveSiblingSwipesAtStart = false,
    selectedSwipeId = null,
} = {}) {
    const context = getContext();
    const chat = context?.chat || [];
    const startIndex = Number(messageId);
    for (let index = startIndex; index < chat.length; index += 1) {
        const message = chat[index];
        const preserveSiblings = preserveSiblingSwipesAtStart && index === startIndex;
        const selected = Number(selectedSwipeId ?? message?.swipe_id ?? 0);
        const current = message?.extra?.[SNAPSHOT_KEY];
        if (current && (!preserveSiblings || Number(message?.swipe_id ?? 0) === selected)) {
            current.stale = true;
        }
        for (let swipeIndex = 0; swipeIndex < (message?.swipe_info?.length || 0); swipeIndex += 1) {
            if (preserveSiblings && swipeIndex !== selected) continue;
            const data = message.swipe_info?.[swipeIndex]?.extra?.[SNAPSHOT_KEY];
            if (data) data.stale = true;
        }
    }
    void context?.saveChat?.();
}

function onMessageEdited(messageId) {
    invalidateAsyncWorldContext();
    const context = getContext();
    const index = Number(messageId);
    const message = context?.chat?.[index];
    const swipeId = Number(message?.swipe_id ?? 0);
    const existing = message ? branchDataFromMessage(message, swipeId) : null;

    if (
        message
        && !message.is_user
        && index === context.chat.length - 1
        && existing?.status === 'committed'
        && existing.result
        && !existing.stale
    ) {
        runtime.editDecision = {
            chatToken: currentChatToken(),
            messageId: index,
            swipeId,
            previousSourceKey: existing.sourceKey,
        };
        const store = getStore();
        captureBranchSurface(
            store,
            String(runtime.editDecision?.previousSourceKey || branchSurfaceKeyFromState(store.currentState)),
        );
        const previous = findLatestResultSnapshot(index);
        const safeBase = existing.base && !existing.stale
            ? restoreBranchSnapshot(existing.base, store.initialState)
            : (previous ? stateWithBranchOverride(previous.snapshot, store) : clone(store.initialState));
        store.currentState = markPendingSync(safeBase, true);
        restoreSurfaceForState(store, store.currentState);
        saveStore(store, { immediate: true });
        refreshInjection();
        setSyncStatus({
            phase: 'pending',
            message: 'Chính văn đã suy diễn bị chỉnh sửa; thế giới đã lùi an toàn về trước khi sửa, chờ bạn chọn giữ suy diễn cũ hay đồng bộ lại',
            error: '',
        });
        runtime.ui?.render();
        return;
    }

    markSnapshotsStaleFrom(index, {
        preserveSiblingSwipesAtStart: true,
        selectedSwipeId: swipeId,
    });

    const previous = findLatestResultSnapshot(index);
    const store = getStore();
    captureBranchSurface(store, branchSurfaceKeyFromState(store.currentState));
    store.currentState = markPendingSync(
        previous ? stateWithBranchOverride(previous.snapshot, store) : clone(store.initialState),
        true,
    );
    restoreSurfaceForState(store, store.currentState);
    saveStore(store);
    refreshInjection();
    runtime.ui?.render();

    if (message && !message.is_user && index === context.chat.length - 1) {
        setSyncStatus({
            phase: 'pending',
            message: 'Chính văn đã được sửa, trạng thái thế giới chưa thay đổi; xác nhận nội dung xong hãy đồng bộ thủ công',
            error: '',
        });
        toast('Đã lưu chỉnh sửa chính văn, nhưng sẽ không tự động suy diễn lại; khi thấy ổn hãy bấm “Đồng bộ chính văn mới nhất”.', 'info');
        return;
    }
    toast('Đã quay về snapshot thế giới trước điểm chỉnh sửa; chính văn phía sau cần sinh lại hoặc đồng bộ thủ công.', 'info');
}

async function resolveMessageEdit(mode) {
    const decision = runtime.editDecision;
    if (!decision || decision.chatToken !== currentChatToken()) {
        runtime.editDecision = null;
        throw new Error('Chỉnh sửa chính văn này không còn nằm trong nhánh trò chuyện hiện tại');
    }
    const context = getContext();
    const message = context?.chat?.[decision.messageId];
    if (!message || message.is_user || decision.messageId !== context.chat.length - 1) {
        runtime.editDecision = null;
        throw new Error('Vị trí chính văn đã thay đổi, hãy dùng “Suy diễn chính văn mới nhất” để đồng bộ');
    }

    if (mode === 'keep') {
        const swipeId = Number(message.swipe_id ?? decision.swipeId ?? 0);
        const existing = branchDataFromMessage(message, swipeId);
        if (!existing?.result || existing.stale) {
            runtime.editDecision = null;
            throw new Error('Snapshot thế giới trước khi sửa không còn dùng được, hãy chuyển sang đồng bộ lại');
        }
        const store = getStore();
        const keptState = stateWithBranchOverride(existing.result, store);
        const sourceKey = branchSourceKey(decision.messageId, message, swipeId);
        if (keptState?.lastCommit) {
            keptState.lastCommit = {
                ...keptState.lastCommit,
                messageId: decision.messageId,
                swipeId,
                sourceKey,
            };
        }
        rebindBranchSurface(store, decision.previousSourceKey, sourceKey);
        const rebound = {
            ...existing,
            sourceKey,
            base: existing.base
                ? createBranchSnapshot(restoreBranchSnapshot(existing.base, store.initialState), {
                    messageId: decision.messageId,
                    swipeId,
                    sourceKey,
                    kind: 'base',
                })
                : null,
            result: createBranchSnapshot(keptState, {
                messageId: decision.messageId,
                swipeId,
                sourceKey,
                kind: 'result',
            }),
            stale: false,
        };
        attachBranchData(message, swipeId, rebound);
        store.currentState = trimState(keptState);
        restoreSurfaceForState(store, store.currentState);
        saveStore(store, { immediate: true });
        void context?.saveChat?.();
        runtime.editDecision = null;
        refreshInjection();
        setSyncStatus({
            phase: 'success',
            message: 'Đã xác nhận chỉnh sửa chỉ đổi câu chữ; suy diễn thế giới cũ đã được gắn với chính văn sau khi sửa',
            error: '',
        });
        runtime.ui?.render();
        toast('Đã giữ suy diễn cũ và gắn lại với chính văn sau khi sửa.', 'success');
        return;
    }

    if (!getSettings().worldSimulationEnabled) {
        throw new Error('Mô-đun suy diễn thế giới hiện đang tắt, không thể suy diễn lại theo chính văn đã sửa');
    }
    runtime.editDecision = null;
    markSnapshotsStaleFrom(decision.messageId, {
        preserveSiblingSwipesAtStart: true,
        selectedSwipeId: Number(message.swipe_id ?? decision.swipeId ?? 0),
    });
    const store = getStore();
    const previous = findLatestResultSnapshot(decision.messageId);
    store.currentState = markPendingSync(
        previous ? stateWithBranchOverride(previous.snapshot, store) : clone(store.initialState),
        true,
    );
    restoreSurfaceForState(store, store.currentState);
    saveStore(store);
    refreshInjection();
    runtime.ui?.render();
    await queueSimulation(decision.messageId, {
        force: true,
        trigger: 'edited-reply',
        newAssistantCount: 1,
    });
    toast('Đã suy diễn thế giới lại xong theo chính văn đã sửa.', 'success');
}

function onMessageDeleted(messageId) {
    invalidateAsyncWorldContext();
    const rawIndex = messageId && typeof messageId === 'object'
        ? (messageId.messageId ?? messageId.message_id ?? messageId.index ?? messageId.id)
        : messageId;
    const index = Number(rawIndex);
    if (!Number.isFinite(index) || index < 0) {
        restoreLatestBranch({ pending: true });
        return;
    }

    // 删除中间楼层后，后面的消息索引整体左移；旧 snapshot/sourceMessageId
    // 已经不再指向同一段正文。先作废删除点之后的快照，再退回删除点之前。
    markSnapshotsStaleFrom(index);
    const store = getStore();
    captureBranchSurface(store, branchSurfaceKeyFromState(store.currentState));
    const previous = findLatestResultSnapshot(index);
    store.currentState = markPendingSync(
        previous ? stateWithBranchOverride(previous.snapshot, store) : clone(store.initialState),
        true,
    );
    restoreSurfaceForState(store, store.currentState);
    saveStore(store, { immediate: true });
    refreshInjection();
    runtime.ui?.render();
    setSyncStatus({
        phase: 'pending',
        message: 'Tin nhắn đã bị xóa, snapshot thế giới cũ sau điểm xóa đã bị hủy; hãy đồng bộ lại theo chính văn hiện tại',
        error: '',
    });
}

function onChatChanged() {
    runtime.worldbookScanToken = null;
    discardWorldbookDrafts();
    invalidateAsyncWorldContext();
    runtime.activePublicOpinion?.controller?.abort?.();
    runtime.activePublicOpinionSandbox?.controller?.abort?.();
    runtime.activeObservation?.controller?.abort?.();
    runtime.activeLingqi?.controller?.abort?.();
    runtime.activePublicOpinion = null;
    runtime.activePublicOpinionSandbox = null;
    runtime.activeObservation = null;
    runtime.activeLingqi = null;
    // 旧聊天的 single-flight promise 不能挡住新聊天第一次舆情检查。
    // 旧 promise 的 finally 有 identity guard，不会误清新聊天随后建立的 transaction。
    runtime.publicOpinionRefreshTransaction = null;
    runtime.pendingPublicImpact = false;
    runtime.pendingPublicOpinion = false;
    runtime.queuedSimulations.clear();
    if (runtime.publicImpactTimer !== null) {
        window.clearTimeout(runtime.publicImpactTimer);
        runtime.publicImpactTimer = null;
    }
    if (runtime.publicOpinionTimer !== null) {
        window.clearTimeout(runtime.publicOpinionTimer);
        runtime.publicOpinionTimer = null;
    }
    runtime.lastTaskConnection = null;
    resetLastCustomApiOperation();
    runtime.ui?.resetContext?.();
    runtime.ui?.ensureMounted?.();
    installSettingsEntry();
    if (runtime.autoMemoryTimer !== null) {
        window.clearTimeout(runtime.autoMemoryTimer);
        runtime.autoMemoryTimer = null;
    }
    if (runtime.autoHideTimer !== null) {
        window.clearTimeout(runtime.autoHideTimer);
        runtime.autoHideTimer = null;
    }
    if (runtime.socialPulseTimer !== null) {
        window.clearTimeout(runtime.socialPulseTimer);
        runtime.socialPulseTimer = null;
    }
    if (runtime.manualUndoTimer !== null) {
        window.clearTimeout(runtime.manualUndoTimer);
        runtime.manualUndoTimer = null;
    }
    runtime.manualUndo = null;
    runtime.editDecision = null;
    runtime.activeChatToken = currentChatToken();
    runtime.historyProgress = {
        phase: 'idle',
        processed: 0,
        total: getContext()?.chat?.length || 0,
        message: '',
    };
    runtime.publicOpinionStatus = {
        phase: 'idle',
        message: 'Chưa tạo snapshot dư luận',
        error: '',
    };
    runtime.lingqiStatus = {
        phase: 'idle',
        message: '玲七 đang đợi bạn ở đây～',
        error: '',
    };
    runtime.syncStatus = {
        phase: 'idle',
        message: 'Đang đọc trạng thái suy diễn của cuộc trò chuyện hiện tại',
        error: '',
        attemptedAt: '',
        succeededAt: '',
        method: '',
    };
    window.setTimeout(() => {
        runtime.activeChatToken = currentChatToken();
        restoreLatestBranch();
        syncSettingsEntry();
        if (compactBranchSnapshotStorage()) void getContext()?.saveChat?.();
        void reconcileAutoHidePrerequisites(currentChatToken()).catch(error => {
            console.warn('[世界背面] Kiểm tra an toàn của tự động ẩn thất bại', error);
        });
        scheduleAutoHideArchivedFloors(120);
        schedulePendingCatchUp();
    }, 80);
}

function armManualUndo(previousState, {
    key = currentAnchorKey(),
    label = 'Hoàn tác thay đổi thủ công vừa rồi',
    previousInitialState = null,
    previousManualDeletions = null,
} = {}) {
    if (runtime.manualUndoTimer !== null) window.clearTimeout(runtime.manualUndoTimer);
    runtime.manualUndo = {
        state: clone(previousState),
        previousInitialState: previousInitialState ? clone(previousInitialState) : null,
        previousManualDeletions: previousManualDeletions
            ? clone(previousManualDeletions)
            : null,
        key,
        label,
        chatToken: currentChatToken(),
        expiresAt: Date.now() + 9000,
    };
    runtime.manualUndoTimer = window.setTimeout(() => {
        runtime.manualUndo = null;
        runtime.manualUndoTimer = null;
        runtime.ui?.render();
    }, 9000);
    runtime.ui?.render();
}

function undoManualChange() {
    const undo = runtime.manualUndo;
    if (
        !undo
        || undo.expiresAt <= Date.now()
        || undo.chatToken !== currentChatToken()
        || undo.key !== currentAnchorKey()
    ) {
        throw new Error('Đã hết thời gian có thể hoàn tác, hoặc nhánh chính văn đã thay đổi');
    }
    if (runtime.manualUndoTimer !== null) window.clearTimeout(runtime.manualUndoTimer);
    runtime.manualUndo = null;
    runtime.manualUndoTimer = null;

    const store = getStore();
    if (undo.previousManualDeletions) {
        store.manualDeletions = normalizeManualDeletions(undo.previousManualDeletions);
    }
    const monotonicUndoState = ensureMonotonicRevision(undo.state, store.currentState);
    store.currentState = applyPlayerCharacterRecordingPolicy(
        applyManualDeletionFilters(monotonicUndoState, store),
        getSettings(),
    );
    if (undo.previousInitialState) store.initialState = trimState(undo.previousInitialState);
    store.branchOverrides[undo.key] = createBranchSnapshot(store.currentState, {
        sourceKey: undo.key,
        kind: 'manual-undo',
    });
    saveStore(store, { immediate: true });
    refreshInjection();
    runtime.ui?.render();
    toast('Đã hoàn tác thay đổi thủ công vừa rồi.', 'success');
}

function commitManualState(nextState, message = 'Trạng thái thế giới đã được cập nhật', {
    mutateStore = null,
} = {}) {
    const key = currentAnchorKey();
    const store = getStore();
    const previousState = clone(store.currentState);
    const previousManualDeletions = clone(
        normalizeManualDeletions(store.manualDeletions),
    );
    if (typeof mutateStore === 'function') mutateStore(store);
    const committed = setCurrentState(nextState, { overrideKey: key });
    armManualUndo(previousState, {
        key,
        previousManualDeletions,
    });
    schedulePublicPostProcessing(committed, {
        impactDelay: 160,
        opinionDelay: 620,
    });
    toast(message, 'success');
}

function createManualRecoveryPoint() {
    const store = addRecoveryPoint(getStore(), {
        reason: 'manual',
        label: 'Điểm khôi phục tạo thủ công',
    });
    saveStore(store, { immediate: true });
    runtime.ui?.render();
    toast('Đã lưu điểm khôi phục rồi～cứ yên tâm vọc tiếp nhé `(｡•̀ᴗ-)✧`', 'success');
    return listRecoveryPoints(store).at(-1) || null;
}

function restoreLatestSavedRecovery() {
    const currentStore = getStore();
    const beforeRestoreState = clone(currentStore.currentState);
    const key = currentAnchorKey();
    const target = listRecoveryPoints(currentStore).at(-1);
    if (!target) throw new Error('Cuộc trò chuyện hiện tại chưa có điểm lưu nào để khôi phục');
    const confirmed = globalThis.confirm?.(
        `(・_・;)  Khôi phục thế giới hiện tại về: ${target.label}\n${target.createdAt}\n\nTrước khi khôi phục cũng sẽ tự động lưu trạng thái hiện tại.`,
    );
    if (confirmed === false) return null;

    let store = addRecoveryPoint(currentStore, {
        reason: 'before-restore',
        label: 'Tự động lưu trước khi khôi phục',
    });
    const restored = restoreRecoveryPoint(store, target.id);
    if (!restored.point) throw new Error('Điểm khôi phục đã mất hiệu lực, hãy mở lại cài đặt rồi thử lại');
    store = restored.store;
    store.currentState = ensureMonotonicRevision(store.currentState, beforeRestoreState);
    store.branchOverrides ||= {};
    store.branchOverrides[key] = createBranchSnapshot(store.currentState, {
        sourceKey: key,
        kind: 'recovery-restore',
    });
    saveStore(store, { immediate: true });
    refreshInjection();
    runtime.ui?.render();
    toast('Thế giới đã được khôi phục về điểm lưu, có thể tiếp tục rồi.', 'success');
    return restored.point;
}

function redactDiagnosticText(value) {
    let text = String(value || '');
    const settings = getSettings();
    const keys = [
        String(settings.customApiKey || ''),
        ...(settings.apiProfiles || []).map(profile => String(profile.key || '')),
    ].filter(key => key.length >= 4);
    for (const key of keys) text = text.split(key).join('[đã ẩn API Key]');
    return text
        .replace(/Bearer\s+[A-Za-z0-9._~+/=-]+/gi, 'Bearer [đã ẩn]')
        .replace(/https?:\/\/[^\s"'<>]+/gi, '[đã ẩn địa chỉ API]')
        .replace(/(api[-_ ]?key\s*[:=]\s*)[^\s,;]+/gi, '$1[đã ẩn]')
        .slice(0, 600);
}

function classifyDiagnosticIssue(value) {
    const text = String(value || '').toLocaleLowerCase();
    if (!text) return 'none';
    if (/abort|cancel|取消|停止|đã hủy|bị hủy|hủy bỏ|dừng/i.test(text)) return 'cancelled';
    if (/请先填写|尚未配置|配置缺失|missing[_\s-]*(?:field|configuration)|hãy điền|chưa điền|chưa cấu hình|thiếu cấu hình/i.test(text)) return 'configuration';
    if (/401|403|unauthorized|forbidden|鉴权|密钥|api.?key|xác thực|khóa bí mật/i.test(text)) return 'authorization';
    if (/insufficient[_\s-]*quota|quota\s*(?:exceeded|exhausted|depleted)|credits?\s*(?:exhausted|depleted)|额度(?:不足|耗尽)|余额不足|hạn mức (?:không đủ|đã hết|đã cạn)|hết hạn mức|số dư không đủ/i.test(text)) return 'quota-exhausted';
    if (/429|too many requests|rate[_\s-]*limit|请求过于频繁|频率限制|限流|giới hạn tốc độ|quá nhiều yêu cầu/i.test(text)) return 'rate-limit';
    if (/\b503\b|service unavailable|temporarily unavailable|服务不可用|服务暂不可用|dịch vụ không khả dụng|dịch vụ tạm(?: thời)? không khả dụng/i.test(text)) return 'service-unavailable';
    if (/timeout|timed out|超时|quá thời gian|hết thời gian chờ/i.test(text)) return 'timeout';
    if (/network|fetch|connection|econn|socket hang up|socket closed|connection reset|网络|连接|mạng|kết nối/i.test(text)) return 'network';
    if (/no message|empty|空回|没有生成|未生成|phản hồi trống|trả lời trống|nội dung trống|không tạo được|chưa tạo|không có tin nhắn|trả về rỗng/i.test(text)) return 'empty-response';
    if (/length|max[_\s-]*tokens?|token[_\s-]*limit|输出上限|长度上限|过长|giới hạn đầu ra|giới hạn độ dài|quá dài/i.test(text)) return 'output-limit';
    if (/json|解析|parse|格式|phân tích cú pháp|không phân tích được|định dạng/i.test(text)) return 'invalid-json';
    return 'other';
}

function diagnosticSecretShape(value, source = 'plugin-settings') {
    const raw = String(value || '');
    const trimmed = raw.trim();
    const length = trimmed.length;
    return {
        source,
        present: length > 0,
        lengthRange: length === 0
            ? 'empty'
            : length < 16
                ? '1-15'
                : length < 32
                    ? '16-31'
                    : length < 64
                        ? '32-63'
                        : '64+',
        leadingOrTrailingWhitespace: raw !== trimmed,
        internalWhitespace: /\s/.test(trimmed),
    };
}

function diagnosticEndpointShape(value) {
    const raw = String(value || '').trim();
    if (!raw) {
        return {
            present: false,
            validUrl: false,
            protocol: '',
            secure: false,
            pathSegments: 0,
            hasQuery: false,
            hasHash: false,
            pathHint: 'empty',
        };
    }
    try {
        const parsed = new URL(raw);
        const segments = parsed.pathname.split('/').filter(Boolean);
        const path = parsed.pathname.toLocaleLowerCase();
        return {
            present: true,
            validUrl: Boolean(parsed.host && ['http:', 'https:'].includes(parsed.protocol)),
            protocol: parsed.protocol.replace(':', ''),
            secure: parsed.protocol === 'https:',
            pathSegments: segments.length,
            hasQuery: Boolean(parsed.search),
            hasHash: Boolean(parsed.hash),
            pathHint: /\/chat\/completions\/?$/.test(path)
                ? 'chat-completions'
                : /\/models\/?$/.test(path)
                    ? 'models'
                    : /\/v\d+(?:beta)?\/?$/.test(path)
                        ? 'version-root'
                        : 'custom-root',
        };
    } catch {
        return {
            present: true,
            validUrl: false,
            protocol: '',
            secure: false,
            pathSegments: 0,
            hasQuery: raw.includes('?'),
            hasHash: raw.includes('#'),
            pathHint: 'unparseable',
        };
    }
}

function diagnosticCustomConfiguration(settings, source = 'default-independent') {
    const endpoint = diagnosticEndpointShape(settings?.customApiUrl);
    const key = diagnosticSecretShape(settings?.customApiKey, source);
    const rawModel = String(settings?.customApiModel || '');
    const model = rawModel.trim();
    const transport = settings?.customApiTransport === 'direct' ? 'direct' : 'proxy';
    const missing = [];
    if (!endpoint.present) missing.push('apiUrl');
    else if (!endpoint.validUrl) missing.push('validApiUrl');
    if (!key.present) missing.push('apiKey');
    if (!model) missing.push('model');
    return {
        ready: missing.length === 0,
        missing,
        transport,
        endpoint,
        key,
        model: {
            present: Boolean(model),
            characters: model.length,
            leadingOrTrailingWhitespace: rawModel !== model,
        },
        configuredTimeoutMs: Math.max(0, Number(settings?.customApiTimeoutMs) || 0),
    };
}

function diagnosticRouteKind(routeValue) {
    const route = String(routeValue || 'default');
    if (route === 'default' || route === 'tavern') return route;
    if (route.startsWith('profile:')) return 'saved-independent-profile';
    if (route.startsWith('tavern-profile:')) return 'saved-tavern-profile';
    return 'unknown';
}

function diagnosticModuleRoute(settings, taskKind) {
    const routeKey = taskRouteKey(taskKind);
    const selectedRoute = String(settings.apiModuleRoutes?.[routeKey] || 'default');
    const resolved = resolveTaskConnection(settings, taskKind);
    const result = {
        module: routeKey,
        selectedRouteKind: diagnosticRouteKind(selectedRoute),
        resolvedMode: resolved.mode,
        resolved: true,
    };
    if (resolved.mode === 'custom') {
        result.configuration = diagnosticCustomConfiguration(
            resolved.settings,
            selectedRoute.startsWith('profile:') ? 'saved-independent-profile' : 'default-independent',
        );
        result.profileResolved = selectedRoute.startsWith('profile:') ? Boolean(resolved.profile) : null;
    } else if (resolved.mode === 'tavern-profile') {
        result.profileResolved = Boolean(resolved.profile);
        result.requestServiceAvailable = typeof getContext()?.ConnectionManagerRequestService?.sendRequest === 'function';
    } else {
        result.currentTavernSource = getCurrentTavernConnectionInfo().source;
        result.generateRawAvailable = typeof getContext()?.generateRaw === 'function';
    }
    if (
        selectedRoute.startsWith('profile:')
        && !settings.apiProfiles?.some(item => item.id === selectedRoute.slice('profile:'.length))
    ) {
        result.resolved = false;
        result.fallback = resolved.mode;
    }
    return result;
}

function diagnosticEntityHealth(items) {
    const list = Array.isArray(items) ? items : [];
    const ids = list.map(item => String(item?.id || '').trim()).filter(Boolean);
    return {
        isArray: Array.isArray(items),
        count: list.length,
        missingIds: list.length - ids.length,
        duplicateIds: ids.length - new Set(ids).size,
    };
}

function diagnosticSerializedCharacters(value) {
    try {
        return JSON.stringify(value).length;
    } catch {
        return -1;
    }
}

function diagnosticDuration(start, finish) {
    const startedAt = Date.parse(start || '');
    const finishedAt = Date.parse(finish || '');
    return Number.isFinite(startedAt) && Number.isFinite(finishedAt)
        ? Math.max(0, finishedAt - startedAt)
        : 0;
}

function diagnosticRouteLabel(value, settings = getSettings()) {
    const label = String(value || '').trim();
    if (!label) return '';
    const independentIndex = (settings.apiProfiles || [])
        .findIndex(profile => String(profile?.name || '').trim() === label);
    if (independentIndex >= 0) return `Cấu hình độc lập đã lưu #${independentIndex + 1}`;
    const tavernIndex = listTavernConnectionProfiles()
        .findIndex(profile => String(profile?.name || '').trim() === label);
    if (tavernIndex >= 0) return `Cấu hình kết nối Tavern #${tavernIndex + 1}`;
    return redactDiagnosticText(label);
}

function diagnosticRemoteKind(value) {
    const text = String(value || '').toLocaleLowerCase();
    if (!text) return 'unknown';
    if (text.includes('github.com')) return 'github';
    if (text.startsWith('git@') || text.startsWith('ssh://')) return 'git-ssh';
    if (text.startsWith('http://') || text.startsWith('https://')) return 'git-http';
    return 'git-other';
}

async function refreshInstallationDiagnostics() {
    let folder = 'unknown';
    try {
        folder = new URL('.', import.meta.url).pathname
            .split('/')
            .map(part => decodeURIComponent(part))
            .filter(Boolean)
            .at(-1) || 'unknown';
    } catch {
        // Keep the safe fallback. Full local paths are intentionally never reported.
    }
    const manager = globalThis.worldBackstageUpdateManager;
    const update = typeof manager?.getStatus === 'function' ? manager.getStatus() : null;
    let manifestVersion = '';
    let manifestAvailable = false;
    let manifestErrorType = 'none';
    try {
        const response = await globalThis.fetch?.(new URL('./manifest.json', import.meta.url), {
            cache: 'no-store',
        });
        if (!response?.ok) throw new Error(`manifest HTTP ${Number(response?.status) || 0}`);
        const manifest = await response.json();
        manifestVersion = String(manifest?.version || '').trim().slice(0, 80);
        manifestAvailable = true;
    } catch (error) {
        manifestErrorType = classifyDiagnosticIssue(error?.message || error);
    }
    runtime.installationDiagnostics = {
        folder,
        scope: update ? (update.isGlobal ? 'global' : 'local') : 'unknown',
        manifestAvailable,
        manifestErrorType,
        manifestVersion,
        runtimeVersion: PLUGIN_VERSION,
        versionsAligned: Boolean(manifestVersion && manifestVersion === PLUGIN_VERSION),
        updateManagerAvailable: Boolean(update),
        update: update ? {
            phase: String(update.phase || ''),
            currentVersion: String(update.currentVersion || ''),
            updateAvailable: Boolean(update.updateAvailable),
            lastCheckedAt: Number(update.lastCheckedAt) > 0
                ? new Date(Number(update.lastCheckedAt)).toISOString()
                : '',
            branch: String(update.branch || '').slice(0, 80),
            commitHash: String(update.commitHash || '').slice(0, 12),
            remoteKind: diagnosticRemoteKind(update.remoteUrl),
            errorType: classifyDiagnosticIssue(update.error),
        } : null,
    };
    return runtime.installationDiagnostics;
}

function diagnosticConflictLedger(state) {
    const conflicts = Array.isArray(state?.consistencyConflicts) ? state.consistencyConflicts : [];
    const byResolution = conflicts.reduce((result, conflict) => {
        const key = String(conflict?.resolution || 'unknown');
        result[key] = (result[key] || 0) + 1;
        return result;
    }, {});
    const latestAt = conflicts.reduce((latest, conflict) => (
        Math.max(latest, Number(conflict?.at) || 0)
    ), 0);
    return {
        ledgerEntries: conflicts.length,
        byResolution,
        distinctFields: new Set(conflicts.map(conflict => String(conflict?.field || '')).filter(Boolean)).size,
        linkedToMessages: conflicts.filter(conflict => Number(conflict?.messageId) >= 0).length,
        latestWorldMinute: latestAt,
        entriesAtCurrentWorldMinute: conflicts.filter(conflict => (
            Number(conflict?.at) === Number(state?.clock?.absoluteMinute)
        )).length,
        pendingReconciliation: Boolean(state?.needsReconciliation),
        note: 'consistencyConflicts là sổ cái xử lý xung đột được giữ lại, không đồng nghĩa với lỗi hiện chưa giải quyết.',
    };
}

function diagnosticRequestShape(value) {
    const request = value && typeof value === 'object' ? value : null;
    if (!request) return null;
    return {
        taskKind: String(request.taskKind || ''),
        routeKey: String(request.routeKey || ''),
        routeMode: String(request.routeMode || ''),
        apiSurface: String(request.apiSurface || ''),
        transport: String(request.transport || ''),
        messageCount: Number(request.messageCount) || 0,
        messageCharacters: Number(request.messageCharacters) || 0,
        temperature: Number(request.temperature) || 0,
        stream: Boolean(request.stream),
        requestedMaxTokens: Number(request.requestedMaxTokens) || 0,
        maxTokensSent: Number(request.maxTokensSent) || 0,
        tokenLimitSource: String(request.tokenLimitSource || ''),
        timeoutMs: Number(request.timeoutMs) || 0,
        timeoutLimitSource: String(request.timeoutLimitSource || ''),
        rejectTruncated: Boolean(request.rejectTruncated),
        includePreset: request.includePreset ?? null,
        includeInstruct: request.includeInstruct ?? null,
        includeReasoning: request.includeReasoning ?? null,
        extractData: request.extractData ?? null,
        trimNames: request.trimNames ?? null,
        skipWIAN: request.skipWIAN ?? null,
        removeReasoning: request.removeReasoning ?? null,
        statusVisibility: String(request.statusVisibility || ''),
    };
}

function buildDiagnosticReport() {
    const context = getContext();
    const settings = getSettings();
    const state = getState();
    const store = getStore();
    const connection = getConnectionInfo();
    const recoveryPoints = listRecoveryPoints(store);
    const activeEvents = state.events.filter(event => ['active', 'waiting', 'ready'].includes(event.status));
    const viewport = globalThis.visualViewport;
    const nowMs = Date.now();
    const currentApiTimeline = runtime.apiRequestTimeline
        .filter(item => item.chatToken === currentChatToken());
    const requestStartedAtMs = item => {
        const value = Date.parse(item.startedAt || item.queuedAt || '');
        return Number.isFinite(value) ? value : 0;
    };
    const requestsInWindow = milliseconds => currentApiTimeline.filter(item => (
        requestStartedAtMs(item) > 0
        && nowMs - requestStartedAtMs(item) <= milliseconds
    ));
    const recentFiveMinuteRequests = requestsInWindow(5 * 60 * 1000);
    const recentByTask = recentFiveMinuteRequests.reduce((result, item) => {
        const key = String(item.taskKind || 'unknown');
        result[key] = (result[key] || 0) + 1;
        return result;
    }, {});
    const narrative = latestNarrativeSyncSnapshot();
    const lastOperation = getLastCustomApiOperation();
    const moduleRoutes = ['simulation', 'person-observation', 'history', 'public-opinion']
        .map(taskKind => diagnosticModuleRoute(settings, taskKind));
    const defaultIndependentConfiguration = diagnosticCustomConfiguration(settings);
    const savedIndependentProfiles = (settings.apiProfiles || []).map((profile, index) => {
        const profileSettings = settingsForApiProfile(settings, profile);
        return {
            slot: index + 1,
            configuration: diagnosticCustomConfiguration(profileSettings, 'saved-independent-profile'),
        };
    });
    const activeTaskLabels = activeBackgroundTaskLabels();
    const report = {
        report: {
            schema: 3,
            generatedAt: new Date().toISOString(),
            secretsRedacted: true,
            privacyLevel: 'diagnostic-metadata',
        },
        plugin: {
            name: 'World Backstage',
            version: PLUGIN_VERSION,
            stateSchema: SCHEMA_VERSION,
            settingsSchema: Number(settings.settingsVersion || DEFAULT_SETTINGS.settingsVersion),
            initialized: Boolean(runtime.initialized),
        },
        installation: runtime.installationDiagnostics || {
            folder: 'unknown',
            scope: 'unknown',
            manifestAvailable: false,
            manifestErrorType: 'not-collected',
            manifestVersion: '',
            runtimeVersion: PLUGIN_VERSION,
            versionsAligned: false,
            updateManagerAvailable: false,
            update: null,
        },
        sillyTavern: {
            version: String(
                context?.version
                || globalThis.SillyTavern?.version
                || document.querySelector?.('#version_display')?.textContent
                || 'Không nhận diện được',
            ).trim().slice(0, 120),
            contextAvailable: Boolean(context),
            chatLoaded: hasChatContext(),
            mainApi: String(context?.mainApi || 'unknown').slice(0, 80),
            onlineStatus: String(context?.onlineStatus || '').slice(0, 80),
            capabilities: {
                generateRaw: typeof context?.generateRaw === 'function',
                connectionManagerRequest: typeof context?.ConnectionManagerRequestService?.sendRequest === 'function',
                extensionSettings: Boolean(context?.extensionSettings),
                chatMetadata: Boolean(context?.chatMetadata),
                saveMetadata: typeof context?.saveMetadataDebounced === 'function',
                requestHeaders: typeof context?.getRequestHeaders === 'function',
            },
        },
        device: {
            userAgent: String(globalThis.navigator?.userAgent || 'Không nhận diện được').slice(0, 240),
            viewport: `${Math.round(Number(viewport?.width || globalThis.innerWidth || 0))}x${Math.round(Number(viewport?.height || globalThis.innerHeight || 0))}`,
            touchPoints: Number(globalThis.navigator?.maxTouchPoints || 0),
            online: globalThis.navigator?.onLine !== false,
            pageVisibility: String(globalThis.document?.visibilityState || 'unknown'),
            reducedMotion: Boolean(globalThis.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches),
            capabilities: {
                fetch: typeof globalThis.fetch === 'function',
                abortController: typeof globalThis.AbortController === 'function',
                structuredClone: typeof globalThis.structuredClone === 'function',
                clipboardWrite: typeof globalThis.navigator?.clipboard?.writeText === 'function',
                visualViewport: Boolean(viewport),
            },
        },
        connection: {
            mode: settings.apiMode,
            api: connection.apiLabel,
            source: connection.source,
            model: redactDiagnosticText(connection.model),
            transport: settings.apiMode === 'custom'
                ? settings.customApiTransport
                : settings.apiMode === 'tavern-profile'
                    ? 'tavern-profile'
                    : 'tavern',
            configured: connection.configured,
            method: connection.method,
            internalCompatChars: Number(runtime.lastPromptBridge?.internalCompatChars
                ?? String(INTERNAL_COMPAT_SYSTEM_PROMPT || '').trim().length),
            defaultIndependentConfiguration,
            savedIndependentProfiles,
            savedTavernProfileCount: listTavernConnectionProfiles().length,
            moduleRoutes,
            modelList: {
                phase: runtime.modelPullStatus.phase,
                messageType: classifyDiagnosticIssue(runtime.modelPullStatus.message),
                modelsReceived: runtime.customModels.length,
            },
            imageApi: {
                enabled: Boolean(settings.imageApiEnabled),
                endpoint: diagnosticEndpointShape(settings.imageApiUrl),
                key: diagnosticSecretShape(settings.imageApiKey, 'image-api-settings'),
                modelPresent: Boolean(String(settings.imageApiModel || '').trim()),
                size: String(settings.imageApiSize || ''),
                timeoutMs: Math.max(0, Number(settings.imageApiTimeoutMs) || 0),
            },
        },
        features: {
            pluginEnabled: settings.enabled,
            worldSimulation: settings.worldSimulationEnabled,
            worldAuto: settings.worldAutoEnabled,
            worldContinuityInjection: settings.worldSimulationEnabled,
            worldRevealInjection: settings.worldPromptInjection,
            memorySystem: settings.memorySystemEnabled,
            memoryInjection: settings.memoryPromptInjection,
            simulationMode: settings.autoSimulationMode,
            worldPulseActivity: settings.worldPulseActivity,
            simulationInterval: settings.autoSimulationInterval,
            retryCount: settings.autoRetryCount,
            contextTurns: settings.contextTurns,
            npcBudget: settings.backgroundNpcBudget,
            uiScale: settings.uiScale,
            publicOpinionAuto: settings.publicOpinionAutoEnabled,
            publicOpinionRevealMode: settings.publicOpinionRevealMode,
            apiProfileCount: settings.apiProfiles?.length || 0,
            tavernProfileCount: listTavernConnectionProfiles().length,
            apiModuleRoutes: { ...(settings.apiModuleRoutes || {}) },
            generationMaxTokenCap: settings.maxOutputTokens,
            generationTimeoutMs: settings.generationTimeoutMs,
            generationModuleLimits: clone(settings.generationModuleLimits || {}),
            autoSync: settings.autoSync,
            memoryAutoIndexInterval: settings.memoryAutoIndexInterval,
            enhancedBackgroundSimulation: settings.enhancedBackgroundSimulation,
            pendingSimulationPrompt: settings.pendingSimulationPromptEnabled,
            recordPlayerCharacter: settings.recordPlayerCharacter,
            includeUserInnerVoice: settings.includeUserInnerVoice,
            contextTurnsCustom: settings.customContextTurns,
            timePolicy: settings.timePolicy,
            injectionTimeMode: settings.injectionTimeMode,
            injectionParts: {
                worldBackground: settings.injectionWorldBackground,
                people: settings.injectionPeople,
                events: settings.injectionEvents,
                echoes: settings.injectionEchoes,
                facts: settings.injectionFacts,
                memory: settings.injectionMemory,
                publicOpinion: settings.injectionPublicOpinion,
                social: settings.injectionSocial,
            },
            filters: {
                tagFilterEnabled: settings.tagFilterEnabled,
                tagRuleCount: Array.isArray(settings.tagFilterRules) ? settings.tagFilterRules.length : 0,
                narrativeIncludeTagPresent: Boolean(String(settings.narrativeIncludeTag || '').trim()),
                narrativeRegexFiltersPresent: Boolean(String(settings.narrativeRegexFilters || '').trim()),
            },
        },
        state: {
            revision: state.revision,
            worldMinute: state.clock?.absoluteMinute,
            pendingSync: state.pendingSync,
            people: state.people.length,
            events: state.events.length,
            activeEvents: activeEvents.length,
            echoes: state.echoes.length,
            archive: state.archive.length,
            memoryFacts: state.storyMemory?.facts?.length || 0,
            memorySummaries: state.storyMemory?.summaries?.length || 0,
            memoryClues: state.storyMemory?.clues?.length || 0,
            worldFacts: state.worldFacts?.length || 0,
            publicImpactLedger: state.publicImpactLedger?.length || 0,
            pendingPublicImpacts: pendingPublicImpactEvents(state, { maximum: 96 }).length,
            consistencyConflicts: state.consistencyConflicts?.length || 0,
            needsReconciliation: Boolean(state.needsReconciliation),
            indexedThroughMessageId: state.storyMemory?.indexedThroughMessageId ?? -1,
            chatMessages: context?.chat?.length || 0,
            recoveryPoints: recoveryPoints.length,
            latestSnapshot: Boolean(findLatestResultSnapshot()),
            anchoredClock: Boolean(state.clock?.anchored),
            clockDay: Number(state.clock?.day || 0),
            branchOverrides: Object.keys(store.branchOverrides || {}).length,
            observationRecords: Object.keys(store.personObservations || {}).length,
            memorySummaryArchive: Array.isArray(store.memorySummaryArchive) ? store.memorySummaryArchive.length : 0,
            historyBootstrapCheckpoint: Boolean(store.historyBootstrapCheckpoint),
            serializedCharacters: diagnosticSerializedCharacters(state),
        },
        dataHealth: {
            people: diagnosticEntityHealth(state.people),
            events: diagnosticEntityHealth(state.events),
            echoes: diagnosticEntityHealth(state.echoes),
            archive: diagnosticEntityHealth(state.archive),
            worldFacts: diagnosticEntityHealth(state.worldFacts),
            memoryFacts: diagnosticEntityHealth(state.storyMemory?.facts),
            memorySummaries: diagnosticEntityHealth(state.storyMemory?.summaries),
            memoryClues: diagnosticEntityHealth(state.storyMemory?.clues),
            storeSchema: Number(store.schemaVersion || 0),
            storeSerializedCharacters: diagnosticSerializedCharacters(store),
            manualDeletions: {
                eventIds: store.manualDeletions?.eventIds?.length || 0,
                events: store.manualDeletions?.events?.length || 0,
                people: store.manualDeletions?.people?.length || 0,
                memoryFacts: store.manualDeletions?.memory?.factIds?.length || 0,
                memorySummaries: store.manualDeletions?.memory?.summaryIds?.length || 0,
                memoryClues: store.manualDeletions?.memory?.clueIds?.length || 0,
            },
            consistencyConflictLedger: diagnosticConflictLedger(state),
        },
        settingsPersistence: {
            runtimeAttachedToExtensionSettings: context?.extensionSettings?.[MODULE_ID] === settings,
            saveMethodAvailable: typeof context?.saveSettingsDebounced === 'function',
            saveCompletionObservable: false,
            saveRequestsThisPage: Number(runtime.settingsPersistence?.saveRequests || 0),
            lastSaveRequestedAt: runtime.settingsPersistence?.lastSaveRequestedAt || '',
            lastSaveFields: runtime.settingsPersistence?.lastSaveFields || [],
            uiDrafts: runtime.ui?.getDiagnosticDraftStatus?.() || null,
            note: 'SillyTavern chỉ cung cấp lối lưu có debounce; plugin xác nhận được là đã yêu cầu lưu, nhưng không thể giả mạo thời điểm ghi đĩa hoàn tất.',
        },
        execution: {
            contextEpoch: runtime.contextEpoch,
            dataEpoch: runtime.dataEpoch,
            simulationCount: runtime.simulationCount,
            inBackgroundGeneration: runtime.inBackgroundGeneration,
            consistencyBarrierRunning: runtime.consistencyBarrierRunning,
            activeTasks: activeTaskLabels,
            queuedSimulations: runtime.queuedSimulations.size,
            queuedConnectionLanes: runtime.connectionLanes.size,
            pendingManualSimulation: Boolean(runtime.pendingManualSimulation),
            pendingPublicImpact: Boolean(runtime.pendingPublicImpact),
            pendingPublicOpinion: Boolean(runtime.pendingPublicOpinion),
            narrativeSync: {
                active: Boolean(narrative.active),
                queued: Boolean(narrative.queued),
                status: String(narrative.status || ''),
                committed: Boolean(narrative.committed),
                needsSimulation: Boolean(narrative.needsSimulation),
                pendingTurns: Number(narrative.pendingTurns || 0),
                hasLatest: Boolean(narrative.hasLatest),
            },
            promptInjection: {
                authoritativeCharacters: String(runtime.injection?.text || '').length,
                eventIds: runtime.injection?.eventIds?.length || 0,
                directorNoteIds: runtime.injection?.directorNoteIds?.length || 0,
                bridgeEnabled: Boolean(runtime.lastPromptBridge?.enabled),
                bridgeAvailable: Boolean(runtime.lastPromptBridge?.available),
                bridgePromptCount: Number(runtime.lastPromptBridge?.promptCount || 0),
                bridgeTruncated: Boolean(runtime.lastPromptBridge?.truncated),
            },
            moduleStatus: {
                memory: {
                    kind: runtime.historyProgress.kind,
                    phase: runtime.historyProgress.phase,
                    processed: Number(runtime.historyProgress.processed || 0),
                    total: Number(runtime.historyProgress.total || 0),
                    messageType: classifyDiagnosticIssue(runtime.historyProgress.message),
                },
                publicOpinion: {
                    phase: runtime.publicOpinionStatus.phase,
                    errorType: classifyDiagnosticIssue(runtime.publicOpinionStatus.error),
                    sandboxPhase: runtime.publicOpinionSandboxStatus.phase,
                    sandboxErrorType: classifyDiagnosticIssue(runtime.publicOpinionSandboxStatus.error),
                },
                lingqi: {
                    phase: runtime.lingqiStatus.phase,
                    errorType: classifyDiagnosticIssue(runtime.lingqiStatus.error),
                },
                social: {
                    phase: runtime.socialStatus.phase,
                    errorType: classifyDiagnosticIssue(runtime.socialStatus.error),
                    friendRequestPhase: runtime.friendRequestStatus.phase,
                    momentsPhase: runtime.momentsStatus.phase,
                },
                worldbookScan: {
                    phase: runtime.worldbookScan.phase,
                    entryCount: runtime.worldbookScan.entries?.length || 0,
                },
            },
        },
        lastWorldTask: {
            phase: runtime.syncStatus.phase,
            messageType: runtime.syncStatus.phase === 'success'
                ? 'success'
                : classifyDiagnosticIssue(runtime.syncStatus.message),
            errorType: classifyDiagnosticIssue(runtime.syncStatus.error),
            attemptedAt: runtime.syncStatus.attemptedAt,
            succeededAt: runtime.syncStatus.succeededAt,
            method: runtime.syncStatus.method,
            route: diagnosticRouteLabel(runtime.lastTaskConnection?.apiLabel || '', settings),
            model: redactDiagnosticText(runtime.lastTaskConnection?.model || ''),
            taskKind: runtime.lastTaskConnection?.taskKind || '',
            requestedMaxTokens: runtime.lastTaskConnection?.requestedMaxTokens || 0,
            effectiveMaxTokens: runtime.lastTaskConnection?.maxTokens || 0,
            tokenLimitSource: runtime.lastTaskConnection?.tokenLimitSource || '',
            timeoutMs: runtime.lastTaskConnection?.timeoutMs || 0,
            timeoutLimitSource: runtime.lastTaskConnection?.timeoutLimitSource || '',
            memoryPhase: runtime.historyProgress.phase,
            memoryMessageType: classifyDiagnosticIssue(runtime.historyProgress.message),
            request: diagnosticRequestShape(runtime.lastTaskTrace?.request || runtime.lastRequestShape),
            pipeline: runtime.lastTaskTrace ? {
                taskKind: runtime.lastTaskTrace.taskKind,
                phase: runtime.lastTaskTrace.phase,
                stage: runtime.lastTaskTrace.stage,
                attempt: runtime.lastTaskTrace.attempt,
                responseOutcome: runtime.lastTaskTrace.responseOutcome,
                parseOutcome: runtime.lastTaskTrace.parseOutcome,
                validationOutcome: runtime.lastTaskTrace.validationOutcome,
                commitOutcome: runtime.lastTaskTrace.commitOutcome,
                responseCharacters: runtime.lastTaskTrace.responseCharacters,
                errorType: runtime.lastTaskTrace.errorType,
                errorSummary: redactDiagnosticText(runtime.lastTaskTrace.errorSummary || ''),
                attemptedAt: runtime.lastTaskTrace.attemptedAt,
                responseAt: runtime.lastTaskTrace.responseAt,
                parsedAt: runtime.lastTaskTrace.parsedAt,
                committedAt: runtime.lastTaskTrace.committedAt,
                finishedAt: runtime.lastTaskTrace.finishedAt,
                timingsMs: {
                    request: diagnosticDuration(runtime.lastTaskTrace.attemptedAt, runtime.lastTaskTrace.responseAt),
                    parse: diagnosticDuration(runtime.lastTaskTrace.responseAt, runtime.lastTaskTrace.parsedAt),
                    validate: diagnosticDuration(runtime.lastTaskTrace.parsedAt, runtime.lastTaskTrace.committedAt),
                    total: diagnosticDuration(runtime.lastTaskTrace.attemptedAt, runtime.lastTaskTrace.finishedAt),
                },
                attemptHistory: (runtime.lastTaskTrace.attemptHistory || []).map(item => ({
                    ...item,
                    errorSummary: redactDiagnosticText(item.errorSummary || ''),
                })),
            } : null,
        },
        retryControl: getRetryControlStatus(),
        apiCadence: {
            last60Seconds: requestsInWindow(60 * 1000).length,
            last5Minutes: recentFiveMinuteRequests.length,
            byTaskLast5Minutes: recentByTask,
            queuedPhysicalRoutes: runtime.connectionLanes.size,
            retainedTimelineEntries: currentApiTimeline.length,
            successesLast5Minutes: recentFiveMinuteRequests.filter(item => item.outcome === 'success').length,
            errorsLast5Minutes: recentFiveMinuteRequests.filter(item => item.outcome === 'error').length,
            timeoutsLast5Minutes: recentFiveMinuteRequests.filter(item => item.outcome === 'timeout').length,
            cancellationsLast5Minutes: recentFiveMinuteRequests.filter(item => item.outcome === 'cancelled').length,
        },
        recentApiRequests: runtime.apiRequestTimeline
            .filter(item => item.chatToken === currentChatToken())
            .slice(-20)
            .map(item => ({
            taskKind: item.taskKind,
            route: diagnosticRouteLabel(item.route || '', settings),
            model: redactDiagnosticText(item.model || ''),
            queuedAt: item.queuedAt,
            startedAt: item.startedAt,
            finishedAt: item.finishedAt,
            waitMs: item.waitMs,
            durationMs: item.durationMs,
            outcome: item.outcome,
            outcomeScope: 'response',
            connectionLane: String(item.lane || '').split(':')[0],
            errorType: item.errorType,
            transportStatus: item.transportStatus,
            upstreamStatus: item.upstreamStatus,
            retryAfterMs: item.retryAfterMs,
            request: diagnosticRequestShape(item.request),
        })),
        lastApiOperation: (() => {
            const operation = lastOperation;
            if (!operation) return null;
            return {
                phase: operation.phase,
                operation: operation.operation,
                source: operation.source,
                route: diagnosticRouteLabel(operation.route || '', settings),
                model: redactDiagnosticText(operation.model || ''),
                transport: operation.transport,
                transportStatus: operation.transportStatus,
                upstreamStatus: operation.upstreamStatus,
                retryAfterMs: Number(operation.retryAfterMs) || 0,
                errorType: operation.errorType,
                errorSummary: redactDiagnosticText(operation.errorSummary || ''),
                missingField: operation.missingField || '',
                request: operation.request ? {
                    endpointKind: operation.request.endpointKind,
                    method: operation.request.method,
                    timeoutMs: Number(operation.request.timeoutMs) || 0,
                    apiUrlPresent: Boolean(operation.request.apiUrlPresent),
                    apiKeyPresent: Boolean(operation.request.apiKeyPresent),
                    modelPresent: Boolean(operation.request.modelPresent),
                    messageCount: Number(operation.request.messageCount) || 0,
                    messageCharacters: Number(operation.request.messageCharacters) || 0,
                    maxTokensSent: Number(operation.request.maxTokensSent) || 0,
                    temperature: Number(operation.request.temperature) || 0,
                    stream: Boolean(operation.request.stream),
                    deepSeekV4Compatibility: Boolean(operation.request.deepSeekV4Compatibility),
                } : null,
                attemptedAt: operation.attemptedAt,
                succeededAt: operation.succeededAt,
                failedAt: operation.failedAt,
                durationMs: diagnosticDuration(
                    operation.attemptedAt,
                    operation.succeededAt || operation.failedAt,
                ),
            };
        })(),
        privacy: {
            summary: 'Không bao gồm API Key, địa chỉ API, chính văn chat, điểm neo danh tính nhân vật hay prompt tùy chỉnh.',
            omitted: [
                'API keys and authorization headers',
                'API hosts and full endpoint URLs',
                'chat and generated response text',
                'character names and identity anchors',
                'custom prompts and filter contents',
                'profile names and identifiers',
            ],
            retainedOnlyAsMetadata: [
                'secret presence and length range',
                'endpoint validity and path shape',
                'message counts and character counts',
                'prompt lengths and state counts',
            ],
        },
    };
    return `Thông tin chẩn đoán 世界背面 (có thể chia sẻ an toàn)\n${JSON.stringify(report, null, 2)}`;
}

async function copyDiagnosticReport() {
    await refreshInstallationDiagnostics();
    const report = buildDiagnosticReport();
    try {
        if (typeof globalThis.navigator?.clipboard?.writeText !== 'function') {
            throw new Error('Clipboard API unavailable');
        }
        await globalThis.navigator.clipboard.writeText(report);
    } catch {
        const textarea = document.createElement('textarea');
        textarea.value = report;
        textarea.setAttribute('readonly', '');
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        const copied = document.execCommand?.('copy');
        textarea.remove();
        if (!copied) throw new Error('Trình duyệt không cho phép sao chép, hãy kiểm tra quyền clipboard');
    }
    toast('Đã sao chép thông tin chẩn đoán, nội dung nhạy cảm không được đưa vào.', 'success');
    return report;
}

function exportState() {
    const payload = {
        format: 'world-backstage-state',
        version: SCHEMA_VERSION,
        exportedAt: new Date().toISOString(),
        state: getState(),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeWorldName = String(getState().world.name || 'Thế giới')
        .replace(/[\\/:*?"<>|]+/g, '_')
        .slice(0, 60);
    link.href = url;
    link.download = `世界背面_${safeWorldName}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    toast('Đã xuất trạng thái thế giới hiện tại.', 'success');
}

function importState(text) {
    const parsed = JSON.parse(String(text || ''));
    const imported = trimState(parsed?.state || parsed);
    const confirmed = globalThis.confirm?.(
        `(・_・;)  Nhập sẽ thay thế trạng thái thế giới hiện tại của cuộc trò chuyện này.\n\nNhập: ${imported.world.name}`,
    );
    if (confirmed === false) return;

    let store = addRecoveryPoint(getStore(), {
        reason: 'before-import',
        label: 'Tự động lưu trước khi nhập trạng thái thế giới',
    });
    const previousState = clone(store.currentState);
    const previousInitialState = clone(store.initialState);
    const key = currentAnchorKey();
    store.currentState = imported;
    if (!findLatestResultSnapshot()) store.initialState = clone(imported);
    store.branchOverrides[key] = createBranchSnapshot(imported, {
        sourceKey: key,
        kind: 'import',
    });
    saveStore(store, { immediate: true });
    refreshInjection();
    runtime.ui?.render();
    armManualUndo(previousState, {
        key,
        label: 'Hoàn tác nhập trạng thái',
        previousInitialState,
    });
    toast('Trạng thái thế giới đã dọn vào rồi～mọi thứ đều ở đúng chỗ.', 'success');
}

function saveApiProfile(payload = {}) {
    const context = getContext();
    const settings = getSettings();
    const id = String(payload.id || '').trim() || makeApiProfileId();
    const existing = settings.apiProfiles.find(item => item.id === id);
    const name = String(payload.name || existing?.name || 'API độc lập của tôi').trim().slice(0, 80) || 'API độc lập của tôi';
    const url = String(payload.url || payload.customApiUrl || existing?.url || '').trim().slice(0, 500);
    const replacementKey = String(payload.key || payload.customApiKey || '').trim();
    const key = (replacementKey || existing?.key || '').slice(0, 1000);
    const model = String(payload.model || payload.customApiModel || existing?.model || '').trim().slice(0, 180);
    const transportValue = payload.transport || payload.customApiTransport || existing?.transport || 'proxy';
    const transport = ['proxy', 'direct'].includes(transportValue) ? transportValue : 'proxy';
    if (!url) throw new Error('Điền địa chỉ API trước đã nhé～');
    if (!key) throw new Error('Cấu hình này còn thiếu API Key nè');
    if (!model) throw new Error('Chưa chọn model nè～');
    const profile = { id, name, url, key, model, transport };
    const next = settings.apiProfiles.filter(item => item.id !== id);
    next.push(profile);
    settings.apiProfiles = normalizeApiProfiles(next);
    settings.apiModuleRoutes = normalizeApiModuleRoutes(settings.apiModuleRoutes, settings.apiProfiles);
    context.extensionSettings[MODULE_ID] = settings;
    saveSettings();
    runtime.ui?.render();
    toast(`“${name}” đã được cất ngoan ngoãn rồi～`, 'success');
    return { ...profile, key: '' };
}

function deleteApiProfile(profileId) {
    const context = getContext();
    const settings = getSettings();
    const id = String(profileId || '').trim();
    const existing = settings.apiProfiles.find(item => item.id === id);
    if (!existing) throw new Error('Không tìm thấy cấu hình API này');
    settings.apiProfiles = settings.apiProfiles.filter(item => item.id !== id);
    settings.apiModuleRoutes = normalizeApiModuleRoutes(settings.apiModuleRoutes, settings.apiProfiles);
    context.extensionSettings[MODULE_ID] = settings;
    saveSettings();
    runtime.ui?.render();
    toast(`“${existing.name}” đã xóa rồi nha～`, 'success');
    return true;
}

function duplicateApiProfile(profileId) {
    const settings = getSettings();
    const existing = settings.apiProfiles.find(item => item.id === String(profileId || ''));
    if (!existing) throw new Error('Không tìm thấy cấu hình API này');
    return saveApiProfile({
        ...existing,
        id: '',
        name: `${existing.name} · bản sao`.slice(0, 80),
    });
}

function profileRequestSettings(profileId) {
    const settings = getSettings();
    const profile = settings.apiProfiles.find(item => item.id === String(profileId || ''));
    if (!profile) throw new Error('Không tìm thấy cấu hình API này');
    return { settings, profile, requestSettings: settingsForApiProfile(settings, profile) };
}

async function testApiProfileConnection(profileId) {
    const { profile, requestSettings } = profileRequestSettings(profileId);
    const context = getContext();
    setBusy(true);
    try {
        const reply = await requestCustomCompletion(requestSettings, buildBackstageMessages('Đây là kiểm tra kết nối. Chỉ trả lời: Kết nối thành công'), {
            fetchImpl: globalThis.fetch.bind(globalThis),
            getRequestHeaders: () => context?.getRequestHeaders?.() || {},
            maxTokens: 80,
            temperature: 0,
            operation: 'connection-test',
            routeLabel: profile.name || 'Cấu hình đã lưu',
        });
        if (!String(reply || '').trim()) throw new Error('API không trả về nội dung');
        toast(`“${profile.name}” kết nối thành công rồi～`, 'success');
        return true;
    } finally {
        setBusy(false);
    }
}

async function pullApiProfileModels(profileId) {
    const { profile, requestSettings } = profileRequestSettings(profileId);
    runtime.modelPullStatus = { phase: 'running', message: `Đang đọc danh sách model của “${profile.name}”` };
    runtime.ui?.render();
    try {
        const context = getContext();
        const models = await requestCustomModels(requestSettings, {
            fetchImpl: globalThis.fetch.bind(globalThis),
            getRequestHeaders: () => context?.getRequestHeaders?.() || {},
            routeLabel: profile.name || 'Cấu hình đã lưu',
        });
        runtime.customModels = models;
        runtime.modelPullStatus = {
            phase: 'success',
            message: `Tìm thấy ${models.length} model rồi～vẫn có thể điền thủ công nhé`,
        };
        return models;
    } catch (error) {
        runtime.modelPullStatus = { phase: 'error', message: describeError(error) };
        throw error;
    } finally {
        runtime.ui?.render();
    }
}

function settingsFromApiDraft(payload = {}, { requireModel = true } = {}) {
    const base = getSettings();
    const url = String(payload.url || payload.customApiUrl || '').trim().slice(0, 500);
    const key = String(payload.key || payload.customApiKey || '').trim().slice(0, 1000);
    const model = String(payload.model || payload.customApiModel || '').trim().slice(0, 180);
    const transport = ['proxy', 'direct'].includes(payload.transport || payload.customApiTransport)
        ? (payload.transport || payload.customApiTransport)
        : 'proxy';
    if (!url) throw new Error('Còn chưa điền địa chỉ API mà～');
    if (!key) throw new Error('Còn thiếu API Key nè～');
    if (requireModel && !model) throw new Error('Chưa chọn model nè～');
    return {
        ...base,
        apiMode: 'custom',
        customApiUrl: url,
        customApiKey: key,
        customApiModel: model,
        customApiTransport: transport,
    };
}

async function testApiDraftConnection(payload = {}) {
    const requestSettings = settingsFromApiDraft(payload, { requireModel: true });
    const context = getContext();
    setBusy(true);
    try {
        const reply = await requestCustomCompletion(requestSettings, buildBackstageMessages('Đây là kiểm tra kết nối. Chỉ trả lời: Kết nối thành công'), {
            fetchImpl: globalThis.fetch.bind(globalThis),
            getRequestHeaders: () => context?.getRequestHeaders?.() || {},
            maxTokens: 80,
            temperature: 0,
            operation: 'connection-test',
            routeLabel: String(payload.label || 'API độc lập tạm thời').slice(0, 80),
        });
        if (!String(reply || '').trim()) throw new Error('API không trả về nội dung');
        toast(`${String(payload.label || 'API này').slice(0, 80)} kết nối thành công rồi～`, 'success');
        return true;
    } finally {
        setBusy(false);
    }
}

async function pullApiDraftModels(payload = {}) {
    const requestSettings = settingsFromApiDraft(payload, { requireModel: false });
    const label = String(payload.label || 'API này').slice(0, 80);
    runtime.modelPullStatus = { phase: 'running', message: `Đang lật danh sách model của${label}～` };
    runtime.ui?.render();
    try {
        const context = getContext();
        const models = await requestCustomModels(requestSettings, {
            fetchImpl: globalThis.fetch.bind(globalThis),
            getRequestHeaders: () => context?.getRequestHeaders?.() || {},
            routeLabel: label,
        });
        runtime.customModels = models;
        runtime.modelPullStatus = {
            phase: 'success',
            message: `Tìm thấy ${models.length} model rồi～sẽ không thay đổi API mặc định`,
        };
        toast(`Tìm thấy ${models.length} model dùng được rồi nè～`, 'success');
        return models;
    } catch (error) {
        runtime.modelPullStatus = { phase: 'error', message: describeError(error) };
        throw error;
    } finally {
        runtime.ui?.render();
    }
}

async function testCustomApiConnection() {
    const settings = getSettings();
    if (settings.apiMode !== 'custom') {
        throw new Error('Hãy chuyển kết nối suy diễn thế giới sang “API độc lập” trước');
    }
    setBusy(true);
    setSyncStatus({
        phase: 'running',
        message: 'Đang chọc thử API độc lập, xem nó có tỉnh không～',
        error: '',
        attemptedAt: new Date().toISOString(),
    });
    try {
        const context = getContext();
        runtime.syncStatus.method = settings.customApiTransport === 'direct'
            ? 'API độc lập mặc định · Trình duyệt kết nối trực tiếp'
            : 'API độc lập mặc định · Tavern chuyển tiếp';
        const reply = await requestCustomCompletion(
            settings,
            buildBackstageMessages('Đây là kiểm tra kết nối. Chỉ trả lời: Kết nối thành công'),
            {
                fetchImpl: globalThis.fetch.bind(globalThis),
                getRequestHeaders: () => context?.getRequestHeaders?.() || {},
                maxTokens: 80,
                temperature: 0,
                operation: 'connection-test',
                routeLabel: 'API độc lập mặc định',
            },
        );
        if (!String(reply || '').trim()) throw new Error('API không trả về nội dung');
        setSyncStatus({
            phase: 'success',
            message: 'API độc lập kết nối thành công rồi～',
            error: '',
            succeededAt: new Date().toISOString(),
            method: runtime.syncStatus.method,
        });
        toast('API độc lập thông rồi～có thể bắt tay vào việc `(•̀ᴗ•́)و`', 'success');
        return true;
    } catch (error) {
        const errorMessage = describeError(error);
        setSyncStatus({
            phase: 'error',
            message: 'API độc lập chưa kết nối được QAQ',
            error: errorMessage,
            method: runtime.syncStatus.method,
        });
        throw error;
    } finally {
        setBusy(false);
    }
}

async function pullCustomApiModels() {
    const settings = getSettings();
    if (settings.apiMode !== 'custom') {
        throw new Error('Hãy chuyển kết nối suy diễn thế giới sang “API độc lập” trước');
    }
    runtime.modelPullStatus = { phase: 'running', message: 'Đang lật danh sách model～' };
    runtime.ui?.render();
    try {
        const context = getContext();
        const models = await requestCustomModels(settings, {
            fetchImpl: globalThis.fetch.bind(globalThis),
            getRequestHeaders: () => context?.getRequestHeaders?.() || {},
            routeLabel: 'API độc lập mặc định',
        });
        runtime.customModels = models;
        runtime.modelPullStatus = {
            phase: 'success',
            message: `Tìm thấy ${models.length} model rồi～vẫn có thể điền thủ công`,
        };
        toast(`Tìm thấy ${models.length} model dùng được rồi nè～`, 'success');
        return models;
    } catch (error) {
        runtime.modelPullStatus = {
            phase: 'error',
            message: describeError(error),
        };
        throw error;
    } finally {
        runtime.ui?.render();
    }
}

async function runOneMemoryRollup(state, controller) {
    const plan = planMemoryRollup(state);
    if (!plan) return { state, rolledUp: false };
    if (controller?.signal?.aborted) {
        const error = new Error('Đã dừng sắp xếp ký ức');
        error.name = 'AbortError';
        throw error;
    }
    runtime.historyProgress = {
        ...runtime.historyProgress,
        phase: 'running',
        message: `Đang nén ${plan.sourceSummaryIds.length} mục L${plan.sourceLevel} ký ức thành L${plan.targetLevel}～`,
    };
    runtime.ui?.render();
    const payload = await runWithRetries(async attempt => {
        const prompt = buildMemoryRollupPrompt(state, plan, { compact: attempt > 0 });
        const raw = await backgroundSimulation(retryJsonPrompt(prompt, attempt), {
            maxTokens: retryTokenBudget(2400, attempt),
            temperature: attempt > 0 ? 0.03 : 0.08,
            signal: controller?.signal,
            taskKind: 'history',
        });
        const parsed = extractJsonObject(raw);
        if (parsed) return parsed;
        throw unreadableJsonError(raw, 'Model nén ký ức');
    }, {
        retries: getSettings().autoRetryCount,
        shouldRetry: error => !(
            /请先填写独立 API|HTTP 40[0134]|没有提供安静生成接口|hãy điền.{0,40}API độc lập|chưa điền.{0,40}API độc lập|không (?:cung cấp|có|hỗ trợ).{0,30}(?:quiet|tạo ngầm|tạo im lặng|tạo yên lặng)|sinh yên lặng/i
                .test(describeError(error))
        ),
        onRetry: ({ attempt, total, delayMs, rateLimited }) => {
            runtime.historyProgress.message = rateLimited
                ? `Tuyến lịch sử bị giới hạn tốc độ rồi～chờ hồi ${cooldownSeconds(delayMs)} giây nữa sẽ chỉ tiếp tục đúng phần nén ký ức này`
                : `Nén ký ức chưa ổn, đang thử lại với định dạng gọn hơn ${attempt}/${total}`;
            runtime.ui?.render();
        },
        ...retryTaskOptions(
            'history',
            `history-rollup:${currentChatToken()}:${plan.sourceSummaryIds.join(',')}:${plan.targetLevel}`,
            {
                onCooldown: ({ delayMs }) => {
                    runtime.historyProgress.message = `API lịch sử đang chờ hồi～còn khoảng ${cooldownSeconds(delayMs)} giây, sẽ không mở tác vụ trùng lặp`;
                    runtime.ui?.render();
                },
            },
        ),
        signal: controller?.signal,
    });
    if (controller?.signal?.aborted) {
        const error = new Error('Đã dừng sắp xếp ký ức');
        error.name = 'AbortError';
        throw error;
    }
    return {
        state: applyMemoryRollupResult(state, payload, plan),
        rolledUp: true,
    };
}



async function runPublicImpactPropagation({
    quiet = false,
    force = false,
    maximumEvents = 8,
    scheduleOpinion = true,
} = {}) {
    const settings = getSettings();
    if (
        !settings.enabled
        || !settings.worldSimulationEnabled
        || (!force && !settings.worldAutoEnabled)
    ) return false;

    if (runtime.activePublicImpact?.promise) {
        return runtime.activePublicImpact.promise;
    }
    if (
        runtime.activeSimulation
        || runtime.activeWorldPulse
        || runtime.activeHistoryScan
        || runtime.activePublicOpinion
        || runtime.queuedSimulations.size > 0
    ) return false;

    const baseState = getState();
    const baseRevision = Math.max(0, Number(baseState?.revision) || 0);
    const sourceEvents = pendingPublicImpactEvents(baseState, { maximum: maximumEvents });
    if (!sourceEvents.length) return false;

    const chatToken = currentChatToken();
    const contextEpochAtStart = runtime.contextEpoch;
    const controller = new AbortController();
    const active = {
        controller,
        chatToken,
        sourceEventIds: sourceEvents.map(event => event.id),
        promise: null,
    };
    runtime.activePublicImpact = active;
    runtime.pendingPublicImpact = false;

    active.promise = (async () => {
        setBusy(true);
        if (!quiet) {
            setSyncStatus({
                phase: 'running',
                message: 'Sự kiện công cộng đang lan ảnh hưởng ra ngoài theo ngành nghề, tổ chức và quan hệ nhân vật～',
                error: '',
            });
        }
        try {
            const prompt = buildPublicImpactPrompt(baseState, {
                sourceEventIds: active.sourceEventIds,
                userName: getContext()?.name1 || '',
                maximumEvents,
                recordPlayerCharacter: settings.recordPlayerCharacter,
            });
            const baseMaxTokens = 3400;

            const payload = await runWithRetries(async attempt => {
                const raw = await backgroundSimulation(retryJsonPrompt(prompt, attempt), {
                    maxTokens: retryTokenBudget(baseMaxTokens, attempt),
                    temperature: attempt > 0 ? 0.04 : 0.12,
                    signal: controller.signal,
                    taskKind: 'public-impact',
                });
                const parsed = extractJsonObject(raw);
                if (parsed) return parsed;
                throw unreadableJsonError(raw, 'Model ảnh hưởng sự kiện công cộng');
            }, {
                retries: settings.autoRetryCount,
                shouldRetry: error => !(
                    /请先填写独立 API|HTTP 40[0134]|没有提供安静生成接口|hãy điền.{0,40}API độc lập|chưa điền.{0,40}API độc lập|không (?:cung cấp|có|hỗ trợ).{0,30}(?:quiet|tạo ngầm|tạo im lặng|tạo yên lặng)|sinh yên lặng/i
                        .test(describeError(error))
                ),
                onRetry: ({ delayMs, rateLimited }) => {
                    if (!quiet && rateLimited) {
                        setSyncStatus({
                            phase: 'running',
                            message: `Ảnh hưởng sự kiện công cộng gặp giới hạn tốc độ～chờ hồi ${cooldownSeconds(delayMs)} giây`,
                            error: 'Tác vụ ảnh hưởng hiện tại giữ một phiên duy nhất, sẽ không tạo trùng lặp.',
                        });
                    }
                },
                ...retryTaskOptions(
                    'public-impact',
                    `public-impact:${chatToken}:${active.sourceEventIds.join(',')}`,
                ),
                signal: controller.signal,
            });

            if (controller.signal.aborted || currentChatToken() !== chatToken) return false;
            if (
                runtime.contextEpoch !== contextEpochAtStart
                || Math.max(0, Number(getState()?.revision) || 0) !== baseRevision
            ) {
                runtime.pendingPublicImpact = true;
                if (!quiet) {
                    setSyncStatus({
                        phase: 'pending',
                        message: 'Trạng thái thế giới đã thay đổi trong lúc sinh ảnh hưởng sự kiện công cộng, kết quả cũ chưa được áp dụng',
                        error: '',
                    });
                }
                return false;
            }

            let next = applyPublicImpactResult(baseState, payload, {
                sourceEventIds: active.sourceEventIds,
                userName: getContext()?.name1 || '',
                sourceKey: `public-impact:${active.sourceEventIds.join(',')}:${Date.now()}`,
                backgroundNpcBudget: settings.backgroundNpcBudget,
                recordPlayerCharacter: settings.recordPlayerCharacter,
            });

            const store = getStore();
            const anchorKey = baseState.lastCommit?.sourceKey || 'root';
            store.currentState = ensureMonotonicRevision(next, store.currentState);
            next = store.currentState;
            store.branchOverrides[anchorKey] = createBranchSnapshot(next, {
                sourceKey: anchorKey,
                kind: 'public-impact',
            });
            saveStore(store, { immediate: true });
            refreshInjection();
            runtime.ui?.render();
            if (scheduleOpinion) scheduleAutoPublicOpinion(next, 180);

            if (!quiet) {
                setSyncStatus({
                    phase: 'success',
                    message: 'Hệ quả thế giới của sự kiện công cộng đã được nối vào nền rồi～',
                    error: '',
                    succeededAt: new Date().toISOString(),
                });
            }
            return true;
        } catch (error) {
            if (isAbortError(error) || controller.signal.aborted) return false;
            if (!quiet) {
                setSyncStatus({
                    phase: 'error',
                    message: 'Lần này ảnh hưởng sự kiện công cộng chưa kết toán xong～thế giới vẫn dùng trạng thái đã xác nhận gần nhất',
                    error: describeError(error),
                });
            }
            throw error;
        } finally {
            setBusy(false);
        }
    })();

    try {
        return await active.promise;
    } finally {
        if (runtime.activePublicImpact === active) runtime.activePublicImpact = null;
        if (runtime.pendingPublicImpact && currentChatToken() === active.chatToken) {
            scheduleDeferredPublicImpact(140, active.chatToken);
        }
        window.setTimeout(schedulePendingCatchUp, 40);
    }
}

function setPersonLifePriority(personId, enabled = true) {
    const id = String(personId || '').trim();
    if (!id) throw new Error('Không tìm thấy nhân vật này');
    const next = clone(getState());
    const person = next.people.find(item => item.id === id);
    if (!person) throw new Error('Không tìm thấy nhân vật này');
    if (person.isUser) throw new Error('Nhân vật của người chơi không dùng kết toán đời sống nhân vật nền');
    if (person.simulationEnabled === false) {
        throw new Error('Suy diễn ngoài ống kính của nhân vật này đã tắt; hãy bật “Tham gia suy diễn ngoài ống kính” trong thẻ nhân vật trước');
    }
    person.lifeTickPriority = Boolean(enabled);
    person.lifeTickPriorityAt = enabled ? Number(next.clock?.absoluteMinute || 0) : 0;
    commitManualState(
        next,
        enabled
            ? `${person.name} đã được xếp lên trước lượt kết toán nhân vật nền tiếp theo rồi～`
            : `${person.name} đã bỏ ưu tiên ở lượt tiếp theo.`,
    );
    return {
        personId: person.id,
        enabled: person.lifeTickPriority,
    };
}

async function runPersonLifeCatchUp(personId) {
    const id = String(personId || '').trim();
    if (!id) throw new Error('Không tìm thấy nhân vật này');
    const settings = getSettings();
    if (!settings.enabled || !settings.worldSimulationEnabled) {
        throw new Error('Suy diễn thế giới đang tắt, phải bật lên trước mới bù được tình hình nhân vật');
    }
    if (coreSimulationBusy()) {
        throw new Error('Hiện vẫn còn suy diễn thế giới hoặc kết toán nền đang chạy, đợi lượt này xong rồi hẵng bù tình hình của cô ấy');
    }
    const person = getState().people.find(item => item.id === id);
    if (!person) throw new Error('Không tìm thấy nhân vật này');
    if (person.isUser) throw new Error('Nhân vật của người chơi không dùng kết toán đời sống nhân vật nền');
    if (person.simulationEnabled === false) {
        throw new Error('Suy diễn ngoài ống kính của nhân vật này đã tắt; hãy bật “Tham gia suy diễn ngoài ống kính” trong thẻ nhân vật trước');
    }
    setBusy(true);
    try {
        const completed = await runWorldPulseTick({
            reason: `Bù suy diễn nhân vật thủ công: ${person.name}`,
            quiet: false,
            force: true,
            publicCycle: false,
            personTargetId: person.id,
        });
        if (!completed) throw new Error('Lần bù suy diễn nhân vật này chưa hoàn tất, trạng thái cũ giữ nguyên');
        return true;
    } finally {
        setBusy(false);
    }
}

async function runWorldPulseTick({
    reason = 'Thời gian thế giới chính đã được đẩy tới',
    quiet = false,
    force = false,
    publicCycle = false,
    personTargetId = '',
} = {}) {
    const settings = getSettings();
    const requestedPersonTargetId = String(personTargetId || '').trim();
    const requestedPersonTarget = requestedPersonTargetId
        ? getState().people.find(item => item.id === requestedPersonTargetId) || null
        : null;
    const manualPersonCatchUp = Boolean(requestedPersonTargetId);
    if (manualPersonCatchUp) {
        if (!requestedPersonTarget) throw new Error('Không tìm thấy nhân vật này');
        if (requestedPersonTarget.isUser) throw new Error('Nhân vật của người chơi không dùng kết toán đời sống nhân vật nền');
        if (requestedPersonTarget.simulationEnabled === false) {
            throw new Error('Suy diễn ngoài ống kính của nhân vật này đã tắt');
        }
    }
    if (
        !settings.enabled
        || !settings.worldSimulationEnabled
        || (!force && !settings.worldAutoEnabled)
        || runtime.activeSimulation
        || runtime.activePublicImpact
        || runtime.activeWorldPulse
        || runtime.activeHistoryScan
        || runtime.queuedSimulations.size > 0
    ) return false;

    const chatToken = currentChatToken();
    const contextEpochAtStart = runtime.contextEpoch;
    const controller = new AbortController();
    runtime.activeWorldPulse = { controller, chatToken };
    if (!quiet) {
        setSyncStatus({
            phase: 'running',
            message: manualPersonCatchUp
                ? `Mình đi cập nhật cho ${requestedPersonTarget.name} tình hình thời gian qua～`
                : 'Nhịp đập thế giới đang kiểm tra các thay đổi ngoài ống kính～',
            error: '',
        });
    }
    try {
        const state = getState();
        const baseRevision = Math.max(0, Number(state?.revision) || 0);
        const effectiveBackgroundNpcBudget = manualPersonCatchUp ? 1 : settings.backgroundNpcBudget;
        const backgroundPersonTargets = manualPersonCatchUp
            ? [{
                id: requestedPersonTarget.id,
                name: requestedPersonTarget.name,
                overdueMinutes: Math.max(0, Number(state.clock?.absoluteMinute || 0) - Number(requestedPersonTarget.lastLifeTickAt ?? requestedPersonTarget.updatedAt ?? state.clock?.absoluteMinute ?? 0)),
                priorityReason: 'manual-now',
            }]
            : listDueBackgroundPeople(state, {
                maximum: settings.backgroundNpcBudget,
                requiredOnly: !settings.enhancedBackgroundSimulation,
            });
        const worldCoverageTargets = manualPersonCatchUp
            ? []
            : selectWorldCoverageTargets(state, {
                customInstruction: settings.customSimulationInstruction,
                maximum: settings.worldPulseActivity === 'busy' ? 3 : 2,
            });
        const prompt = buildWorldPulsePrompt(state, {
            activity: manualPersonCatchUp ? 'quiet' : settings.worldPulseActivity,
            reason,
            backgroundNpcBudget: effectiveBackgroundNpcBudget,
            publicCycle: manualPersonCatchUp ? false : publicCycle,
            customInstruction: manualPersonCatchUp ? '' : settings.customSimulationInstruction,
            enhancedBackgroundSimulation: manualPersonCatchUp ? false : settings.enhancedBackgroundSimulation,
            backgroundPersonTargets,
            worldCoverageTargets,
            recordPlayerCharacter: settings.recordPlayerCharacter,
        });
        const baseMaxTokens = manualPersonCatchUp
            ? 2400
            : settings.worldPulseActivity === 'busy'
                ? 3800
                : settings.worldPulseActivity === 'quiet'
                    ? 2200
                    : 3000;
        const payload = await runWithRetries(async attempt => {
            const raw = await backgroundSimulation(retryJsonPrompt(prompt, attempt), {
                maxTokens: retryTokenBudget(baseMaxTokens, attempt),
                temperature: attempt > 0 ? 0.05 : 0.16,
                signal: controller.signal,
                taskKind: 'simulation',
            });
            const parsed = extractJsonObject(raw);
            if (parsed) return parsed;
            throw unreadableJsonError(raw, 'Model nhịp đập thế giới');
        }, {
            retries: settings.autoRetryCount,
            shouldRetry: error => !(
                /请先填写独立 API|HTTP 40[0134]|没有提供安静生成接口|hãy điền.{0,40}API độc lập|chưa điền.{0,40}API độc lập|không (?:cung cấp|có|hỗ trợ).{0,30}(?:quiet|tạo ngầm|tạo im lặng|tạo yên lặng)|sinh yên lặng/i
                    .test(describeError(error))
            ),
            onRetry: ({ delayMs, rateLimited }) => {
                if (!quiet && rateLimited) {
                    setSyncStatus({
                        phase: 'running',
                        message: `Nhịp đập thế giới gặp giới hạn tốc độ～chờ hồi ${cooldownSeconds(delayMs)} giây`,
                        error: 'Lượt nhịp đập này sẽ không tạo lại tác vụ thứ hai.',
                    });
                }
            },
            ...retryTaskOptions(
                'simulation',
                `world-pulse:${chatToken}:${getState().clock?.absoluteMinute ?? -1}:${manualPersonCatchUp ? `person:${requestedPersonTargetId}` : publicCycle ? 'public' : 'normal'}:${reason}`,
            ),
            signal: controller.signal,
        });

        if (controller.signal.aborted || currentChatToken() !== chatToken) return false;
        if (
            runtime.contextEpoch !== contextEpochAtStart
            || Math.max(0, Number(getState()?.revision) || 0) !== baseRevision
        ) {
            if (!quiet) {
                setSyncStatus({
                    phase: 'pending',
                    message: 'Trạng thái thế giới đã thay đổi trong lúc sinh nhịp đập thế giới, kết quả cũ chưa được áp dụng',
                    error: '',
                });
            }
            return false;
        }

        let payloadForCommit = payload;
        if (manualPersonCatchUp) {
            const returnedPeople = Array.isArray(payload?.people_upsert)
                ? payload.people_upsert
                : Array.isArray(payload?.peopleUpsert)
                    ? payload.peopleUpsert
                    : [];
            const targetPeople = returnedPeople.filter(item => (
                String(item?.id || '') === requestedPersonTargetId
            ));
            if (!targetPeople.length) {
                throw new Error(`Bù suy diễn nhân vật không trả về trạng thái của ${requestedPersonTarget.name}, lượt này đã bị loại bỏ, dữ liệu cũ sẽ không bị thay đổi`);
            }

            // 单人物补推演不是一次缩小版“全世界推演”。模型即使越界返回了
            // 其他人物或宏观脉搏，提交前也会被本地防火墙挡掉。与指定人物
            // 直接关联的既有/新事件仍允许更新，保证她不是被从世界里单独拎出来。
            const targetRefs = new Set([requestedPersonTargetId, String(requestedPersonTarget.name || '')].filter(Boolean));
            const eventTouchesTarget = event => {
                const actors = Array.isArray(event?.actors) ? event.actors.map(String) : [];
                if (actors.some(actor => targetRefs.has(actor))) return true;
                const causedBy = String(event?.caused_by ?? event?.causedBy ?? '');
                return Boolean(causedBy && relatedEventIds.has(causedBy));
            };
            const relatedEventIds = new Set(
                (Array.isArray(state.events) ? state.events : [])
                    .filter(event => {
                        const actors = Array.isArray(event?.actors) ? event.actors.map(String) : [];
                        return actors.some(actor => targetRefs.has(actor));
                    })
                    .map(event => String(event.id || ''))
                    .filter(Boolean),
            );
            const rawCreates = Array.isArray(payload?.events_create)
                ? payload.events_create
                : Array.isArray(payload?.eventsCreate)
                    ? payload.eventsCreate
                    : [];
            const rawUpdates = Array.isArray(payload?.events_update)
                ? payload.events_update
                : Array.isArray(payload?.eventsUpdate)
                    ? payload.eventsUpdate
                    : [];
            const eventCreates = rawCreates.filter(eventTouchesTarget);
            const eventUpdates = rawUpdates.filter(event => (
                relatedEventIds.has(String(event?.id || ''))
                || eventTouchesTarget(event)
            ));
            const allowedEventIds = new Set([
                ...relatedEventIds,
                ...eventCreates.map(event => String(event?.id || '')).filter(Boolean),
                ...eventUpdates.map(event => String(event?.id || '')).filter(Boolean),
            ]);
            const rawFacts = Array.isArray(payload?.world_facts_upsert)
                ? payload.world_facts_upsert
                : Array.isArray(payload?.worldFactsUpsert)
                    ? payload.worldFactsUpsert
                    : [];
            const worldFacts = rawFacts.filter(fact => (
                String(fact?.subject_id ?? fact?.subjectId ?? '') === requestedPersonTargetId
                || String(fact?.subject ?? '') === String(requestedPersonTarget.name || '')
                || allowedEventIds.has(String(fact?.event_id ?? fact?.eventId ?? ''))
            ));

            payloadForCommit = {
                ...payload,
                people_upsert: targetPeople,
                peopleUpsert: targetPeople,
                people_remove: [],
                peopleRemove: [],
                events_create: eventCreates,
                eventsCreate: eventCreates,
                events_update: eventUpdates,
                eventsUpdate: eventUpdates,
                world_facts_upsert: worldFacts,
                worldFactsUpsert: worldFacts,
                world_pulse_upsert: [],
                worldPulseUpsert: [],
                deliveries_confirmed: [],
                deliveriesConfirmed: [],
                consistency_conflicts: [],
                consistencyConflicts: [],
            };
        }

        let next = applySimulationResult(state, {
            ...payloadForCommit,
            elapsed_minutes: 0,
            memory_update: {
                facts_upsert: [],
                facts_invalidate: [],
                clues_upsert: [],
                clues_resolve: [],
            },
        }, {
            messageId: null,
            swipeId: null,
            sourceKey: manualPersonCatchUp
                ? `person-catchup:${requestedPersonTargetId}:${Date.now()}`
                : `world-pulse:${Date.now()}`,
            userName: getContext()?.name1 || '',
            allowUserInnerVoice: false,
            recordPlayerCharacter: settings.recordPlayerCharacter,
            timePolicy: settings.timePolicy,
            narrativeText: '',
            backgroundNpcBudget: effectiveBackgroundNpcBudget,
            lifeSettlementTargetIds: backgroundPersonTargets.map(person => person.id),
            preserveCommitAnchor: true,
        });
        if (!manualPersonCatchUp) {
            next = markWorldCoverageChecked(next, worldCoverageTargets, {
                publicCycle,
                customInstruction: settings.customSimulationInstruction,
            });
            if (publicCycle) {
                // 公共世界巡查已经在同一份模型结果里结算直接客观后果与真实
                // 获知渠道；为本轮公开表面建立传播指纹，避免紧接着再打一份
                // 公共影响 API。之后公开信息真正变化时仍会产生新的指纹。
                next = markCurrentPublicImpactsProcessed(next, {
                    reason: 'public-cycle-integrated-impact',
                });
            }
        }

        const store = getStore();
        const anchorKey = state.lastCommit?.sourceKey || 'root';
        store.currentState = ensureMonotonicRevision(next, store.currentState);
        next = store.currentState;
        store.branchOverrides[anchorKey] = createBranchSnapshot(next, {
            sourceKey: anchorKey,
            kind: manualPersonCatchUp ? 'person-catchup' : 'world-pulse',
        });
        saveStore(store, { immediate: true });
        refreshInjection();
        schedulePublicPostProcessing(next, {
            impactDelay: 160,
            opinionDelay: 620,
        });
        runtime.ui?.render();
        if (!quiet) {
            setSyncStatus({
                phase: 'success',
                message: manualPersonCatchUp
                    ? `${requestedPersonTarget.name} đã được bù đủ tình hình gần đây～không đẩy thêm thời gian thế giới`
                    : 'Nhịp đập thế giới đã kiểm tra xong～ngoài ống kính mọi người cũng tiếp tục sống cuộc sống của mình',
                error: '',
                succeededAt: new Date().toISOString(),
            });
        }
        return true;
    } catch (error) {
        if (error?.name === 'AbortError') return false;
        if (!quiet) {
            setSyncStatus({
                phase: 'error',
                message: manualPersonCatchUp
                    ? `${requestedPersonTarget?.name || 'Nhân vật này'} — lần này chưa bù được tình hình～trạng thái cũ giữ nguyên`
                    : 'Thời gian thế giới đã được đẩy tới, nhưng lần này nhịp đập thế giới chưa nối được～lần suy diễn sau sẽ tiếp tục đuổi theo',
                error: describeError(error),
            });
        }
        if (manualPersonCatchUp) throw error;
        return false;
    } finally {
        if (runtime.activeWorldPulse?.controller === controller) runtime.activeWorldPulse = null;
        window.setTimeout(schedulePendingCatchUp, 40);
    }
}

async function bootstrapWorldFromHistory() {
    if (runtime.historyProgress.phase === 'running') {
        throw new Error('Sắp xếp lịch sử đang được tiến hành');
    }
    if (coreSimulationBusy()) {
        throw new Error('Suy diễn thế giới hoặc kết toán nền đang chạy, hãy đợi tác vụ hiện tại xong rồi mới truy hồi lịch sử');
    }
    const context = getContext();
    const chatToken = currentChatToken();
    const contextEpochAtStart = runtime.contextEpoch;
    const chatLength = context?.chat?.length || 0;
    if (!chatLength) throw new Error('Cuộc trò chuyện hiện tại chưa có chính văn nào để truy hồi');

    const bootstrapBaseRevision = Math.max(0, Number(getState()?.revision) || 0);
    const checkpointStore = getStore();
    const checkpoint = validHistoryBootstrapCheckpoint(checkpointStore, {
        chatToken,
        chatLength,
        baseRevision: bootstrapBaseRevision,
    });
    if (!checkpoint && checkpointStore.historyBootstrapCheckpoint) {
        checkpointStore.historyBootstrapCheckpoint = null;
        saveStore(checkpointStore, { immediate: true });
    }
    const resumeCursor = checkpoint?.cursor || 0;

    const confirmed = globalThis.confirm?.(
        (checkpoint
            ? `( •ᴗ• )  Lần trước đã cất an toàn ${resumeCursor} tầng đầu, sẽ tiếp tục từ tầng ${resumeCursor}, còn lại khoảng ${Math.max(0, chatLength - resumeCursor)} tin nhắn.\n`
            : `( •ᴗ• )  Sẽ truy hồi nhánh hiện tại bắt đầu từ tầng 0, tổng cộng khoảng ${chatLength} tin nhắn.\n`)
        + 'Sẽ đồng thời dựng thời gian thế giới, trạng thái hiện tại của nhân vật, sự thật thế giới, Mạch ngầm chưa xong, nhịp đập thế giới và ký ức dài hạn.\n'
        + 'Mỗi đợt sẽ lưu điểm dừng an toàn, nhưng chỉ khi quét thành công toàn bộ mới gửi một lần vào thế giới chính thức. Có tiếp tục không?',
    );
    if (confirmed === false) return false;

    if (!checkpoint) {
        const protectedStore = addRecoveryPoint(getStore(), {
            reason: 'before-world-history-bootstrap',
            label: 'Tự động lưu trước khi truy hồi lịch sử',
        });
        saveStore(protectedStore, { immediate: true });
    }

    const controller = new AbortController();
    runtime.activeHistoryScan = controller;
    runtime.historyProgress = {
        kind: 'world-bootstrap',
        phase: 'running',
        processed: resumeCursor,
        total: chatLength,
        message: checkpoint
            ? `Tiếp nối dấu chân mèo lần trước, từ tầng ${resumeCursor} trở đi～`
            : 'Đang nối đoạn chat cũ thành một thế giới hoàn chỉnh～',
    };
    setBusy(true);
    runtime.ui?.render();

    // IMPORTANT: staging only. Nothing below is written to the live store until all
    // batches succeed. Manual edits during the scan invalidate the staged result.
    let stagedState = checkpoint ? trimState(checkpoint.stagedState) : trimState(getState());
    let cursor = resumeCursor;
    let assistantBatchLimit = checkpoint
        ? Math.max(1, Number.parseInt(checkpoint.assistantBatchLimit, 10) || 1)
        : HISTORY_BATCH_TARGET_ASSISTANT_TURNS;

    try {
        while (cursor < chatLength) {
            if (controller.signal.aborted) {
                const error = new Error('Truy hồi lịch sử đã dừng');
                error.name = 'AbortError';
                throw error;
            }
            if (currentChatToken() !== chatToken) {
                throw new Error('Đã chuyển đoạn chat trong lúc truy hồi, kết quả lần này sẽ không được ghi');
            }

            const batch = nextHistoryBatch(cursor, {
                maximumAssistantTurns: assistantBatchLimit,
                maximumUserTurns: HISTORY_BATCH_TARGET_ASSISTANT_TURNS + 1,
            });
            if (!batch.messages.length) {
                cursor = batch.nextCursor;
                continue;
            }

            runtime.historyProgress = {
                kind: 'world-bootstrap',
                phase: 'running',
                processed: batch.startMessageId,
                total: chatLength,
                message: `Đang truy hồi tin nhắn ${batch.startMessageId}—${batch.endMessageId}: nhân vật, Mạch ngầm, sự thật và Nhịp đập thế giới cùng được thu dọn～`,
            };
            runtime.ui?.render();

            let payload;
            try {
                payload = await runWithRetries(async attempt => {
                    const prompt = buildWorldBootstrapPrompt(stagedState, {
                        messages: batch.messages,
                        userName: context?.name1 || '',
                        playerIdentityAnchor: getPlayerIdentityAnchor(stagedState),
                        recordPlayerCharacter: getSettings().recordPlayerCharacter,
                        compact: attempt > 0,
                    });
                    const historyBaseTokens = 6400;
                    const raw = await backgroundSimulation(retryJsonPrompt(prompt, attempt), {
                        maxTokens: retryTokenBudget(historyBaseTokens, attempt),
                        temperature: attempt > 0 ? 0.04 : 0.08,
                        signal: controller.signal,
                        taskKind: 'history',
                    });
                    const parsed = extractJsonObject(raw);
                    if (!parsed) throw unreadableJsonError(raw, 'Model truy hồi lịch sử thế giới');

                    const requiredSummaryIds = batch.messages
                        .map(message => Number(message.id));
                    const summarizedIds = new Set(
                        (Array.isArray(parsed.turn_summaries) ? parsed.turn_summaries : parsed.turnSummaries || [])
                            .filter(item => String(item?.summary || '').trim())
                            .map(item => Number(item?.source_message_id ?? item?.sourceMessageId ?? item?.message_id ?? item?.messageId))
                            .filter(Number.isFinite),
                    );
                    const missingIds = requiredSummaryIds.filter(id => !summarizedIds.has(id));
                    if (missingIds.length) {
                        const error = new Error(`Truy hồi lịch sử thiếu tóm tắt L0: tin nhắn ${missingIds.join(', ')}`);
                        error.code = 'WORLD_BOOTSTRAP_L0_MISSING';
                        throw error;
                    }
                    return parsed;
                }, {
                    retries: getSettings().autoRetryCount,
                    shouldRetry: error => !(
                        /请先填写独立 API|HTTP 40[0134]|没有提供安静生成接口|hãy điền.{0,40}API độc lập|chưa điền.{0,40}API độc lập|không (?:cung cấp|có|hỗ trợ).{0,30}(?:quiet|tạo ngầm|tạo im lặng|tạo yên lặng)|sinh yên lặng/i
                            .test(describeError(error))
                    ),
                    onRetry: ({ attempt, total, delayMs, rateLimited }) => {
                        runtime.historyProgress.message = rateLimited
                            ? `API truy hồi lịch sử bị giới hạn tốc độ～chờ hạ nhiệt ${cooldownSeconds(delayMs)} giây rồi tiếp tục đợt hiện tại`
                            : `Đợt đường cơ sở thế giới này chưa thu gọn được, đang thử lại với định dạng gọn ${attempt}/${total}`;
                        runtime.ui?.render();
                    },
                    ...retryTaskOptions(
                        'history',
                        `world-bootstrap:${chatToken}:${batch.startMessageId}:${batch.endMessageId}`,
                    ),
                    signal: controller.signal,
                });
            } catch (error) {
                const assistantTurns = batch.messages.filter(message => message.role === 'assistant').length;
                const canSplit = assistantTurns > 1 && (
                    /JSON|L0 摘要缺失|L0摘要缺失|截断|长度上限|No message generated|没有返回最终正文|没有可读取的最终正文|thiếu tóm tắt L0|tóm tắt L0 bị thiếu|bị cắt|cắt cụt|giới hạn độ dài|không (?:trả về|có)[^.\n]{0,30}chính văn|cắt ngắn/i
                        .test(describeError(error))
                );
                if (canSplit) {
                    assistantBatchLimit = Math.max(1, Math.floor(assistantTurns / 2));
                    runtime.historyProgress.message = `Đầu ra phình quá～tự động thu nhỏ còn mỗi đợt ${assistantBatchLimit} lượt rồi thử lại`;
                    runtime.ui?.render();
                    continue;
                }
                throw error;
            }

            const narrativeText = batch.messages
                .filter(message => message.role === 'assistant')
                .map(message => message.content)
                .join('\n');
            stagedState = applyWorldBootstrapResult(stagedState, payload, {
                startMessageId: batch.startMessageId,
                endMessageId: batch.endMessageId,
                narrativeText,
                userName: context?.name1 || '',
                allowUserInnerVoice: false,
                recordPlayerCharacter: getSettings().recordPlayerCharacter,
                memoryEnabled: getSettings().memorySystemEnabled,
            });
            cursor = batch.nextCursor;
            assistantBatchLimit = Math.min(
                HISTORY_BATCH_TARGET_ASSISTANT_TURNS,
                assistantBatchLimit + 1,
            );
            await saveHistoryBootstrapCheckpoint({
                chatToken,
                cursor,
                chatLength,
                baseRevision: bootstrapBaseRevision,
                stagedState,
                assistantBatchLimit,
            });
            runtime.historyProgress.processed = Math.min(chatLength, cursor);
            runtime.historyProgress.message = `Tin nhắn ${batch.startMessageId}—${batch.endMessageId} đã được lưu an toàn～tiếp tục thu dọn phần sau`;
            runtime.ui?.render();
        }

        // Compact one hierarchy layer after the full staged history has been built.
        if (getSettings().memorySystemEnabled) {
            const rollup = await runOneMemoryRollup(stagedState, controller);
            stagedState = rollup.state;
        }
        if (controller.signal.aborted || currentChatToken() !== chatToken) {
            const error = new Error('Truy hồi lịch sử đã bị dừng trước khi ghi');
            error.name = 'AbortError';
            throw error;
        }

        if (
            runtime.contextEpoch !== contextEpochAtStart
            || (getContext()?.chat?.length || 0) !== chatLength
            || Math.max(0, Number(getState()?.revision) || 0) !== bootstrapBaseRevision
        ) {
            const error = new Error('Trạng thái thế giới đã bị sửa thủ công trong lúc truy hồi lịch sử, đường cơ sở cũ lần này sẽ không ghi đè trạng thái mới');
            error.name = 'AbortError';
            throw error;
        }

        stagedState.storyMemory.indexedThroughMessageId = Math.max(
            stagedState.storyMemory.indexedThroughMessageId,
            chatLength - 1,
        );
        stagedState.worldPulse ||= { baselineEstablished: true, lastSweepAt: stagedState.clock.absoluteMinute, domains: [] };
        stagedState.worldPulse.baselineEstablished = true;
        stagedState.worldPulse.lastSweepAt = stagedState.clock.absoluteMinute;
        stagedState = trimState(stagedState);

        // Atomic commit happens only here. The history helper uses synthetic
        // source keys internally, but the live state must remain anchored to the
        // real foreground branch so later manual overrides survive reload/swipe.
        const latest = latestAssistantEntry();
        if (latest) {
            const latestSwipeId = Number(latest.message?.swipe_id ?? 0);
            stagedState.pendingSync = false;
            stagedState.needsReconciliation = false;
            stagedState.lastCommit = {
                messageId: latest.index,
                swipeId: latestSwipeId,
                sourceKey: branchSourceKey(latest.index, latest.message, latestSwipeId),
                at: stagedState.clock?.absoluteMinute ?? 0,
                committedAt: new Date().toISOString(),
            };
        }
        const store = getStore();
        store.historyBootstrapCheckpoint = null;
        store.currentState = ensureMonotonicRevision(stagedState, store.currentState);
        stagedState = store.currentState;
        const anchorKey = stagedState.lastCommit?.sourceKey || 'root';
        store.branchOverrides[anchorKey] = createBranchSnapshot(stagedState, {
            sourceKey: anchorKey,
            kind: 'world-history-bootstrap',
        });
        saveStore(store, { immediate: true });

        runtime.historyProgress = {
            kind: 'world-bootstrap',
            phase: 'success',
            processed: chatLength,
            total: chatLength,
            message: 'Truy hồi lịch sử hoàn tất～世界背面 đã theo kịp đoạn chat này',
        };
        refreshInjection();
        runtime.ui?.render();
        schedulePublicPostProcessing(stagedState, {
            impactDelay: 180,
            opinionDelay: 320,
        });

        const activeCurrents = (stagedState.events || []).filter(event => (
            !['resolved', 'cancelled', 'missed'].includes(event.status)
        )).length;
        toast(
            `Đã nối xong đường cơ sở thế giới～nhân vật ${stagedState.people.length} · sự thật thế giới ${stagedState.worldFacts.length} · `
            + `Mạch ngầm chưa xong ${activeCurrents} · ký ức dài hạn ${stagedState.storyMemory?.facts?.length || 0}`,
            'success',
        );
        return true;
    } catch (error) {
        runtime.historyProgress = {
            kind: 'world-bootstrap',
            phase: error?.name === 'AbortError' ? 'idle' : 'error',
            processed: Math.min(chatLength, cursor),
            total: chatLength,
            message: error?.name === 'AbortError'
                ? (cursor > 0
                    ? `Truy hồi lịch sử đã dừng ở tầng ${Math.min(chatLength, cursor)}～thế giới chính thức chưa bị động đến, lần sau có thể làm tiếp`
                    : 'Truy hồi lịch sử đã dừng～thế giới chính thức không bị ghi bán thành phẩm')
                : (cursor > 0
                    ? `Truy hồi lịch sử dừng ở tầng ${Math.min(chatLength, cursor)}: ${describeError(error)}; điểm dừng đã được giữ lại, thế giới chính thức không thay đổi`
                    : `Truy hồi lịch sử thất bại: ${describeError(error)}; thế giới chính thức không thay đổi`),
        };
        runtime.ui?.render();
        if (error?.name === 'AbortError') return false;
        throw error;
    } finally {
        if (runtime.activeHistoryScan === controller) runtime.activeHistoryScan = null;
        setBusy(false);
        runtime.ui?.render();
    }
}

async function scanStoryMemoryHistory({
    automatic = false,
    maximumBatches = Number.POSITIVE_INFINITY,
    skipConfirmation = false,
} = {}) {
    if (!getSettings().memorySystemEnabled) {
        if (automatic) return false;
        throw new Error('Hệ thống ký ức hiện đang bị tắt');
    }
    if (runtime.historyProgress.phase === 'running') {
        if (automatic) return false;
        throw new Error('Việc lập hồ sơ lịch sử đang được tiến hành');
    }
    if (coreSimulationBusy()) {
        if (automatic) return false;
        throw new Error('Suy diễn thế giới hoặc kết toán nền đang chạy, hãy đợi tác vụ hiện tại kết thúc rồi mới sắp xếp ký ức');
    }
    const context = getContext();
    const chatToken = currentChatToken();
    const contextEpochAtStart = runtime.contextEpoch;
    const chatLength = context?.chat?.length || 0;
    if (!chatLength) throw new Error('Đoạn chat hiện tại chưa có chính văn để quét');

    let state = getState();
    let cursor = Math.max(0, Number(state.storyMemory?.indexedThroughMessageId ?? -1) + 1);
    const initialRollupPlan = planMemoryRollup(state);
    if (cursor >= chatLength && !initialRollupPlan) {
        if (!automatic) toast('Hồ sơ lịch sử đã theo kịp tầng mới nhất rồi～', 'info');
        return true;
    }
    if (!automatic && cursor < chatLength) {
        if (!skipConfirmation) {
            const confirmed = globalThis.confirm?.(
                `( •ᴗ• )  Sẽ bắt đầu từ tầng ${cursor}, đọc nhánh hiện tại theo từng đợt, tổng cộng khoảng ${chatLength - cursor} tin nhắn.\n`
                + 'Việc này sẽ phát sinh thêm lượt gọi API, nhưng mỗi đợt thành công đều được lưu tiến độ ngay. Tiếp tục chứ?',
            );
            if (confirmed === false) return false;
        }
        // 玲七代办时，用户刚刚已经明确说“整理记忆”，无需再确认第二遍；
        // 但恢复点仍然照常建立，数据安全不打折。
        const protectedStore = addRecoveryPoint(getStore(), {
            reason: 'before-memory-maintenance',
            label: 'Tự động lưu trước khi sắp xếp ký ức thủ công',
        });
        saveStore(protectedStore, { immediate: true });
    }

    runtime.historyProgress = {
        kind: 'memory',
        phase: 'running',
        processed: cursor,
        total: chatLength,
        message: cursor < chatLength
            ? (automatic ? 'Đang lặng lẽ sắp xếp ký ức mới～' : 'Đang lưu trữ hồ sơ lịch sử～')
            : 'Chính văn đã theo kịp rồi～tiện tay nén trải nghiệm cũ thêm một tầng',
    };
    const controller = new AbortController();
    runtime.activeHistoryScan = controller;
    setBusy(true);
    runtime.ui?.render();

    try {
        let completedBatches = 0;
        let assistantBatchLimit = automatic
            ? Math.min(
                HISTORY_BATCH_TARGET_ASSISTANT_TURNS,
                Math.max(1, getSettings().memoryAutoIndexInterval),
            )
            : HISTORY_BATCH_TARGET_ASSISTANT_TURNS;
        const batchLimit = Number.isFinite(Number(maximumBatches))
            ? Math.max(1, Number.parseInt(maximumBatches, 10) || 1)
            : Number.POSITIVE_INFINITY;
        while (cursor < chatLength && completedBatches < batchLimit) {
            if (!getSettings().memorySystemEnabled || controller.signal.aborted) {
                const error = new Error('Hệ thống ký ức đã tắt, lần sắp xếp này đã dừng');
                error.name = 'AbortError';
                throw error;
            }
            if (currentChatToken() !== chatToken) {
                throw new Error('Đã chuyển đoạn chat trong lúc quét, lần này đã dừng ở đợt hoàn tất trước đó');
            }
            const batch = nextHistoryBatch(cursor, {
                maximumAssistantTurns: assistantBatchLimit,
                maximumUserTurns: HISTORY_BATCH_TARGET_ASSISTANT_TURNS + 1,
            });
            if (!batch.messages.length) {
                cursor = batch.nextCursor;
                continue;
            }
            runtime.historyProgress = {
                phase: 'running',
                processed: batch.startMessageId,
                total: chatLength,
                message: `Đang dọn dẹp tin nhắn ${batch.startMessageId}—${batch.endMessageId}～`,
            };
            runtime.ui?.render();

            let payload;
            try {
                payload = await runWithRetries(async attempt => {
                    const prompt = buildHistoryIndexPrompt(state, {
                        messages: batch.messages,
                        userName: context?.name1 || '',
                        playerIdentityAnchor: getPlayerIdentityAnchor(state),
                        compact: attempt > 0,
                    });
                    const historyBaseTokens = 4200;
                    const raw = await backgroundSimulation(retryJsonPrompt(prompt, attempt), {
                        maxTokens: retryTokenBudget(historyBaseTokens, attempt),
                        temperature: attempt > 0 ? 0.05 : 0.1,
                        signal: controller.signal,
                        taskKind: 'history',
                    });
                    const parsed = extractJsonObject(raw);
                    if (parsed) {
                        const requiredSummaryIds = batch.messages
                            .map(message => Number(message.id));
                        const summarizedIds = new Set(
                            (Array.isArray(parsed.turn_summaries) ? parsed.turn_summaries : parsed.turnSummaries || [])
                                .filter(item => String(item?.summary || '').trim())
                                .map(item => Number(item?.source_message_id ?? item?.sourceMessageId ?? item?.message_id ?? item?.messageId))
                                .filter(Number.isFinite),
                        );
                        const missingIds = requiredSummaryIds.filter(id => !summarizedIds.has(id));
                        const fallbackSummary = parsed?.chapter_summary ?? parsed?.chapterSummary;
                        if (missingIds.length && !(requiredSummaryIds.length === 1 && fallbackSummary?.summary)) {
                            const error = new Error(`Thiếu tóm tắt L0: tin nhắn ${missingIds.join(', ')}`);
                            error.code = 'MEMORY_L0_MISSING';
                            throw error;
                        }
                        return parsed;
                    }
                    throw unreadableJsonError(raw, 'Model sắp xếp ký ức');
                }, {
                    retries: getSettings().autoRetryCount,
                    shouldRetry: error => !(
                        /请先填写独立 API|HTTP 40[0134]|没有提供安静生成接口|hãy điền.{0,40}API độc lập|chưa điền.{0,40}API độc lập|không (?:cung cấp|có|hỗ trợ).{0,30}(?:quiet|tạo ngầm|tạo im lặng|tạo yên lặng)|sinh yên lặng/i
                            .test(describeError(error))
                    ),
                    onRetry: ({ attempt, total, delayMs, rateLimited }) => {
                        runtime.historyProgress.message = rateLimited
                            ? `API sắp xếp ký ức bị giới hạn tốc độ～chờ hạ nhiệt ${cooldownSeconds(delayMs)} giây rồi tiếp tục đợt hiện tại`
                            : `Sắp xếp ký ức thất bại, đang thử lại với định dạng gọn ${attempt}/${total}`;
                        runtime.ui?.render();
                    },
                    ...retryTaskOptions(
                        'history',
                        `memory-history:${chatToken}:${batch.startMessageId}:${batch.endMessageId}`,
                    ),
                    signal: controller.signal,
                });
            } catch (error) {
                const assistantTurns = batch.messages.filter(message => message.role === 'assistant').length;
                const canSplit = assistantTurns > 1 && (
                    /JSON|L0摘要缺失|截断|长度上限|No message generated|没有返回最终正文|没有可读取的最终正文|thiếu tóm tắt L0|tóm tắt L0 bị thiếu|bị cắt|cắt cụt|giới hạn độ dài|không (?:trả về|có)[^.\n]{0,30}chính văn|cắt ngắn/i
                        .test(describeError(error))
                );
                if (canSplit) {
                    assistantBatchLimit = Math.max(1, Math.floor(assistantTurns / 2));
                    runtime.historyProgress.message = `Đầu ra quá dài hoặc trống, đã tự động thu nhỏ còn mỗi đợt ${assistantBatchLimit} lượt rồi thử lại`;
                    runtime.ui?.render();
                    continue;
                }
                throw error;
            }
            if (!getSettings().memorySystemEnabled || controller.signal.aborted) {
                const error = new Error('Hệ thống ký ức đã tắt, lần sắp xếp này đã dừng');
                error.name = 'AbortError';
                throw error;
            }
            if (
                runtime.contextEpoch !== contextEpochAtStart
                || Math.max(0, Number(getState()?.revision) || 0) !== Math.max(0, Number(state?.revision) || 0)
            ) {
                const error = new Error('Trạng thái thế giới đã bị sửa trong lúc sắp xếp ký ức, đợt cũ sẽ không ghi đè trạng thái mới');
                error.name = 'AbortError';
                throw error;
            }
            state = applyHistoryIndexResult(state, payload, {
                startMessageId: batch.startMessageId,
                endMessageId: batch.endMessageId,
            });
            cursor = batch.nextCursor;
            completedBatches += 1;
            assistantBatchLimit = Math.min(
                HISTORY_BATCH_TARGET_ASSISTANT_TURNS,
                assistantBatchLimit + 1,
            );

            const store = getStore();
            store.currentState = ensureMonotonicRevision(state, store.currentState);
            state = store.currentState;
            const anchorKey = state.lastCommit?.sourceKey || 'root';
            store.branchOverrides[anchorKey] = createBranchSnapshot(state, {
                sourceKey: anchorKey,
                kind: 'history-index',
            });
            await saveStore(store, { immediate: true });
            runtime.historyProgress.processed = Math.min(chatLength, cursor);
            runtime.historyProgress.message = `Tin nhắn ${batch.startMessageId}—${batch.endMessageId} đã được lưu an toàn～tiếp tục thu dọn phần sau`;
            refreshInjection();
            runtime.ui?.render();

            if (runtime.queuedSimulations.size > 0) {
                runtime.historyProgress.message = 'Đợt ký ức hiện tại đã thu xong～Suy diễn thế giới đang xếp hàng, nhường đường trước đã';
                runtime.ui?.render();
                break;
            }
        }

        let rolledUp = false;
        if (runtime.queuedSimulations.size === 0) {
            const rollupBaseRevision = Math.max(0, Number(state?.revision) || 0);
            const rollup = await runOneMemoryRollup(state, controller);
            if (
                runtime.contextEpoch !== contextEpochAtStart
                || Math.max(0, Number(getState()?.revision) || 0) !== rollupBaseRevision
            ) {
                const error = new Error('Trạng thái thế giới đã bị sửa trong lúc nén ký ức, kết quả cũ sẽ không ghi đè trạng thái mới');
                error.name = 'AbortError';
                throw error;
            }
            state = rollup.state;
            rolledUp = rollup.rolledUp;
        }
        if (rolledUp) {
            const store = getStore();
            store.currentState = ensureMonotonicRevision(state, store.currentState);
            state = store.currentState;
            const anchorKey = state.lastCommit?.sourceKey || 'root';
            store.branchOverrides[anchorKey] = createBranchSnapshot(state, {
                sourceKey: anchorKey,
                kind: 'memory-rollup',
            });
            saveStore(store, { immediate: true });
            refreshInjection();
            runtime.ui?.render();
        }

        const caughtUp = cursor >= chatLength;
        if (caughtUp) {
            state.storyMemory.indexedThroughMessageId = Math.max(
                state.storyMemory.indexedThroughMessageId,
                chatLength - 1,
            );
        }
        const store = getStore();
        store.currentState = ensureMonotonicRevision(state, store.currentState);
        state = store.currentState;
        saveStore(store, { immediate: true });
        runtime.historyProgress = {
            phase: 'success',
            processed: Math.min(chatLength, cursor),
            total: chatLength,
            message: caughtUp
                ? (rolledUp
                    ? 'Ký ức chính văn đã theo kịp, tiện tay sắp xếp xong thêm một tầng trải nghiệm phía trên～'
                    : (automatic ? 'Ký ức mới đã được tự động sắp xếp' : 'Hồ sơ lịch sử của nhánh hiện tại đã được lập'))
                : `Đã sắp xếp đến tin nhắn ${state.storyMemory.indexedThroughMessageId}`,
        };
        refreshInjection();
        runtime.ui?.render();
        if (!automatic) {
            toast(
                `Lập hồ sơ ký ức hoàn tất: ${state.storyMemory.facts.length} sự thật dài hạn, `
                + `${state.storyMemory.clues.length} phục bút, `
                + `${state.storyMemory.summaries.length} đoạn trải nghiệm phân tầng.`,
                'success',
            );
        } else {
            scheduleAutoMemoryIndex();
        }
        return true;
    } catch (error) {
        if (error?.name === 'AbortError') {
            runtime.historyProgress = {
                ...runtime.historyProgress,
                phase: 'idle',
                message: 'Sắp xếp ký ức đã dừng, đợt đang sinh dở không được ghi',
            };
            runtime.ui?.render();
            return false;
        }
        runtime.historyProgress = {
            ...runtime.historyProgress,
            phase: 'error',
            message: describeError(error),
        };
        runtime.ui?.render();
        throw error;
    } finally {
        if (runtime.activeHistoryScan === controller) runtime.activeHistoryScan = null;
        setBusy(false);
    }
}

function personObservationCacheKey(state, person) {
    const latest = latestAssistantEntry();
    const source = latest
        ? branchSourceKey(latest.index, latest.message)
        : 'no-assistant';
    const stateFingerprint = hashText(JSON.stringify({
        clock: state.clock.absoluteMinute,
        world: state.world,
        person: {
            id: person.id,
            location: person.location,
            action: person.action,
            intent: person.intent,
            goal: person.longTermGoal,
            identityAnchor: person.identityAnchor,
            personalityAnchor: person.personalityAnchor,
            appearanceProfile: person.appearanceProfile,
            backgroundProfile: person.backgroundProfile,
            abilityProfile: person.abilityProfile,
            speakingStyle: person.speakingStyle,
            behaviorBoundaries: person.behaviorBoundaries,
            innerVoice: person.innerVoice,
            innerVoiceAt: person.innerVoiceAt,
            knowledge: person.knowledge,
            cognitionReady: person.cognitionReady,
            knownEventViews: person.knownEventViews,
            knownFactBeliefs: person.knownFactBeliefs,
            knownClueIds: person.knownClueIds,
            physicalState: person.physicalState,
            emotionalState: person.emotionalState,
            resourceState: person.resourceState,
            updatedAt: person.updatedAt,
        },
    }));
    return `${person.id}:${source}:${stateFingerprint}`;
}

function cachedPersonObservation(personId) {
    const state = getState();
    const person = state.people.find(item => item.id === personId);
    if (!person) return null;
    const store = getStore();
    const currentKey = personObservationCacheKey(state, person);
    const current = store.personObservations?.[currentKey];
    const activeFallback = Object.values(store.personObservations || {})
        .reverse()
        .find(item => (
            item?.personId === personId
            && item?.queuedEventId
            && state.events.some(event => event.id === item.queuedEventId)
        ));
    const cached = current || activeFallback;
    if (!cached) return null;
    const queuedEvent = cached.queuedEventId
        ? state.events.find(event => event.id === cached.queuedEventId)
        : null;
    const revealState = queuedEvent?.delivery?.state === 'delivered'
        ? 'delivered'
        : queuedEvent?.delivery?.state === 'expired'
            ? 'expired'
            : (
                queuedEvent
                && (cached.revealEnabled ?? (
                    queuedEvent.delivery?.manualQueued
                    || queuedEvent.delivery?.state === 'pending'
                ))
            )
                ? 'enabled'
                : 'off';
    return {
        ...cached,
        queued: revealState === 'enabled',
        revealState,
    };
}

function queuePersonObservation(personId) {
    const state = getState();
    const person = state.people.find(item => item.id === personId);
    if (!person) throw new Error('Không tìm thấy nhân vật này');
    const sceneRelation = personObservationSceneRelation(state, person, getContext()?.name1 || '');
    const cacheKey = personObservationCacheKey(state, person);
    const store = getStore();
    const current = store.personObservations?.[cacheKey];
    const activeFallback = Object.values(store.personObservations || {})
        .reverse()
        .find(item => (
            item?.personId === personId
            && item?.queuedEventId
            && state.events.some(event => event.id === item.queuedEventId)
        ));
    const observation = current || activeFallback;
    if (!observation?.text) throw new Error('Hãy tạo một lần Quan sát nhân vật trước');
    const existing = state.events.find(event => event.id === observation.queuedEventId);
    if (existing?.delivery?.state === 'delivered') {
        throw new Error('Đoạn quan sát này đã được chính văn tiếp nhận tự nhiên, không thể rút lại');
    }

    if (existing) {
        const enabled = !['delivered', 'expired', 'none'].includes(existing.delivery?.state)
            && (observation.revealEnabled ?? (
                existing.delivery?.manualQueued
                || existing.delivery?.state === 'pending'
            ));
        const next = clone(state);
        const event = next.events.find(item => item.id === existing.id);
        event.delivery ||= { state: 'none' };
        event.delivery.manualQueued = !enabled;
        event.delivery.state = enabled ? 'none' : 'pending';
        if (!enabled) event.delivery.attempts = 0;
        observation.revealEnabled = !enabled;
        store.personObservations[cacheKey] = observation;
        commitManualState(
            next,
            enabled
                ? `Đã đưa ${person.name} (Quan sát hậu trường) về chế độ chỉ xem.`
                : `Đã cho phép ${person.name} — Quan sát hậu trường được hé lộ tự nhiên vào lúc thích hợp.`,
        );
        saveStore(store);
        return cachedPersonObservation(personId);
    }

    const previousIds = new Set(state.events.map(event => event.id));
    const next = addManualEvent(state, {
        title: `${person.name} — đoạn ngoài ống kính`,
        place: person.location,
        summary: observation.text,
        expected_result: '',
        result: '',
        consequence: '',
        status: 'ready',
        clock_mode: 'condition',
        visibility: 'trace',
        delivery_queued: true,
        delivery_mode: 'soft-observation',
        delivery_route: sceneRelation.kind === 'same_place'
            ? 'Trạng thái chính thức cho thấy nhân vật và người chơi hiện đang ở cùng địa điểm, nhưng cùng địa điểm không có nghĩa là đã nhận ra nhau hay đã tương tác. Chỉ được phép đáp lại nhẹ nhàng qua lời nói, hành động quan sát được khi ống kính hiện tại của chính văn thực sự tiếp xúc tự nhiên với nhân vật này; không được chép nguyên độc thoại nội tâm, không được dựa vào quan sát để tạo ra cuộc gặp gỡ hay khiến nhân vật đột nhiên biết đến người chơi.'
            : 'Chỉ là manh mối mềm về động cơ và cảm xúc của nhân vật; không phải sự kiện đã xảy ra, chỉ được đáp lại nhẹ nhàng khi thực sự liên quan tự nhiên đến ngữ cảnh hiện tại, không được dựa vào đó để thay đổi địa điểm, tạo ra cuộc gặp gỡ hay để lộ độc thoại nội tâm.',
    });
    const created = next.events.find(event => !previousIds.has(event.id));
    if (!created) throw new Error('Không tạo được ứng viên Hé lộ tự nhiên');
    commitManualState(next, `Đã cho phép ${person.name} — Quan sát hậu trường được hé lộ tự nhiên vào lúc thích hợp.`);
    observation.queuedEventId = created.id;
    observation.revealEnabled = true;
    store.personObservations[cacheKey] = observation;
    saveStore(store);
    return cachedPersonObservation(personId);
}

function personObservationPollutionReason(text, person) {
    const value = String(text || '').trim();
    if (!value) return 'Nội dung trả về trống';
    if (/<\/?content\b|<UpdateVariable\b|<JSONPatch\b|JSONPatch|<details\b/i.test(value)) {
        return 'Nội dung trả về bị lẫn chính văn của chat chính / giao thức cập nhật biến';
    }
    const playerCentricHits = (value.match(/(?:^|[。！？\n])\s*你(?:正|又|还|已经|沿|走|坐|站|抬|低|伸|把|看|听|闻|感觉|发现|来到|回到|穿|拿|吃|喝|说|问|停|转)|(?:^|[.!?\n。！？])\s*(?:Bạn|bạn|Ngươi|ngươi)\s(?:đang|lại|vẫn|đã|men theo|đi|ngồi|đứng|ngẩng|cúi|vươn|đưa|nhìn|nghe|ngửi|cảm thấy|phát hiện|đến|tới|trở về|quay về|mặc|cầm|ăn|uống|nói|hỏi|dừng|quay|xoay)/g) || []).length;
    const firstPersonHits = (value.match(/(?:^|[。！？\n，,])\s*我(?:正|又|还|已经|在|把|看|听|闻|想|觉得|发现|走|坐|站|抬|低|伸|拿|吃|喝|说|问|停|转|没|有)|(?:^|[.!?\n,。！？，])\s*(?:Tôi|tôi|Ta|ta|Mình|mình)\s(?:đang|lại|vẫn|đã|ở|đưa|nhìn|nghe|ngửi|nghĩ|thấy|cảm thấy|phát hiện|đi|ngồi|đứng|ngẩng|cúi|vươn|cầm|ăn|uống|nói|hỏi|dừng|quay|không|chưa|có)/g) || []).length;
    if (playerCentricHits >= 3 && firstPersonHits === 0) {
        return `Nội dung trả về có vẻ lấy người chơi làm chủ thể kể chuyện, thay vì để ${person?.name || 'nhân vật được quan sát'} ở ngôi thứ nhất`;
    }
    return '';
}

function personObservationLooksComplete(text) {
    const value = String(text || '').trim();
    if (!value) return false;
    // Character observations are prose-only. A result that ends mid-word or
    // mid-sentence is overwhelmingly likely to be a max-token truncation on
    // tavern-backed generation, where finish_reason is not exposed to plugins.
    return /[。！？!?…」』”’）)\]】]$/.test(value);
}

async function generateIndependentPersonObservation(prompt, person, settings, { signal } = {}) {
    runtime.syncStatus.method = settings.apiMode === 'custom'
        ? 'Quan sát nhân vật · API độc lập của 世界背面'
        : settings.apiMode === 'tavern-profile'
            ? 'Quan sát nhân vật · Cấu hình đã lưu của Tavern'
            : 'Quan sát nhân vật · Ngữ cảnh độc lập của 世界背面';

    const requestedAttempts = [
        { maxTokens: 4096, temperature: 0.75 },
        { maxTokens: 8192, temperature: 0.65 },
    ];
    const attempts = [];
    for (const requested of requestedAttempts) {
        const effective = resolveGenerationLimits(
            settings,
            'person-observation',
            requested.maxTokens,
        ).maxTokens;
        if (attempts.some(item => item.maxTokens === effective)) continue;
        attempts.push({ ...requested, maxTokens: effective });
    }
    let lastTruncation = null;

    for (let index = 0; index < attempts.length; index += 1) {
        const attempt = attempts[index];
        try {
            const raw = String(await runWithRetries(
                () => backgroundSimulation(prompt, {
                    maxTokens: attempt.maxTokens,
                    temperature: attempt.temperature,
                    // Person observation must never inherit the foreground preset. It has
                    // its own POV/output contract.
                    taskKind: 'person-observation',
                    // Custom APIs expose finish_reason, so reject MAX_TOKENS/length
                    // immediately instead of accepting a visibly cut-off paragraph.
                    rejectTruncated: true,
                    signal,
                }),
                {
                    retries: Math.min(1, getSettings().autoRetryCount),
                    shouldRetry: error => rateLimitLike(error)
                        || error?.code === 'GENERATION_TIMEOUT'
                        || error?.errorType === 'timeout',
                    ...retryTaskOptions(
                        'person-observation',
                        `person-observation:${currentChatToken()}:${person.id}:${getState().revision}:${attempt.maxTokens}`,
                    ),
                    signal,
                },
            ) || '');
            const filtered = filterNarrativeText(raw, settings).trim();
            if (!filtered) {
                throw new Error('Nội dung Quan sát nhân vật trả về bị trống sau khi lọc thẻ');
            }
            const pollution = personObservationPollutionReason(filtered, person);
            if (pollution) {
                throw new Error(`Đầu ra Quan sát nhân vật bị nhiễm bẩn: ${pollution}`);
            }
            if (!personObservationLooksComplete(filtered)) {
                const error = new Error('Quan sát nhân vật có vẻ bị cắt cụt do độ dài đầu ra, chưa lưu nội dung dở dang');
                error.code = 'OUTPUT_TRUNCATED';
                error.partialText = filtered;
                throw error;
            }
            return filtered;
        } catch (error) {
            if (isAbortError(error)) throw error;
            const truncated = error?.code === 'OUTPUT_TRUNCATED'
                || /输出达到长度上限|输出长度被截断|MAX_TOKENS|finish_reason.?length|đạt giới hạn độ dài|chạm giới hạn độ dài|độ dài đầu ra bị cắt|bị cắt do độ dài|(?:cắt cụt|cắt ngắn) do độ dài/i.test(String(error?.message || error));
            if (!truncated) throw error;
            lastTruncation = error;
            if (index >= attempts.length - 1) break;
            console.warn(`[世界背面] Quan sát nhân vật có vẻ bị cắt cụt, tự động tăng hạn mức đầu ra rồi thử lại (${attempt.maxTokens} → ${attempts[index + 1].maxTokens}）`);
        }
    }

    const reason = String(lastTruncation?.finishReason || '').trim();
    const finalBudget = attempts.at(-1)?.maxTokens || 0;
    throw new Error(
        `Quan sát nhân vật đã chạm giới hạn đầu ra hiện tại${finalBudget ? `（${finalBudget} tokens）` : ''}${reason ? `（${reason}）` : ''}, chưa lưu nội dung dở dang; có thể tăng giới hạn Token của Quan sát nhân vật trong「Giới hạn sinh」rồi thử lại`,
    );
}

async function observePerson(personId, { force = false } = {}) {
    const state = getState();
    const baselineRevision = Number(state.revision || 0);
    const baselineChatToken = currentChatToken();
    const baselineAssistantStamp = latestAssistantSourceStamp();
    const person = state.people.find(item => item.id === personId);
    if (!person) throw new Error('Không tìm thấy nhân vật này');
    if (!isPersonObservationEligible(person, getContext()?.name1 || '')) {
        throw new Error('Nhân vật người chơi không dùng quan sát tức thời nhân vật');
    }
    const cacheKey = personObservationCacheKey(state, person);
    const cached = getStore().personObservations?.[cacheKey];
    if (cached && !force) return cached;
    const settings = getSettings();
    const latest = latestAssistantEntry();
    const narrative = latest
        ? narrativeContext(latest.index, settings.contextTurns)
        : { turns: [] };
    const prompt = buildPersonObservationPrompt(state, person, {
        narrativeTurns: narrative.turns,
        userName: getContext()?.name1 || '',
        includeUserInnerVoice: false,
        playerIdentityAnchor: getPlayerIdentityAnchor(state),
    });

    const controller = new AbortController();
    const activeObservation = {
        controller,
        personId: person.id,
        chatToken: baselineChatToken,
        revision: baselineRevision,
        assistantStamp: baselineAssistantStamp,
    };
    runtime.activeObservation = activeObservation;
    setBusy(true);
    setSyncStatus({
        phase: 'running',
        message: `Đang xem ${person.name} lúc này đang làm gì`,
        error: '',
        attemptedAt: new Date().toISOString(),
    });
    try {
        const text = await generateIndependentPersonObservation(prompt, person, settings, { signal: controller.signal });
        const stale = (
            currentChatToken() !== baselineChatToken
            || Number(getState().revision || 0) !== baselineRevision
            || latestAssistantSourceStamp() !== baselineAssistantStamp
        );
        if (stale) {
            const error = new Error('Thế giới đã đi tiếp trong lúc quan sát rồi～kết quả cũ chưa được lưu, quan sát lại một lần sẽ lấy trạng thái mới nhất làm chuẩn');
            error.code = 'STALE_BACKGROUND_TASK';
            throw error;
        }
        setSyncStatus({
            phase: 'success',
            message: `${person.name} — đã tạo xong Quan sát tức thời`,
            error: '',
            succeededAt: new Date().toISOString(),
            method: runtime.syncStatus.method,
        });
        const result = {
            personId: person.id,
            text,
            worldMinute: state.clock.absoluteMinute,
            cacheKey,
        };
        const store = getStore();
        // Re-inserting an existing key does not refresh its insertion order.
        // A forced refresh could therefore be immediately discarded by the
        // 30-entry cap if this was one of the oldest keys.
        delete store.personObservations[cacheKey];
        store.personObservations[cacheKey] = result;
        const cacheEntries = Object.entries(store.personObservations);
        if (cacheEntries.length > 30) {
            store.personObservations = Object.fromEntries(cacheEntries.slice(-30));
        }
        saveStore(store);
        return result;
    } catch (error) {
        if (isAbortError(error) || controller.signal.aborted) {
            setSyncStatus({
                phase: 'pending',
                message: 'Chính văn mới tới rồi～tạm dừng Quan sát nhân vật cũ, sẽ không lưu kết quả quá hạn',
                error: '',
                method: runtime.syncStatus.method,
            });
            throw error;
        }
        const errorMessage = describeError(error);
        setSyncStatus({
            phase: error?.code === 'STALE_BACKGROUND_TASK' ? 'pending' : 'error',
            message: error?.code === 'STALE_BACKGROUND_TASK'
                ? 'Quan sát nhân vật đã quá hạn, không ghi vào bộ nhớ đệm'
                : 'Quan sát nhân vật tức thời chưa hoàn tất',
            error: errorMessage,
            method: runtime.syncStatus.method,
        });
        throw error;
    } finally {
        if (runtime.activeObservation === activeObservation) runtime.activeObservation = null;
        setBusy(false);
    }
}



async function generatePublicOpinionSnapshot(options = {}) {
    const existing = runtime.publicOpinionRefreshTransaction;
    if (existing?.promise) return existing.promise;

    const transaction = {
        chatToken: currentChatToken(),
        startedAt: Date.now(),
        promise: null,
    };
    runtime.publicOpinionRefreshTransaction = transaction;
    runtime.ui?.render();

    const promise = generatePublicOpinionSnapshotInternal(options)
        .finally(() => {
            if (runtime.publicOpinionRefreshTransaction === transaction) {
                runtime.publicOpinionRefreshTransaction = null;
            }
            runtime.ui?.render();
        });
    transaction.promise = promise;
    return promise;
}

async function generatePublicOpinionSnapshotInternal({ allowDefer = true, ensurePublicWorld = false, settlePublicImpact = true, force = false } = {}) {
    const chatTokenAtStart = currentChatToken();
    if (allowDefer && coreSimulationBusy()) {
        runtime.pendingPublicOpinion = true;
        runtime.publicOpinionStatus = {
            phase: 'queued',
            message: 'Mạch chính của thế giới vẫn đang suy diễn～Dư luận xếp ra sau, đợi trạng thái cốt lõi theo kịp sẽ tự động tiếp tục `(•̀ᴗ•́)و`',
            error: '',
        };
        runtime.ui?.render();
        return null;
    }

    runtime.publicOpinionStatus = {
        phase: 'running',
        message: 'Đang kiểm tra thay đổi của thế giới～',
        error: '',
    };
    runtime.ui?.render();

    let state = getState();
    let candidates = eligiblePublicOpinionEvents(state);
    const publicWorldSweepPlanned = Boolean(
        ensurePublicWorld
        && getSettings().worldSimulationEnabled
        && publicWorldNeedsRefresh(state, candidates)
    );

    // 先把已经公开的世界事件对人物/行业/地点造成的真实后果接进后台。
    // 到期的公共世界巡查会在同一次世界请求里一并承担这项工作，避免
    // “旧影响 + 世界巡查 + 舆情整理”连续打三份 API。
    if (
        settlePublicImpact
        && !publicWorldSweepPlanned
        && pendingPublicImpactEvents(state, { maximum: 8 }).length
    ) {
        runtime.publicOpinionStatus = {
            phase: 'running',
            message: 'Đang kết toán ảnh hưởng của sự kiện công khai lên thế giới～',
            error: '',
        };
        runtime.ui?.render();
        try {
            await runPublicImpactPropagation({ quiet: true, force: true, scheduleOpinion: false });
            state = getState();
            candidates = eligiblePublicOpinionEvents(state);
        } catch (error) {
            if (!isAbortError(error)) {
                console.warn('[世界背面] Lan truyền ảnh hưởng công cộng trước khi làm mới Dư luận thất bại, sẽ dùng tiếp trạng thái đã xác nhận trước đó', error);
            }
        }
    }

    if (publicWorldSweepPlanned) {
        runtime.publicOpinionStatus = {
            phase: 'running',
            message: 'Cho thế giới công cộng đi tuần một vòng～xem khoảng thời gian này lại xảy ra chuyện gì',
            error: '',
        };
        runtime.ui?.render();

        const completed = await runWorldPulseTick({
            reason: 'Người dùng làm mới Dư luận thế giới thực thủ công',
            quiet: true,
            force: true,
            publicCycle: true,
        });

        runtime.publicOpinionStatus = {
            phase: 'running',
            message: completed
                ? 'Thay đổi công cộng và hậu quả trực tiếp lên thế giới đã được nối xong cùng lúc～đang sắp xếp tin tức'
                : 'Lần này thế giới công cộng không ghi trạng thái mới～dùng tiếp nội dung đã xác nhận để sắp xếp tin tức',
            error: '',
        };
        runtime.ui?.render();
        state = getState();
        candidates = eligiblePublicOpinionEvents(state);
    }

    if (currentChatToken() !== chatTokenAtStart) return null;

    const store = getStore();
    const previousCache = normalizePublicOpinionCache(store.publicOpinion || emptyPublicOpinionCache());
    const plan = planPublicOpinionRefresh(state, previousCache, { force });
    const sourceRevision = Number(state.revision || 0);
    const sourceAssistantStamp = latestAssistantSourceStamp();
    const sourceWorldMinute = Number(state.clock?.absoluteMinute ?? -1);
    const sourceEventSignature = plan.sourceEventSignature;
    const generatedAt = new Date().toISOString();

    if (!candidates.length) {
        // Refresh is atomic from the UI's point of view: keep the current rolling
        // feed until a newer valid snapshot exists. "No new public event" is not
        // equivalent to "erase yesterday's world".
        const currentFeed = normalizePublicOpinionCache(store.publicOpinion || emptyPublicOpinionCache());
        runtime.publicOpinionStatus = {
            phase: 'success',
            message: ensurePublicWorld
                ? 'Kiểm tra thế giới công cộng xong～lần này không có thay đổi mới nào đáng đưa tin, tin tức hiện tại tiếp tục được giữ.'
                : 'Hiện không có sự kiện thế giới công khai mới～tin tức hiện có tiếp tục được giữ.',
            error: '',
        };
        runtime.ui?.render();
        return currentFeed;
    }

    if (!plan.due) {
        runtime.pendingPublicOpinion = false;
        runtime.publicOpinionStatus = {
            phase: 'success',
            message: 'Kiểm tra rồi nè～nguồn công khai không có thay đổi mới, thời gian thế giới cũng chưa tới mốc diễn biến Dư luận/tin tức tiếp theo.',
            error: '',
        };
        runtime.ui?.render();
        return previousCache;
    }

    const controller = new AbortController();
    const activePublicOpinion = {
        controller,
        chatToken: chatTokenAtStart,
        sourceRevision,
        assistantStamp: sourceAssistantStamp,
    };
    runtime.activePublicOpinion = activePublicOpinion;
    runtime.pendingPublicOpinion = false;
    runtime.publicOpinionStatus = {
        phase: 'running',
        message: 'Đang sắp xếp tin tức và thảo luận～',
        error: '',
    };
    runtime.ui?.render();

    const settings = getSettings();
    const prompt = buildPublicOpinionPrompt(state, {
        clockLabel: formatWorldClockFactLabel(state),
        previousCache,
        forumElapsedMinutes: Number.isFinite(plan.forumElapsed) ? plan.forumElapsed : 0,
        newsElapsedMinutes: Number.isFinite(plan.newsElapsed) ? plan.newsElapsed : 0,
        allowNews: plan.allowNews,
        allowForums: plan.allowForums,
        reason: plan.reason,
        customInstruction: settings.customSimulationInstruction,
    });
    const baseTokens = 3600;

    try {
        const raw = await runWithRetries(
            attempt => backgroundSimulation(retryJsonPrompt(prompt, attempt), {
                maxTokens: retryTokenBudget(baseTokens, attempt),
                temperature: 0.65,
                taskKind: 'public-opinion',
                rejectTruncated: true,
                signal: controller.signal,
            }),
            {
                retries: Math.min(1, settings.autoRetryCount),
                delayMs: 650,
                shouldRetry: error => rateLimitLike(error)
                    || error?.code === 'GENERATION_TIMEOUT'
                    || error?.errorType === 'timeout'
                    || /JSON|截断|长度上限|empty|No message generated|没有返回最终正文|bị cắt|cắt cụt|giới hạn độ dài|không (?:trả về|có)[^.\n]{0,30}chính văn|cắt ngắn/i.test(String(error?.message || error || '')),
                onRetry: ({ delayMs, rateLimited }) => {
                    if (rateLimited) {
                        runtime.publicOpinionStatus = {
                            phase: 'running',
                            message: `Tuyến Dư luận đang bị giới hạn tốc độ～chờ hạ nhiệt ${cooldownSeconds(delayMs)} giây rồi chỉ tiếp tục đúng lần làm mới này`,
                            error: 'Sẽ không tự động chuyển sang “Dạo chơi tùy ý”, cũng không chạy song song tác vụ dựng lại.',
                        };
                        runtime.ui?.render();
                    }
                },
                ...retryTaskOptions(
                    'public-opinion',
                    `public-opinion:${chatTokenAtStart}:${sourceEventSignature}:${sourceAssistantStamp}`,
                ),
                signal: controller.signal,
            },
        );
        const parsed = extractJsonObject(raw);
        if (!parsed) throw new Error('API Dư luận không trả về JSON có thể phân tích');
        if (controller.signal.aborted) {
            const error = new Error('Tác vụ Dư luận đã bị hủy');
            error.name = 'AbortError';
            throw error;
        }

        const latestOpinionState = getState();
        const stale = (
            currentChatToken() !== chatTokenAtStart
            || publicOpinionEventSignature(latestOpinionState) !== sourceEventSignature
            || Number(latestOpinionState.clock?.absoluteMinute ?? -1) !== sourceWorldMinute
            || latestAssistantSourceStamp() !== sourceAssistantStamp
        );
        if (stale) {
            runtime.pendingPublicOpinion = currentChatToken() === chatTokenAtStart;
            runtime.publicOpinionStatus = {
                phase: 'pending',
                message: 'Thế giới vừa đi thêm một bước nữa～tạm giữ tin tức hiện tại, đang nối bản mới nhất `(｡•̀ᴗ-)✧`',
                error: '',
            };
            runtime.ui?.render();
            scheduleDeferredPublicOpinion(260);
            return null;
        }

        let generatedCache = normalizePublicOpinionPayload(parsed, {
            validEventIds: candidates.map(item => item.id),
            eventVisibilityById: Object.fromEntries(candidates.map(item => [item.id, item.visibility])),
            eventPublicityById: Object.fromEntries(candidates.map(item => [item.id, item.publicity])),
            sourceRevision: state.revision,
            sourceWorldMinute,
            sourceEventSignature,
            forumSourceSignature: plan.forumSourceSignature,
            newsSourceSignature: plan.newsSourceSignature,
            generatedAt,
            lastForumWorldMinute: plan.allowForums
                ? sourceWorldMinute
                : previousCache.lastForumWorldMinute,
            lastNewsWorldMinute: plan.allowNews
                ? sourceWorldMinute
                : previousCache.lastNewsWorldMinute,
        });
        // 代码层再做一次硬门禁：即使模型无视 allow_*，没到新闻/讨论节点的类别
        // 也不会被写入。空数组是合法的“检查后无需变化”，不是生成失败。
        generatedCache = {
            ...generatedCache,
            news: plan.allowNews
                ? generatedCache.news.map(item => ({ ...item, worldSynced: true }))
                : [],
            forums: plan.allowForums ? generatedCache.forums : [],
        };
        // AI 的后续报道已经过本轮时间门槛和公开事实回查，这里直接进入滚动流。
        // 不再拿事件最初的 publicHeadline/publicSummary 覆盖它，否则新闻永远无法演化。
        const latestSnapshot = generatedCache;
        const latestStore = getStore();
        const cache = mergePublicOpinionStream(
            latestStore.publicOpinion || emptyPublicOpinionCache(),
            latestSnapshot,
            {
                maximumNews: 18,
                maximumForums: 12,
            },
        );
        cache.sourceWorldMinute = sourceWorldMinute;
        cache.sourceEventSignature = sourceEventSignature;
        cache.forumSourceSignature = plan.allowForums
            ? plan.forumSourceSignature
            : previousCache.forumSourceSignature;
        cache.newsSourceSignature = plan.allowNews
            ? plan.newsSourceSignature
            : previousCache.newsSourceSignature;
        cache.lastForumWorldMinute = plan.allowForums
            ? sourceWorldMinute
            : previousCache.lastForumWorldMinute;
        cache.lastNewsWorldMinute = plan.allowNews
            ? sourceWorldMinute
            : previousCache.lastNewsWorldMinute;
        latestStore.publicOpinionDismissed = normalizePublicOpinionDismissed(latestStore.publicOpinionDismissed);
        latestStore.publicOpinion = filterDismissedPublicOpinion(
            cache,
            latestStore.publicOpinionDismissed,
        );
        latestStore.publicOpinionListHidden = false;
        saveStore(latestStore);
        refreshInjection();
        if (!cache.news.length && !cache.forums.length) {
            runtime.publicOpinionStatus = {
                phase: 'success',
                message: 'Lượt này không hình thành Dư luận mới nào để hiển thị～',
                error: '',
            };
            runtime.ui?.render();
            return cache;
        }
        runtime.publicOpinionStatus = {
            phase: 'success',
            message: `Đã nối với động thái thế giới mới nhất · hiện có ${cache.news.length} tin tức · ${cache.forums.length} chủ đề diễn đàn`,
            error: '',
        };
        runtime.ui?.render();
        return cache;
    } catch (error) {
        if (isAbortError(error) || controller.signal.aborted) {
            if (currentChatToken() === chatTokenAtStart) {
                runtime.pendingPublicOpinion = true;
                runtime.publicOpinionStatus = {
                    phase: 'queued',
                    message: 'Chính văn mới tới trước rồi～tạm dừng Dư luận cũ, đợi Suy diễn thế giới theo kịp rồi xem bản mới',
                    error: '',
                };
                runtime.ui?.render();
                scheduleDeferredPublicOpinion(260);
            }
            return null;
        }
        if (currentChatToken() === chatTokenAtStart) {
            runtime.publicOpinionStatus = {
                phase: 'error',
                message: 'Lần này chưa bới xong Dư luận QAQ',
                error: describeError(error),
            };
            runtime.ui?.render();
        }
        throw error;
    } finally {
        if (runtime.activePublicOpinion === activePublicOpinion) {
            runtime.activePublicOpinion = null;
        }
    }
}

async function generatePublicOpinionSandbox() {
    const existing = runtime.activePublicOpinionSandbox;
    if (existing?.promise && !existing.controller?.signal?.aborted) {
        return existing.promise;
    }

    const chatTokenAtStart = currentChatToken();
    const state = getState();
    const controller = new AbortController();
    const activeSandbox = {
        controller,
        chatToken: chatTokenAtStart,
        promise: null,
    };
    runtime.activePublicOpinionSandbox = activeSandbox;
    const generatedAt = new Date().toISOString();
    runtime.publicOpinionSandboxStatus = {
        phase: 'running',
        message: 'Đang dạo phố linh tinh～xem hôm nay có chuyện náo nhiệt vụn vặt gì không `(ﾉ◕ヮ◕)ﾉ`',
        error: '',
    };
    runtime.ui?.render();

    const promise = (async () => {
        try {
            const prompt = buildPublicOpinionSandboxPrompt(state, {
                clockLabel: formatWorldClockFactLabel(state),
            });
            const settings = getSettings();
            const sandbox = await runWithRetries(
                async attempt => {
                    const raw = await backgroundSimulation(retryJsonPrompt(prompt, attempt), {
                        maxTokens: retryTokenBudget(2800, attempt),
                        temperature: 0.9,
                        taskKind: 'public-opinion-sandbox',
                        rejectTruncated: true,
                        signal: controller.signal,
                    });
                    const parsed = extractJsonObject(raw);
                    if (!parsed) throw new Error('Dư luận dạo chơi không trả về JSON có thể phân tích');
                    const normalized = normalizePublicOpinionSandboxPayload(parsed, { generatedAt });
                    if (!normalized.news.length && !normalized.forums.length) {
                        throw new Error('Dư luận dạo chơi trả về nội dung trống');
                    }
                    return normalized;
                },
                {
                    retries: Math.min(1, settings.autoRetryCount),
                    delayMs: 520,
                    shouldRetry: error => rateLimitLike(error)
                        || error?.code === 'GENERATION_TIMEOUT'
                        || error?.errorType === 'timeout'
                        || /JSON|空内容|截断|长度上限|empty|No message generated|nội dung trống|bị cắt|cắt cụt|giới hạn độ dài|cắt ngắn/i.test(String(error?.message || error || '')),
                    ...retryTaskOptions(
                        'public-opinion-sandbox',
                        `public-opinion-sandbox:${chatTokenAtStart}:${state.revision}:${generatedAt}`,
                    ),
                    signal: controller.signal,
                },
            );

            if (currentChatToken() !== chatTokenAtStart) return null;
            const store = getStore();
            store.publicOpinionSandbox = sandbox;
            saveStore(store);
            runtime.publicOpinionSandboxStatus = {
                phase: 'success',
                message: `Dạo một vòng thấy ${sandbox.news.length} tin vặt · ${sandbox.forums.length} chủ đề tán gẫu～mấy cái này đều không tính là chính sử đâu nha`,
                error: '',
            };
            runtime.ui?.render();
            return sandbox;
        } catch (error) {
            if (isAbortError(error) || controller.signal.aborted) {
                if (currentChatToken() === chatTokenAtStart) {
                    runtime.publicOpinionSandboxStatus = {
                        phase: 'idle',
                        message: 'Dạo chơi dọn hàng trước nhé～lần sau muốn xem chuyện náo nhiệt thì bấm mình `(｡•̀ᴗ-)✧`',
                        error: '',
                    };
                    runtime.ui?.render();
                }
                return null;
            }
            if (currentChatToken() === chatTokenAtStart) {
                runtime.publicOpinionSandboxStatus = {
                    phase: 'error',
                    message: 'Hôm nay dạo mãi chẳng thấy gì QAQ',
                    error: describeError(error),
                };
                runtime.ui?.render();
            }
            throw error;
        } finally {
            if (runtime.activePublicOpinionSandbox === activeSandbox) {
                runtime.activePublicOpinionSandbox = null;
            }
            runtime.ui?.render();
        }
    })();

    activeSandbox.promise = promise;
    return promise;
}

function clearPublicOpinionSandbox() {
    runtime.activePublicOpinionSandbox?.controller?.abort?.();
    runtime.activePublicOpinionSandbox = null;
    const store = getStore();
    store.publicOpinionSandbox = emptyPublicOpinionSandbox();
    saveStore(store);
    runtime.publicOpinionSandboxStatus = { phase: 'idle', message: 'Tờ báo dạo chơi đã được cất đi～', error: '' };
    runtime.ui?.render();
    return true;
}

function clearPublicOpinionSnapshot() {
    runtime.activePublicOpinion?.controller?.abort?.();
    runtime.activePublicOpinion = null;
    runtime.pendingPublicOpinion = false;
    const store = getStore();
    store.publicOpinion = emptyPublicOpinionCache();
    store.publicOpinionListHidden = true;
    saveStore(store);
    refreshInjection();
    runtime.publicOpinionStatus = {
        phase: 'idle',
        message: 'Danh sách Dư luận đã được cất đi～sự thật thế giới và những ảnh hưởng đã xảy ra vẫn còn nguyên (｡•̀ᴗ-)✧',
        error: '',
    };
    runtime.ui?.render();
    return true;
}


function lingqiWorldDigest(state = getState()) {
    const clock = formatWorldCalendar(state);
    return {
        world: {
            name: String(state.world?.name || ''),
            title: String(state.world?.title || ''),
            detail: String(state.world?.detail || ''),
            background: String(state.world?.background || '').slice(0, 1800),
        },
        clock: formatWorldClockFactLabel(state),
        people: (state.people || [])
            .slice()
            .sort((a, b) => Number(b?.relevance || 0) - Number(a?.relevance || 0))
            .slice(0, 16)
            .map(person => ({
                id: person.id,
                name: person.name,
                location: person.location,
                action: person.action,
                intent: person.intent,
                long_term_goal: person.longTermGoal || person.long_term_goal || '',
                emotional_state: person.emotionalState || person.emotional_state || '',
                knowledge: person.knowledge,
                is_user: Boolean(person.isUser || person.is_user),
            })),
        active_events: (state.events || [])
            .filter(event => ['active', 'waiting', 'ready'].includes(event.status))
            .slice(0, 16)
            .map(event => ({
                id: event.id,
                title: event.title,
                place: event.place,
                status: event.status,
                summary: event.summary,
                cause: event.cause,
                visibility: event.visibility,
                publicity: event.publicity,
            })),
        recent_memory: {
            facts: (state.storyMemory?.facts || [])
                .filter(item => ['active', 'disputed'].includes(item.status))
                .slice(-8)
                .map(item => ({ subject: item.subject, predicate: item.predicate, value: item.value })),
            clues: (state.storyMemory?.clues || [])
                .filter(item => !['resolved', 'discarded'].includes(item.status))
                .slice(-8)
                .map(item => ({ title: item.title, text: item.text, status: item.status })),
        },
        lingqi_notes: activeLingqiNotes(getStore().lingqi || emptyLingqiState()).map(note => ({
            id: note.id,
            paper_text: note.paperText,
            directive: note.directive,
            scope: note.scope,
            strength: note.strength,
            remaining_uses: note.remainingUses,
        })),
    };
}


const LINGQI_SETTING_LABELS = Object.freeze({
    worldSimulationEnabled: 'Suy diễn thế giới',
    worldPromptInjection: 'Công tắc tổng chèn vào chính văn',
    injectionTimeMode: 'Chèn thời gian thế giới',
    injectionWorldBackground: 'Chèn bối cảnh thế giới',
    injectionPeople: 'Chèn trạng thái nhân vật',
    injectionEvents: 'Chèn Mạch ngầm / môi trường thế giới',
    injectionEchoes: 'Chèn Tiếng vọng / hậu quả',
    injectionFacts: 'Chèn sự thật thế giới',
    injectionMemory: 'Chèn ký ức dài hạn',
    injectionPublicOpinion: 'Chèn dư luận',
    injectionSocial: 'Liên lạc ảnh hưởng chính văn',
    socialAutoEnabled: 'Nhân vật chủ động liên lạc',
    memorySystemEnabled: 'Hệ thống ký ức',
    worldAutoEnabled: 'Tự động suy diễn thế giới',
    publicOpinionAutoEnabled: 'Tự động dư luận',
    recordPlayerCharacter: 'Ghi nhận nhân vật người chơi',
    enhancedBackgroundSimulation: 'Tăng cường suy diễn nhân vật nền',
});

function lingqiSettingDisplayValue(key, value) {
    if (key === 'injectionTimeMode') {
        return {
            full: 'Đầy đủ',
            anchor: 'Điểm neo tối thiểu',
            off: 'Tắt',
        }[value] || String(value);
    }
    return value ? 'Bật' : 'Tắt';
}

function validateLingqiSettingValue(key, value) {
    const rule = LINGQI_SAFE_SETTING_KEYS[key];
    if (!rule) return { ok: false, value: null };
    if (rule === 'boolean') {
        if (typeof value === 'boolean') return { ok: true, value };
        const text = String(value ?? '').trim().toLowerCase();
        if (['true', '1', 'on', 'yes', 'bật', 'Bật'].includes(text)) return { ok: true, value: true };
        if (['false', '0', 'off', 'no', 'tắt', 'Tắt'].includes(text)) return { ok: true, value: false };
        return { ok: false, value: null };
    }
    if (rule.startsWith('enum:')) {
        const allowed = rule.slice(5).split(',');
        const text = String(value ?? '').trim();
        return allowed.includes(text)
            ? { ok: true, value: text }
            : { ok: false, value: null };
    }
    return { ok: false, value: null };
}

function lingqiRelevantPeople(state, userText = '') {
    const query = String(userText || '').toLocaleLowerCase();
    const people = Array.isArray(state?.people) ? state.people : [];
    const exact = people.filter(person => {
        const name = String(person?.name || '').trim().toLocaleLowerCase();
        return name && query.includes(name);
    });
    const fallback = people
        .filter(person => !exact.some(item => item.id === person.id))
        .sort((a, b) => Number(b.relevance || 0) - Number(a.relevance || 0))
        .slice(0, Math.max(0, 12 - exact.length));
    return [...exact, ...fallback].slice(0, 12).map(person => ({
        id: person.id,
        name: person.name,
        isUser: Boolean(person.isUser),
        simulationEnabled: person.simulationEnabled !== false,
        locked: Boolean(person.locked),
        location: String(person.location || '').slice(0, 140),
        action: String(person.action || '').slice(0, 220),
        intent: String(person.intent || '').slice(0, 220),
        knowledge: person.knowledge || 'backstage',
        source: person.source || '',
    }));
}

function lingqiRelevantEvents(state, userText = '') {
    const query = String(userText || '').toLocaleLowerCase();
    const events = Array.isArray(state?.events) ? state.events : [];
    return events
        .map(event => {
            const haystack = [
                event?.title,
                event?.place,
                event?.summary,
                ...(event?.actors || []),
            ].join(' ').toLocaleLowerCase();
            let score = ['active', 'waiting', 'ready'].includes(event?.status) ? 20 : 0;
            if (query && haystack && [...query].some(char => char.trim() && haystack.includes(char))) score += 5;
            return { event, score };
        })
        .sort((a, b) => b.score - a.score || Number(b.event?.updatedAt || 0) - Number(a.event?.updatedAt || 0))
        .slice(0, 12)
        .map(({ event }) => ({
            id: event.id,
            title: event.title,
            status: event.status,
            place: event.place,
            summary: String(event.summary || event.expectedResult || event.cause || '').slice(0, 260),
            visibility: event.visibility,
            deliveryState: event.delivery?.state || 'none',
            publicity: event.publicity || 'private',
        }));
}

function buildLingqiButlerContext(userText = '') {
    const state = getState();
    const settings = getSettings();
    const sync = getSyncStatus();
    const connection = getConnectionInfo();
    const lastOperation = getLastCustomApiOperation();
    const clock = formatWorldCalendar(state);
    const help = buildLingqiHelpContext(userText, PLUGIN_VERSION);
    const social = normalizeSocialState(getStore().social || emptySocialState(), state.people || []);
    const socialPeopleById = new Map((state.people || []).map(person => [String(person?.id || ''), person]));
    const snapshot = {
        plugin: {
            version: PLUGIN_VERSION,
            stateSchema: SCHEMA_VERSION,
        },
        world: {
            name: state.world?.name || '',
            title: state.world?.title || '',
            time: clock.stamp,
            anchored: Boolean(state.clock?.anchored),
            revision: state.revision,
            pendingSync: Boolean(sync.narrative?.needsSimulation),
            narrativeSync: {
                status: sync.narrative?.status || 'empty',
                committed: Boolean(sync.narrative?.committed),
                needsSimulation: Boolean(sync.narrative?.needsSimulation),
                pendingTurns: Number(sync.narrative?.pendingTurns || 0),
            },
            needsReconciliation: Boolean(state.needsReconciliation),
            publicCoverage: {
                lastSweepAt: Number(state.worldPulse?.coverage?.lastSweepAt ?? -1),
                lastPublicSweepAt: Number(state.worldPulse?.coverage?.lastPublicSweepAt ?? -1),
                recentScopes: (state.worldPulse?.coverage?.entries || []).slice(0, 6).map(entry => ({
                    label: String(entry?.label || '').slice(0, 120),
                    kind: String(entry?.kind || '').slice(0, 40),
                    lastCheckedAt: Number(entry?.lastCheckedAt ?? -1),
                })),
                customFocus: String(settings.customSimulationInstruction || '').slice(0, 500),
            },
        },
        settings: {
            worldSimulationEnabled: settings.worldSimulationEnabled,
            worldAutoEnabled: settings.worldAutoEnabled,
            enhancedBackgroundSimulation: settings.enhancedBackgroundSimulation,
            recordPlayerCharacter: settings.recordPlayerCharacter,
            worldPromptInjection: settings.worldPromptInjection,
            injectionTimeMode: settings.injectionTimeMode,
            injectionWorldBackground: settings.injectionWorldBackground,
            injectionPeople: settings.injectionPeople,
            injectionEvents: settings.injectionEvents,
            injectionEchoes: settings.injectionEchoes,
            injectionFacts: settings.injectionFacts,
            injectionMemory: settings.injectionMemory,
            injectionPublicOpinion: settings.injectionPublicOpinion,
            memorySystemEnabled: settings.memorySystemEnabled,
            publicOpinionAutoEnabled: settings.publicOpinionAutoEnabled,
            socialAutoEnabled: settings.socialAutoEnabled,
            socialInstantReply: settings.socialInstantReply,
            injectionSocial: settings.injectionSocial,
            autoSimulationMode: settings.autoSimulationMode,
            worldPulseActivity: settings.worldPulseActivity,
            backgroundNpcBudget: settings.backgroundNpcBudget,
            maxOutputTokens: settings.maxOutputTokens,
            generationTimeoutMs: settings.generationTimeoutMs,
        },
        tasks: {
            world: {
                phase: sync.phase,
                message: String(sync.message || '').slice(0, 280),
                error: String(sync.error || '').slice(0, 360),
            },
            active: (sync.activeBackgroundTasks || []).filter(label => label !== '玲七'),
            queuePendingTurns: sync.queue?.pendingTurns || 0,
            memory: {
                phase: sync.memory?.phase || 'idle',
                message: String(sync.memory?.message || '').slice(0, 280),
                pendingAssistantResponses: sync.memory?.pendingAssistantResponses || 0,
            },
            opinion: {
                phase: sync.publicOpinion?.phase || 'idle',
                message: String(sync.publicOpinion?.message || '').slice(0, 260),
                stale: Boolean(sync.publicOpinion?.stale),
                canonRunning: Boolean(sync.publicOpinion?.canonRunning),
            },
        },
        connection: {
            configured: Boolean(connection.configured),
            mode: settings.apiMode,
            api: String(connection.apiLabel || '').slice(0, 120),
            source: String(connection.source || '').slice(0, 120),
            model: redactDiagnosticText(connection.model || ''),
            method: String(connection.method || '').slice(0, 100),
            transport: settings.apiMode === 'custom'
                ? settings.customApiTransport
                : settings.apiMode === 'tavern-profile'
                    ? 'tavern-profile'
                    : 'tavern',
            lastOperation: lastOperation ? {
                phase: lastOperation.phase,
                operation: lastOperation.operation,
                transportStatus: lastOperation.transportStatus,
                upstreamStatus: lastOperation.upstreamStatus,
                errorType: lastOperation.errorType,
                errorSummary: redactDiagnosticText(lastOperation.errorSummary || ''),
                retryAfterMs: Number(lastOperation.retryAfterMs) || 0,
            } : null,
        },
        social: {
            accepted: social.connections.filter(item => item.status === 'accepted').map(item => socialPeopleById.get(item.personId)?.name).filter(Boolean).slice(0, 30),
            incomingRequests: social.connections.filter(item => item.status === 'incoming').map(item => socialPeopleById.get(item.personId)?.name).filter(Boolean).slice(0, 20),
            pendingRequests: social.connections.filter(item => item.status === 'pending').map(item => socialPeopleById.get(item.personId)?.name).filter(Boolean).slice(0, 20),
            removed: social.connections.filter(item => item.status === 'removed').map(item => socialPeopleById.get(item.personId)?.name).filter(Boolean).slice(-20),
            unreadNotices: social.notices.filter(item => !item.readAt).length,
            conversations: social.conversations.length,
            moments: social.moments.length,
        },
        counts: {
            people: state.people?.length || 0,
            activeEvents: (state.events || []).filter(event => ['active', 'waiting', 'ready'].includes(event.status)).length,
            echoes: state.echoes?.length || 0,
            archive: state.archive?.length || 0,
            worldFacts: state.worldFacts?.length || 0,
            memoryFacts: state.storyMemory?.facts?.length || 0,
            memorySummaries: state.storyMemory?.summaries?.length || 0,
            memoryClues: state.storyMemory?.clues?.length || 0,
            consistencyConflicts: state.consistencyConflicts?.length || 0,
            recoveryPoints: listRecoveryPointHeaders(getStore()).length,
        },
        people: lingqiRelevantPeople(state, userText),
        events: lingqiRelevantEvents(state, userText),
    };
    return `${help}\n\n【Trạng thái thời gian thực hiện tại】\n${JSON.stringify(snapshot)}`.slice(0, 22000);
}


const LINGQI_TRIAGE_CATEGORY_LABELS = Object.freeze({
    usage: 'Cách sử dụng',
    settings: 'Cài đặt / cấu hình',
    api: 'API / trung chuyển',
    task: 'Tác vụ nền',
    memory: 'Ký ức',
    people: 'Nhân vật',
    injection: 'Chèn vào chính văn',
    opinion: 'Dư luận / tin tức',
    worldbook: 'Nhập World Info',
    data: 'Tính nhất quán dữ liệu',
    ui: 'Giao diện / tương tác',
    compatibility: 'Tính tương thích',
    performance: 'Hiệu năng / giới hạn tốc độ',
    unknown: 'Chưa phân loại',
});

function lingqiTriageCategoryLabel(category = 'unknown') {
    return LINGQI_TRIAGE_CATEGORY_LABELS[category] || LINGQI_TRIAGE_CATEGORY_LABELS.unknown;
}

function lingqiProviderErrorLooksExternal() {
    const lastOperation = getLastCustomApiOperation();
    if (!lastOperation) return false;
    const status = Number(lastOperation.upstreamStatus || lastOperation.transportStatus) || 0;
    const text = [
        lastOperation.errorType,
        lastOperation.errorSummary,
    ].filter(Boolean).join(' ').toLocaleLowerCase();
    return (
        [401, 403, 408, 409, 425, 429, 500, 502, 503, 504].includes(status)
        || /unauthorized|forbidden|rate.?limit|quota|timeout|upstream|model.?unavailable|overload|provider|额度|限流|鉴权|中转|上游|hạn mức|giới hạn tốc độ|xác thực|trung chuyển/u.test(text)
    );
}

function finalizeLingqiTriage(response, actionResults = [], userText = '') {
    const source = response?.triage && typeof response.triage === 'object'
        ? response.triage
        : {};
    const triage = {
        route: source.route || (response?.needsAuthorHelp ? 'mama' : 'resolved'),
        owner: source.owner || (response?.needsAuthorHelp ? 'unknown' : 'user'),
        category: source.category || 'unknown',
        summary: String(source.summary || '').trim().slice(0, 360),
        checked: (Array.isArray(source.checked) ? source.checked : [])
            .map(item => String(item || '').trim().slice(0, 220))
            .filter(Boolean)
            .slice(0, 4),
        nextStep: String(source.nextStep || '').trim().slice(0, 500),
        reason: String(source.reason || response?.helpReason || '').trim().slice(0, 500),
    };

    // 玲七不能把“教用户怎么用 / 改一个设置”这种问题甩给妈妈。
    if (triage.route === 'mama' && ['usage', 'settings'].includes(triage.category)) {
        triage.route = 'self_service';
        triage.owner = 'user';
        if (!triage.nextStep) {
            triage.nextStep = 'Trước tiên hãy kiểm tra công tắc hoặc chỗ thao tác tương ứng theo hướng dẫn ở trên của 玲七; nếu hành vi thực tế vẫn không khớp với hướng dẫn, hãy quay lại để 玲七 tra tiếp.';
        }
    }

    // 模型已经判断责任在用户自己 / 第三方时，玲七不能仍然把纸条丢给妈妈。
    if (triage.route === 'mama' && triage.owner === 'user') {
        triage.route = 'self_service';
        if (!triage.nextStep) {
            triage.nextStep = 'Trước tiên hãy sửa cài đặt cục bộ hoặc thao tác theo hướng dẫn 玲七 đưa ra; nếu sửa xong vẫn tái hiện, hãy quay lại tra tiếp.';
        }
    }
    if (triage.route === 'mama' && triage.owner === 'provider') {
        triage.route = 'external';
        if (!triage.nextStep) {
            triage.nextStep = 'Trước tiên hãy xử lý vấn đề của API, proxy trung chuyển, model hoặc môi trường bên thứ ba hiện tại; sau khi bên thứ ba bình thường trở lại mà plugin vẫn bất thường thì quay lại tra tiếp.';
        }
    }

    // dev.8 能明确识别世界推演输出截断。这种情况有直接可执行的自助方案，
    // 而且本轮状态已经安全不提交，不需要先占妈妈的反馈。
    const currentSyncError = String(getSyncStatus()?.error || '');
    if (
        triage.route === 'mama'
        && /输出上限|output-limit|OUTPUT_TRUNCATED|没有闭合，疑似被输出上限截断|giới hạn đầu ra/iu.test(
            `${triage.summary}\n${triage.reason}\n${currentSyncError}`,
        )
    ) {
        triage.route = 'self_service';
        triage.owner = 'user';
        triage.category = 'performance';
        triage.nextStep = 'Vào「Nâng cao & bảo trì → Giới hạn sinh」tăng giới hạn Token của mô-đun “Suy diễn thế giới”; nếu mô-đun để 0 thì tăng Giới hạn Token toàn cục. Lượt bị cắt cụt này sẽ không ghi nhân vật, sự kiện, ký ức hay thời gian thế giới.';
    }

    // 明确属于上游/API 的常见错误先去解决接口，不占妈妈的插件反馈。
    const pluginApiSymptom = /插件|按钮|界面|显示|解析|状态不一致|没有触发|未触发|写入|保存|恢复|复活|串聊天|plugin|tiện ích|nút|giao diện|hiển thị|phân tích cú pháp|trạng thái không nhất quán|không kích hoạt|chưa kích hoạt|không được kích hoạt|ghi vào|lưu|khôi phục|hồi sinh|lẫn chat|lẫn cuộc trò chuyện/iu.test(
        `${triage.summary}\n${triage.reason}`,
    );
    if (
        triage.route === 'mama'
        && ['api', 'performance', 'compatibility'].includes(triage.category)
        && !pluginApiSymptom
        && lingqiProviderErrorLooksExternal()
    ) {
        triage.route = 'external';
        triage.owner = 'provider';
        if (!triage.nextStep) {
            triage.nextStep = 'Trước tiên hãy kiểm tra xác thực, hạn mức, giới hạn tốc độ và tình trạng khả dụng của model ở API/proxy trung chuyển hiện tại; nếu bản thân API đã bình thường trở lại mà plugin vẫn bất thường thì quay lại tra plugin tiếp.';
        }
    }

    // 如果玲七刚刚已经成功代办了一个动作，就别同时写纸条告状。
    const actionSucceeded = actionResults.some(text => (
        /已经|开始了|打开|关掉|停下|检查完了|最新一层|đã|bắt đầu rồi|mở|bật|tắt|dừng|kiểm tra xong|tầng mới nhất/iu.test(String(text || ''))
        && !/没弄成|不敢|没认准|没找到|没有拿到结果|关着|先等|chưa làm được|không làm được|không dám|chưa nhận ra|không nhận ra|không tìm thấy|chưa tìm thấy|không lấy được kết quả|chưa lấy được kết quả|đang tắt|đang đóng|chờ đã|đợi đã|chờ trước|đợi trước/iu.test(String(text || ''))
    ));
    if (triage.route === 'mama' && actionSucceeded) {
        triage.route = 'resolved';
        triage.owner = 'user';
        triage.reason = '';
    }

    if (triage.route === 'mama') {
        triage.owner = triage.owner === 'provider' || triage.owner === 'user'
            ? 'unknown'
            : triage.owner;
        if (!triage.summary) {
            triage.summary = String(response?.helpReason || userText || 'Trạng thái hiện có không giải thích được hiện tượng này')
                .trim()
                .slice(0, 360);
        }
        if (!triage.checked.length) {
            triage.checked = [
                'Đã đối chiếu phiên bản plugin hiện tại, các cài đặt liên quan và tác vụ nền đang chạy',
            ];
        }
        if (!triage.reason) {
            triage.reason = 'Kiến thức trợ giúp hiện có và trạng thái thời gian thực đều không giải thích được hiện tượng này, cần mẹ xem kỹ hơn hành vi của plugin.';
        }
    }

    return triage;
}

function buildLingqiSupportPack(userText = '', triage = {}) {
    const question = String(userText || '').trim().slice(0, 1600);
    const category = lingqiTriageCategoryLabel(triage.category);
    const summary = String(triage.summary || question || 'Trạng thái hiện có không giải thích được hiện tượng này').trim().slice(0, 500);
    const checked = (Array.isArray(triage.checked) ? triage.checked : [])
        .map(item => String(item || '').trim())
        .filter(Boolean)
        .slice(0, 4);
    const why = String(triage.reason || '').trim().slice(0, 600);
    return [
        'Mảnh giấy nhỏ 玲七 gửi mẹ',
        `Loại vấn đề: ${category}`,
        `Một câu: ${summary}`,
        checked.length ? `玲\u4e03 đã kiểm tra: ${checked.join('；')}` : '',
        why ? `Vì sao cần mẹ xem: ${why}` : '',
        question ? `Nguyên văn người dùng: ${question}` : '',
        '',
        '—— Dưới đây là thông tin kỹ thuật chỉ cần xem khi dò lỗi ——',
        buildDiagnosticReport(),
    ].filter(Boolean).join('\n');
}

async function copyTextSafely(text) {
    const value = String(text || '');
    if (!value) return false;
    try {
        if (typeof globalThis.navigator?.clipboard?.writeText === 'function') {
            await globalThis.navigator.clipboard.writeText(value);
            return true;
        }
    } catch {
        // Fall through to execCommand.
    }
    const textarea = document.createElement('textarea');
    textarea.value = value;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    const copied = document.execCommand?.('copy');
    textarea.remove();
    return Boolean(copied);
}

function findLingqiPersonTarget(action) {
    const state = getState();
    const personId = String(action?.personId || '').trim();
    const personName = String(action?.personName || '').trim().toLocaleLowerCase();
    if (personId) {
        return state.people.find(person => person.id === personId) || null;
    }
    if (!personName) return null;
    const exact = state.people.filter(person => String(person.name || '').trim().toLocaleLowerCase() === personName);
    return exact.length === 1 ? exact[0] : null;
}

function lingqiDeletionSourceMessages() {
    const state = normalizeLingqiState(getStore().lingqi || emptyLingqiState());
    const messages = [...state.messages];
    // 删除请求本身刚刚才写入玲七聊天；定位“最近/全部/范围”时不要把这句请求
    // 当成用户想删的历史记录。真正执行 all 时仍会把整个聊天清空。
    if (messages.at(-1)?.role === 'user') messages.pop();
    return messages;
}

function resolveLingqiChatDeletionPlan(action = {}) {
    const state = normalizeLingqiState(getStore().lingqi || emptyLingqiState());
    return buildLingqiChatDeletionPlan(lingqiDeletionSourceMessages(), action, state.messages.length);
}

const LINGQI_CONFIRM_ACTION_TYPES = new Set([
    'simulate_latest',
    'refresh_public_world',
    'catch_up_person',
    'delete_lingqi_chat',
    'social_send_message',
    'social_accept_request',
    'social_refuse_request',
    'social_remove_friend',
    'social_refresh_moments',
]);

function lingqiActionConfirmation(action) {
    if (action.type === 'delete_lingqi_chat') {
        const plan = resolveLingqiChatDeletionPlan(action);
        return plan.ok ? plan : { error: plan.message };
    }
    if (action.type === 'simulate_latest') {
        return {
            title: 'Suy diễn chính văn mới nhất?',
            detail: 'Sẽ chạy một lần Suy diễn thế giới; nếu đã theo kịp rồi thì mình không chọc API lặp lại.',
            confirmLabel: 'Suy diễn',
        };
    }
    if (action.type === 'refresh_public_world') {
        return {
            title: 'Ra ngoài tuần tra một vòng?',
            detail: 'Sẽ kiểm tra thế giới công cộng và làm mới Dư luận; cùng một thời điểm thế giới và cùng trọng tâm sẽ được tự động loại trùng.',
            confirmLabel: 'Đi tuần',
        };
    }
    if (action.type === 'catch_up_person') {
        const person = findLingqiPersonTarget(action);
        return {
            title: person ? `Cập nhật tình hình của ${person.name} gần đây?` : 'Cập nhật tình hình gần đây của nhân vật?',
            detail: 'Sẽ gọi riêng một lần kết toán đời sống nhân vật, không đẩy thời gian thế giới tiến lên.',
            confirmLabel: 'Đi xem',
        };
    }
    return null;
}

function queueLingqiActionConfirmation(action) {
    const confirmation = lingqiActionConfirmation(action);
    if (!confirmation) return { queued: false, message: 'Thao tác này hiện chưa có cách xác nhận nào dùng được.' };
    if (confirmation.error) return { queued: false, message: confirmation.error };
    const { action: preparedAction, ...confirmationMeta } = confirmation;
    const queuedAction = clone(preparedAction || action);
    if (queuedAction.type === 'delete_lingqi_chat') {
        const state = normalizeLingqiState(getStore().lingqi || emptyLingqiState());
        queuedAction.chatSnapshotSignature = lingqiChatSnapshotSignature(state.messages);
    }
    runtime.pendingLingqiAction = {
        id: `lingqi_action_${Date.now().toString(36)}`,
        chatToken: currentChatToken(),
        contextEpoch: runtime.contextEpoch,
        action: queuedAction,
        ...confirmationMeta,
    };
    return { queued: true };
}

function sealPendingLingqiChatDeletionSnapshot() {
    const pending = runtime.pendingLingqiAction;
    if (
        pending?.action?.type !== 'delete_lingqi_chat'
        || pending.chatToken !== currentChatToken()
        || pending.contextEpoch !== runtime.contextEpoch
    ) return false;
    const state = normalizeLingqiState(getStore().lingqi || emptyLingqiState());
    pending.action.chatSnapshotSignature = lingqiChatSnapshotSignature(state.messages);
    if (pending.action.deleteAll) {
        pending.action.resolvedCount = state.messages.length;
        pending.title = `Xóa sạch ${state.messages.length} tin nhắn trò chuyện với 玲\u4e03?`;
    }
    return true;
}

async function executeLingqiButlerActions(actions = [], { confirmed = false } = {}) {
    const results = [];
    for (const action of Array.isArray(actions) ? actions.slice(0, 8) : []) {
        try {
            if (LINGQI_CONFIRM_ACTION_TYPES.has(action.type) && !confirmed) {
                if (action.type === 'simulate_latest' && !latestNarrativeSyncSnapshot().needsSimulation) {
                    results.push('Chính văn mới nhất đã theo kịp rồi, không cần chọc API thêm lần nữa.');
                    continue;
                }
                if (action.type === 'catch_up_person' && !findLingqiPersonTarget(action)) {
                    results.push('Người đó mình chưa nhận ra chắc… tên bị trùng hoặc không tìm thấy, mình chưa chạy lung tung đâu.');
                    continue;
                }
                if (runtime.pendingLingqiAction) {
                    results.push('Dưới chân mèo đã đè sẵn một thao tác đang chờ bạn gật đầu rồi～xử lý cái đó trước nhé.');
                    break;
                }
                const queued = queueLingqiActionConfirmation(action);
                if (!queued.queued) {
                    results.push(queued.message || 'Phạm vi này mình chưa nhận ra chắc, tạm chưa đụng lung tung.');
                    continue;
                }
                results.push(action.type === 'delete_lingqi_chat'
                    ? 'Mình khoanh vùng phần cần xóa rồi nè. Bạn xem qua trước, gật đầu xong mới xóa thật.'
                    : action.type.startsWith('social_')
                        ? 'Đây là thao tác sẽ thực sự thay đổi liên lạc hoặc quan hệ. Mình đặt nhân vật và nội dung lên thẻ xác nhận, bạn gật đầu rồi mới làm.'
                        : 'Việc này sẽ gọi model nền một lần. Mình tạm để chân mèo dừng trên nút, đợi bạn gật đầu～');
                break;
            }
            if (action.type === 'delete_lingqi_chat') {
                if (!confirmed) continue;
                const currentStore = getStore();
                const state = normalizeLingqiState(currentStore.lingqi || emptyLingqiState());
                if (
                    !action.chatSnapshotSignature
                    || action.chatSnapshotSignature !== lingqiChatSnapshotSignature(state.messages)
                ) {
                    results.push('Nội dung chat đã thay đổi trong lúc xác nhận, mình chưa xóa gì cả. Bạn nói lại phạm vi cần xóa nhé.');
                    continue;
                }
                const ids = new Set(Array.isArray(action.resolvedMessageIds) ? action.resolvedMessageIds : []);
                const before = state.messages.length;
                if (action.deleteAll) {
                    state.messages = [];
                } else {
                    state.messages = state.messages.filter(message => !ids.has(message.id));
                }
                const removed = Math.max(0, before - state.messages.length);
                state.updatedAt = new Date().toISOString();
                currentStore.lingqi = state;
                saveStore(currentStore, { immediate: true });
                results.push(removed
                    ? `Đã xóa ${removed} tin nhắn chat với 玲七. Ký ức dài hạn không bị động đến.`
                    : 'Đoạn ghi chép đó không còn ở đây nữa, mình không xóa lung tung thứ khác.');
                continue;
            }
            if (action.type === 'update_setting') {
                const key = String(action.setting || '');
                const checked = validateLingqiSettingValue(key, action.value);
                if (!checked.ok) {
                    results.push(`Cài đặt này mình không dám đụng bừa: ${key || 'chưa nhìn rõ tên'}。`);
                    continue;
                }
                await handleUiAction('update-settings', { [key]: checked.value });
                results.push(`${LINGQI_SETTING_LABELS[key] || key} giờ đã là ${lingqiSettingDisplayValue(key, checked.value)}。`);
                continue;
            }
            if (action.type === 'set_person_simulation') {
                const person = findLingqiPersonTarget(action);
                if (!person) {
                    results.push('Người đó mình chưa nhận ra chắc… tên bị trùng hoặc không tìm thấy, mình chưa sửa bừa đâu.');
                    continue;
                }
                if (person.isUser) {
                    results.push('Đây là nhân vật người chơi. Có ghi nhận user hay không thì dùng công tắc “Ghi nhận nhân vật người chơi”, không lấy công tắc suy diễn nhân vật ra sửa ép.');
                    continue;
                }
                const next = clone(getState());
                const target = next.people.find(item => item.id === person.id);
                if (!target) {
                    results.push('Nhân vật vừa thấy lúc nãy biến mất rồi, tạm chưa động vào.');
                    continue;
                }
                target.simulationEnabled = Boolean(action.enabled);
                target.updatedAt = next.clock.absoluteMinute;
                commitManualState(next, `${target.name} — suy diễn nhân vật nền: ${action.enabled ? 'Bật' : 'Tắt'}。`);
                results.push(`${target.name} — suy diễn nền đã được ${action.enabled ? 'bật' : 'tắt'}。`);
                continue;
            }
            if (action.type === 'prioritize_person') {
                const person = findLingqiPersonTarget(action);
                if (!person || person.isUser) {
                    results.push('Người đó mình chưa nhận ra chắc, hoặc đó là nhân vật người chơi… cái này tạm chưa xếp bừa.');
                    continue;
                }
                setPersonLifePriority(person.id, action.enabled !== false);
                results.push(action.enabled === false
                    ? `${person.name} không còn giữ vị trí ưu tiên ở lượt sau.`
                    : `${person.name} đã được xếp lên đầu lượt sau rồi～không gọi API thêm.`);
                continue;
            }
            if (action.type === 'catch_up_person') {
                const person = findLingqiPersonTarget(action);
                if (!person || person.isUser) {
                    results.push('Người đó mình chưa nhận ra chắc, tạm chưa bù bừa.');
                    continue;
                }
                await runPersonLifeCatchUp(person.id);
                results.push(`${person.name} — tình hình gần đây đã được bù xong～thời gian thế giới không bị vặn tới.`);
                continue;
            }
            if (action.type === 'social_send_message') {
                const person = findLingqiPersonTarget(action);
                if (!person || person.isUser) {
                    results.push('Tai mình chưa nghe rõ là nhân vật liên lạc nào, tin nhắn này mình vẫn đè dưới chân mèo, chưa gửi.');
                    continue;
                }
                let socialStore = getStore();
                socialStore.social = openDirectConversation(socialStore.social, person, socialStore.currentState.people);
                const conversationId = socialStore.social.activeConversationId;
                saveStore(socialStore, { immediate: true });
                const sent = await sendSocialMessage(conversationId, action.text);
                results.push(sent?.replyCount
                    ? `Tin nhắn đã được gửi giúp bạn tới chỗ ${person.name} rồi～mình tha về được ${sent.replyCount} phản hồi.`
                    : `Tin nhắn đã được gửi giúp bạn tới chỗ ${person.name} rồi. Lần này đối phương chưa trả lời, mình không hối thay bạn đâu.`);
                continue;
            }
            if (['social_accept_request', 'social_refuse_request'].includes(action.type)) {
                const person = findLingqiPersonTarget(action);
                if (!person || person.isUser) {
                    results.push('Người gửi lời mời kết bạn mình chưa nhận ra chắc, tạm lấy chân mèo đè lại, chưa xử lý bừa.');
                    continue;
                }
                const socialStore = getStore();
                const accept = action.type === 'social_accept_request';
                socialStore.social = respondIncomingFriendRequest(socialStore.social, socialStore.currentState, person.id, accept);
                saveStore(socialStore, { immediate: true });
                results.push(accept
                    ? `${person.name} — lời mời kết bạn đã được chấp nhận theo xác nhận của bạn. Giờ người đó đã nằm trong danh bạ rồi～`
                    : `${person.name} — lời mời kết bạn đã bị từ chối theo xác nhận của bạn. Bản ghi quan hệ mình cũng giữ lại rồi.`);
                continue;
            }
            if (action.type === 'social_remove_friend') {
                const person = findLingqiPersonTarget(action);
                if (!person || person.isUser) {
                    results.push('Người cần hủy quan hệ mình chưa nhận ra chắc, tạm chưa động vào.');
                    continue;
                }
                const socialStore = getStore();
                socialStore.social = removeSocialFriend(socialStore.social, socialStore.currentState, person.id, {
                    source: 'lingqi-user-request',
                    reason: 'Người dùng xác nhận xóa bạn thông qua 玲七',
                });
                saveStore(socialStore, { immediate: true });
                refreshInjection();
                results.push(`Đã hủy quan hệ bạn bè với ${person.name} theo xác nhận của bạn. Tin nhắn cũ và nhóm chat chung vẫn còn, mình không đụng thêm gì.`);
                continue;
            }
            if (action.type === 'social_refresh_moments') {
                const refreshed = await refreshSocialMoments();
                results.push(refreshed?.postCount
                    ? `Mình ngồi canh bên cửa sổ Khoảnh khắc về rồi đây～thấy ${refreshed.postCount} bài đăng mới${refreshed.imageCount ? ', trong đó có một bài còn kèm ảnh' : ''}。`
                    : 'Mình canh một vòng rồi, lần này không có bạn bè nào muốn đăng bài. Yên ắng cũng là bình thường, mình không bịa thay họ.');
                continue;
            }
            if (action.type === 'simulate_latest') {
                const narrative = latestNarrativeSyncSnapshot();
                if (!narrative.needsSimulation) {
                    results.push('Chính văn mới nhất đã theo kịp rồi, không suy diễn lặp lại.');
                    continue;
                }
                const result = await requestManualWorldSimulation();
                results.push(result?.queued
                    ? 'Chính văn mới nhất đã được xếp hàng an toàn, tác vụ phía trước xong là sẽ suy diễn tiếp.'
                    : result?.started
                        ? 'Chính văn mới nhất đã suy diễn xong rồi～'
                        : 'Lần này không khởi động Suy diễn thế giới mới.');
                continue;
            }
            if (action.type === 'refresh_public_world') {
                await generatePublicOpinionSnapshot({
                    allowDefer: true,
                    ensurePublicWorld: true,
                    settlePublicImpact: true,
                    force: false,
                });
                results.push(['queued', 'pending'].includes(runtime.publicOpinionStatus?.phase)
                    ? 'Lượt bên ngoài này tạm xếp hàng an toàn rồi～tác vụ thế giới phía trước xong, mình sẽ đi tuần tiếp, không mở trùng thêm bản nào.'
                    : 'Bên ngoài tuần xong rồi～thay đổi công cộng và Dư luận cần kết toán đã nối xong; không có gì mới thì mình không bịa.');
                continue;
            }
            if (action.type === 'cancel_simulation') {
                const cancelled = cancelActiveSimulation();
                results.push(cancelled ? 'Suy diễn thế giới hiện tại đã dừng lại.' : 'Hiện không có Suy diễn thế giới nào đang chạy.');
                continue;
            }
            if (action.type === 'cancel_background_tasks') {
                const result = cancelActiveBackgroundTasks({ preserveLingqi: true });
                results.push(
                    result.cancelled
                        ? `Các tác vụ nền khác đã dừng: ${result.labels.filter(label => label !== '玲七').join('、') || 'không có tác vụ nào khác'}。`
                        : 'Hiện không có tác vụ nền nào khác đang chạy.',
                );
                continue;
            }
            if (action.type === 'check_world_state') {
                const result = await checkAndCorrectWorldState();
                if (!result) {
                    results.push('Lần kiểm tra sự thật này không nhận được kết quả.');
                } else if (result.applied?.length || result.removedEventIds?.length) {
                    results.push(`Kiểm tra xong: đã sửa ${result.applied?.length || 0} mục${result.removedEventIds?.length ? `, hủy ${result.removedEventIds.length} mục phái sinh chưa xảy ra` : ''}。`);
                } else {
                    results.push(result.skipped
                        ? `Kiểm tra xong, có ${result.skipped} mục không đủ bằng chứng, mình không để nó sửa bừa.`
                        : 'Kiểm tra xong, không phát hiện mâu thuẫn rõ ràng nào cần tự động sửa.');
                }
                continue;
            }
            if (action.type === 'organize_memory') {
                const settings = getSettings();
                if (!settings.memorySystemEnabled) {
                    results.push('Hệ thống ký ức đang tắt, chưa bật nó lên thì mình không sắp xếp được.');
                    continue;
                }
                if (runtime.historyProgress.phase === 'running') {
                    results.push(runtime.historyProgress.kind === 'world-bootstrap'
                        ? 'Đang làm Truy hồi lịch sử thế giới, mình tạm không chen đường nó.'
                        : 'Ký ức đang được sắp xếp rồi.');
                    continue;
                }
                if (coreSimulationBusy()) {
                    results.push('Vẫn còn Suy diễn thế giới/kết toán đang chạy, đợi nó xong rồi mới sắp xếp ký ức, kẻo hai bản trạng thái ghi đè lẫn nhau.');
                    continue;
                }
                const context = getContext();
                if (!(context?.chat?.length > 0)) {
                    results.push('Đoạn chat hiện tại chưa có chính văn để sắp xếp.');
                    continue;
                }
                if (unindexedAssistantCount() <= 0 && !planMemoryRollup(getState())) {
                    results.push('Ký ức đã sắp xếp tới tầng mới nhất rồi, hiện không có gì mới cần thu.');
                    continue;
                }

                const startMemoryMaintenance = () => {
                    void scanStoryMemoryHistory({
                        automatic: false,
                        maximumBatches: Number.POSITIVE_INFINITY,
                        skipConfirmation: true,
                    }).catch(error => {
                        if (!isAbortError(error)) {
                            console.warn('[世界背面] 玲七 làm hộ việc sắp xếp ký ức thất bại', error);
                            toast(`Sắp xếp ký ức không thành: ${describeError(error)}`, 'error');
                        }
                    });
                };

                // 如果这条动作来自玲七模型回复，先让玲七自己的请求正常收尾，
                // 再启动记忆任务，避免玲七 finally 把记忆任务的 busy 状态误清掉。
                if (runtime.activeLingqi && !runtime.activeLingqi.controller?.signal?.aborted) {
                    window.setTimeout(startMemoryMaintenance, 0);
                } else {
                    startMemoryMaintenance();
                }
                results.push('Sắp xếp ký ức đã bắt đầu. Đây không phải Truy hồi lịch sử thế giới, chỉ chạy quy trình sắp xếp ký ức dài hạn hiện có.');
            }
        } catch (error) {
            results.push(`Việc này chưa làm được: ${describeError(error)}`);
        }
    }
    return results;
}

async function confirmLingqiPendingAction() {
    const pending = runtime.pendingLingqiAction;
    if (
        !pending
        || pending.chatToken !== currentChatToken()
        || pending.contextEpoch !== runtime.contextEpoch
    ) {
        runtime.pendingLingqiAction = null;
        throw new Error('Thao tác vừa rồi không còn thuộc đoạn chat hiện tại nữa～');
    }
    runtime.pendingLingqiAction = null;
    runtime.lingqiStatus = { phase: 'running', message: '玲七 đang thò chân mèo ra làm……', error: '' };
    runtime.ui?.render();
    const results = await executeLingqiButlerActions([pending.action], { confirmed: true });
    if (
        pending.chatToken !== currentChatToken()
        || pending.contextEpoch !== runtime.contextEpoch
    ) return results;
    const text = results.join('\n') || 'Xong rồi nè～';
    const store = getStore();
    const isChatDelete = pending.action?.type === 'delete_lingqi_chat';
    const chatDeleteFailed = isChatDelete && results.some(item => /没有删除|没有再乱删|失败|không xóa|chưa xóa|thất bại|không có gì bị xóa/iu.test(String(item || '')));
    if (!(isChatDelete && pending.action?.deleteAll && !chatDeleteFailed)) {
        store.lingqi = addLingqiMessage(store.lingqi || emptyLingqiState(), 'assistant', text);
    } else {
        store.lingqi = normalizeLingqiState(store.lingqi || emptyLingqiState());
    }
    store.lingqi.mascotState = chatDeleteFailed || results.some(item => /没|失败|不敢|不能|không|chưa|thất bại/iu.test(item)) ? 'hold' : 'happy';
    saveStore(store, { immediate: true });
    runtime.lingqiStatus = {
        phase: chatDeleteFailed ? 'error' : 'success',
        message: isChatDelete ? (results[0] || 'Lịch sử chat đã dọn xong rồi～') : '玲七 tiện tay làm xong rồi～',
        error: '',
    };
    if (isChatDelete) toast(results[0] || 'Lịch sử chat với 玲七 đã dọn xong rồi～', chatDeleteFailed ? 'error' : 'success');
    runtime.ui?.render();
    return results;
}

function dismissLingqiPendingAction() {
    if (!runtime.pendingLingqiAction) return false;
    runtime.pendingLingqiAction = null;
    runtime.lingqiStatus = { phase: 'idle', message: 'Tạm không đụng nữa, rụt chân mèo về rồi～', error: '' };
    runtime.ui?.render();
    return true;
}



function resolveCompletedLingqiMascotState(preferred = 'watch', {
    proposal = null,
    triage = null,
    actionResults = [],
} = {}) {
    const normalized = ['idle', 'watch', 'note', 'confused', 'happy', 'hold'].includes(preferred)
        ? preferred
        : 'watch';
    const resultText = (Array.isArray(actionResults) ? actionResults : [])
        .map(value => String(value || ''))
        .join('\n');

    // Actual execution result outranks the model's pre-action guess.
    if (
        /没弄成|不敢乱碰|没认准|没找到|不见了|没有拿到结果|先等它结束|关着.+没法|不能|失败|chưa làm được|không làm được|không dám|chưa nhận ra|không nhận ra|không tìm thấy|chưa tìm thấy|không lấy được kết quả|chưa lấy được kết quả|biến mất|không thấy đâu|(?:chờ|đợi) nó kết thúc|đang tắt.+không thể|không thể|thất bại/iu.test(resultText)
    ) {
        return 'hold';
    }
    if (proposal) return 'note';
    if (triage?.route === 'mama') {
        return ['confused', 'hold'].includes(normalized) ? normalized : 'confused';
    }
    if (/记忆整理已经开始|记忆已经在整理|sắp xếp ký ức đã bắt đầu|đã bắt đầu sắp xếp ký ức|ký ức đang được sắp xếp|đang sắp xếp ký ức/iu.test(resultText)) return 'note';
    if (
        resultText
        && /已经(?:打开|关掉|开启|关闭|停|开始)|检查完了|修正\s*\d+\s*项|停下来了|đã (?:mở|tắt|bật|đóng|dừng|bắt đầu)|kiểm tra xong|sửa\s*\d+\s*mục|dừng lại rồi/iu.test(resultText)
    ) {
        return 'happy';
    }
    return normalized;
}

function lingqiLocalPersonSummary(person) {
    if (!person) return 'Người này mình chưa nhận ra chắc… có thể tên bị trùng, hoặc mục Nhân vật chưa có người này.';
    const parts = [
        `${person.name}${person.isUser ? ' (nhân vật người chơi)' : ''}`,
        `Vị trí: ${String(person.location || 'chưa ghi rõ').trim()}`,
        `Đang làm: ${String(person.action || 'không có hành động rõ ràng').trim()}`,
        `Ý định: ${String(person.intent || 'không có ghi nhận rõ ràng').trim()}`,
        person.isUser
            ? 'Cách ghi nhận: chỉ lưu trạng thái khách quan đã được chính văn xác nhận rõ là đã xảy ra'
            : `Suy diễn nền: ${person.simulationEnabled === false ? 'đã tắt' : 'Bật'}${person.lifeTickPriority ? ', ưu tiên lượt sau' : ''}`,
        person.locked ? 'Trạng thái: Đã khóa, nền sẽ không tùy tiện sửa trạng thái cốt lõi' : '',
    ].filter(Boolean);
    return parts.join('\n');
}

const LINGQI_GUIDE_SETTING_LABELS = Object.freeze({
    memoryAutoIndexInterval: 'Khoảng cách sắp xếp ký ức',
    maxOutputTokens: 'Giới hạn Token toàn cục',
    generationTimeoutMs: 'Thời gian chờ tối đa toàn cục',
    uiScale: 'Cỡ chữ giao diện',
    orbEnabled: 'Hiện bóng nổi',
    orbEdgeHide: 'Bóng nổi thu gọn bám mép',
    theme: 'Sáng/tối giao diện',
});

function lingqiGuideSettingValue(key, value) {
    if (key === 'injectionTimeMode') return lingqiSettingDisplayValue(key, value);
    if (key === 'memoryAutoIndexInterval') return Number(value) > 0 ? `Mỗi ${Number(value)} lượt` : 'Thủ công';
    if (key === 'maxOutputTokens') return Number(value) > 0 ? String(Number(value)) : 'Tự động';
    if (key === 'generationTimeoutMs') return Number(value) > 0 ? `${Math.round(Number(value) / 1000)} giây` : 'Tự động';
    if (key === 'uiScale') return ({ compact: 'Gọn', comfortable: 'Tiêu chuẩn', large: 'Chữ lớn' }[value] || String(value));
    if (key === 'theme') return ({ auto: 'Tự động', day: 'Ban ngày', night: 'Ban đêm' }[value] || String(value));
    if (typeof value === 'boolean') return value ? 'Bật' : 'Tắt';
    return String(value ?? 'Chưa đặt');
}

function lingqiLocalWorldDiagnosis() {
    const settings = getSettings();
    const sync = getSyncStatus();
    const narrative = latestNarrativeSyncSnapshot();
    const connection = getConnectionInfo();
    const lastOperation = getLastCustomApiOperation();

    if (!settings.worldSimulationEnabled) {
        return 'Tìm ra nguyên nhân rồi: công tắc tổng Suy diễn thế giới hiện đang tắt. Suy diễn tự động lẫn thủ công đều sẽ không chạy bình thường.';
    }
    if (!connection.configured) {
        return 'Tìm ra nguyên nhân rồi: hiện không có kết nối model nền nào dùng được. Hãy cấu hình API / kết nối Tavern của 世界背面 trước.';
    }
    if (sync.phase === 'running') {
        return `Không bị kẹt đâu, Suy diễn thế giới đang chạy.${sync.message ? `\nHiện tại: ${String(sync.message).slice(0, 220)}` : ''}`;
    }
    if ((sync.queue?.pendingTurns || 0) > 0) {
        return `Không mất đâu, trong hàng đợi vẫn còn ${sync.queue.pendingTurns} lượt chờ xử lý. Tác vụ nền phía trước xong sẽ tiếp tục.`;
    }
    if (sync.error) {
        return `Tác vụ thế giới gần nhất đã thất bại: ${String(sync.error).slice(0, 360)}\nMình chỉ báo lỗi thực sự còn lưu lại, không đoán nguyên nhân thay API.`;
    }
    if (lastOperation && lastOperation.phase === 'error') {
        const status = Number(lastOperation.upstreamStatus || lastOperation.transportStatus) || '';
        const detail = redactDiagnosticText(lastOperation.errorSummary || lastOperation.errorType || 'Phía upstream không để lại nguyên nhân đọc được');
        return `Yêu cầu nền gần nhất thất bại${status ? `（${status}）` : ''}：${detail}`;
    }
    if (narrative.needsSimulation && !settings.worldAutoEnabled) {
        return `Chính văn mới nhất chưa được suy diễn, nhưng Tự động suy diễn thế giới đang tắt. Hiện có ${narrative.pendingTurns || 1} lượt đang chờ suy diễn thủ công.`;
    }
    if (narrative.needsSimulation) {
        return `Chính văn mới nhất chưa theo kịp, hiện có ${narrative.pendingTurns || 1} lượt chờ suy diễn. Suy diễn tự động đang bật; nếu mãi không khởi động, hãy kiểm tra xem có tác vụ nền nào khác đang chiếm hàng đợi không.`;
    }
    return 'Mình đã đối chiếu công tắc, kết nối, tác vụ, hàng đợi và ảnh chụp chính văn mới nhất: hiện đã theo kịp, không thấy bị kẹt hay thất bại.';
}

function resolveLingqiLocalQuery(request, { state, settings, sync, clock }) {
    if (!request) return null;
    if (request.type === 'list_skills') {
        return { reply: buildLingqiSkillMenuText(), mascotState: 'happy', actions: [] };
    }
    if (request.type === 'setting_guide') {
        const guide = LINGQI_SETTING_GUIDES.find(item => item.id === request.guideId);
        if (!guide) return null;
        const current = guide.keys
            .map(key => `· ${LINGQI_SETTING_LABELS[key] || LINGQI_GUIDE_SETTING_LABELS[key] || key}：${lingqiGuideSettingValue(key, settings[key])}`)
            .join('\n');
        const reply = [
            `${guide.title} tìm ở đây: ${guide.path}`,
            current ? `\nCài đặt hiện tại của bạn:\n${current}` : '',
            `\nNó điều khiển gì: ${guide.meaning}`,
            `\nChọn thế nào:\n${guide.choices.map(item => `· ${item}`).join('\n')}`,
            `\nGợi ý của mình: ${guide.recommendation}`,
            guide.delegable ? '\nCác công tắc an toàn trong này, bạn cũng có thể nói thẳng với mình “bật / tắt / đổi sang mức nào”, mình sẽ đối chiếu trước rồi làm hộ.' : '',
        ].filter(Boolean).join('');
        return { reply, mascotState: 'watch', actions: [] };
    }
    if (request.type === 'status_overview') {
        const narrative = latestNarrativeSyncSnapshot();
        const activeTasks = (sync.activeBackgroundTasks || []).filter(label => label !== '玲七');
        const disabledPeople = (state.people || []).filter(person => !person.isUser && person.simulationEnabled === false).length;
        const lines = [
            `Thời gian thế giới: ${state.clock?.anchored ? clock.stamp : 'chưa ghim chắc'}`,
            `Chính văn mới nhất: ${narrative.needsSimulation ? `chờ suy diễn ${narrative.pendingTurns || 1} lượt` : 'đã theo kịp'}`,
            `Tác vụ nền: ${activeTasks.length ? activeTasks.join('、') : 'rảnh'}${sync.queue?.pendingTurns ? `; hàng đợi ${sync.queue.pendingTurns} lượt` : ''}`,
            `Nhân vật: ${state.people?.length || 0} người${disabledPeople ? `, trong đó ${disabledPeople} người tắt suy diễn nền` : ''}`,
            `Mạch ngầm: ${(state.events || []).filter(event => ['active', 'waiting', 'ready'].includes(event.status)).length} đang hoạt động; Tiếng vọng ${state.echoes?.length || 0} mục`,
            `Ký ức: sự thật ${state.storyMemory?.facts?.length || 0}, tóm tắt ${state.storyMemory?.summaries?.length || 0}, manh mối ${state.storyMemory?.clues?.length || 0}`,
            sync.error ? `Lỗi gần nhất: ${String(sync.error).slice(0, 260)}` : '',
        ].filter(Boolean);
        return { reply: `Mình đã tuần tra một vòng.\n${lines.join('\n')}`, mascotState: sync.error ? 'hold' : 'watch', actions: [] };
    }
    if (request.type === 'list_people') {
        const people = (state.people || [])
            .slice()
            .sort((a, b) => Number(b.relevance || 0) - Number(a.relevance || 0));
        if (!people.length) return { reply: 'Mục Nhân vật hiện vẫn còn trống.', mascotState: 'idle', actions: [] };
        const shown = people.slice(0, 18).map(person => (
            `· ${person.name}${person.isUser ? ' (người chơi)' : person.simulationEnabled === false ? ' (tắt suy diễn)' : ''}｜${person.location || 'chưa ghi vị trí'}｜${person.action || 'chưa có hành động'}`
        ));
        if (people.length > shown.length) shown.push(`· Còn ${people.length - shown.length} người nữa, gọi đích danh hỏi mình sẽ chính xác hơn.`);
        return { reply: `Ở đây có ${people.length} nhân vật:\n${shown.join('\n')}`, mascotState: 'watch', actions: [] };
    }
    if (request.type === 'person_status') {
        const person = findLingqiPersonTarget(request);
        return { reply: lingqiLocalPersonSummary(person), mascotState: person ? 'watch' : 'confused', actions: [] };
    }
    if (request.type === 'diagnose_person') {
        const person = findLingqiPersonTarget(request);
        if (!person) return { reply: lingqiLocalPersonSummary(null), mascotState: 'confused', actions: [] };
        const reasons = [];
        if (person.isUser) reasons.push('Đây là nhân vật người chơi, không đi theo suy diễn nhân vật nền như NPC thường');
        if (!settings.worldSimulationEnabled) reasons.push('Công tắc tổng Suy diễn thế giới đang tắt');
        if (person.simulationEnabled === false) reasons.push('Công tắc suy diễn nền riêng của nhân vật này đang tắt');
        if (!person.isUser && !settings.enhancedBackgroundSimulation) reasons.push('Tăng cường suy diễn nhân vật nền đang tắt, nhân vật ngoài ống kính chỉ được kết toán theo hạn định thông thường và mức liên quan');
        if ((sync.activeBackgroundTasks || []).length) reasons.push(`Nền hiện đang xử lý: ${sync.activeBackgroundTasks.join('、')}`);
        const diagnosis = reasons.length
            ? `Mình tìm thấy những điều kiện có thể ảnh hưởng trực tiếp đến việc cập nhật nhân vật này:\n${reasons.map(item => `· ${item}`).join('\n')}`
            : 'Trong công tắc và trạng thái tác vụ không tìm thấy nguyên nhân nào chứng minh trực tiếp được. Mình sẽ không đoán bừa; cũng có thể nhân vật này chỉ là chưa tới hạn, hoặc khoảng thời gian này thật sự không có thay đổi trạng thái.';
        return {
            reply: `${diagnosis}\n\n${lingqiLocalPersonSummary(person)}`,
            mascotState: reasons.length ? 'watch' : 'confused',
            actions: [],
        };
    }
    if (request.type === 'recent_events') {
        const events = (state.events || [])
            .filter(event => ['active', 'waiting', 'ready'].includes(event.status))
            .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
        if (!events.length) return { reply: 'Hiện không có Mạch ngầm nào đang hoạt động. Yên ắng cũng là bình thường, không bịa ra một cái.', mascotState: 'idle', actions: [] };
        const shown = events.slice(0, 8).map(event => (
            `· ${event.title || 'Sự kiện chưa đặt tên'}｜${event.status || 'active'}｜${event.place || 'chưa rõ địa điểm'}\n  ${String(event.summary || event.cause || event.expectedResult || 'chưa có tóm tắt').slice(0, 180)}`
        ));
        return { reply: `Hiện có ${events.length} Mạch ngầm đang hoạt động:\n${shown.join('\n')}`, mascotState: 'watch', actions: [] };
    }
    if (request.type === 'memory_status') {
        const memory = state.storyMemory || {};
        const pending = Number(sync.memory?.pendingAssistantResponses || 0);
        const lines = [
            `Sự thật dài hạn: ${memory.facts?.length || 0}`,
            `Tóm tắt phân tầng: ${memory.summaries?.length || 0}`,
            `Manh mối đang mở: ${(memory.clues || []).filter(item => !['resolved', 'discarded'].includes(item.status)).length}`,
            `Chính văn chờ sắp xếp: ${pending}`,
            `Tác vụ ký ức: ${sync.memory?.phase || 'idle'}${sync.memory?.message ? `｜${String(sync.memory.message).slice(0, 180)}` : ''}`,
            `Hệ thống ký ức: ${settings.memorySystemEnabled ? 'Bật' : 'Tắt'}; chèn vào chính văn: ${settings.injectionMemory ? 'Bật' : 'Tắt'}`,
        ];
        return { reply: `Hộp ký ức hiện giờ thế này:\n${lines.join('\n')}`, mascotState: 'note', actions: [] };
    }
    if (request.type === 'settings_overview') {
        const keys = [
            'worldSimulationEnabled', 'worldAutoEnabled', 'enhancedBackgroundSimulation',
            'recordPlayerCharacter', 'worldPromptInjection', 'injectionTimeMode',
            'injectionPeople', 'injectionEvents', 'injectionMemory', 'injectionPublicOpinion', 'injectionSocial',
            'socialAutoEnabled', 'memorySystemEnabled', 'publicOpinionAutoEnabled',
        ];
        const lines = keys.map(key => `· ${LINGQI_SETTING_LABELS[key]}：${lingqiSettingDisplayValue(key, settings[key])}`);
        return { reply: `Các công tắc thường dùng:\n${lines.join('\n')}`, mascotState: 'watch', actions: [] };
    }
    if (request.type === 'social_overview') {
        const social = normalizeSocialState(getStore().social || emptySocialState(), state.people || []);
        const accepted = social.connections.filter(item => item.status === 'accepted');
        const incoming = social.connections.filter(item => item.status === 'incoming');
        const pending = social.connections.filter(item => item.status === 'pending');
        const unread = social.notices.filter(item => !item.readAt);
        const peopleById = new Map((state.people || []).map(person => [String(person.id || ''), person]));
        const requestNames = incoming.map(item => peopleById.get(item.personId)?.name).filter(Boolean);
        const lines = [
            `Bạn liên lạc: ${accepted.length} người`,
            `Lời mời kết bạn đã nhận: ${incoming.length}${requestNames.length ? `（${requestNames.join('、')}）` : ''}`,
            `Bạn đã gửi, vẫn đang chờ xử lý: ${pending.length}`,
            `Thông báo liên lạc chưa đọc: ${unread.length}`,
            `Bài đăng Khoảnh khắc: ${social.moments.length} mục`,
            `Nhân vật chủ động liên lạc: ${settings.socialAutoEnabled !== false ? 'Bật' : 'Tắt'}`,
            `Trò chuyện ảnh hưởng chính văn: ${settings.injectionSocial === true ? 'Bật (vẫn chỉ là bản ghi chưa kết toán)' : 'Tắt'}`,
        ];
        return { reply: `Mình đi tuần một vòng các góc liên lạc rồi, tình hình tha về được là:\n${lines.join('\n')}`, mascotState: unread.length || incoming.length ? 'watch' : 'idle', actions: [] };
    }
    if (request.type === 'social_person_status') {
        const person = findLingqiPersonTarget(request);
        if (!person || person.isUser) return { reply: 'Tai xoay hai vòng rồi mà vẫn chưa nhận ra bạn nói ai. Mình tạm không đoán bừa quan hệ.', mascotState: 'confused', actions: [] };
        const social = normalizeSocialState(getStore().social || emptySocialState(), state.people || []);
        const relation = social.connections.find(item => item.personId === String(person.id || ''));
        const label = {
            accepted: 'Bạn liên lạc', incoming: 'Đối phương gửi lời mời kết bạn cho bạn', pending: 'Lời mời của bạn đang chờ xử lý',
            declined: 'Lời mời không được chấp nhận', suggested: 'Có thể quen, nhưng chưa phải bạn bè', removed: 'Quan hệ bạn bè đã kết thúc',
        }[relation?.status] || 'Không có quan hệ liên lạc';
        const evidence = relation?.decisionReply || relation?.decisionReason || relation?.evidence || '';
        return { reply: `Về ${person.name}, mình lật thẻ quan hệ ra rồi đây: ${label}${evidence ? `\nGhi chép để lại: ${evidence}` : ''}`, mascotState: 'watch', actions: [] };
    }
    if (request.type === 'diagnose_world') {
        const reply = lingqiLocalWorldDiagnosis();
        return { reply, mascotState: /失败|错误|关闭|没有可用|卡住|thất bại|lỗi|đã tắt|đang tắt|bị tắt|không có .{0,20}khả dụng|bị kẹt|kẹt lại|bị treo/iu.test(reply) ? 'hold' : 'watch', actions: [] };
    }
    if (request.type === 'search_lingqi_chat') {
        const lingqi = normalizeLingqiState(getStore().lingqi || emptyLingqiState());
        const matches = findLingqiChatMatches(lingqi.messages, request.query, 8);
        if (!matches.length) {
            return { reply: `Mình lục lọi rồi, không tìm thấy đoạn chat với 玲七 nào nhắc tới “${request.query}”. Thử đổi từ khác gần với nguyên văn hơn nhé?`, mascotState: 'confused', actions: [] };
        }
        const lines = matches.map(item => {
            const date = item.at ? new Date(item.at) : null;
            const stamp = date && !Number.isNaN(date.getTime()) ? date.toLocaleString() : `# ${item.index + 1} mục`;
            const preview = item.text.replace(/\s+/gu, ' ').slice(0, 120);
            return `· ${stamp}｜${item.role === 'user' ? 'Bạn' : '玲七'}：${preview}${item.text.length > 120 ? '…' : ''}`;
        });
        return { reply: `Tìm thấy ${matches.length} chỗ nhắc đến “${request.query}”：\n${lines.join('\n')}`, mascotState: 'watch', actions: [] };
    }
    return null;
}

function resolveLingqiLocalButlerRequest(userText = '') {
    const raw = String(userText || '').trim();
    const text = raw.toLocaleLowerCase();
    const settings = getSettings();
    const state = getState();
    const sync = getSyncStatus();
    const clock = formatWorldCalendar(state);

    const chatDeleteAction = parseLingqiLocalChatDeleteRequest(raw);
    if (chatDeleteAction) {
        return {
            reply: 'Ừm. Mình khoanh đoạn bạn nói ra trước đã, không xóa thẳng đâu.',
            mascotState: 'watch',
            actions: [chatDeleteAction],
        };
    }

    const localQuery = parseLingqiLocalQueryRequest(raw, state.people || []);
    const localQueryResponse = resolveLingqiLocalQuery(localQuery, { state, settings, sync, clock });
    if (localQueryResponse) return localQueryResponse;

    // Pure local questions: no reason to spend an extra model request.
    if (/(?:当前|现在|插件).{0,4}(?:版本|version)|(?:版本号)|(?:phiên bản|version).{0,6}(?:hiện tại|bây giờ|plugin|mấy|nào|bao nhiêu|là gì)|(?:plugin|tiện ích|hiện tại).{0,10}(?:phiên bản|version)|số phiên bản/iu.test(raw)) {
        return {
            reply: `Phiên bản…… ở đây ghi ${PLUGIN_VERSION}。`,
            mascotState: 'watch',
            actions: [],
        };
    }
    if (/(?:现在|当前).{0,5}(?:几点|时间|日期)|世界时间.{0,4}(?:多少|是什么|呢|？|\?)|(?:bây giờ|hiện tại|hiện giờ).{0,10}(?:mấy giờ|thời gian|ngày (?:mấy|bao nhiêu))|mấy giờ rồi|thời gian thế giới.{0,10}(?:bao nhiêu|là gì|thế nào|nhỉ|\?)/iu.test(raw)) {
        return {
            reply: state.clock?.anchored
                ? `Bây giờ là ${clock.stamp}. Ừm, đồng hồ ở đây.`
                : 'Hiện giờ thời gian câu chuyện vẫn chưa được ghim chắc. Đừng coi thời gian tạm thế là thật nhé.',
            mascotState: 'watch',
            actions: [],
        };
    }
    if (/(?:现在|当前).{0,8}(?:什么|哪些|有啥).{0,5}(?:后台任务|任务).{0,4}(?:跑|运行)|后台任务.{0,5}(?:有哪些|有啥|在跑)|tác vụ nền.{0,20}(?:nào|gì|đang chạy)|(?:tác vụ|nhiệm vụ) (?:nào|gì).{0,15}(?:đang )?chạy/iu.test(raw)) {
        const tasks = (sync.activeBackgroundTasks || []).filter(label => label !== '玲七');
        return {
            reply: tasks.length
                ? `Hiện vẫn đang chạy: ${tasks.join('、')}。`
                : 'Hiện không có tác vụ nền nào khác đang chạy.',
            mascotState: tasks.length ? 'watch' : 'idle',
            actions: [],
        };
    }

    const settingQuestions = [
        { re: /人物(?:状态)?注入.{0,5}(?:开|关|开启|关闭|状态|吗|么)|(?:chèn (?:trạng thái )?nhân vật).{0,12}(?:bật|tắt|trạng thái|không|chưa|\?)|(?:bật|tắt)\s+(?:chèn (?:trạng thái )?nhân vật)/iu, key: 'injectionPeople' },
        { re: /记录玩家角色.{0,5}(?:开|关|开启|关闭|状态|吗|么)|(?:ghi nhận nhân vật người chơi|ghi lại nhân vật người chơi).{0,12}(?:bật|tắt|trạng thái|không|chưa|\?)|(?:bật|tắt)\s+(?:ghi nhận nhân vật người chơi|ghi lại nhân vật người chơi)/iu, key: 'recordPlayerCharacter' },
        { re: /记忆注入.{0,5}(?:开|关|开启|关闭|状态|吗|么)|(?:chèn ký ức).{0,12}(?:bật|tắt|trạng thái|không|chưa|\?)|(?:bật|tắt)\s+(?:chèn ký ức)/iu, key: 'injectionMemory' },
        { re: /舆情注入.{0,5}(?:开|关|开启|关闭|状态|吗|么)|(?:chèn dư luận).{0,12}(?:bật|tắt|trạng thái|không|chưa|\?)|(?:bật|tắt)\s+(?:chèn dư luận)/iu, key: 'injectionPublicOpinion' },
        { re: /(?:通讯|聊天).{0,5}(?:影响正文|注入).{0,5}(?:开|关|开启|关闭|状态|吗|么)|(?:(?:liên lạc|chat|trò chuyện).{0,8}(?:ảnh hưởng (?:đến )?chính văn|chèn)|chèn (?:liên lạc|chat)).{0,12}(?:bật|tắt|trạng thái|không|chưa|\?)|(?:bật|tắt)\s+(?:(?:liên lạc|chat|trò chuyện).{0,8}(?:ảnh hưởng (?:đến )?chính văn|chèn)|chèn (?:liên lạc|chat))/iu, key: 'injectionSocial' },
        { re: /(?:角色|人物).{0,5}(?:主动联系|主动消息|主动申请).{0,5}(?:开|关|开启|关闭|状态|吗|么)|(?:nhân vật.{0,8}chủ động (?:liên lạc|nhắn tin|gửi lời mời|kết bạn)).{0,12}(?:bật|tắt|trạng thái|không|chưa|\?)|(?:bật|tắt)\s+(?:nhân vật.{0,8}chủ động (?:liên lạc|nhắn tin|gửi lời mời|kết bạn))/iu, key: 'socialAutoEnabled' },
        { re: /世界事实注入.{0,5}(?:开|关|开启|关闭|状态|吗|么)|(?:chèn sự thật thế giới).{0,12}(?:bật|tắt|trạng thái|không|chưa|\?)|(?:bật|tắt)\s+(?:chèn sự thật thế giới)/iu, key: 'injectionFacts' },
        { re: /自动(?:世界)?推演.{0,5}(?:开|关|开启|关闭|状态|吗|么)|(?:tự động (?:suy diễn|suy diễn thế giới)|suy diễn (?:thế giới )?tự động).{0,12}(?:bật|tắt|trạng thái|không|chưa|\?)|(?:bật|tắt)\s+(?:tự động (?:suy diễn|suy diễn thế giới)|suy diễn (?:thế giới )?tự động)/iu, key: 'worldAutoEnabled' },
        { re: /记忆系统.{0,5}(?:开|关|开启|关闭|状态|吗|么)|(?:hệ thống ký ức).{0,12}(?:bật|tắt|trạng thái|không|chưa|\?)|(?:bật|tắt)\s+(?:hệ thống ký ức)/iu, key: 'memorySystemEnabled' },
    ];
    for (const item of settingQuestions) {
        if (!item.re.test(raw)) continue;
        return {
            reply: `${LINGQI_SETTING_LABELS[item.key]} hiện tại là${lingqiSettingDisplayValue(item.key, settings[item.key])}。`,
            mascotState: 'watch',
            actions: [],
        };
    }

    if (/世界时间注入.{0,8}(?:什么|哪|模式|状态|现在)|chèn thời gian thế giới.{0,12}(?:gì|nào|chế độ|trạng thái|hiện tại|bây giờ)/iu.test(raw)) {
        return {
            reply: `Chèn thời gian thế giới hiện là “${lingqiSettingDisplayValue('injectionTimeMode', settings.injectionTimeMode)}”。`,
            mascotState: 'watch',
            actions: [],
        };
    }

    if (/^(?:帮我|请|让玲七|玲七)?\s*(?:推演|同步)\s*(?:一下|下)?\s*(?:最新|新的)?\s*(?:正文|剧情)\s*[吧。！!]*$|^(?:玲七(?:\s*ơi)?[,\s]*)?(?:giúp (?:tôi|mình)|hãy|làm ơn|nhờ 玲七)?\s*(?:suy diễn|đồng bộ)\s*(?:chính văn|cốt truyện|tình tiết)\s*(?:mới nhất|mới)?\s*(?:đi|nhé|nha|giùm|giúp (?:tôi|mình))?\s*[.!。！]*$/iu.test(raw)) {
        return {
            reply: 'Để mình xem có bị sót không đã. Nếu thật sự chưa theo kịp thì mình mới thò chân mèo ra～',
            mascotState: 'watch',
            actions: [{ type: 'simulate_latest' }],
        };
    }

    if (/^(?:帮我|请|让玲七|玲七)?\s*(?:出去)?\s*(?:巡一圈|看看外面|刷新世界舆情|刷新舆情)\s*[吧。！!]*$|^(?:玲七(?:\s*ơi)?[,\s]*)?(?:giúp (?:tôi|mình)|hãy|làm ơn|nhờ 玲七)?\s*(?:ra ngoài tuần tra(?: một vòng)?|đi tuần(?: một vòng)?|ra ngoài xem|xem bên ngoài|làm mới dư luận(?: thế giới)?)\s*(?:đi|nhé|nha|giùm|giúp (?:tôi|mình))?\s*[.!。！]*$/iu.test(raw)) {
        return {
            reply: 'Bên ngoài à? Ừm… mình có thể ra ngoài dạo một vòng. Đợi bạn gật đầu trước đã.',
            mascotState: 'watch',
            actions: [{ type: 'refresh_public_world' }],
        };
    }
    if (/^(?:帮我|请|让玲七|玲七)?\s*(?:刷新|看看|看下)\s*(?:新的)?朋友圈\s*[吧。！!]*$|^(?:玲七(?:\s*ơi)?[,\s]*)?(?:giúp (?:tôi|mình)|hãy|làm ơn|nhờ 玲七)?\s*(?:làm mới|xem)\s*(?:các\s*)?(?:bài đăng\s*)?khoảnh khắc(?:\s*mới)?\s*(?:đi|nhé|nha|giùm|giúp (?:tôi|mình))?\s*[.!。！]*$/iu.test(raw)) {
        return { reply: 'Mình ra ngồi bên cửa sổ Khoảnh khắc một lát, xem có ai thật sự muốn đăng bài không～việc này sẽ gọi model nền một lần; nếu đang bật ảnh kèm thì có thể dùng thêm API tạo ảnh một lần nữa, nên để bạn xác nhận trước.', mascotState: 'watch', actions: [{ type: 'social_refresh_moments' }] };
    }

    const socialSendMatch = raw.match(/^(?:帮我|请|让玲七|玲七|giúp (?:tôi|mình)|hãy|làm ơn)?\s*(?:给|向|(?:gửi tin nhắn|gửi tin|nhắn tin|nhắn|nói)\s+(?:cho|với))\s*([^，。！？!：:]{1,40})\s*(?:发消息|发条消息|说|(?<=(?:cho|với)\s+[^：:]{1,40})(?=[：:]))\s*[：:]?\s*[“「『]?([^”」』]{1,1600})[”」』]?\s*$/iu);
    if (socialSendMatch) {
        return { reply: 'Câu này sẽ thật sự được gửi tới đối phương. Mình tạm lấy chân mèo đè lại, đặt người nhận và nguyên văn vào thẻ xác nhận; bạn gật đầu rồi mình mới gửi.', mascotState: 'watch', actions: [{ type: 'social_send_message', personName: socialSendMatch[1].trim(), text: socialSendMatch[2].trim() }] };
    }
    const socialRelationMatch = raw.match(/^(?:帮我|请|让玲七|玲七|giúp (?:tôi|mình)|hãy|làm ơn)?\s*(接受|同意|拒绝|婉拒|删除|删掉|移除|chấp nhận|đồng ý|từ chối khéo|từ chối|xóa|xoá|gỡ|loại bỏ)\s*(?:(?:lời mời kết bạn|lời mời)\s+(?:của|từ)\s+|bạn\s+)?([^，。！？!]{1,40}?)(?:的)?\s*(好友申请|好友|khỏi danh sách bạn(?: bè)?)?\s*(?:đi|nhé|nha|giùm)?\s*[吧。！!.]*$/iu);
    if (socialRelationMatch) {
        const verb = socialRelationMatch[1];
        const type = /接受|同意|chấp nhận|đồng ý/ui.test(verb)
            ? 'social_accept_request'
            : /拒绝|婉拒|từ chối|khước từ/ui.test(verb)
                ? 'social_refuse_request'
                : 'social_remove_friend';
        return { reply: 'Thao tác quan hệ không thể một vuốt đập xuống được. Mình xác minh nhân vật và quan hệ hiện tại trước, rồi mới để bạn xác nhận.', mascotState: 'hold', actions: [{ type, personName: socialRelationMatch[2].trim() }] };
    }

    const priorityPersonMatch = raw.match(
        /^(?:帮我|请|让玲七|玲七|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy))?\s*(?:让|把|cho|để|ưu tiên)?\s*([^，。！？!]{1,40}?)\s*(?:下一轮优先|排到下一轮前面|下一轮先看|(?:được\s*)?ưu tiên\s*(?:ở\s*|vào\s*|trong\s*)?lượt\s*(?:sau|tới|kế tiếp|kế)|(?:lên|xếp|xem)\s*trước\s*(?:ở\s*|vào\s*|trong\s*)?lượt\s*(?:sau|tới|kế tiếp|kế)|(?<=ưu tiên\s.*)(?:ở\s*|vào\s*|trong\s*)?lượt\s*(?:sau|tới|kế tiếp|kế))\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
    );
    if (priorityPersonMatch) {
        return {
            reply: `${priorityPersonMatch[1].trim()} — lượt sau xem trước. Được, mình đẩy người này lên trước một chút.`,
            mascotState: 'note',
            actions: [{ type: 'prioritize_person', personName: priorityPersonMatch[1].trim(), enabled: true }],
        };
    }

    const catchUpPersonMatch = raw.match(
        /^(?:帮我|请|让玲七|玲七|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy))?\s*(?:补一下|补下|看看|(?:xem(?:\s*thử)?|cập nhật|kể)\s*(?:tình hình\s*)?(?:gần đây\s*|dạo này\s*)?(?:của\s*)?|hỏi thăm)\s*([^，。！？!]{1,40}?)(?:的)?\s*(?:近况|最近怎么样|dạo này\s*(?:thế nào|ra sao|sao rồi|làm gì)|gần đây\s*(?:thế nào|ra sao|sao rồi|làm gì)|(?<=(?:tình hình|hỏi thăm)\s.*))\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
    );
    if (catchUpPersonMatch) {
        return {
            reply: `Mình đi xem${catchUpPersonMatch[1].trim()} dạo này đang làm gì～nhưng việc này sẽ gọi model nền một lần, đợi bạn gật đầu đã.`,
            mascotState: 'watch',
            actions: [{ type: 'catch_up_person', personName: catchUpPersonMatch[1].trim() }],
        };
    }

    // Reversible direct commands. Keep patterns deliberately strict so casual
    // discussion such as“如果关掉会怎样”does not silently change settings.
    const directSettingCommands = [
        {
            re: /^(?:帮我|请|把|直接|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy))?\s*(?:关掉|关闭|tắt)\s*(?:人物(?:状态)?注入|chèn\s*(?:trạng thái\s*)?nhân vật)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
            action: { type: 'update_setting', setting: 'injectionPeople', value: false },
            reply: 'Không muốn đưa trạng thái nhân vật cho chính văn. Ừm, để mình tắt.',
            mascotState: 'happy',
        },
        {
            re: /^(?:帮我|请|把|直接|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy))?\s*(?:打开|开启|bật|mở)\s*(?:人物(?:状态)?注入|chèn\s*(?:trạng thái\s*)?nhân vật)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
            action: { type: 'update_setting', setting: 'injectionPeople', value: true },
            reply: 'Muốn đưa trạng thái nhân vật cho chính văn. Được.',
            mascotState: 'happy',
        },
        {
            re: /^(?:帮我|请|把|直接|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy))?\s*(?:关掉|关闭|tắt)\s*(?:(?:角色|人物)?(?:主动联系|主动消息|主动申请)|(?:tính năng\s*)?(?:nhân vật\s*)?chủ động\s*(?:liên lạc|nhắn tin|gửi tin nhắn|gửi lời mời|kết bạn)(?:\s*của\s*nhân vật)?)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
            action: { type: 'update_setting', setting: 'socialAutoEnabled', value: false },
            reply: 'Nhân vật sẽ không chủ động nhắn tin, gửi lời mời hay đăng bài nữa. Quan hệ và bản ghi hiện có đều được giữ lại.',
            mascotState: 'happy',
        },
        {
            re: /^(?:帮我|请|把|直接|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy))?\s*(?:打开|开启|bật|mở)\s*(?:(?:角色|人物)?(?:主动联系|主动消息|主动申请)|(?:tính năng\s*)?(?:nhân vật\s*)?chủ động\s*(?:liên lạc|nhắn tin|gửi tin nhắn|gửi lời mời|kết bạn)(?:\s*của\s*nhân vật)?)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
            action: { type: 'update_setting', setting: 'socialAutoEnabled', value: true },
            reply: 'Nhân vật có thể chủ động liên lạc với tần suất thấp theo tính cách; khi không có động cơ thì vẫn sẽ im lặng.',
            mascotState: 'happy',
        },
        {
            re: /^(?:帮我|请|把|直接|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy))?\s*(?:关掉|关闭|不要记录|tắt|đừng ghi lại|đừng ghi|không ghi lại|ngừng ghi)\s*(?:玩家角色|user|我|(?:nhân vật\s*)?người chơi|tôi)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
            action: { type: 'update_setting', setting: 'recordPlayerCharacter', value: false },
            reply: 'Không ghi người chơi như nhân vật nền. Ừm.',
            mascotState: 'happy',
        },
        {
            re: /^(?:帮我|请|把|直接|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy))?\s*(?:打开|开启|记录|bật|ghi lại|ghi)\s*(?:玩家角色|user|(?:nhân vật\s*)?người chơi)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
            action: { type: 'update_setting', setting: 'recordPlayerCharacter', value: true },
            reply: 'Sẽ ghi nhận trạng thái khách quan đã xảy ra rõ ràng của người chơi. Được.',
            mascotState: 'happy',
        },
        {
            re: /^(?:帮我|请|把|直接|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy)|đổi|chuyển|đặt)?\s*(?:时间|世界时间|(?:chèn\s*)?thời gian(?:\s*thế giới)?)(?:注入)?\s*(?:改成|设成|用|(?:đổi|chuyển|đặt)?\s*(?:thành|sang)|dùng)\s*(?:最小锚点|最小时间锚点|điểm neo\s*(?:thời gian\s*)?tối thiểu)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
            action: { type: 'update_setting', setting: 'injectionTimeMode', value: 'anchor' },
            reply: 'Thời gian chỉ giữ điểm neo tối thiểu. Như vậy sẽ không báo giờ liên tục.',
            mascotState: 'happy',
        },
        {
            re: /^(?:帮我|请|直接|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy))?\s*(?:停止|停掉|停下|dừng(?:\s*lại)?|ngừng)\s*(?:全部|所有|tất cả|toàn bộ)?\s*(?:后台任务|后台|(?:các\s*)?tác vụ nền)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
            action: { type: 'cancel_background_tasks' },
            reply: 'Tất cả tạm dừng một chút. 玲七 tự giữ lại để nói hết câu này.',
            mascotState: 'hold',
        },
        {
            re: /^(?:帮我|请|直接|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy))?\s*(?:停止|停掉|停下|dừng(?:\s*lại)?|ngừng)\s*(?:当前)?\s*(?:世界)?(?:推演|(?:việc\s*)?suy diễn(?:\s*thế giới)?(?:\s*hiện tại)?)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
            action: { type: 'cancel_simulation' },
            reply: 'Lần Suy diễn thế giới này tạm dừng.',
            mascotState: 'hold',
        },
        {
            re: /^(?:帮我|帮忙|请|给我|直接|(?:玲七\s*(?:ơi\s*)?[,，]?\s*)?(?:giúp tôi|giúp mình|làm ơn|hãy))?\s*(?:整理|收拾|归档|sắp xếp|dọn dẹp|thu dọn|lưu trữ)(?:一下|下)?\s*(?:(?:长期)?记忆|(?:lại\s*)?(?:các\s*)?ký ức(?:\s*dài hạn)?)\s*(?:nhé|nha|đi|giúp tôi|giùm)?\s*[吧。！!.]*$/iu,
            action: { type: 'organize_memory' },
            reply: 'Ký ức… ừm, để mình dọn.',
            mascotState: 'note',
        },
    ];
    for (const item of directSettingCommands) {
        if (!item.re.test(raw)) continue;
        return {
            reply: item.reply,
            mascotState: item.mascotState || 'watch',
            actions: [item.action],
        };
    }

    return null;
}

async function sendLingqiMessage(text) {
    const userText = String(text || '').trim().slice(0, 3000);
    if (!userText) throw new Error('Nói gì đó với 玲七 trước đã nào～');
    if (runtime.activeLingqi && !runtime.activeLingqi.controller?.signal?.aborted) {
        throw new Error('玲七 vẫn đang nghĩ câu trước đó～đợi cô ấy một chút nha');
    }

    const localRequest = resolveLingqiLocalButlerRequest(userText);
    if (localRequest) {
        let localStore = getStore();
        localStore.lingqi = addLingqiMessage(localStore.lingqi || emptyLingqiState(), 'user', userText);
        saveStore(localStore);
        const results = await executeLingqiButlerActions(localRequest.actions);
        const finalReply = [
            localRequest.reply,
            ...results.map(value => `· ${value}`),
        ].filter(Boolean).join('\n');
        const completedMascotState = resolveCompletedLingqiMascotState(
            localRequest.mascotState || 'watch',
            { actionResults: results },
        );
        localStore = getStore();
        localStore.lingqi = addLingqiMessage(
            localStore.lingqi || emptyLingqiState(),
            'assistant',
            finalReply,
        );
        localStore.lingqi.mascotState = completedMascotState;
        saveStore(localStore, { immediate: true });
        sealPendingLingqiChatDeletionSnapshot();
        refreshInjection();
        runtime.lingqiStatus = {
            phase: 'success',
            message: runtime.pendingLingqiAction ? 'Đã khoanh vùng xong～đợi bạn gật đầu.' : localRequest.actions?.length ? '玲七 tiện tay làm xong rồi～' : '玲\u4e03 biết cái này～',
            error: '',
        };
        runtime.ui?.render();
        return {
            reply: finalReply,
            mascotState: completedMascotState,
            actions: localRequest.actions || [],
            local: true,
        };
    }

    const chatToken = currentChatToken();
    const contextEpoch = runtime.contextEpoch;
    const controller = new AbortController();
    const active = { chatToken, contextEpoch, controller, promise: null };
    runtime.activeLingqi = active;

    let store = getStore();
    store.lingqi = addLingqiMessage(store.lingqi || emptyLingqiState(), 'user', userText);
    saveStore(store);
    runtime.lingqiStatus = { phase: 'running', message: '……', error: '' };
    runtime.ui?.render();

    const prompt = buildLingqiChatPrompt({
        world: lingqiWorldDigest(store.currentState),
        messages: store.lingqi.messages.slice(0, -1),
        userText,
        butlerContext: buildLingqiButlerContext(userText),
    });

    const promise = (async () => {
        try {
            const parsed = await runWithRetries(async attempt => {
                const raw = await backgroundSimulation(retryJsonPrompt(prompt, attempt), {
                    maxTokens: retryTokenBudget(1800, attempt),
                    temperature: attempt > 0 ? 0.25 : 0.55,
                    signal: controller.signal,
                    taskKind: 'lingqi',
                    rejectTruncated: true,
                });
                const object = extractJsonObject(raw);
                if (object) return object;
                throw unreadableJsonError(raw);
            }, {
                retries: 1,
                shouldRetry: error => !isAbortError(error),
                signal: controller.signal,
            });

            if (
                controller.signal.aborted
                || currentChatToken() !== chatToken
                || runtime.contextEpoch !== contextEpoch
            ) return null;

            const response = normalizeLingqiAssistantPayload(parsed);
            const actionResults = await executeLingqiButlerActions(response.actions);
            const triage = finalizeLingqiTriage(response, actionResults, userText);
            const actionReply = actionResults.length
                ? actionResults.map(text => `· ${text}`).join('\n')
                : '';
            const nextStepLine = (
                ['self_service', 'external'].includes(triage.route)
                && triage.nextStep
                && !String(response.reply || '').includes(triage.nextStep)
            )
                ? `· Có thể thử trước: ${triage.nextStep}`
                : '';
            const fallbackHelpLine = triage.route === 'mama'
                && !/(妈妈|帖子|看不出来|不知道|查不明白|求助|mẹ|bài đăng|không nhìn ra|không biết|không tra ra|chưa tra ra|không hiểu nổi|nhờ giúp|cầu cứu)/u.test(response.reply)
                ? 'Cái này ở chỗ mình tra chưa ra… phải hỏi mẹ thôi. Mình viết sẵn mảnh giấy nhỏ rồi.'
                : '';
            const finalReply = [
                response.reply,
                actionReply,
                nextStepLine,
                fallbackHelpLine,
            ].filter(Boolean).join('\n');
            const completedMascotState = resolveCompletedLingqiMascotState(
                response.mascotState,
                {
                    proposal: response.proposal,
                    triage,
                    actionResults,
                },
            );

            store = getStore();
            store.lingqi = addLingqiMessage(
                store.lingqi || emptyLingqiState(),
                'assistant',
                finalReply,
                {
                    planText: response.proposal?.planText || response.proposal?.directive || '',
                    needsAuthorHelp: triage.route === 'mama',
                    supportReason: triage.reason,
                    supportTriage: triage,
                },
            );
            store.lingqi.pendingProposal = response.proposal;
            store.lingqi.mascotState = completedMascotState;
            const autoConfirmed = shouldAutoConfirmLingqiProposal(
                userText,
                response.proposal?.autoConfirm,
            );
            if (autoConfirmed) {
                store.lingqi = confirmLingqiProposal(store.lingqi);
            }
            saveStore(store, { immediate: true });
            sealPendingLingqiChatDeletionSnapshot();
            refreshInjection();
            runtime.lingqiStatus = {
                phase: 'success',
                message: autoConfirmed
                    ? '玲七 đã dán mảnh giấy nhỏ này lên rồi～'
                    : response.proposal
                        ? '玲七 viết xong một mảnh giấy nhỏ, đợi bạn gật đầu～'
                        : triage.route === 'mama'
                            ? 'Cái này 玲七 cũng tra chưa ra, mảnh giấy nhỏ gửi mẹ đã viết xong rồi～'
                            : runtime.pendingLingqiAction
                                ? '玲七 đã đè thao tác cần làm lại rồi～đợi bạn gật đầu.'
                                : actionResults.length
                                    ? '玲七 đã xử lý xong những việc có thể làm hộ rồi～'
                                    : '玲\u4e03 nghĩ xong rồi～',
                error: '',
            };
            runtime.ui?.render();
            return {
                ...response,
                mascotState: completedMascotState,
            };
        } catch (error) {
            if (isAbortError(error) || controller.signal.aborted) return null;
            runtime.lingqiStatus = {
                phase: 'error',
                message: '玲七 vừa rồi không bắt kịp lời……',
                error: describeError(error),
            };
            runtime.ui?.render();
            throw error;
        } finally {
            if (runtime.activeLingqi === active) runtime.activeLingqi = null;
            runtime.ui?.render();
        }
    })();
    active.promise = promise;
    return promise;
}

function confirmLingqiNoteProposal() {
    const store = getStore();
    if (!store.lingqi?.pendingProposal) return false;
    store.lingqi = confirmLingqiProposal(store.lingqi);
    saveStore(store, { immediate: true });
    refreshInjection();
    runtime.lingqiStatus = { phase: 'success', message: 'ฅ', error: '' };
    runtime.ui?.render();
    return true;
}

function dismissLingqiNoteProposal() {
    const store = getStore();
    if (!store.lingqi?.pendingProposal) return false;
    store.lingqi = dismissLingqiProposal(store.lingqi);
    saveStore(store);
    runtime.lingqiStatus = { phase: 'idle', message: '……', error: '' };
    runtime.ui?.render();
    return true;
}

function updateLingqiNoteStatus(noteId, status) {
    const store = getStore();
    store.lingqi = setLingqiNoteStatus(store.lingqi || emptyLingqiState(), noteId, status);
    saveStore(store, { immediate: true });
    refreshInjection();
    runtime.ui?.render();
    return true;
}

function recentRawAssistantTexts(count = 1) {
    const chat = getContext()?.chat || [];
    const limit = Math.max(1, Math.min(20, Number(count) || 1));
    const result = [];
    for (let index = chat.length - 1; index >= 0 && result.length < limit; index -= 1) {
        const message = chat[index];
        if (!message || message.is_user || message.is_system) continue;
        const swipeId = Number(message.swipe_id ?? 0);
        const text = String(message.swipes?.[swipeId] ?? message.mes ?? '');
        if (!text.trim()) continue;
        result.unshift(text);
    }
    return result;
}


function resetRuntimeMaintenanceState({
    clearRetryState = false,
} = {}) {
    runtime.worldbookScanToken = null;
    discardWorldbookDrafts();
    runtime.dataEpoch += 1;

    const abortables = [
        runtime.activeSimulation?.controller,
        runtime.activeHistoryScan,
        runtime.activeWorldPulse?.controller,
        runtime.activePublicImpact?.controller,
        runtime.activeCorrection?.controller,
        runtime.activePublicOpinion?.controller,
        runtime.publicOpinionRefreshTransaction?.controller,
        runtime.activePublicOpinionSandbox?.controller,
        runtime.activeObservation?.controller,
        runtime.activeLingqi?.controller,
        runtime.activeSocial?.controller,
        runtime.activeFriendRequest?.controller,
        runtime.activeMoments?.controller,
        runtime.activeSocialPulse?.controller,
    ];
    for (const abortable of abortables) {
        try {
            abortable?.abort?.();
        } catch {
            // Maintenance must continue even if one stale task object is malformed.
        }
    }

    if (runtime.autoMemoryTimer !== null) {
        window.clearTimeout(runtime.autoMemoryTimer);
        runtime.autoMemoryTimer = null;
    }
    if (runtime.manualUndoTimer !== null) {
        window.clearTimeout(runtime.manualUndoTimer);
        runtime.manualUndoTimer = null;
    }

    runtime.activeSimulation = null;
    runtime.activeHistoryScan = null;
    runtime.activeWorldPulse = null;
    runtime.activePublicImpact = null;
    runtime.activeCorrection = null;
    runtime.activePublicOpinion = null;
    runtime.publicOpinionRefreshTransaction = null;
    runtime.activePublicOpinionSandbox = null;
    runtime.activeObservation = null;
    runtime.activeLingqi = null;
    runtime.activeSocial = null;
    runtime.activeFriendRequest = null;
    runtime.activeMoments = null;
    runtime.activeSocialPulse = null;
    runtime.lingqiStatus = { phase: 'idle', message: '', error: '' };
    runtime.socialStatus = { phase: 'idle', message: '', error: '', conversationId: '' };
    runtime.friendRequestStatus = { phase: 'idle', message: '', error: '', personId: '' };
    runtime.momentsStatus = { phase: 'idle', message: '', error: '' };
    runtime.pendingLingqiAction = null;
    runtime.pendingPublicImpact = false;
    runtime.pendingPublicOpinion = false;
    runtime.inBackgroundGeneration = false;
    runtime.consistencyBarrierRunning = false;
    runtime.queuedSimulations.clear();
    clearDeferredManualSimulation();
    runtime.simulationChain = Promise.resolve();
    runtime.simulationCount = 0;
    runtime.manualUndo = null;
    runtime.editDecision = null;
    runtime.injection = { text: '', eventIds: [], directorNoteIds: [] };
    runtime.generationOffer = { eventIds: [], directorNoteIds: [], at: 0, rerollBase: false };
    runtime.lastPromptBridge = null;
    runtime.lastTaskConnection = null;
    runtime.customModels = [];
    runtime.modelPullStatus = { phase: 'idle', message: '' };
    runtime.worldbookScan = {
        phase: 'idle',
        message: '',
        bookName: '',
        entries: [],
    };
    runtime.historyProgress = {
        kind: 'memory',
        phase: 'idle',
        processed: 0,
        total: 0,
        message: '',
    };
    runtime.publicOpinionStatus = {
        phase: 'idle',
        message: 'Dư luận còn chưa mở hàng đâu～',
        error: '',
    };
    runtime.publicOpinionSandboxStatus = {
        phase: 'idle',
        message: '',
        error: '',
    };
    runtime.syncStatus = {
        phase: 'idle',
        message: 'Chưa suy diễn lần nào～thế giới đang đợi bạn ở đây',
        error: '',
        attemptedAt: '',
        succeededAt: '',
        method: '',
        summary: null,
    };

    resetLastCustomApiOperation();
    if (clearRetryState) resetRetryControl();
}

function clearStoredChatCaches() {
    const store = getStore();
    store.personObservations = {};
    store.publicOpinionSandbox = emptyPublicOpinionSandbox();
    store.historyBootstrapCheckpoint = null;
    saveStore(store, { immediate: true });
    return store;
}

function clearCurrentChatCache() {
    // Keep route cooldowns: a real 429 cooldown is protection, not corrupt cache.
    resetRuntimeMaintenanceState({ clearRetryState: false });
    clearStoredChatCaches();
    refreshInjection();
    runtime.ui?.render();
    return {
        cleared: true,
        preservedWorldState: true,
        preservedApiSettings: true,
    };
}

function clearMessageBranchSnapshots(context = getContext()) {
    let removed = 0;
    for (const message of context?.chat || []) {
        if (message?.extra && Object.prototype.hasOwnProperty.call(message.extra, SNAPSHOT_KEY)) {
            delete message.extra[SNAPSHOT_KEY];
            removed += 1;
        }
        for (const swipe of Array.isArray(message?.swipe_info) ? message.swipe_info : []) {
            if (swipe?.extra && Object.prototype.hasOwnProperty.call(swipe.extra, SNAPSHOT_KEY)) {
                delete swipe.extra[SNAPSHOT_KEY];
                removed += 1;
            }
        }
    }
    return removed;
}

async function resetCurrentChatData() {
    const context = getContext();
    if (!hasChatContext()) throw new Error('Hiện không có đoạn chat nào có thể đặt lại');

    // Do not create a recovery point here. A reset that secretly leaves a complete
    // restore copy would not be a real clean-room test.
    resetRuntimeMaintenanceState({ clearRetryState: false });

    const removedSnapshots = clearMessageBranchSnapshots(context);
    const freshStore = makeStore();
    runtime.transientStore = null;
    context.chatMetadata[STATE_KEY] = freshStore;

    if (typeof context.saveMetadata === 'function') {
        await context.saveMetadata();
    } else {
        context.saveMetadataDebounced?.();
    }
    await context.saveChat?.();

    refreshInjection();
    runtime.ui?.render();

    return {
        reset: true,
        removedSnapshots,
        preservedChatMessages: true,
        preservedApiSettings: true,
    };
}


async function checkAndCorrectWorldState() {
    if (coreSimulationBusy()) {
        throw new Error('Vẫn còn tác vụ thế giới đang chạy～đợi lượt này xong rồi hẵng kiểm tra, tránh hai bản trạng thái ghi đè lẫn nhau');
    }

    const settings = getSettings();
    const chatToken = currentChatToken();
    const controller = new AbortController();
    runtime.activeCorrection = {
        controller,
        chatToken,
        startedAt: Date.now(),
    };
    setBusy(true);
    setSyncStatus({
        phase: 'running',
        message: 'Đang đối chiếu bằng chứng chính văn và trạng thái nền, chỉ sửa những mục mâu thuẫn rõ ràng～',
        error: '',
    });

    try {
        const narrativeText = recentChatText(20);
        const prompt = buildStateCorrectionPrompt(getState(), {
            narrativeText,
            userName: getContext()?.name1 || '',
        });

        const payload = await runWithRetries(async attempt => {
            const raw = await backgroundSimulation(retryJsonPrompt(prompt, attempt), {
                maxTokens: retryTokenBudget(3200, attempt),
                temperature: attempt > 0 ? 0.02 : 0.08,
                signal: controller.signal,
                taskKind: 'simulation',
                rejectTruncated: true,
            });
            const parsed = extractJsonObject(raw);
            if (parsed) return parsed;
            throw unreadableJsonError(raw, 'Model sửa lỗi sự thật');
        }, {
            retries: settings.autoRetryCount,
            shouldRetry: error => !(
                /请先填写独立 API|HTTP 40[0134]|没有提供安静生成接口|hãy điền.{0,40}API độc lập|chưa điền.{0,40}API độc lập|không (?:cung cấp|có|hỗ trợ).{0,30}(?:quiet|tạo ngầm|tạo im lặng|tạo yên lặng)|sinh yên lặng/i
                    .test(describeError(error))
            ),
            onRetry: ({ delayMs, rateLimited }) => {
                setSyncStatus({
                    phase: 'running',
                    message: rateLimited
                        ? `Kiểm tra sự thật gặp giới hạn tốc độ～chờ hạ nhiệt ${cooldownSeconds(delayMs)} giây rồi tiếp tục cùng tác vụ này`
                        : 'Định dạng trả về của kiểm tra sự thật chưa gọn, đang thử lại với định dạng chặt chẽ hơn～',
                    error: '',
                });
            },
            ...retryTaskOptions(
                'simulation',
                `state-correction:${chatToken}:${getState().revision}:${latestAssistantSourceStamp()}`,
            ),
            signal: controller.signal,
        });

        if (
            controller.signal.aborted
            || currentChatToken() !== chatToken
            || runtime.activeCorrection?.controller !== controller
        ) return null;

        const latestAssistant = latestAssistantEntry();
        const result = applyStateCorrectionResult(getState(), payload, {
            narrativeText,
            messageId: latestAssistant?.index ?? null,
        });

        if (!result.applied.length && !result.removedEventIds.length) {
            setSyncStatus({
                phase: 'success',
                message: result.skipped
                    ? `Kiểm tra xong: không đủ bằng chứng để tự động sửa; ${result.skipped} mục đáng ngờ đã được bỏ qua một cách thận trọng`
                    : 'Kiểm tra xong: không phát hiện mâu thuẫn rõ ràng nào cần sửa～',
                error: '',
            });
            return result;
        }

        const removed = new Set(result.removedEventIds);
        commitManualState(
            result.state,
            `Sửa lỗi sự thật hoàn tất: đã sửa ${result.applied.length} mục${removed.size ? `, hủy ${removed.size} mục phái sinh chưa xảy ra` : ''}。`,
            {
                mutateStore: store => {
                    if (!removed.size) return;
                    const opinion = normalizePublicOpinionCache(store.publicOpinion || emptyPublicOpinionCache());
                    store.publicOpinion = {
                        ...opinion,
                        news: opinion.news.filter(item => !removed.has(String(item.relatedEventId || ''))),
                        forums: opinion.forums.filter(item => !removed.has(String(item.relatedEventId || ''))),
                    };
                },
            },
        );
        setSyncStatus({
            phase: 'success',
            message: `Sửa lỗi sự thật hoàn tất: đã sửa ${result.applied.length} mục${removed.size ? `, hủy ${removed.size} mục phái sinh chưa xảy ra` : ''}`,
            error: '',
        });
        return result;
    } finally {
        if (runtime.activeCorrection?.controller === controller) {
            runtime.activeCorrection = null;
        }
        setBusy(false);
        refreshInjection();
        runtime.ui?.render();
    }
}

async function sendSocialMessage(conversationId, messageText, { requestOnly = false } = {}) {
    if (runtime.activeSocial && !runtime.activeSocial.controller?.signal?.aborted) {
        throw new Error('Tin nhắn xã hội trước đó vẫn đang chờ trả lời');
    }
    const chatToken = currentChatToken();
    const contextEpoch = runtime.contextEpoch;
    const controller = new AbortController();
    let store = getStore();
    if (requestOnly) {
        const normalizedSocial = normalizeSocialState(
            store.social || emptySocialState(),
            store.currentState.people,
        );
        const conversation = normalizedSocial.conversations.find(item => item.id === String(conversationId || ''));
        if (!conversation) throw new Error('Không tìm thấy cuộc trò chuyện này');
        const lastMessage = conversation.rawMessages?.at(-1) || null;
        if (!lastMessage || lastMessage.senderId !== 'user') {
            throw new Error('Hiện không có tin nhắn nào đang chờ trả lời～gửi một câu sang trước đã nào');
        }
    } else {
        store.social = appendUserSocialMessage(
            store.social,
            conversationId,
            messageText,
            store.currentState.clock?.absoluteMinute,
            store.currentState.people,
        );
        saveStore(store, { immediate: true });
        if (getSettings().socialInstantReply === false) {
            runtime.socialStatus = {
                phase: 'success',
                message: 'Tin nhắn đã được đưa đi rồi～lần này không gọi API; muốn đối phương trả lời ngay thì bấm「Mèo con chuyển lời」.',
                error: '',
                conversationId,
            };
            runtime.ui?.render();
            return { stored: true, replyCount: 0, waitingForManualReply: true };
        }
    }
    runtime.activeSocial = { controller, chatToken, contextEpoch, conversationId };
    runtime.socialStatus = {
        phase: 'running',
        message: requestOnly
            ? 'Mèo con ngậm tin nhắn đi gõ cửa rồi～đang đợi đối phương trả lời……'
            : 'Tin nhắn đã gửi, đang xét xem ai thấy, ai biết, ai muốn trả lời……',
        error: '',
        conversationId,
    };
    runtime.ui?.render();

    try {
        const prompt = buildSocialReplyPrompt(store.social, store.currentState, conversationId, {
            userName: String(getContext()?.name1 || 'Bạn'),
        });
        const raw = await backgroundSimulation(prompt, {
            maxTokens: 1400,
            temperature: 0.72,
            signal: controller.signal,
            taskKind: 'social',
            rejectTruncated: true,
        });
        const parsed = extractJsonObject(raw);
        if (!parsed) throw unreadableJsonError(raw, 'Model trả lời xã hội');
        if (
            controller.signal.aborted
            || chatToken !== currentChatToken()
            || contextEpoch !== runtime.contextEpoch
        ) return null;
        store = getStore();
        const applied = applySocialReplyPayload(store.social, conversationId, parsed, store.currentState);
        store.social = applied.social;
        saveStore(store, { immediate: true });
        refreshInjection();
        runtime.socialStatus = {
            phase: 'success',
            message: applied.replyCount
                ? `Nhận được ${applied.replyCount} phản hồi.`
                : 'Lần này không ai trả lời. Đây không phải lỗi sinh, mà là kết quả im lặng sau khi định tuyến.',
            error: '',
            conversationId,
        };
        runtime.ui?.render();
        return applied;
    } catch (error) {
        if (isAbortError(error) || controller.signal.aborted) return null;
        if (chatToken === currentChatToken() && contextEpoch === runtime.contextEpoch) {
            store = getStore();
            store.social = setSocialConversationError(store.social, conversationId, error, store.currentState.people);
            saveStore(store, { immediate: true });
            runtime.socialStatus = {
                phase: 'error',
                message: 'Tin nhắn đã được giữ lại, nhưng lần này không lấy được phản hồi của nhân vật.',
                error: describeError(error),
                conversationId,
            };
            runtime.ui?.render();
        }
        // The outgoing raw message was already saved successfully. Treat the
        // action as completed so the composer does not put the same text back
        // and invite an accidental duplicate send.
        return { stored: true, replyCount: 0, error: describeError(error) };
    } finally {
        if (runtime.activeSocial?.controller === controller) runtime.activeSocial = null;
    }
}

async function requestSocialFriend(personId, requestMessage = '') {
    if (runtime.activeFriendRequest && !runtime.activeFriendRequest.controller?.signal?.aborted) {
        throw new Error('Lời mời kết bạn trước đó vẫn đang chờ đối phương xử lý');
    }
    const chatToken = currentChatToken();
    const contextEpoch = runtime.contextEpoch;
    const controller = new AbortController();
    let store = getStore();
    const person = store.currentState.people.find(item => String(item?.id || '') === String(personId || ''));
    if (!person || person.isUser) throw new Error('Không tìm thấy nhân vật này');
    const prompt = buildFriendRequestPrompt(store.social, store.currentState, person.id, {
        userName: String(getContext()?.name1 || 'Bạn'),
        requestMessage,
    });
    runtime.activeFriendRequest = { controller, chatToken, contextEpoch, personId: String(person.id) };
    runtime.friendRequestStatus = {
        phase: 'running',
        message: `Đang chờ ${person.name} xử lý lời mời`,
        error: '',
        personId: String(person.id),
    };
    runtime.ui?.render();
    try {
        const raw = await backgroundSimulation(prompt, {
            maxTokens: 700,
            temperature: 0.38,
            signal: controller.signal,
            taskKind: 'social',
            rejectTruncated: true,
        });
        const parsed = extractJsonObject(raw);
        if (!parsed) throw unreadableJsonError(raw, 'Model phán định lời mời kết bạn');
        if (controller.signal.aborted || chatToken !== currentChatToken() || contextEpoch !== runtime.contextEpoch) return null;
        store = getStore();
        const result = applyFriendDecisionPayload(store.social, store.currentState, person.id, parsed, { requestMessage });
        store.social = result.social;
        saveStore(store, { immediate: true });
        runtime.friendRequestStatus = {
            phase: 'success',
            message: result.decision === 'accepted'
                ? `${person.name} đã chấp nhận lời mời kết bạn`
                : result.decision === 'declined'
                    ? `${person.name} không chấp nhận lời mời`
                    : `${person.name} tạm thời chưa xử lý lời mời`,
            error: '',
            personId: String(person.id),
        };
        runtime.ui?.render();
        return { ...result, personName: person.name };
    } catch (error) {
        if (isAbortError(error) || controller.signal.aborted) return null;
        runtime.friendRequestStatus = {
            phase: 'error',
            message: 'Lời mời kết bạn chưa hoàn tất',
            error: describeError(error),
            personId: String(person.id),
        };
        runtime.ui?.render();
        throw error;
    } finally {
        if (runtime.activeFriendRequest?.controller === controller) runtime.activeFriendRequest = null;
    }
}

async function refreshSocialMoments() {
    if (runtime.activeMoments && !runtime.activeMoments.controller?.signal?.aborted) {
        throw new Error('Khoảnh khắc vẫn đang làm mới');
    }
    const chatToken = currentChatToken();
    const contextEpoch = runtime.contextEpoch;
    const controller = new AbortController();
    let store = getStore();
    const prompt = buildMomentsPrompt(store.social, store.currentState, {
        userName: String(getContext()?.name1 || 'Bạn'),
    });
    runtime.activeMoments = { controller, chatToken, contextEpoch };
    runtime.momentsStatus = { phase: 'running', message: 'Đang xem bạn bè gần đây có nội dung gì muốn chia sẻ không', error: '' };
    runtime.ui?.render();
    try {
        const raw = await backgroundSimulation(prompt, {
            maxTokens: 1800,
            temperature: 0.68,
            signal: controller.signal,
            taskKind: 'social',
            rejectTruncated: true,
        });
        const parsed = extractJsonObject(raw);
        if (!parsed) throw unreadableJsonError(raw, 'Model tạo Khoảnh khắc');
        if (controller.signal.aborted || chatToken !== currentChatToken() || contextEpoch !== runtime.contextEpoch) return null;
        store = getStore();
        const applied = applyMomentsPayload(store.social, store.currentState, parsed);
        store.social = applied.social;
        saveStore(store, { immediate: true });

        const settings = getSettings();
        let imageCount = 0;
        if (
            settings.imageApiEnabled
            && settings.imageApiUrl
            && settings.imageApiKey
            && settings.imageApiModel
        ) {
            // Limit one generated photo per refresh. It keeps costs and chat
            // metadata bounded while still allowing a natural mixed feed.
            const target = applied.posts.find(post => post.wantsImage && post.imagePrompt);
            if (target) {
                try {
                    const person = store.currentState.people.find(item => String(item?.id || '') === target.personId);
                    const generated = await requestImageGeneration(settings, {
                        prompt: [
                            'Một bức ảnh kèm bài đăng Khoảnh khắc tự nhiên, đời thường. Khung hình là thứ người đăng có thể chụp hoặc sở hữu ngay lúc đó, không xuất hiện chữ giao diện, watermark hay bí mật chưa được biết.',
                            `Người đăng: ${person?.name || 'Nhân vật'}. Bài đăng: ${target.text}`,
                            `Hình ảnh: ${target.imagePrompt}`,
                        ].join('\n'),
                        signal: controller.signal,
                    });
                    store = getStore();
                    store.social = attachMomentImage(store.social, store.currentState, target.id, {
                        imageUrl: generated.imageUrl,
                    });
                    saveStore(store, { immediate: true });
                    imageCount = 1;
                } catch (imageError) {
                    if (!isAbortError(imageError)) {
                        store = getStore();
                        store.social = attachMomentImage(store.social, store.currentState, target.id, {
                            error: describeError(imageError),
                        });
                        saveStore(store, { immediate: true });
                    }
                }
            }
        }
        runtime.momentsStatus = {
            phase: 'success',
            message: applied.posts.length
                ? `Thấy ${applied.posts.length} bài đăng mới${imageCount ? ', trong đó 1 bài có ảnh kèm' : ''}`
                : 'Lần này không có bạn bè nào muốn đăng bài',
            error: '',
        };
        runtime.ui?.render();
        return { postCount: applied.posts.length, imageCount };
    } catch (error) {
        if (isAbortError(error) || controller.signal.aborted) return null;
        runtime.momentsStatus = { phase: 'error', message: 'Làm mới Khoảnh khắc thất bại', error: describeError(error) };
        runtime.ui?.render();
        throw error;
    } finally {
        if (runtime.activeMoments?.controller === controller) runtime.activeMoments = null;
    }
}

async function handleUiAction(action, payload = {}) {
    if (action === 'test-image-api') {
        const result = await requestImageGeneration({
            imageApiUrl: payload.imageApiUrl,
            imageApiKey: payload.imageApiKey,
            imageApiModel: payload.imageApiModel,
            imageApiSize: '512x512',
            imageApiTimeoutMs: 180000,
        }, {
            prompt: 'A simple softly lit ceramic cup on a plain wooden table, natural photo, no text, no watermark.',
        });
        return Boolean(result?.imageUrl);
    }

    if (action === 'social-open-person') {
        const store = getStore();
        const person = store.currentState.people.find(item => String(item.id || '') === String(payload.personId || ''));
        if (!person || person.isUser) throw new Error('Không tìm thấy nhân vật có thể liên lạc');
        store.social = openDirectConversation(store.social, person, store.currentState.people);
        saveStore(store, { immediate: true });
        runtime.ui?.render();
        return store.social.activeConversationId;
    }

    if (action === 'social-select-conversation') {
        const store = getStore();
        store.social = selectSocialConversation(store.social, payload.conversationId, store.currentState.people);
        saveStore(store);
        return true;
    }

    if (action === 'social-create-group') {
        const store = getStore();
        store.social = createGroupConversation(store.social, payload, store.currentState.people);
        saveStore(store, { immediate: true });
        runtime.ui?.render();
        return store.social.activeConversationId;
    }

    if (action === 'social-send-message') {
        return await sendSocialMessage(payload.conversationId, payload.text);
    }

    if (action === 'social-request-reply') {
        return await sendSocialMessage(payload.conversationId, '', { requestOnly: true });
    }

    if (action === 'social-request-friend') {
        return await requestSocialFriend(payload.personId, payload.message || '');
    }

    if (action === 'social-respond-friend-request') {
        const store = getStore();
        const personId = String(payload.personId || '');
        const person = store.currentState.people.find(item => String(item?.id || '') === personId && !item?.isUser);
        if (!person) throw new Error('Không tìm thấy người gửi lời mời');
        store.social = respondIncomingFriendRequest(store.social, store.currentState, personId, payload.accept === true);
        saveStore(store, { immediate: true });
        runtime.ui?.render();
        return { accepted: payload.accept === true, personName: person.name };
    }

    if (action === 'social-remove-friend') {
        const store = getStore();
        const personId = String(payload.personId || '');
        const person = store.currentState.people.find(item => String(item?.id || '') === personId && !item?.isUser);
        if (!person) throw new Error('Không tìm thấy người bạn này');
        store.social = removeSocialFriend(store.social, store.currentState, personId);
        saveStore(store, { immediate: true });
        refreshInjection();
        runtime.ui?.render();
        return { removed: true, personName: person.name };
    }

    if (action === 'social-read-notice') {
        const store = getStore();
        store.social = markSocialNoticeRead(store.social, store.currentState, payload.noticeId || '');
        saveStore(store, { immediate: true });
        return true;
    }

    if (action === 'social-refresh-moments') {
        return await refreshSocialMoments();
    }

    if (action === 'social-toggle-moment-like') {
        const store = getStore();
        store.social = toggleMomentLike(store.social, store.currentState, payload.momentId);
        saveStore(store, { immediate: true });
        return true;
    }

    if (action === 'undo-manual') {
        undoManualChange();
        return;
    }

    if (action === 'create-recovery-point') {
        return createManualRecoveryPoint();
    }

    if (action === 'restore-latest-recovery') {
        return restoreLatestSavedRecovery();
    }

    if (action === 'copy-diagnostics') {
        return copyDiagnosticReport();
    }

    if (action === 'clear-current-chat-cache') {
        return clearCurrentChatCache();
    }

    if (action === 'reset-current-chat-data') {
        return await resetCurrentChatData();
    }

    if (action === 'check-correct-world-state') {
        return await checkAndCorrectWorldState();
    }

    if (action === 'preview-notice') {
        toast('Từ giờ việc lưu, khôi phục, suy diễn và báo lỗi đều sẽ được báo cho bạn bằng thông báo như thế này.', 'success');
        return null;
    }

    if (action === 'update-settings') {
        const context = getContext();
        const settings = getSettings();
        const autoHideDependencyDisabled = (
            payload.enabled === false
            || payload.memorySystemEnabled === false
            || payload.injectionMemory === false
            || payload.autoHideArchivedFloors === false
        );
        Object.assign(settings, payload);
        if (!settings.enabled || !settings.memorySystemEnabled || !settings.injectionMemory) {
            settings.autoHideArchivedFloors = false;
        }
        if (payload.memorySystemEnabled === false) {
            if (runtime.autoMemoryTimer !== null) {
                window.clearTimeout(runtime.autoMemoryTimer);
                runtime.autoMemoryTimer = null;
            }
            runtime.activeHistoryScan?.abort();
        }
        if (payload.publicOpinionAutoEnabled === false) {
            runtime.pendingPublicOpinion = false;
        }
        context.extensionSettings[MODULE_ID] = settings;
        saveSettings(Object.keys(payload || {}));
        let autoHideRestoreResult = null;
        if (autoHideDependencyDisabled) {
            if (runtime.autoHideTimer !== null) {
                window.clearTimeout(runtime.autoHideTimer);
                runtime.autoHideTimer = null;
            }
            autoHideRestoreResult = await restoreAutoHiddenFloors({ quiet: true });
            if (autoHideRestoreResult.restoredCount > 0) {
                toast(
                    `Đã dừng tự động ẩn và khôi phục ${autoHideRestoreResult.restoredCount} tầng chính văn cũ.`,
                    'success',
                );
            }
        }
        if (Object.prototype.hasOwnProperty.call(payload, 'recordPlayerCharacter')) {
            const store = getStore();
            store.currentState = applyPlayerCharacterRecordingPolicy(store.currentState, settings);
            store.initialState = applyPlayerCharacterRecordingPolicy(store.initialState, settings);
            saveStore(store, { immediate: true });
        }
        refreshInjection();
        syncSettingsEntry();
        runtime.ui?.render();
        if (payload.publicOpinionAutoEnabled === true) {
            scheduleAutoPublicOpinion(getState(), 120);
        }
        if (payload.autoHideArchivedFloors === true) {
            scheduleAutoHideArchivedFloors(20);
        }
        if (
            (payload.worldAutoEnabled === true)
            || (payload.autoSimulationMode && getSettings().worldAutoEnabled)
        ) {
            window.setTimeout(schedulePendingCatchUp, 40);
        }
        return autoHideRestoreResult;
    }

    if (action === 'lingqi-send-message') {
        return await sendLingqiMessage(payload.text || '');
    }

    if (action === 'lingqi-copy-support-pack') {
        const messageId = String(payload.messageId || '');
        const store = getStore();
        const messages = store.lingqi?.messages || [];
        const index = messages.findIndex(item => item.id === messageId);
        const message = index >= 0 ? messages[index] : null;
        if (!message?.needsAuthorHelp) throw new Error('Tin nhắn này không có gói nhờ trợ giúp');
        let question = '';
        for (let cursor = index - 1; cursor >= 0; cursor -= 1) {
            if (messages[cursor]?.role === 'user') {
                question = messages[cursor].text;
                break;
            }
        }
        const supportPack = buildLingqiSupportPack(
            question,
            message.supportTriage || {
                category: 'unknown',
                summary: question,
                checked: [],
                reason: message.supportReason,
            },
        );
        const copied = await copyTextSafely(supportPack);
        if (!copied) throw new Error('Trình duyệt không cho phép sao chép, hãy kiểm tra quyền clipboard');
        toast('Mảnh giấy nhỏ tha tới cho bạn rồi～mang đi cho mẹ xem nhé.', 'success');
        return supportPack;
    }

    if (action === 'lingqi-confirm-note') {
        return confirmLingqiNoteProposal();
    }

    if (action === 'lingqi-confirm-action') {
        return await confirmLingqiPendingAction();
    }

    if (action === 'lingqi-dismiss-action') {
        return dismissLingqiPendingAction();
    }

    if (action === 'lingqi-dismiss-note') {
        return dismissLingqiNoteProposal();
    }

    if (action === 'lingqi-pause-note') {
        return updateLingqiNoteStatus(payload.noteId, 'paused');
    }

    if (action === 'lingqi-resume-note') {
        return updateLingqiNoteStatus(payload.noteId, 'active');
    }

    if (action === 'lingqi-cancel-note') {
        return updateLingqiNoteStatus(payload.noteId, 'cancelled');
    }

    if (action === 'test-api') {
        return testCustomApiConnection();
    }

    if (action === 'pull-api-models') {
        return pullCustomApiModels();
    }

    if (action === 'save-api-profile') {
        return saveApiProfile(payload);
    }

    if (action === 'delete-api-profile') {
        return deleteApiProfile(payload.profileId);
    }

    if (action === 'duplicate-api-profile') {
        return duplicateApiProfile(payload.profileId);
    }

    if (action === 'test-api-profile') {
        return await testApiProfileConnection(payload.profileId);
    }

    if (action === 'pull-api-profile-models') {
        return await pullApiProfileModels(payload.profileId);
    }

    if (action === 'test-api-draft') {
        return await testApiDraftConnection(payload);
    }

    if (action === 'pull-api-draft-models') {
        return await pullApiDraftModels(payload);
    }

    if (action === 'scan-history') {
        return scanStoryMemoryHistory();
    }

    if (action === 'restore-auto-hidden-floors') {
        const result = await handleUiAction('update-settings', { autoHideArchivedFloors: false });
        if (!result?.restoredCount) {
            toast('Tự động ẩn đã tắt; hiện không có tầng nào cần khôi phục.', 'info');
        }
        return result;
    }

    if (action === 'bootstrap-history') {
        return bootstrapWorldFromHistory();
    }

    if (action === 'generate-public-opinion-sandbox') {
        return generatePublicOpinionSandbox();
    }

    if (action === 'clear-public-opinion-sandbox') {
        return clearPublicOpinionSandbox();
    }

    if (action === 'catch-up-person') {
        return await runPersonLifeCatchUp(String(payload.personId || ''));
    }

    if (action === 'prioritize-person') {
        return setPersonLifePriority(
            String(payload.personId || ''),
            payload.enabled !== false,
        );
    }

    if (action === 'observe-person') {
        return observePerson(String(payload.personId || ''), { force: Boolean(payload.force) });
    }

    if (action === 'get-person-observation') {
        return cachedPersonObservation(String(payload.personId || ''));
    }

    if (action === 'queue-person-observation') {
        return queuePersonObservation(String(payload.personId || ''));
    }

    if (action === 'save-world-summary') {
        const title = String(payload.title || '').trim();
        const detail = String(payload.detail || '').trim();
        const background = String(payload.background || '').trim();
        if (!title || !detail) throw new Error('Tiêu đề và tổng quan thế giới không được để trống');
        const next = clone(getState());
        next.world ||= {};
        next.world.title = title.slice(0, 140);
        next.world.detail = detail.slice(0, 900);
        next.world.background = background.slice(0, 5000);
        commitManualState(
            next,
            background
                ? 'Tổng quan thế giới và thiết lập bối cảnh đã được cập nhật rồi～'
                : 'Tổng quan thế giới đã được cập nhật; thiết lập bối cảnh vẫn để trống.',
        );
        return next.world;
    }

    if (action === 'save-record') {
        const kind = payload.kind === 'archive' ? 'archive' : 'echo';
        const id = String(payload.id || '');
        const title = String(payload.title || '').trim();
        const text = String(payload.text || '').trim();
        if (!title || !text) throw new Error('Tiêu đề và nội dung không được để trống');
        const next = clone(getState());
        const visibility = ['hidden', 'trace', 'known', 'direct'].includes(payload.visibility)
            ? payload.visibility
            : 'hidden';

        if (kind === 'echo') {
            const event = next.events.find(item => item.id === id);
            if (!event) throw new Error('Không tìm thấy Tiếng vọng này');
            event.title = title.slice(0, 140);
            event.result = text.slice(0, 900);
            event.consequence = event.result;
            event.place = String(payload.place || event.place || '').trim().slice(0, 160);
            event.visibility = visibility;
            event.delivery ||= { state: 'none' };
            event.delivery.state = ['none', 'pending', 'delivered', 'expired'].includes(payload.deliveryState)
                ? payload.deliveryState
                : event.delivery.state;
            event.updatedAt = next.clock.absoluteMinute;
            for (const echo of next.echoes || []) {
                if (echo.eventId !== event.id) continue;
                echo.title = event.title;
                echo.route = event.result;
            }
            for (const entry of next.archive || []) {
                if (entry.eventId !== event.id) continue;
                entry.title = event.title;
                entry.text = event.result;
                entry.visibility = event.visibility;
                entry.deliveryState = event.delivery.state;
            }
            commitManualState(next, `Tiếng vọng “${event.title}” đã được cập nhật.`);
            return event;
        }

        const entry = next.archive.find(item => item.id === id);
        if (!entry) throw new Error('Không tìm thấy mục Biên niên này');
        entry.title = title.slice(0, 140);
        entry.text = text.slice(0, 900);
        entry.visibility = visibility;
        entry.manual = true;
        commitManualState(next, `Biên niên “${entry.title}” đã được cập nhật.`);
        return entry;
    }

    if (action === 'delete-record') {
        const kind = payload.kind === 'archive' ? 'archive' : 'echo';
        const id = String(payload.id || '');
        const next = clone(getState());
        if (kind === 'echo') {
            const index = next.events.findIndex(item => item.id === id);
            if (index < 0) throw new Error('Không tìm thấy Tiếng vọng này');
            const [removed] = next.events.splice(index, 1);
            next.echoes = (next.echoes || []).filter(item => item.eventId !== removed.id);
            next.archive = (next.archive || []).filter(item => item.eventId !== removed.id);
            commitManualState(next, `Tiếng vọng “${removed.title}” đã bị xóa.`, {
                mutateStore: store => addEventDeletionTombstone(store, removed),
            });
            return true;
        }
        const index = next.archive.findIndex(item => item.id === id);
        if (index < 0) throw new Error('Không tìm thấy mục Biên niên này');
        const [removed] = next.archive.splice(index, 1);
        commitManualState(next, `Biên niên “${removed.title || 'Bản ghi chưa đặt tên'}” đã bị xóa.`);
        return;
    }

    if (action === 'save-memory-item') {
        const kind = ['fact', 'clue', 'summary'].includes(payload.kind) ? payload.kind : 'fact';
        const id = String(payload.id || '');
        const title = String(payload.title || '').trim();
        const relation = String(payload.relation || '').trim();
        const content = String(payload.content || '').trim();
        const cluePeople = Array.isArray(payload.people)
            ? payload.people.map(value => String(value || '').trim()).filter(Boolean).slice(0, 16)
            : [];
        const clueLocations = Array.isArray(payload.locations)
            ? payload.locations.map(value => String(value || '').trim()).filter(Boolean).slice(0, 12)
            : [];
        const clueEvents = Array.isArray(payload.events)
            ? payload.events.map(value => String(value || '').trim()).filter(Boolean).slice(0, 16)
            : [];
        if (!title || !content) throw new Error('Tiêu đề và nội dung không được để trống');

        const next = clone(getState());
        next.storyMemory ||= { facts: [], clues: [], summaries: [] };
        const collection = kind === 'fact'
            ? next.storyMemory.facts
            : kind === 'clue'
                ? next.storyMemory.clues
                : next.storyMemory.summaries;
        const existing = collection.find(item => item.id === id);
        if (existing?.locked && payload.locked === false) {
            throw new Error('Hãy mở khóa bằng nút khóa trên thẻ trước, rồi mới sửa ký ức này');
        }
        const itemId = existing?.id || `${kind}_manual_${Date.now().toString(36)}`;
        const common = {
            ...(existing || {}),
            id: itemId,
            locked: Boolean(payload.locked),
            important: Boolean(payload.important),
            manual: true,
        };
        let updated;
        if (kind === 'fact') {
            updated = {
                ...common,
                key: existing?.key || `manual:${hashText(`${title}\n${relation}`)}`,
                subject: title.slice(0, 100),
                predicate: relation.slice(0, 100),
                value: content.slice(0, 520),
                status: existing?.status || 'active',
                confidence: existing?.confidence || 'high',
                importance: payload.important ? 3 : (existing?.importance || 2),
                visibility: existing?.visibility || 'known',
                updatedAt: next.clock.absoluteMinute,
            };
        } else if (kind === 'clue') {
            updated = {
                ...common,
                title: title.slice(0, 120),
                text: content.slice(0, 620),
                status: existing?.status || 'open',
                people: cluePeople,
                locations: clueLocations,
                events: clueEvents,
                archived: Boolean(existing?.archived),
                archivedAt: existing?.archivedAt ?? null,
                importance: payload.important ? 3 : (existing?.importance || 1),
                visibility: existing?.visibility || 'hidden',
                updatedAt: next.clock.absoluteMinute,
                createdAt: existing?.createdAt ?? next.clock.absoluteMinute,
            };
            const timingBaseMinute = Number(updated.createdAt ?? next.clock.absoluteMinute) || next.clock.absoluteMinute;
            updated.timing = resolveFutureTimeExpression(
                [updated.sourceExcerpt, updated.text].filter(Boolean).join('\n'),
                {
                    baseAbsoluteMinute: timingBaseMinute,
                    baseCalendar: formatWorldCalendar(next, timingBaseMinute),
                    calendarBound: Boolean(next.clock?.anchored),
                },
            );
            if (updated.timing) {
                updated.timing = normalizeClueTiming(updated.timing, next.clock.absoluteMinute);
            }
        } else {
            const anchor = latestAssistantEntry()?.index ?? 0;
            updated = {
                ...common,
                title: title.slice(0, 120),
                summary: content.slice(0, 1400),
                startMessageId: existing?.startMessageId ?? anchor,
                endMessageId: existing?.endMessageId ?? anchor,
                level: existing?.level ?? 1,
                hierarchyManaged: existing?.hierarchyManaged ?? false,
                parentId: existing?.parentId || '',
                sourceSummaryIds: existing?.sourceSummaryIds || [],
                createdAt: existing?.createdAt || new Date().toISOString(),
            };
        }
        if (existing) Object.assign(existing, updated);
        else collection.unshift(updated);
        commitManualState(next, existing ? 'Ký ức đã được cập nhật.' : 'Đã thêm ký ức thủ công.');
        return updated;
    }

    if (action === 'set-clue-archive-state') {
        const next = clone(getState());
        const clue = next.storyMemory?.clues?.find(entry => entry.id === String(payload.id || ''));
        if (!clue) throw new Error('Không tìm thấy Phục bút này');
        if (clue.locked) throw new Error('Phục bút đã khóa không thể lưu trữ, hãy mở khóa trước');
        const archived = Boolean(payload.archived);
        if (archived && !['resolved', 'discarded'].includes(clue.status)) {
            throw new Error('Phục bút vẫn đang phát triển thì không thể lưu trữ trực tiếp; hãy để nó hoàn tất/buông bỏ trước, hoặc xóa thẳng');
        }
        clue.archived = archived;
        clue.archivedAt = archived ? next.clock.absoluteMinute : null;
        clue.updatedAt = next.clock.absoluteMinute;
        commitManualState(
            next,
            archived ? `Phục bút “${clue.title || 'Phục bút chưa đặt tên'}” đã được lưu trữ.` : `Phục bút “${clue.title || 'Phục bút chưa đặt tên'}” đã được chuyển về danh sách Đã thu hồi.`,
        );
        return true;
    }

    if (action === 'toggle-memory-flag') {
        const kind = ['fact', 'clue', 'summary'].includes(payload.kind) ? payload.kind : 'fact';
        const field = payload.field === 'locked' ? 'locked' : 'important';
        const next = clone(getState());
        const collection = kind === 'fact'
            ? next.storyMemory?.facts
            : kind === 'clue'
                ? next.storyMemory?.clues
                : next.storyMemory?.summaries;
        const item = collection?.find(entry => entry.id === String(payload.id || ''));
        if (!item) throw new Error('Không tìm thấy ký ức này');
        item[field] = !item[field];
        if (field === 'important' && item.important && 'importance' in item) item.importance = 3;
        commitManualState(next, field === 'locked'
            ? (item.locked ? 'Ký ức đã khóa, sẽ không bị tự động sắp xếp ghi đè.' : 'Ký ức đã được mở khóa.')
            : (item.important ? 'Đã đánh dấu là ký ức quan trọng.' : 'Đã bỏ đánh dấu quan trọng.'));
        return;
    }

    if (action === 'bulk-delete-memory') {
        const requested = Array.isArray(payload.items) ? payload.items : [];
        const unique = new Map();
        for (const item of requested) {
            const kind = ['fact', 'clue', 'summary'].includes(item?.kind) ? item.kind : '';
            const id = String(item?.id || '').trim();
            if (!kind || !id) continue;
            unique.set(`${kind}:${id}`, { kind, id });
        }
        if (!unique.size) throw new Error('Chưa chọn ký ức nào để xóa');

        // Bulk deletion is intentionally safer than a normal one-card delete:
        // create a durable recovery point before touching the memory pool.
        let store = addRecoveryPoint(getStore(), {
            reason: 'before-memory-bulk-delete',
            label: `Dọn hàng loạt ${unique.size} ký ức — tự động lưu trước khi dọn`,
        });
        saveStore(store, { immediate: true });

        const next = clone(store.currentState);
        next.storyMemory ||= { facts: [], clues: [], summaries: [] };
        const removedSummaryIds = new Set();
        const removedItems = [];
        let removed = 0;
        let lockedSkipped = 0;

        for (const { kind, id } of unique.values()) {
            const collection = kind === 'fact'
                ? next.storyMemory.facts
                : kind === 'clue'
                    ? next.storyMemory.clues
                    : next.storyMemory.summaries;
            const index = collection.findIndex(entry => entry.id === id);
            if (index < 0) continue;
            if (collection[index].locked) {
                lockedSkipped += 1;
                continue;
            }
            if (kind === 'summary') removedSummaryIds.add(collection[index].id);
            removedItems.push({ kind, item: clone(collection[index]) });
            collection.splice(index, 1);
            removed += 1;
        }

        if (removedSummaryIds.size) {
            for (const summary of next.storyMemory.summaries || []) {
                if (removedSummaryIds.has(summary.parentId)) summary.parentId = '';
                if (Array.isArray(summary.sourceSummaryIds)) {
                    summary.sourceSummaryIds = summary.sourceSummaryIds.filter(
                        id => !removedSummaryIds.has(id),
                    );
                }
            }
            // The chat-level summary reservoir must forget manually deleted
            // summaries too, otherwise restoring a compact branch could resurrect them.
            store.memorySummaryArchive = (store.memorySummaryArchive || []).filter(
                summary => !removedSummaryIds.has(summary?.id),
            );
            saveStore(store, { immediate: true });
        }

        if (!removed) {
            throw new Error(lockedSkipped
                ? 'Các ký ức đã chọn đều đang bị khóa, không có gì bị xóa'
                : 'Không tìm thấy các ký ức này, có thể chúng đã được sắp xếp gộp đi rồi');
        }

        commitManualState(
            next,
            lockedSkipped
                ? `Đã xóa ${removed} ký ức, ${lockedSkipped} ký ức đang khóa vẫn ngoan ngoãn ở lại～`
                : `Đã xóa ${removed} ký ức; điểm khôi phục trước khi xóa đã được lưu sẵn rồi～`,
            {
                mutateStore: targetStore => {
                    for (const removedEntry of removedItems) {
                        addMemoryDeletionTombstone(targetStore, removedEntry.kind, removedEntry.item);
                    }
                },
            },
        );
        return true;
    }

    if (action === 'delete-memory-item') {
        const kind = ['fact', 'clue', 'summary'].includes(payload.kind) ? payload.kind : 'fact';
        const next = clone(getState());
        const collection = kind === 'fact'
            ? next.storyMemory?.facts
            : kind === 'clue'
                ? next.storyMemory?.clues
                : next.storyMemory?.summaries;
        const index = collection?.findIndex(entry => entry.id === String(payload.id || '')) ?? -1;
        if (index < 0) throw new Error('Không tìm thấy ký ức này');
        if (collection[index].locked) throw new Error('Ký ức đã khóa thì không xóa được, hãy mở khóa trước');
        const removed = collection[index];
        if (kind === 'summary') {
            const summaries = next.storyMemory?.summaries || [];
            for (const summary of summaries) {
                if (summary.parentId === removed.id) summary.parentId = '';
                if (Array.isArray(summary.sourceSummaryIds) && summary.sourceSummaryIds.includes(removed.id)) {
                    summary.sourceSummaryIds = summary.sourceSummaryIds.filter(id => id !== removed.id);
                }
            }
        }
        collection.splice(index, 1);
        if (kind === 'summary') {
            const store = getStore();
            store.memorySummaryArchive = (store.memorySummaryArchive || []).filter(
                summary => summary?.id !== removed.id,
            );
            saveStore(store);
        }
        commitManualState(next, 'Ký ức đã bị xóa.', {
            mutateStore: store => addMemoryDeletionTombstone(store, kind, removed),
        });
        return;
    }

    if (action === 'save-manual-person') {
        const id = String(payload.id || '');
        const originalName = String(payload.originalName || '').trim();
        const name = String(payload.name || '').trim();
        if (!name) throw new Error('Tên nhân vật không được để trống');
        const next = clone(getState());
        const existing = next.people.find(person => (
            person.id === id
            && (!originalName || person.name === originalName)
        )) || next.people.find(person => person.id === id);
        if (existing?.locked && payload.locked === false) {
            throw new Error('Hãy mở khóa thẻ nhân vật trước rồi mới sửa thiết lập cốt lõi');
        }
        const person = {
            ...(existing || {}),
            id: existing?.id || `person_manual_${hashText(`${name}\n${Date.now()}`)}`,
            name: name.slice(0, 80),
            monogram: name.slice(0, 1),
            avatarDataUrl: payload.avatarDataUrl === null || payload.avatarDataUrl === undefined
                ? String(existing?.avatarDataUrl || '')
                : String(payload.avatarDataUrl || '').slice(0, 180000),
            location: String(payload.location || 'Vị trí chờ xác nhận').trim().slice(0, 160),
            action: String(payload.action || 'Hành động hiện tại chờ xác nhận').trim().slice(0, 280),
            intent: String(payload.intent || 'Ý định ngắn hạn chờ xác nhận').trim().slice(0, 320),
            longTermGoal: String(payload.longTermGoal || '').trim().slice(0, 420),
            innerVoice: String(payload.innerVoice ?? existing?.innerVoice ?? '').trim().slice(0, 240),
            innerVoiceAt: next.clock.absoluteMinute,
            identityAnchor: String(payload.identityAnchor ?? existing?.identityAnchor ?? '').trim(),
            personalityAnchor: String(payload.personalityAnchor ?? existing?.personalityAnchor ?? '').trim(),
            appearanceProfile: String(payload.appearanceProfile ?? existing?.appearanceProfile ?? '').trim(),
            backgroundProfile: String(payload.backgroundProfile ?? existing?.backgroundProfile ?? '').trim(),
            abilityProfile: String(payload.abilityProfile ?? existing?.abilityProfile ?? '').trim(),
            speakingStyle: String(payload.speakingStyle ?? existing?.speakingStyle ?? '').trim(),
            behaviorBoundaries: String(payload.behaviorBoundaries ?? existing?.behaviorBoundaries ?? '').trim(),
            knowledge: payload.knowledge === 'known' ? 'known' : 'backstage',
            relevance: Math.min(3, Math.max(0, Number(payload.relevance) || 2)),
            simulationEnabled: Boolean(payload.simulationEnabled),
            locked: Boolean(payload.locked),
            manual: true,
            source: 'manual',
            isUser: Boolean(existing?.isUser),
            updatedAt: next.clock.absoluteMinute,
        };
        if (existing) Object.assign(existing, person);
        else next.people.push(person);
        const reconciled = settlePersonWorldState(next, person.id, { source: 'manual' });
        commitManualState(
            reconciled,
            existing ? 'Đã cập nhật thẻ nhân vật nền.' : `Đã đưa ${person.name} vào danh sách nhân vật nền.`,
            {
                mutateStore: store => clearPersonDeletionTombstone(store, person),
            },
        );
        return person;
    }

    if (action === 'clear-person-avatar') {
        const next = clone(getState());
        const person = next.people.find(item => item.id === String(payload.id || ''));
        if (!person) throw new Error('Không tìm thấy nhân vật này');
        person.avatarDataUrl = '';
        person.updatedAt = next.clock.absoluteMinute;
        commitManualState(next, 'Ảnh đại diện nhân vật đã trở về dạng chữ rồi～');
        return true;
    }

    if (action === 'delete-manual-person') {
        const next = clone(getState());
        const index = next.people.findIndex(person => person.id === String(payload.id || ''));
        if (index < 0) throw new Error('Không tìm thấy nhân vật này');
        if (next.people[index].locked) throw new Error('Thẻ nhân vật đã khóa thì không xóa được, hãy mở khóa trước');
        const [removed] = next.people.splice(index, 1);
        commitManualState(next, `Đã gỡ nhân vật nền ${removed.name}。`, {
            mutateStore: store => addPersonDeletionTombstone(store, removed),
        });
        return true;
    }

    if (action === 'delete-manual-people') {
        const ids = new Set(
            (Array.isArray(payload.ids) ? payload.ids : [])
                .map(id => String(id || '').trim())
                .filter(Boolean)
                .slice(0, 120),
        );
        if (!ids.size) throw new Error('Hãy chọn nhân vật cần xóa trước');
        const next = clone(getState());
        const removed = next.people.filter(person => (
            ids.has(String(person.id || ''))
            && !person.locked
            && !person.isUser
        ));
        if (!removed.length) throw new Error('Các nhân vật đã chọn đều đang bị khóa, là nhân vật người chơi, hoặc không còn trong danh sách');
        next.people = next.people.filter(person => !removed.includes(person));
        commitManualState(next, `Đã gỡ hàng loạt ${removed.length} nhân vật nền.`, {
            mutateStore: store => {
                for (const person of removed) addPersonDeletionTombstone(store, person);
            },
        });
        return {
            removed: removed.length,
            names: removed.map(person => person.name).filter(Boolean),
            skipped: ids.size - removed.length,
        };
    }
    if (['social_send_message', 'social_accept_request', 'social_refuse_request', 'social_remove_friend'].includes(action.type)) {
        const person = findLingqiPersonTarget(action);
        if (!person || person.isUser) return { error: 'Tai mình nghe chưa rõ là muốn làm với ai, mình giữ chân lại trước, không động lung tung vào quan hệ.' };
        if (action.type === 'social_send_message') {
            const body = String(action.text || '').trim();
            if (!body) return { error: 'Tin nhắn đang trống, mình sẽ không đoán bừa một câu để nhét vào đâu.' };
            return {
                title: `Gửi câu này cho ${person.name}？`,
                detail: `Mình sẽ gửi đúng nguyên văn: “${body.slice(0, 180)}${body.length > 180 ? '…' : ''}”\nGửi xong thì không thể thu hồi ở phía người kia; người kia vẫn sẽ tự quyết định có trả lời hay không tùy hoàn cảnh của mình.`,
                confirmLabel: 'Xác nhận gửi',
            };
        }
        if (action.type === 'social_accept_request') return { title: `Thêm ${person.name} vào danh bạ?`, detail: 'Sau khi xác nhận sẽ chấp nhận lời mời kết bạn, hai bên có thể nhắn tin riêng cho nhau.', confirmLabel: 'Chấp nhận' };
        if (action.type === 'social_refuse_request') return { title: `Từ chối lời mời kết bạn của ${person.name}?`, detail: 'Sau khi từ chối sẽ không vào danh bạ; lời mời và phản ứng của người kia sẽ được giữ lại làm hồ sơ quan hệ.', confirmLabel: 'Từ chối' };
        return { title: `Hủy kết bạn với ${person.name}?`, detail: 'Sau khi xác nhận chỉ hủy kết bạn và dừng chat riêng; tin nhắn cũ và nhóm chat chung vẫn được giữ lại.', confirmLabel: 'Xóa bạn' };
    }
    if (action.type === 'social_refresh_moments') {
        return {
            title: 'Ra cửa sổ Khoảnh khắc ngồi canh một lúc nhé?',
            detail: getSettings().imageApiEnabled
                ? 'Sẽ gọi model xã hội một lần; nếu nhân vật thật sự muốn kèm ảnh thì có thể gọi thêm API tạo ảnh một lần nữa.'
                : 'Sẽ gọi model xã hội một lần; nếu không nhân vật nào muốn đăng bài thì có thể để trống.',
            confirmLabel: 'Làm mới',
        };
    }
    if (action === 'sync-clock-from-story') {
        const latest = latestAssistantEntry();
        if (!latest?.message) {
            toast('Không nhận ra thời gian trong chính văn.', 'warning');
            return false;
        }
        const anchor = extractNarrativeTimeAnchor(selectedMessageText(latest.message));
        if (!anchor) {
            toast('Không nhận ra thời gian trong chính văn.', 'warning');
            return false;
        }

        const current = getState();
        const clock = formatWorldCalendar(current);
        const hasDate = Number.isFinite(anchor.year) && Number.isFinite(anchor.month) && Number.isFinite(anchor.day);
        const hasMinute = Number.isFinite(anchor.hour) && Number.isFinite(anchor.minute);
        const next = setWorldCalendar(current, {
            calendarName: clock.calendarName,
            year: hasDate ? anchor.year : clock.year,
            month: hasDate ? anchor.month : clock.month,
            day: hasDate ? anchor.day : clock.dayOfMonth,
            hour: hasMinute ? anchor.hour : clock.hour,
            minute: hasMinute ? anchor.minute : clock.minute,
            reason: `Căn chỉnh theo chính văn mới nhất${anchor.excerpt ? `：${anchor.excerpt}` : ''}`,
        });
        next.clock.precision = hasMinute ? 'minute' : (anchor.daypart ? 'daypart' : 'date');
        next.clock.source = 'narrative-manual-sync';
        next.clock.reason = `Căn chỉnh thủ công theo chính văn mới nhất${anchor.excerpt ? `：${anchor.excerpt}` : ''}`.slice(0, 240);
        commitManualState(
            next,
            hasDate && hasMinute
                ? `Đã căn chỉnh theo chính văn đến ${anchor.year}年${anchor.month}月${anchor.day}日 ${String(anchor.hour).padStart(2, '0')}:${String(anchor.minute).padStart(2, '0')}。`
                : hasDate
                    ? `Đã đồng bộ ngày theo chính văn: ${anchor.year}年${anchor.month}月${anchor.day}日${anchor.daypart ? ` · ${anchor.daypart}` : ''}; chính văn chưa nêu giờ phút chính xác, giữ nguyên giờ phút hiện tại.`
                    : `Đã đồng bộ giờ theo chính văn: ${String(anchor.hour).padStart(2, '0')}:${String(anchor.minute).padStart(2, '0')}。`,
        );
        return true;
    }

    if (action === 'set-clock') {
        const next = setWorldCalendar(getState(), {
            calendarName: payload.calendarName,
            year: payload.year,
            month: payload.month,
            day: payload.day,
            hour: payload.hour,
            minute: payload.minute,
            reason: 'Căn chỉnh trong 世界背面',
        });
        commitManualState(next, 'Đã căn chỉnh thời gian thế giới chính.');
        return;
    }

    if (action === 'advance-clock') {
        const minutes = Number(payload.minutes) || 0;
        const next = advanceWorldClock(getState(), minutes, 'Đẩy tới thủ công trong 世界背面');
        commitManualState(next, `Thời gian thế giới chính đã được đẩy tới ${minutes} phút.`);
        if (minutes > 0 && getSettings().worldAutoEnabled && getSettings().worldSimulationEnabled) {
            window.setTimeout(() => {
                void runWorldPulseTick({
                    reason: `Người dùng tự đẩy thời gian thế giới chính thêm ${minutes} phút`,
                });
            }, 80);
        }
        return;
    }

    if (action === 'add-event') {
        const durationHours = Number(payload.durationHours) || 0;
        const durationMinutes = Math.max(0, Math.round(durationHours * 60));
        const clockMode = payload.clockMode;
        const next = addManualEvent(getState(), {
            title: payload.title,
            place: payload.place,
            summary: payload.summary,
            expected_result: payload.expectedResult,
            consequence: payload.expectedResult,
            clock_mode: clockMode,
            duration_minutes: durationMinutes,
            scheduled_at: clockMode === 'scheduled'
                ? getState().clock.absoluteMinute + durationMinutes
                : null,
            visibility: payload.visibility,
            delivery_route: '',
        });
        const created = next.events.at(-1);
        commitManualState(next, `Mạch ngầm “${payload.title}” đã bắt đầu phát triển.`, {
            mutateStore: store => clearEventDeletionTombstone(store, created),
        });
        return;
    }

    if (action === 'update-event') {
        const eventId = String(payload.id || payload.eventId || '');
        const title = String(payload.title || '').trim();
        if (!title) throw new Error('Tên sự kiện không được để trống');

        const next = clone(getState());
        const event = next.events.find(item => item.id === eventId);
        if (!event) throw new Error('Không tìm thấy Mạch ngầm này');
        if (['resolved', 'cancelled', 'missed'].includes(event.status)) {
            throw new Error('Sự kiện đã có kết quả thì hãy xem ở “Tiếng vọng”, không thể sửa như một Mạch ngầm nữa');
        }

        const previousClockMode = event.clockMode;
        const previousDuration = Number(event.durationMinutes) || 0;
        const clockMode = ['duration', 'active', 'scheduled', 'condition'].includes(payload.clockMode)
            ? payload.clockMode
            : event.clockMode;
        const durationHours = Math.max(0, Number(payload.durationHours) || 0);
        const durationMinutes = Math.round(durationHours * 60);
        const timingChanged = previousClockMode !== clockMode || previousDuration !== durationMinutes;
        const previousStatus = event.status;
        const previousWasTerminal = ['resolved', 'cancelled', 'missed'].includes(previousStatus);
        const requestedStatus = ['active', 'waiting', 'ready', 'resolved', 'cancelled', 'missed']
            .includes(payload.status)
            ? payload.status
            : previousStatus;
        const hasManualResult = Object.prototype.hasOwnProperty.call(payload, 'result');

        event.title = title.slice(0, 140);
        event.place = String(payload.place || 'Địa điểm chờ xác nhận').trim().slice(0, 140) || 'Địa điểm chờ xác nhận';
        event.summary = String(payload.summary || '').trim().slice(0, 420);
        event.expectedResult = String(payload.expectedResult || '').trim().slice(0, 420);
        event.consequence = event.expectedResult;
        event.visibility = ['hidden', 'trace', 'known', 'direct'].includes(payload.visibility)
            ? payload.visibility
            : event.visibility;
        event.clockMode = clockMode;
        event.durationMinutes = durationMinutes;

        if (timingChanged) {
            if (clockMode === 'duration' || clockMode === 'scheduled') {
                event.dueAt = Number(event.startedAt || next.clock.absoluteMinute) + durationMinutes;
                event.accruedMinutes = 0;
                if (event.dueAt <= next.clock.absoluteMinute) {
                    event.status = 'ready';
                } else if (event.status === 'ready') {
                    event.status = 'active';
                    event.result = '';
                }
            } else if (clockMode === 'active') {
                event.dueAt = null;
                event.accruedMinutes = Math.min(Number(event.accruedMinutes) || 0, durationMinutes || Number.MAX_SAFE_INTEGER);
                if (durationMinutes > 0 && event.accruedMinutes >= durationMinutes) {
                    event.status = 'ready';
                } else if (event.status === 'ready') {
                    event.status = 'active';
                    event.result = '';
                }
            } else {
                event.dueAt = null;
                event.accruedMinutes = 0;
                if (event.status === 'ready') {
                    event.status = 'active';
                    event.result = '';
                }
            }
        }

        event.status = requestedStatus;
        if (['resolved', 'cancelled', 'missed'].includes(requestedStatus)) {
            if (hasManualResult) event.result = String(payload.result || '').trim().slice(0, 620);
            event.resolvedAt = previousWasTerminal
                ? (event.resolvedAt ?? next.clock.absoluteMinute)
                : next.clock.absoluteMinute;
        } else {
            if (previousWasTerminal && requestedStatus !== previousStatus) event.result = '';
            event.resolvedAt = null;
        }
        event.updatedAt = next.clock.absoluteMinute;
        commitManualState(next, `Mạch ngầm “${event.title}” đã được cập nhật.`);
        return event;
    }

    if (action === 'delete-event') {
        const eventId = String(payload.eventId || payload.id || '');
        cancelActiveBackgroundTasks({ preserveLingqi: true });
        const next = clone(getState());
        const index = next.events.findIndex(item => item.id === eventId);
        if (index < 0) throw new Error('Không tìm thấy Mạch ngầm này');
        const [removed] = next.events.splice(index, 1);
        next.echoes = (next.echoes || []).filter(echo => echo.eventId !== eventId);
        commitManualState(next, `Mạch ngầm “${removed.title}” đã bị xóa, và các lượt suy diễn sau sẽ không tự động thêm lại.`, {
            mutateStore: store => addEventDeletionTombstone(store, removed),
        });
        return;
    }

    if (action === 'toggle-event-delivery') {
        const eventId = String(payload.eventId || '');
        const next = clone(getState());
        const event = next.events.find(item => item.id === eventId);
        if (!event) throw new Error('Không tìm thấy sự kiện này');
        if (event.visibility === 'hidden') {
            throw new Error('Sự kiện bị ẩn hoàn toàn thì không thể chèn vào chính văn; hãy chỉnh lại mức hiển thị của nó trước');
        }
        event.delivery ||= { state: 'none' };
        event.delivery.manualQueued = !event.delivery.manualQueued;
        commitManualState(
            next,
            event.delivery.manualQueued
                ? `“${event.title}” sẽ được ưu tiên tìm thời điểm hé lộ tự nhiên ở lượt sau.`
                : `Đã hủy hé lộ ở lượt sau của “${event.title}”.`,
        );
        return;
    }

    if (action === 'generate-public-opinion') {
        return await generatePublicOpinionSnapshot({
            allowDefer: true,
            // 不借按钮凭空推进公共世界，但既有公开事件的传播后果必须先进入世界状态；
            // 否则新闻只会成为与人物认知和正文脱节的 UI 卡片。
            ensurePublicWorld: true,
            settlePublicImpact: true,
            // 没有新的公开表面、世界时间节点或覆盖巡查结果时，不为了换措辞
            // 再打一份舆情 API；按钮仍会先完成所有真正到期的世界工作。
            force: false,
        });
    }

    if (action === 'clear-public-opinion') {
        return clearPublicOpinionSnapshot();
    }

    if (action === 'dismiss-public-opinion-item') {
        return dismissPublicOpinionItem(payload.kind, payload.itemId);
    }

    if (action === 'scan-tag-candidates') {
        const texts = recentRawAssistantTexts(payload.count || 1);
        return extractTagFilterCandidates(texts, getSettings().tagFilterRules || []);
    }

    if (action === 'select-worldbook') {
        runtime.worldbookScanToken = null;
        discardWorldbookDrafts();
        runtime.worldbookScan = { phase: 'idle', message: '', bookName: String(payload.bookName || ''), entries: [] };
        runtime.ui?.render();
        return true;
    }

    if (action === 'scan-worldbook') {
        return await scanWorldbook(payload.bookName);
    }

    if (action === 'import-worldbook-people') {
        return importWorldbookPeople(payload.bookName, payload.entryIds);
    }

    if (action === 'smart-import-worldbook-people') {
        return await smartImportWorldbookPeople(payload.bookName);
    }

    if (action === 'cancel-background-tasks') {
        const result = cancelActiveBackgroundTasks();
        if (!result.cancelled) {
            toast('Hiện không có tác vụ nền nào đang chạy hoặc đang xếp hàng.', 'info');
        } else {
            toast(`Đã dừng: ${result.labels.join('、')}。`, 'success');
        }
        return result;
    }

    if (action === 'ai-import-worldbook-people') return await runWorldbookAiImport(payload.bookName, payload.entryIds);
    if (action === 'commit-worldbook-drafts') return commitWorldbookDrafts(payload.selections, payload);
    if (action === 'discard-worldbook-drafts') return discardWorldbookDrafts();

    if (action === 'cancel-simulation') {
        if (!cancelActiveSimulation()) {
            toast('Hiện không có suy diễn thế giới nào đang chạy.', 'info');
        }
        return;
    }

    if (action === 'resolve-message-edit') {
        await resolveMessageEdit(payload.mode === 'keep' ? 'keep' : 'rerun');
        return;
    }

    if (action === 'manual-sync') {
        return await requestManualWorldSimulation();
    }

    if (action === 'export-state') {
        exportState();
        return;
    }

    if (action === 'import-state-data') {
        try {
            importState(payload.text);
        } catch (error) {
            toast(`Nhập thất bại: ${error?.message || error}`, 'error');
        }
    }
}

function installSettingsEntry() {
    if (document.getElementById('world-backstage-settings-entry')) return;
    const host = document.querySelector('#extensions_settings2, #extensions_settings');
    if (!host) return;

    const entry = document.createElement('div');
    entry.id = 'world-backstage-settings-entry';
    entry.className = 'world-backstage-settings-entry';
    entry.innerHTML = `
        <div class="inline-drawer">
            <div class="inline-drawer-toggle inline-drawer-header">
                <b>世界背面</b>
                <div class="inline-drawer-icon fa-solid fa-circle-chevron-down down"></div>
            </div>
            <div class="inline-drawer-content">
                <label class="checkbox_label">
                    <input id="world-backstage-enabled" type="checkbox">
                    <span>Bật 世界背面</span>
                </label>
                <label class="checkbox_label">
                    <input id="world-backstage-orb-enabled" type="checkbox">
                    <span>Hiện bóng nổi</span>
                </label>
                <p class="notes">Những nơi ống kính không chiếu tới cũng vẫn tiếp tục sống～ thời gian, nhân vật và sự kiện đều tự trôi về phía trước (｡•̀ᴗ-)✧</p>
                <button id="world-backstage-open" class="menu_button" type="button">
                    Mở 世界背面
                </button>
            </div>
        </div>
    `;
    host.appendChild(entry);

    entry.querySelector('#world-backstage-enabled')?.addEventListener('change', event => {
        void handleUiAction('update-settings', { enabled: event.target.checked });
    });
    entry.querySelector('#world-backstage-orb-enabled')?.addEventListener('change', event => {
        void handleUiAction('update-settings', { orbEnabled: event.target.checked });
    });
    entry.querySelector('#world-backstage-open')?.addEventListener('click', () => {
        const settings = getSettings();
        if (!settings.enabled) {
            void handleUiAction('update-settings', { enabled: true });
        }
        runtime.ui?.open();
    });
    syncSettingsEntry();
}

function syncSettingsEntry() {
    const settings = getSettings();
    const checkbox = document.getElementById('world-backstage-enabled');
    if (checkbox) checkbox.checked = settings.enabled;
    const orbCheckbox = document.getElementById('world-backstage-orb-enabled');
    if (orbCheckbox) orbCheckbox.checked = settings.orbEnabled !== false;
}

function registerEvents() {
    const context = getContext();
    const source = context?.eventSource;
    const events = context?.eventTypes || context?.event_types;
    if (!source || !events) return;

    const on = (eventName, handler) => {
        const event = events[eventName];
        if (event) source.on(event, handler);
    };

    on('GENERATION_STARTED', onGenerationStarted);
    on('MESSAGE_RECEIVED', onMessageReceived);
    on('MESSAGE_SWIPED', restoreExistingSwipe);
    on('MESSAGE_EDITED', onMessageEdited);
    on('MESSAGE_DELETED', onMessageDeleted);
    on('CHAT_CHANGED', onChatChanged);
    on('CHAT_LOADED', onChatChanged);
}

function registerDebugCheck() {
    const context = getContext();
    context?.registerDebugFunction?.(
        'world_backstage_state_check',
        'Kiểm tra trạng thái 世界背面',
        'Kiểm tra xem đồng hồ thế giới, các sự kiện đang hoạt động và ảnh chụp nhánh hiện tại có đọc được không',
        () => {
            const state = getState();
            const result = {
                ok: true,
                clock: state.clock.absoluteMinute,
                people: state.people.length,
                activeEvents: state.events.filter(event => ['active', 'waiting'].includes(event.status)).length,
                pendingSync: state.pendingSync,
                latestSnapshot: Boolean(findLatestResultSnapshot()),
            };
            console.info('[世界背面] Kiểm tra trạng thái', result);
            toast('Đã kiểm tra trạng thái xong, kết quả chi tiết đã được ghi vào console của trình duyệt.', 'success');
            return result;
        },
    );
}

function initialize() {
    if (runtime.initialized || globalThis.__worldBackstageLoaded) return;
    runtime.initialized = true;
    globalThis.__worldBackstageLoaded = true;
    runtime.activeChatToken = currentChatToken();

    getSettings();
    getStore();
    runtime.ui = createWorldBackstageUI({
        getState,
        getSettings,
        getSyncStatus,
        getTavernProfiles: listTavernConnectionProfiles,
        onAction: handleUiAction,
        pluginVersion: PLUGIN_VERSION,
    });

    // Additive bridge for the companion phone. The world engine and its UI stay
    // identical to the GitHub baseline; this surface only exposes existing state
    // and actions so the phone does not need a second copy of the world.
    globalThis.worldBackstageHost = {
        version: PLUGIN_VERSION,
        integratedLauncher: true,
        open: options => runtime.ui?.open?.(options),
        openEvent: eventId => runtime.ui?.openEvent?.(eventId),
        close: () => runtime.ui?.close?.(),
        getLingqiMascotAsset: state => LINGQI_MASCOT_DATA_URLS[state] || LINGQI_MASCOT_DATA_URLS.idle || '',
        getLingqiConversation: () => normalizeLingqiState(getStore().lingqi || emptyLingqiState()).messages.map(message => ({ ...message })),
        chatWithLingqi: text => sendLingqiMessage(text),
        refreshLauncher: () => runtime.ui?.render?.(),
        getPublicSurface: () => {
            const store = getStore();
            const state = getState();
            const settings = getSettings();
            return {
                opinion: normalizePublicOpinionCache(store.publicOpinion || emptyPublicOpinionCache()),
                sandbox: normalizePublicOpinionSandbox(store.publicOpinionSandbox || emptyPublicOpinionSandbox()),
                status: { ...runtime.publicOpinionStatus },
                sandboxStatus: { ...runtime.publicOpinionSandboxStatus },
                settings: {
                    publicOpinionAutoEnabled: settings.publicOpinionAutoEnabled !== false,
                    publicOpinionRevealMode: settings.publicOpinionRevealMode || 'observe',
                    injectionPublicOpinion: settings.injectionPublicOpinion !== false,
                },
                events: Array.isArray(state.events) ? state.events : [],
                publicImpactLedger: Array.isArray(state.publicImpactLedger) ? state.publicImpactLedger : [],
                people: Array.isArray(state.people) ? state.people : [],
            };
        },
        refreshPublicOpinion: () => handleUiAction('generate-public-opinion', {}),
        generatePublicOpinionSandbox: () => handleUiAction('generate-public-opinion-sandbox', {}),
        clearPublicOpinion: () => handleUiAction('clear-public-opinion', {}),
        clearPublicOpinionSandbox: () => handleUiAction('clear-public-opinion-sandbox', {}),
        dismissPublicOpinionItem: (kind, itemId) => handleUiAction('dismiss-public-opinion-item', { kind, itemId }),
        updatePublicOpinionSettings: patch => handleUiAction('update-settings', patch && typeof patch === 'object' ? patch : {}),
    };
    window.dispatchEvent(new CustomEvent('world-backstage:ready', { detail: { version: PLUGIN_VERSION } }));

    installSettingsEntry();
    registerEvents();
    registerDebugCheck();
    restoreLatestBranch();
    void reconcileAutoHidePrerequisites(currentChatToken()).catch(error => {
        console.warn('[世界背面] Kiểm tra an toàn của tự động ẩn thất bại', error);
    });
    scheduleAutoHideArchivedFloors(120);
    console.info('[世界背面] Đã tải engine trạng thái thế giới');
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize, { once: true });
} else {
    initialize();
}
