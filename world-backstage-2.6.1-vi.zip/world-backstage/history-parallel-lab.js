const DEFAULT_MAX_CHARS = 22000;

function asMessages(messages = []) {
    return (Array.isArray(messages) ? messages : [])
        .map((message, index) => ({
            id: Number.isFinite(Number(message?.id)) ? Number(message.id) : index,
            swipe: Number.isFinite(Number(message?.swipe)) ? Number(message.swipe) : 0,
            role: message?.role === 'user' ? 'user' : 'assistant',
            content: String(message?.content || '').trim(),
        }))
        .filter(message => message.content)
        .sort((a, b) => a.id - b.id);
}

function sourceMessageId(item = {}) {
    const values = [
        item.source_message_id,
        item.sourceMessageId,
        item.message_id,
        item.messageId,
        item.end_message_id,
        item.endMessageId,
        item.start_message_id,
        item.startMessageId,
    ];
    for (const value of values) {
        const numeric = Number(value);
        if (Number.isFinite(numeric)) return numeric;
    }
    return Number.MAX_SAFE_INTEGER;
}

function stableText(value = '') {
    return String(value || '').normalize('NFKC').replace(/\s+/g, ' ').trim().toLocaleLowerCase();
}

function artifactKey(kind, item = {}) {
    const source = sourceMessageId(item);
    if (kind === 'turn_summaries') return `${source}`;
    if (kind === 'facts_upsert') {
        return `${source}|${stableText(item.key)}|${stableText(item.subject)}|${stableText(item.predicate)}|${stableText(item.value)}`;
    }
    if (kind === 'clue_fragments') {
        return `${source}|${stableText(item.id || item.title)}|${stableText(item.text)}`;
    }
    if (kind === 'event_fragments') {
        return `${source}|${stableText(item.event_key || item.eventKey || item.title)}|${stableText(item.phase || item.status)}|${stableText(item.evidence)}`;
    }
    if (kind === 'person_observations') {
        return `${source}|${stableText(item.person_key || item.personKey || item.name)}|${stableText(item.location)}|${stableText(item.action)}`;
    }
    return `${source}|${stableText(JSON.stringify(item))}`;
}

export function planHistoryArchaeologyWindows(messages = [], {
    assistantTurnsPerWindow = 4,
    overlapAssistantTurns = 1,
    maximumCharacters = DEFAULT_MAX_CHARS,
} = {}) {
    const source = asMessages(messages);
    const targetAssistantTurns = Math.max(1, Number.parseInt(assistantTurnsPerWindow, 10) || 4);
    const overlapTurns = Math.max(0, Math.min(
        targetAssistantTurns - 1,
        Number.parseInt(overlapAssistantTurns, 10) || 0,
    ));
    const maxChars = Math.max(2000, Number.parseInt(maximumCharacters, 10) || DEFAULT_MAX_CHARS);
    const windows = [];
    let start = 0;

    while (start < source.length) {
        let end = start;
        let assistantTurns = 0;
        let characters = 0;
        while (end < source.length) {
            const message = source[end];
            const nextCharacters = characters + message.content.length;
            const nextAssistantTurns = assistantTurns + (message.role === 'assistant' ? 1 : 0);
            if (
                end > start
                && (nextCharacters > maxChars || nextAssistantTurns > targetAssistantTurns)
            ) break;
            characters = nextCharacters;
            assistantTurns = nextAssistantTurns;
            end += 1;
            if (assistantTurns >= targetAssistantTurns) break;
        }
        if (end <= start) end = start + 1;

        const slice = source.slice(start, end);
        windows.push({
            index: windows.length,
            id: `history-window-${windows.length}`,
            startMessageId: slice[0]?.id ?? 0,
            endMessageId: slice.at(-1)?.id ?? slice[0]?.id ?? 0,
            assistantTurns: slice.filter(message => message.role === 'assistant').length,
            characters: slice.reduce((sum, message) => sum + message.content.length, 0),
            messages: slice,
        });
        if (end >= source.length) break;

        if (!overlapTurns) {
            start = end;
            continue;
        }

        let overlapStart = end;
        let seenAssistants = 0;
        for (let index = end - 1; index >= start; index -= 1) {
            if (source[index].role === 'assistant') seenAssistants += 1;
            if (seenAssistants >= overlapTurns) {
                overlapStart = index;
                if (index > start && source[index - 1]?.role === 'user') overlapStart = index - 1;
                break;
            }
        }
        start = Math.max(start + 1, overlapStart);
    }

    return windows;
}

export function buildHistoryArchaeologyPrompt(window, {
    userName = '',
    playerIdentityAnchor = '',
    recordPlayerCharacter = true,
} = {}) {
    const messages = asMessages(window?.messages || []);
    const source = messages.map(message => (
        `<message id="${message.id}" swipe="${message.swipe}" role="${message.role}">${message.content}</message>`
    )).join('\n');
    const assistantIds = messages.filter(message => message.role === 'assistant').map(message => message.id);

    return [
        'Bạn là bộ trích xuất khảo cổ lịch sử của “世界背面”. Ở đây chỉ trích xuất bằng chứng, không dựng thế giới hiện tại, không suy diễn tương lai, cũng không đoán dựa vào kết quả của đợt trước.',
        'Đầu ra của bạn sẽ được sinh song song với các cửa sổ lịch sử khác, sau đó code sẽ sắp xếp theo source_message_id rồi dựng lại tuần tự, vì vậy mỗi mục đều phải truy được độc lập về nguyên văn của cửa sổ này.',
        'Quy tắc:',
        '1. Chỉ trích xuất nội dung mà chính văn ủng hộ rõ ràng. Tin đồn, hiểu lầm của nhân vật, phỏng đoán phải giữ nguyên tính chất, không được nâng thành sự thật khách quan.',
        '2. Mỗi chính văn assistant đều phải có một mục turn_summaries; source_message_id phải chính xác.',
        '3. facts_upsert chỉ chứa ứng viên sự thật bền vững, và cố gắng dùng key ngữ nghĩa ổn định. Nếu phần sau thay đổi cùng một sự thật, vẫn dùng lại key đó để giai đoạn dựng lại tuần tự xử lý ghi đè/tranh chấp.',
        '4. event_fragments chỉ là mảnh bằng chứng sự kiện. event_key nên mô tả danh tính ngữ nghĩa ổn định của cùng một sự kiện thực tế; phase chỉ được ghi observed/start/progress/end/cancel/miss/plan. Không tạo id sự kiện kiểu cơ sở dữ liệu, cũng không khẳng định trạng thái current cuối cùng.',
        '5. person_observations ghi lại “lát cắt trạng thái nhân vật được chính văn thể hiện rõ tại source_message_id đó”, không phải trạng thái cuối cùng của nhân vật.',
        '6. clue_fragments ghi lại mảnh bằng chứng của phục bút/lời hứa/việc cần làm/thông tin chưa giải. resolved chỉ được là true khi nguyên văn cửa sổ này cho thấy rõ đã được thu hồi.',
        '7. Mọi evidence/source_excerpt phải chép câu ngắn từ nguyên văn của cửa sổ này; không có bằng chứng nguyên văn thì đừng xuất.',
        '8. Không xuất memory_digest, world current state, people_remove, events_update, clock advance. Dòng thời gian do giai đoạn tuần tự phía sau xử lý.',
        '9. Chỉ xuất JSON hợp lệ, không dùng Markdown. Viết các trường mô tả bằng tiếng Việt (riêng evidence/source_excerpt chép nguyên văn).',
        recordPlayerCharacter
            ? '10. Có thể ghi lại hành động/trạng thái khách quan mà người chơi đã thực sự làm rõ ràng, nhưng không được bịa thêm nội tâm người chơi.'
            : '10. Không dựng trạng thái nhân vật cho người chơi; hành động khách quan của người chơi vẫn có thể dùng làm bằng chứng sự kiện/sự thật.',
        `Tên người chơi: ${String(userName || 'Chưa cung cấp').slice(0, 80)}`,
        playerIdentityAnchor ? `Điểm neo danh tính người chơi: ${String(playerIdentityAnchor).slice(0, 400)}` : 'Điểm neo danh tính người chơi: Chưa cung cấp',
        `ID tin nhắn assistant mà cửa sổ này phải bao phủ: ${assistantIds.join(', ') || 'Không có'}`,
        `Phạm vi cửa sổ: ${window?.startMessageId ?? messages[0]?.id ?? 0}—${window?.endMessageId ?? messages.at(-1)?.id ?? 0}`,
        'Chính văn:',
        source || '(trống)',
        'Cấu trúc trả về:',
        JSON.stringify({
            turn_summaries: [{
                source_message_id: 0,
                title: '',
                summary: '',
                people: [],
                locations: [],
                tags: [],
            }],
            facts_upsert: [{
                key: '',
                subject: '',
                predicate: '',
                value: '',
                status: 'active | disputed',
                visibility: 'hidden | trace | known | direct',
                source_message_id: 0,
                source_excerpt: '',
                people: [],
                locations: [],
                tags: [],
            }],
            event_fragments: [{
                event_key: '',
                title: '',
                phase: 'observed | start | progress | end | cancel | miss | plan',
                place: '',
                actors: [],
                evidence: '',
                publicity: 'private | trace | public',
                source_message_id: 0,
            }],
            person_observations: [{
                person_key: '',
                name: '',
                location: '',
                action: '',
                intent: '',
                physical_state: '',
                emotional_state: '',
                resource_state: '',
                evidence: '',
                source_message_id: 0,
            }],
            clue_fragments: [{
                id: '',
                title: '',
                text: '',
                resolved: false,
                resolution: '',
                evidence: '',
                people: [],
                locations: [],
                tags: [],
                source_message_id: 0,
            }],
        }),
    ].join('\n');
}

function mergedAbortSignal(externalSignal, internalController) {
    if (!externalSignal) return internalController.signal;
    if (externalSignal.aborted) internalController.abort(externalSignal.reason);
    else externalSignal.addEventListener('abort', () => internalController.abort(externalSignal.reason), { once: true });
    return internalController.signal;
}

export async function runHistoryArchaeologyPool(windows = [], {
    extract,
    concurrency = 2,
    signal = null,
    onProgress = null,
} = {}) {
    if (typeof extract !== 'function') throw new TypeError('extract must be a function');
    const tasks = Array.isArray(windows) ? windows.slice() : [];
    if (!tasks.length) return { results: [], elapsedMs: 0, maxActive: 0, completed: 0 };

    const limit = Math.max(1, Math.min(4, Number.parseInt(concurrency, 10) || 1));
    const internalController = new AbortController();
    const poolSignal = mergedAbortSignal(signal, internalController);
    const results = new Array(tasks.length);
    const startedAt = Date.now();
    let nextIndex = 0;
    let active = 0;
    let maxActive = 0;
    let completed = 0;
    let firstError = null;

    const worker = async slot => {
        while (!poolSignal.aborted && !firstError) {
            const index = nextIndex;
            nextIndex += 1;
            if (index >= tasks.length) return;
            const window = tasks[index];
            active += 1;
            maxActive = Math.max(maxActive, active);
            onProgress?.({ phase: 'start', slot, index, window, active, completed, total: tasks.length });
            try {
                const payload = await extract(window, { slot, index, signal: poolSignal });
                if (poolSignal.aborted) return;
                results[index] = { window, payload };
                completed += 1;
                onProgress?.({ phase: 'complete', slot, index, window, active, completed, total: tasks.length });
            } catch (error) {
                if (!firstError) firstError = error;
                internalController.abort(error);
                return;
            } finally {
                active = Math.max(0, active - 1);
            }
        }
    };

    await Promise.all(Array.from({ length: Math.min(limit, tasks.length) }, (_, slot) => worker(slot)));

    if (signal?.aborted || poolSignal.aborted) {
        if (firstError) throw firstError;
        const error = signal?.reason instanceof Error ? signal.reason : new Error('Thử nghiệm lịch sử song song đã dừng');
        if (!error.name || error.name === 'Error') error.name = 'AbortError';
        throw error;
    }
    if (firstError) throw firstError;
    if (results.some(result => !result)) throw new Error('Thử nghiệm lịch sử song song có cửa sổ không trả về kết quả');

    return {
        results,
        elapsedMs: Date.now() - startedAt,
        maxActive,
        completed,
    };
}

export function mergeChronologicalHistoryArtifacts(results = []) {
    const ordered = (Array.isArray(results) ? results : [])
        .filter(result => result?.payload)
        .slice()
        .sort((a, b) => (
            Number(a.window?.startMessageId ?? 0) - Number(b.window?.startMessageId ?? 0)
            || Number(a.window?.index ?? 0) - Number(b.window?.index ?? 0)
        ));
    const fields = ['turn_summaries', 'facts_upsert', 'event_fragments', 'person_observations', 'clue_fragments'];
    const merged = Object.fromEntries(fields.map(field => [field, []]));
    const seen = Object.fromEntries(fields.map(field => [field, new Set()]));

    for (const result of ordered) {
        for (const field of fields) {
            const values = Array.isArray(result.payload?.[field]) ? result.payload[field] : [];
            for (const value of values) {
                if (!value || typeof value !== 'object') continue;
                const key = artifactKey(field, value);
                if (seen[field].has(key)) continue;
                seen[field].add(key);
                merged[field].push({ ...value });
            }
        }
    }

    for (const field of fields) {
        merged[field].sort((a, b) => sourceMessageId(a) - sourceMessageId(b));
    }
    return merged;
}
