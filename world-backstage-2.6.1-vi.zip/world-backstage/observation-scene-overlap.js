const PATCH_KEY = Symbol.for('world_backstage.observation_scene_overlap.v1');
const STATE_KEY = 'world_backstage_v1';
const OBSERVATION_MARKER = 'Bạn là bộ quan sát tức thời nhân vật của “世界背面”.';

function cleanText(value, maximum = 600) {
    return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, maximum);
}

function normalizedReference(value) {
    return cleanText(value, 220).toLocaleLowerCase();
}

function normalizedLocation(value) {
    return normalizedReference(value)
        .replace(/\s+/g, '')
        .replace(/[，,。；;、·|｜/\\]+/g, '');
}

function promptText(value) {
    if (typeof value === 'string') return value.slice(0, 100000);
    try {
        return JSON.stringify(value).slice(0, 100000);
    } catch {
        return '';
    }
}

function isObservationPrompt(value, depth = 0) {
    if (depth > 7 || value == null) return false;
    if (typeof value === 'string') return value.includes(OBSERVATION_MARKER);
    if (Array.isArray(value)) return value.some(item => isObservationPrompt(item, depth + 1));
    if (typeof value !== 'object') return false;
    return Object.values(value).some(item => isObservationPrompt(item, depth + 1));
}

function currentStore(context = null) {
    let resolved = context;
    if (!resolved) {
        try {
            resolved = globalThis.SillyTavern?.getContext?.() || null;
        } catch {
            resolved = null;
        }
    }
    return resolved?.chatMetadata?.[STATE_KEY] || null;
}

function currentState(store) {
    return store?.currentState || store?.initialState || {};
}

function isUserPerson(person) {
    return Boolean(person?.isUser || person?.is_user || person?.role === 'user');
}

function extractObservationAnchor(source) {
    const text = promptText(source);
    const jsonMatch = text.match(/(?:场景关系约束（只作一致性边界，不是角色知识）|[Rr]àng buộc quan hệ (?:trong |của )?cảnh[^\n\r:：{]{0,120})[：:]\s*(\{[^\n\r]+\})/u);
    if (jsonMatch?.[1]) {
        try {
            const parsed = JSON.parse(jsonMatch[1]);
            return {
                personId: cleanText(parsed?.personId, 120),
                userId: cleanText(parsed?.userId, 120),
                personName: '',
            };
        } catch {
            // Fall through to the stable human-readable observation header.
        }
    }
    const nameMatch = text.match(/(?:本次唯一观测主体是|[Cc]hủ thể quan sát duy nhất (?:lần này |của lần này )?là\s*)“([^”]{1,80})”/u);
    return {
        personId: '',
        userId: '',
        personName: cleanText(nameMatch?.[1], 80),
    };
}

function microSceneLocation(value) {
    const text = normalizedLocation(value);
    if (!text) return false;
    return /(?:卧室|客厅|厨房|书房|办公室|会议室|病房|教室|包厢|包间|车厢|驾驶舱|舰桥|电梯|走廊|楼梯间|阳台|浴室|卫生间|柜台|吧台|站台|候诊室|审讯室|仓库|房间|屋内|室内|门口|床边|桌边|座位|卡座|诊室|休息室|更衣室|储物间|phòngngủ|phòngkhách|nhàbếp|bếp|phònglàmviệc|phòngđọcsách|thưphòng|vănphòng|phònghọp|phòngbệnh|lớphọc|phònghọc|phòngriêng|phòngvip|toatàu|khoangtàu|buồnglái|khoanglái|đàichỉhuy|thangmáy|hànhlang|cầuthang|bancông|phòngtắm|nhàtắm|nhàvệsinh|toilet|quầy|quầybar|quầythungân|sânga|phòngchờ|phòngthẩmvấn|phònghỏicung|nhàkho|khohàng|phòng|trongnhà|trongphòng|trướccửa|cửaphòng|cạnhgiường|bêngiường|cạnhbàn|bênbàn|chỗngồi|ghếngồi|phòngkhám|phòngnghỉ|phòngthayđồ|phòngchứađồ)$|^(?:phòngngủ|phòngkhách|nhàbếp|bếp|phònglàmviệc|phòngđọcsách|thưphòng|vănphòng|phònghọp|phòngbệnh|lớphọc|phònghọc|phòngriêng|phòngvip|toatàu|khoangtàu|buồnglái|khoanglái|đàichỉhuy|thangmáy|hànhlang|cầuthang|bancông|phòngtắm|nhàtắm|nhàvệsinh|toilet|quầy|quầybar|quầythungân|sânga|phòngchờ|phòngthẩmvấn|phònghỏicung|nhàkho|khohàng|phòng|trongnhà|trongphòng|trướccửa|cửaphòng|cạnhgiường|bêngiường|cạnhbàn|bênbàn|chỗngồi|ghếngồi|phòngkhám|phòngnghỉ|phòngthayđồ|phòngchứađồ)/u.test(text);
}

function actionProvesPerception(actor, counterpart) {
    if (!actor || !counterpart) return false;
    const source = cleanText(actor?.action ?? actor?.currentAction ?? actor?.current_action, 600);
    if (!source) return false;
    const refs = [counterpart?.id, counterpart?.name]
        .map(normalizedReference)
        .filter(value => value.length >= 1);
    const lowered = source.toLocaleLowerCase();
    if (!refs.some(ref => lowered.includes(ref))) return false;
    return /(?:看见|看到|望向|看着|盯着|注意到|发现|听见|听到|认出|回应|交谈|说话|对话|招呼|叫住|拦住|递给|接过|握住|拉住|牵着|拥抱|搀扶|碰到|面对|并肩|一起|跟随|跟着|点头|示意|回答|问道|说道|正在和|正与|nhìn thấy|trông thấy|thấy|nhìn về|nhìn|nhìn chằm chằm|chú ý|để ý|phát hiện|nghe thấy|nghe|nhận ra|đáp lại|trả lời|trò chuyện|nói chuyện|đối thoại|chào|gọi lại|gọi|chặn|đưa cho|nhận lấy|nắm|kéo|dắt|ôm|dìu|đỡ|chạm|đối mặt|sánh vai|cùng nhau|đi theo|theo sau|gật đầu|ra hiệu|hỏi|nói với|đang cùng|đang với)/u.test(source);
}

function locationBaseRelation(personLocation, userLocation) {
    const observed = normalizedLocation(personLocation);
    const player = normalizedLocation(userLocation);
    if (!observed || !player) return 'unknown';
    if (observed === player) return 'same_place';
    if (
        observed.length >= 3
        && player.length >= 3
        && (observed.includes(player) || player.includes(observed))
    ) return 'same_area';
    return 'separate';
}

export function classifyObservationSceneOverlap(state, person, player = null) {
    const people = Array.isArray(state?.people) ? state.people : [];
    const resolvedPlayer = player || people.find(isUserPerson) || null;
    const personLocation = cleanText(person?.location, 180);
    const userLocation = cleanText(resolvedPlayer?.location, 180);
    const base = locationBaseRelation(personLocation, userLocation);

    let kind = base;
    let perceivedBy = 'none';
    const locationOverlap = ['same_area', 'same_place'].includes(base);
    if (locationOverlap) {
        const personPerceives = actionProvesPerception(person, resolvedPlayer);
        const playerPerceives = actionProvesPerception(resolvedPlayer, person);
        if (personPerceives || playerPerceives) {
            kind = 'perceived';
            perceivedBy = personPerceives && playerPerceives
                ? 'both'
                : personPerceives
                    ? 'person'
                    : 'user';
        } else if (base === 'same_place' && microSceneLocation(personLocation) && microSceneLocation(userLocation)) {
            kind = 'same_scene';
        }
    }

    return {
        kind,
        base,
        perceivedBy,
        personId: cleanText(person?.id, 120),
        personLocation,
        userId: cleanText(resolvedPlayer?.id, 120),
        userLocation: locationOverlap ? userLocation : '',
        source: 'authoritative_person_state',
        mutableByObservation: false,
    };
}

function resolveObservationActors(store, source) {
    const state = currentState(store);
    const people = Array.isArray(state?.people) ? state.people : [];
    const anchor = extractObservationAnchor(source);
    let person = anchor.personId
        ? people.find(item => String(item?.id || '') === anchor.personId)
        : null;
    if (!person && anchor.personName) {
        const wanted = normalizedReference(anchor.personName);
        person = people.find(item => !isUserPerson(item) && normalizedReference(item?.name) === wanted) || null;
    }
    const player = anchor.userId
        ? people.find(item => String(item?.id || '') === anchor.userId) || people.find(isUserPerson) || null
        : people.find(isUserPerson) || null;
    return { state, person, player };
}

export function buildObservationSceneOverlapInstruction(store, promptSource) {
    const { state, person, player } = resolveObservationActors(store, promptSource);
    if (!person) return '';
    const relation = classifyObservationSceneOverlap(state, person, player);
    const personName = cleanText(person?.name, 80) || 'Nhân vật này';
    const playerName = cleanText(player?.name, 80) || 'user';
    const lines = [
        '<world_backstage_observation_scene_overlap>',
        'Đây là “lớp kiểm tra chồng lấn cảnh” cho quan sát nhân vật tức thời. Nó chỉ đọc location / action của nhân vật trong currentState đã kết toán, không đọc cũng không tin vào ngôn ngữ tự nhiên do lần quan sát này tạo ra.',
        'Hướng cố định là: trạng thái thế giới có thẩm quyền → quan sát. Nghiêm cấm dùng ngược văn bản quan sát để sửa, bổ sung hay nâng cấp sự thật thế giới; dù đầu ra lần này có viết “nhìn thấy/gặp phải/đi tới”, cũng không vì thế mà trở thành sự thật có thẩm quyền.',
        `Quan hệ có cấu trúc hiện tại: ${JSON.stringify(relation)}。`,
    ];

    if (relation.kind === 'same_area') {
        lines.push(`${personName} và ${playerName} chỉ ở cùng một khu vực lớn có quan hệ bao hàm phạm vi. Không được viết thành cùng một phòng, cùng tầm nhìn, lướt qua nhau hay đã gặp nhau.`);
    } else if (relation.kind === 'same_place') {
        lines.push(`${personName} và ${playerName} hiện được ghi nhận là cùng địa điểm/nơi chốn, nhưng độ chi tiết không đủ để chứng minh cùng một cảnh nhỏ. Có thể giữ sự thật không gian “có thể ở cùng một nơi”, nhưng không được tự động để bất kỳ bên nào nhìn thấy, nghe thấy, chú ý tới hay suy nghĩ xoay quanh bên kia.`);
    } else if (relation.kind === 'same_scene') {
        lines.push(`${personName} và ${playerName} đã được bản ghi vị trí có thẩm quyền xác định là ở cùng một cảnh cụ thể nhỏ hơn. Mức này chỉ nâng tính liên tục không gian, không tự động cấp quyền cảm nhận: trừ khi action đã chứng minh có tiếp xúc, nếu không vẫn không được đột nhiên nhìn thấy, nghe thấy, nhận ra, bắt chuyện hay thiết lập tương tác.`);
    } else if (relation.kind === 'perceived') {
        lines.push(`Action có thẩm quyền đã chứng minh: ${personName} / ${playerName} có tiếp xúc cảm nhận hoặc tương tác hiện tại với nhau (perceivedBy=${relation.perceivedBy}). Quan sát phải giữ sự liên tục này, không được giả vờ bên kia không tồn tại; nhưng chỉ được dùng thông tin thực sự cảm nhận được, không vì thế mà biết được nội tâm của bên kia, sự thật hậu trường hay kiến thức chưa nói ra.`);
    } else if (relation.kind === 'separate') {
        lines.push(`${personName} và ${playerName} có vị trí có thẩm quyền tách biệt. Không được kéo người chơi vào hiện trường ý thức hiện tại của nhân vật này, cũng không được di chuyển bất kỳ bên nào để tạo cuộc gặp gỡ.`);
    } else {
        lines.push('Hiện thiếu đủ bằng chứng về vị trí. Giữ là chưa biết, không bịa thêm cùng hiện trường, tầm nhìn, gặp gỡ hay vị trí hiện tại của người chơi.');
    }

    lines.push('Nếu relation cũ trong prompt quan sát gốc xung đột với lớp kiểm tra ở đây, lấy kết quả tính lại dựa trên currentState hiện tại ở đây làm chuẩn; đây là hiệu chỉnh phép chiếu, không phải một lần ghi trạng thái thế giới.');
    lines.push('</world_backstage_observation_scene_overlap>');
    return lines.join('\n');
}

function prependInstructionToMessages(messages, instruction) {
    if (!Array.isArray(messages) || !instruction) return messages;
    const next = messages.map(message => ({ ...message }));
    const systemIndex = next.findIndex(message => String(message?.role || '').toLowerCase() === 'system');
    if (systemIndex >= 0) {
        next[systemIndex] = {
            ...next[systemIndex],
            content: `${instruction}\n\n${String(next[systemIndex]?.content || '')}`,
        };
    } else {
        next.unshift({ role: 'system', content: instruction });
    }
    return next;
}

export function adaptObservationScenePayload(payload, context = null) {
    if (!payload || typeof payload !== 'object' || !isObservationPrompt(payload?.messages)) return payload;
    const store = currentStore(context);
    if (!store) return payload;
    const instruction = buildObservationSceneOverlapInstruction(store, payload.messages);
    if (!instruction) return payload;
    return {
        ...payload,
        messages: prependInstructionToMessages(payload.messages, instruction),
    };
}

export function adaptObservationGenerateRawOptions(options, context = null) {
    if (!options || !isObservationPrompt(options.prompt)) return options;
    const store = currentStore(context);
    if (!store) return options;
    const instruction = buildObservationSceneOverlapInstruction(store, options.prompt);
    if (!instruction) return options;
    if (Array.isArray(options.prompt)) {
        return {
            ...options,
            prompt: prependInstructionToMessages(options.prompt, instruction),
        };
    }
    return {
        ...options,
        prompt: `${instruction}\n\n${String(options.prompt || '')}`,
    };
}

function installFetchPolicy() {
    const originalFetch = globalThis.fetch;
    if (typeof originalFetch !== 'function' || originalFetch[PATCH_KEY]) return false;

    const wrappedFetch = async function worldBackstageObservationSceneFetch(input, init) {
        if (typeof init?.body !== 'string') return originalFetch.call(this, input, init);
        let payload;
        try {
            payload = JSON.parse(init.body);
        } catch {
            return originalFetch.call(this, input, init);
        }
        if (!isObservationPrompt(payload?.messages)) return originalFetch.call(this, input, init);
        const adapted = adaptObservationScenePayload(payload);
        if (adapted === payload) return originalFetch.call(this, input, init);
        return originalFetch.call(this, input, {
            ...init,
            body: JSON.stringify(adapted),
        });
    };
    Object.defineProperty(wrappedFetch, PATCH_KEY, { value: true, enumerable: false });
    globalThis.fetch = wrappedFetch;
    return true;
}

function installGenerateRawPolicy() {
    const tavern = globalThis.SillyTavern;
    const originalGetContext = tavern?.getContext;
    if (typeof originalGetContext !== 'function' || originalGetContext[PATCH_KEY]) return false;
    const cache = new WeakMap();

    const wrappedGetContext = function worldBackstageObservationSceneGetContext(...args) {
        const context = originalGetContext.apply(this, args);
        const raw = context?.generateRaw;
        if (!context || typeof raw !== 'function' || raw[PATCH_KEY]) return context;
        let wrapped = cache.get(raw);
        if (!wrapped) {
            wrapped = function worldBackstageObservationSceneGenerateRaw(options = {}) {
                return raw.call(context, adaptObservationGenerateRawOptions(options, context));
            };
            Object.defineProperty(wrapped, PATCH_KEY, { value: true, enumerable: false });
            cache.set(raw, wrapped);
        }
        try {
            context.generateRaw = wrapped;
            return context;
        } catch {
            return new Proxy(context, {
                get(target, property, receiver) {
                    if (property === 'generateRaw') return wrapped;
                    return Reflect.get(target, property, receiver);
                },
            });
        }
    };
    Object.defineProperty(wrappedGetContext, PATCH_KEY, { value: true, enumerable: false });
    tavern.getContext = wrappedGetContext;
    return true;
}

function install() {
    installFetchPolicy();
    if (installGenerateRawPolicy()) return;
    let attempts = 0;
    const timer = globalThis.setInterval(() => {
        attempts += 1;
        if (installGenerateRawPolicy() || attempts >= 40) globalThis.clearInterval(timer);
    }, 250);
}

if (globalThis.SillyTavern || globalThis.document) install();
