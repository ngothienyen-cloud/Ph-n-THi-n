# Ghi chú bản dịch tiếng Việt

Đây là **bản dịch tiếng Việt không chính thức** của extension SillyTavern **世界背面 / World Backstage 2.6.1**.

- Tác giả gốc: **玲**. Mọi bản quyền thuộc về tác giả (xem `LICENSE`, được giữ nguyên).
- Dự án gốc: https://github.com/h675786161-prog/world-backstage
- Bản dịch được chia sẻ **phi thương mại** trong cộng đồng SillyTavern Việt Nam, với sự cho phép của tác giả.
- Tên tác giả, tên dự án, liên kết gốc, quản gia 玲七 và các dấu tác giả/watermark được giữ nguyên.
- Phần dịch gồm: giao diện, lời nhắc (prompt) gửi cho mô hình và tài liệu. Các bộ nhận dạng chữ trong truyện được mở rộng để hiểu cả tiếng Trung lẫn tiếng Việt. Không thay đổi chức năng.
- Muốn đăng lại ở nền tảng khác, chỉnh sửa thêm chức năng hoặc phát hành dưới hình thức khác: **hãy hỏi lại tác giả trước**.
- Đây không phải phiên bản chính thức. Lỗi trong bản dịch thuộc về người dịch, không phải tác giả.

Lưu ý: không bấm “Cập nhật” trong extension, vì nút này kéo bản gốc tiếng Trung về và ghi đè bản dịch.
