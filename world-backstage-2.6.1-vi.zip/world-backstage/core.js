import { readCharacterProfile, readWorldbookProvenance, profilePromptText } from './character-profiles.js';
import {
    buildClockAuthorityLines,
    normalizeClueTiming,
    resolveFutureTimeExpression,
    resolveNarrativeTimeTransition,
} from './world-clock-authority.js';
import {
    WORLD_BACKSTAGE_CORE_REASONING_PROTOCOL,
    WORLD_SIMULATION_REASONING_PROTOCOL,
} from './reasoning-protocol.js';

const WB_STATE_RECONCILE_ORDER = Object.freeze([3, 1, 4, 2]);

export const MODULE_ID = 'world_backstage';
export const STATE_KEY = 'world_backstage_v1';
export const SNAPSHOT_KEY = 'world_backstage';
export const SCHEMA_VERSION = 25;
export const MAX_CALENDAR_YEAR = 999999;
export const MINUTES_PER_DAY = 24 * 60;
export const RECOVERY_LIMIT = 3;

const TERMINAL_EVENT_STATES = new Set(['resolved', 'cancelled', 'missed']);
const ACTIVE_EVENT_STATES = new Set(['active', 'waiting']);
const VALID_CLOCK_MODES = new Set(['duration', 'active', 'scheduled', 'condition']);
const VALID_VISIBILITY = new Set(['hidden', 'trace', 'known', 'direct']);
const VALID_KNOWLEDGE = new Set(['hidden', 'known']);
const VALID_KNOWLEDGE_ROUTES = new Set([
    'witnessed',
    'told',
    'investigated',
    'message',
    'public_channel',
    'inferred',
]);
const VALID_KNOWLEDGE_CERTAINTY = new Set(['confirmed', 'suspected']);
const VALID_CLUE_STATES = new Set(['open', 'developing', 'triggered', 'echoed', 'resolved', 'discarded']);
const VALID_MEMORY_FACT_STATES = new Set(['active', 'disputed', 'superseded', 'invalidated']);
const VALID_MEMORY_CONFIDENCE = new Set(['low', 'medium', 'high']);
const MEMORY_SUMMARY_LEVELS = Object.freeze({
    DETAIL: 0,
    STAGE: 1,
    CHAPTER: 2,
    LONG_TERM: 3,
});
const MEMORY_ROLLUP_THRESHOLDS = Object.freeze({
    0: 12,
    1: 6,
    2: 3,
});
const VALID_EVENT_STATES = new Set([
    'active',
    'waiting',
    'ready',
    'resolved',
    'cancelled',
    'missed',
]);

const LIMITS = Object.freeze({
    // Persistent people storage is intentionally uncapped. These limits only bound
    // one model payload / one task / one prompt context so a large world stays usable.
    peoplePayload: 36,
    peopleTaskBudget: 36,
    peopleModelContext: 36,
    events: 96,
    archive: 120,
    echoes: 80,
    foregroundFacts: 24,
    worldFacts: 160,
    worldPulseDomains: 18,
    worldCoverageEntries: 48,
    publicImpactLedger: 96,
    consistencyConflicts: 32,
    audit: 40,
    text: 800,
    innerVoice: 240,
    longTermGoal: 360,
    identityAnchor: 500,
    personalityAnchor: 600,
    appearanceProfile: 700,
    backgroundProfile: 900,
    worldBackground: 5000,
    worldbookRaw: 4000,
    speakingStyle: 360,
    behaviorBoundaries: 500,
    abilityProfile: 1200,
    cognitiveRefs: 32,
    personState: 220,
    personAvatarData: 180000,
    eventCause: 360,
    eventPublicTrace: 260,
    storySummaries: 2400,
    clues: 480,
    memoryFacts: 720,
    memoryDigest: 2400,
    metabolismLog: 180,
});

function deepClone(value) {
    if (typeof structuredClone === 'function') {
        return structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value));
}

function asString(value, fallback = '', maxLength = LIMITS.text) {
    const result = typeof value === 'string' ? value.trim() : fallback;
    return result.slice(0, maxLength);
}

function asInteger(value, fallback = 0, minimum = Number.MIN_SAFE_INTEGER, maximum = Number.MAX_SAFE_INTEGER) {
    const number = Number.parseInt(value, 10);
    if (!Number.isFinite(number)) return fallback;
    return Math.min(maximum, Math.max(minimum, number));
}

function asArray(value) {
    return Array.isArray(value) ? value : [];
}

function uniqueStrings(value, maximum = 12) {
    return [...new Set(asArray(value)
        .map(item => asString(item, '', 120))
        .filter(Boolean))]
        .slice(0, maximum);
}

function mergeUniqueStrings(previous, incoming, maximum = 12) {
    return uniqueStrings([
        ...asArray(previous),
        ...asArray(incoming),
    ], maximum);
}

const VALID_TIME_RESOLUTION_AUTHORITY = new Set([
    'explicit_end_time',
    'explicit_transition',
    'daypart_transition',
    'duration_only',
    'estimated_elapsed',
    'none',
]);
const VALID_TIME_RESOLUTION_SCOPE = new Set([
    'current', 'memory', 'future', 'reported', 'unknown',
]);
const VALID_TIME_RESOLUTION_CONFIDENCE = new Set(['low', 'medium', 'high']);

function normalizeModelTimeResolution(raw = {}) {
    const authority = asString(raw?.authority, 'none', 40);
    const scope = asString(raw?.scope, 'unknown', 30);
    const confidence = asString(raw?.confidence, 'low', 20);
    return {
        evidenceFound: Boolean(raw?.evidence_found ?? raw?.evidenceFound),
        authority: VALID_TIME_RESOLUTION_AUTHORITY.has(authority) ? authority : 'none',
        scope: VALID_TIME_RESOLUTION_SCOPE.has(scope) ? scope : 'unknown',
        evidence: asString(raw?.evidence, '', 260),
        endTimeText: asString(raw?.end_time_text ?? raw?.endTimeText, '', 120),
        needsElapsedEstimate: Boolean(raw?.needs_elapsed_estimate ?? raw?.needsElapsedEstimate),
        estimatedMinutes: asInteger(
            raw?.estimated_minutes ?? raw?.estimatedMinutes,
            0,
            0,
            5 * 365 * MINUTES_PER_DAY,
        ),
        confidence: VALID_TIME_RESOLUTION_CONFIDENCE.has(confidence) ? confidence : 'low',
        reason: asString(raw?.reason, '', 320),
    };
}

function normalizeInjectionRefs(value, maximum = 24) {
    const placeholder = /(?:人物ID|事件ID|事实key|事实KEY|线索ID|person_id|event_id|fact_key|clue_id|示例|placeholder|ID[_ ]nhân[_ ]vật|ID[_ ]sự[_ ]kiện|key[_ ]sự[_ ]thật|ID[_ ]manh[_ ]mối|ví dụ)/i;
    return uniqueStrings(value, maximum * 2)
        .map(ref => String(ref || '').trim())
        .filter(ref => /^(?:event|fact|person|clue):[^\s|]{1,110}$/i.test(ref))
        .filter(ref => !placeholder.test(ref))
        .slice(0, maximum);
}

function normalizeNextTurnInjection(raw = {}) {
    return {
        requiredRefs: normalizeInjectionRefs(raw?.required_refs ?? raw?.requiredRefs, 24),
        conditionalRefs: normalizeInjectionRefs(raw?.conditional_refs ?? raw?.conditionalRefs, 24),
        suppressRefs: normalizeInjectionRefs(raw?.suppress_refs ?? raw?.suppressRefs, 24),
        reason: asString(raw?.reason, '', 360),
        sourceRevision: asInteger(raw?.source_revision ?? raw?.sourceRevision, 0, 0),
    };
}

function normalizeStoredTimeResolution(raw = {}) {
    if (!raw || typeof raw !== 'object') return null;
    const authority = asString(raw?.authority, 'none', 40);
    const method = asString(raw?.method, 'unchanged', 60);
    return {
        sourceKey: asString(raw?.sourceKey ?? raw?.source_key, '', 180),
        messageId: Number.isFinite(Number(raw?.messageId ?? raw?.message_id))
            ? Number(raw?.messageId ?? raw?.message_id)
            : null,
        beforeMinute: asInteger(raw?.beforeMinute ?? raw?.before_minute, 0, 0),
        afterMinute: asInteger(raw?.afterMinute ?? raw?.after_minute, 0, 0),
        method,
        authority: VALID_TIME_RESOLUTION_AUTHORITY.has(authority) ? authority : 'none',
        evidence: asString(raw?.evidence, '', 260),
        requestedElapsedMinutes: asInteger(raw?.requestedElapsedMinutes ?? raw?.requested_elapsed_minutes, 0, 0),
        appliedElapsedMinutes: asInteger(raw?.appliedElapsedMinutes ?? raw?.applied_elapsed_minutes, 0, 0),
        reason: asString(raw?.reason, '', 320),
        precision: asString(raw?.precision, '', 30),
        daypart: asString(raw?.daypart, '', 40),
        deterministicEvidence: Boolean(raw?.deterministicEvidence ?? raw?.deterministic_evidence),
        model: normalizeModelTimeResolution(raw?.model || {}),
        sourceRevision: asInteger(raw?.sourceRevision ?? raw?.source_revision, 0, 0),
    };
}

function nowIso() {
    return new Date().toISOString();
}

function makeId(prefix = 'wb') {
    if (globalThis.crypto?.randomUUID) {
        return `${prefix}_${globalThis.crypto.randomUUID().replaceAll('-', '').slice(0, 16)}`;
    }
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

function normalizeId(value, prefix) {
    const candidate = asString(value, '', 100)
        .toLowerCase()
        .replace(/[^a-z0-9_-]+/g, '_')
        .replace(/^_+|_+$/g, '');
    return candidate || makeId(prefix);
}

function normalizeClockMode(value) {
    return VALID_CLOCK_MODES.has(value) ? value : 'duration';
}

function normalizeVisibility(value) {
    return VALID_VISIBILITY.has(value) ? value : 'hidden';
}

function normalizeEventStatus(value) {
    return VALID_EVENT_STATES.has(value) ? value : 'active';
}


function inferLegacyEventPublicity(raw = {}, existing = null) {
    const explicit = String(raw?.publicity ?? raw?.public_scope ?? raw?.publicScope ?? existing?.publicity ?? '').trim().toLowerCase();
    if (VALID_EVENT_PUBLICITY.has(explicit)) return explicit;

    const publicTrace = String(
        raw?.public_trace
        ?? raw?.publicTrace
        ?? existing?.publicTrace
        ?? ''
    ).trim();
    const publicHeadline = String(
        raw?.public_headline
        ?? raw?.publicHeadline
        ?? existing?.publicHeadline
        ?? ''
    ).trim();
    const publicSummary = String(
        raw?.public_summary
        ?? raw?.publicSummary
        ?? existing?.publicSummary
        ?? ''
    ).trim();

    if (!publicTrace && !publicHeadline && !publicSummary) return 'private';

    // 1.4.1 以前 public_trace 和 visibility 混用过。
    // 迁移时只在文本本身明确出现“社会传播渠道”证据时才自动认定为 public；
    // 否则宁可保持 private，避免把卧室/私聊/角色已知事件错误同步成新闻。
    const evidence = `${publicHeadline} ${publicSummary} ${publicTrace}`;
    const strongPublicCue = /(公告|通报|报道|新闻|媒体|记者|电视台|广播|报纸|官方|政府|警方|消防|医院|学校|公司发布|机构发布|委员会|公示|通知|预警|交通部门|气象|论坛|社交媒体|热搜|公众|市民|居民|游客|全城|全网|公开声明|新闻发布|thông báo|thông cáo|công bố|đưa tin|bản tin|tin tức|truyền thông|báo chí|phóng viên|nhà báo|đài truyền hình|phát thanh|tờ báo|chính thức|chính quyền|chính phủ|cảnh sát|cứu hỏa|bệnh viện|trường học|công ty công bố|cơ quan công bố|ủy ban|niêm yết công khai|cảnh báo|cơ quan giao thông|khí tượng|diễn đàn|mạng xã hội|hot search|top tìm kiếm|công chúng|thị dân|người dân|cư dân|du khách|khắp thành phố|cả thành phố|toàn thành phố|toàn mạng|cư dân mạng|tuyên bố công khai|họp báo)/i;
    if (strongPublicCue.test(evidence)) return 'public';

    const traceCue = /(有人看见|有人发现|路人|邻居|附近的人|外界察觉|传闻|风声|小道消息|可疑迹象|异常迹象|có người nhìn thấy|có người trông thấy|có người thấy|có người phát hiện|người qua đường|hàng xóm|người gần đó|người xung quanh|bên ngoài nhận ra|bên ngoài phát hiện|lời đồn|tin đồn|phong thanh|tin vỉa hè|dấu hiệu khả nghi|dấu vết khả nghi|dấu hiệu bất thường)/i;
    if (traceCue.test(evidence)) return 'trace';

    return 'private';
}

function normalizeEventPublicity(value, fallback = 'private') {
    const normalized = String(value || '').trim().toLowerCase();
    return VALID_EVENT_PUBLICITY.has(normalized) ? normalized : fallback;
}

function normalizeKnowledge(value) {
    return VALID_KNOWLEDGE.has(value) ? value : 'hidden';
}

export function clamp(value, minimum, maximum) {
    return Math.min(maximum, Math.max(minimum, value));
}

export function hasExplicitTimeEvidence(text) {
    const value = String(text || '');
    const chineseNumber = '[一二两三四五六七八九十百千万半]';
    const arabicDurationUnit = '(?:分钟|分|刻钟|小时|个小时|钟头|天|日|周|星期|个月|月|年)';
    const chineseDurationUnit = '(?:分钟|刻钟|小时|个小时|钟头|天|日|周|星期|个月|月|年)';
    const patterns = [
        new RegExp(`\\d+(?:\\.\\d+)?\\s*${arabicDurationUnit}`),
        new RegExp(`${chineseNumber}+\\s*${chineseDurationUnit}`),
        /(?:凌晨|清晨|早上|上午|中午|下午|傍晚|晚上|夜里)?\s*\d{1,2}\s*(?:点|时|[:：]|giờ)\s*\d{0,2}/,
        new RegExp(`(?:凌晨|清晨|早上|上午|中午|下午|傍晚|晚上|夜里)?\\s*${chineseNumber}+\\s*(?:点|时)`),
        /第\s*\d+\s*[日天]|ngày thứ\s*\d+/,
        new RegExp(`第\\s*${chineseNumber}+\\s*[日天]`),
        /(?:次日|翌日|第二天|隔天|第二周|下周|下个月|次年|hôm sau|ngày hôm sau|ngày tiếp theo|sáng hôm sau|tuần sau|tuần tới|tuần kế tiếp|tháng sau|tháng tới|năm sau|năm tới)/,
    ];
    return patterns.some(pattern => pattern.test(value));
}

export function resolveElapsedMinutes(rawMinutes, narrativeText, policy = 'explicit') {
    const minutes = asInteger(rawMinutes, 0, 0, 5 * 365 * MINUTES_PER_DAY);
    if (policy === 'open' || policy === 'world') return minutes;
    if (hasExplicitTimeEvidence(narrativeText)) return minutes;
    if (policy === 'cautious') return Math.min(minutes, 180);
    return 0;
}

function inferStrongSemanticElapsedMinutes(narrativeText) {
    const tail = String(narrativeText || '').slice(-1800);
    if (!tail.trim()) return 0;

    // This is deliberately a narrow safety floor, not a general duration guesser.
    // Ignore obvious recollection / report / future framing so old or planned travel
    // cannot move the current world clock.
    const nonCurrentFrame = /(?:回忆|想起|记起|梦见|曾经|以前|当年|那天|讲述|转述|据说|听说|计划|预计|打算|将会|将在|明天|后天|hồi tưởng|nhớ lại|nhớ ra|mơ thấy|đã từng|trước kia|năm ấy|năm đó|hôm ấy|hôm đó|ngày ấy|kể lại|thuật lại|nghe nói|người ta nói|kế hoạch|dự kiến|dự định|ngày mai|ngày kia)/;
    if (nonCurrentFrame.test(tail)) return 0;

    const sleepCycle = /(?:睡着|入睡|睡下|睡去|ngủ thiếp|chìm vào giấc ngủ|thiếp đi|ngủ say|đi ngủ)[\s\S]{0,320}?(?:醒来|醒了|醒转|睁开眼|tỉnh dậy|thức dậy|tỉnh giấc|mở mắt)/.test(tail);
    const longTransit = /(?:火车|列车|高铁|航班|飞机|长途车|客轮|轮船|tàu hỏa|xe lửa|đoàn tàu|tàu cao tốc|chuyến bay|máy bay|xe khách đường dài|tàu khách|tàu thủy)/.test(tail)
        && /(?:穿过|跨过|驶过|经过|đi qua|băng qua|vượt qua|chạy qua|lướt qua)[^。！？.!?\n]{0,48}?(?:数座|多座|多个|几座|数个|vài |nhiều |mấy )?(?:城市|城镇|地区|站点|车站|省|州|国家|thành phố|thị trấn|khu vực|vùng|nhà ga|trạm|tỉnh|bang|quốc gia|đất nước)/.test(tail);
    const repeatedService = /(?:第二轮|第三轮|数轮|多轮|lượt thứ hai|lượt thứ ba|vòng thứ hai|vòng thứ ba|mấy lượt|vài lượt|nhiều lượt|nhiều vòng)[^。！？.!?\n]{0,36}?(?:餐车|送餐|服务|广播|检票|xe đẩy đồ ăn|toa ăn|phát đồ ăn|đưa đồ ăn|phục vụ|phát thanh|loa thông báo|soát vé|kiểm vé)/.test(tail);
    const untilDawn = /(?:一路|一直|持续|suốt|liên tục|mãi)[^。！？.!?\n]{0,80}?(?:到|直到|直至|cho đến|cho tới|đến|tới)(?:天亮|黎明|清晨|\s*(?:sáng|rạng sáng|bình minh|hừng đông|tảng sáng))/.test(tail);

    if ((sleepCycle && (longTransit || repeatedService)) || (longTransit && repeatedService) || untilDawn) {
        return 180;
    }
    return 0;
}

export function formatWorldMinute(totalMinutes) {
    const safeTotal = asInteger(totalMinutes, 0, 0);
    const day = Math.floor(safeTotal / MINUTES_PER_DAY);
    const minuteOfDay = safeTotal % MINUTES_PER_DAY;
    const hour = Math.floor(minuteOfDay / 60);
    const minute = minuteOfDay % 60;
    const pad = number => String(number).padStart(2, '0');

    return {
        day,
        hour,
        minute,
        time: `${pad(hour)}:${pad(minute)}`,
        stamp: `# ${day} · ${pad(hour)}:${pad(minute)}`,
    };
}

function daysInCalendarMonth(year, month) {
    if (month === 2) {
        const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
        return leap ? 29 : 28;
    }
    return [4, 6, 9, 11].includes(month) ? 30 : 31;
}

function normalizeCalendarDate({ year, month, day } = {}, fallback = {
    year: 1,
    month: 1,
    day: 1,
}) {
    const safeYear = asInteger(year, fallback.year, 1, MAX_CALENDAR_YEAR);
    const safeMonth = asInteger(month, fallback.month, 1, 12);
    return {
        year: safeYear,
        month: safeMonth,
        day: asInteger(
            day,
            fallback.day,
            1,
            daysInCalendarMonth(safeYear, safeMonth),
        ),
    };
}

function daysBeforeCalendarYear(year) {
    const previous = Math.max(0, asInteger(year, 1, 1, MAX_CALENDAR_YEAR) - 1);
    return (
        previous * 365
        + Math.floor(previous / 4)
        - Math.floor(previous / 100)
        + Math.floor(previous / 400)
    );
}

function calendarOrdinal(date) {
    const safe = normalizeCalendarDate(date);
    let ordinal = daysBeforeCalendarYear(safe.year);
    for (let month = 1; month < safe.month; month += 1) {
        ordinal += daysInCalendarMonth(safe.year, month);
    }
    return ordinal + safe.day - 1;
}

function calendarDateFromOrdinal(value) {
    const maximumOrdinal = (
        daysBeforeCalendarYear(MAX_CALENDAR_YEAR)
        + 365
        + (daysInCalendarMonth(MAX_CALENDAR_YEAR, 2) === 29 ? 1 : 0)
        - 1
    );
    const target = Math.min(maximumOrdinal, Math.max(0, Math.trunc(Number(value) || 0)));

    let low = 1;
    let high = MAX_CALENDAR_YEAR;
    while (low < high) {
        const middle = Math.floor((low + high + 1) / 2);
        if (daysBeforeCalendarYear(middle) <= target) low = middle;
        else high = middle - 1;
    }

    const year = low;
    let dayOfYear = target - daysBeforeCalendarYear(year);
    let month = 1;
    while (month < 12) {
        const monthDays = daysInCalendarMonth(year, month);
        if (dayOfYear < monthDays) break;
        dayOfYear -= monthDays;
        month += 1;
    }
    return { year, month, day: dayOfYear + 1 };
}

function addCalendarDays(date, days) {
    const safe = normalizeCalendarDate(date);
    const delta = asInteger(days, 0, -1000000, 1000000);
    return calendarDateFromOrdinal(calendarOrdinal(safe) + delta);
}

function calendarDayDifference(fromDate, toDate) {
    const from = normalizeCalendarDate(fromDate);
    const to = normalizeCalendarDate(toDate, from);
    return calendarOrdinal(to) - calendarOrdinal(from);
}

function extractExplicitCalendarDate(text = '') {
    const source = asString(text, '', 60000);
    const patterns = [
        /(?:^|\D)(\d{1,6})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日(?:\D|$)/g,
        /(?:^|\D)(\d{1,6})[-/.](\d{1,2})[-/.](\d{1,2})(?:\D|$)/g,
    ];
    let latest = null;
    for (const pattern of patterns) {
        for (const match of source.matchAll(pattern)) {
            const year = Number(match[1]);
            const month = Number(match[2]);
            const day = Number(match[3]);
            if (year < 1 || year > MAX_CALENDAR_YEAR || month < 1 || month > 12) continue;
            if (day < 1 || day > daysInCalendarMonth(year, month)) continue;
            const index = Number(match.index ?? 0);
            if (!latest || index >= latest.index) {
                latest = { year, month, day, index, excerpt: match[0].trim() };
            }
        }
    }
    return latest;
}


/**
 * 从一条正文中读取“作者明确写出来”的时间锚点。
 * 手动“与正文校准”使用它：不调用模型、不推断缺失的钟点。
 * 优先解析正文的“时间与地点” details；找不到时才回退到整条正文。
 */
export function extractNarrativeTimeAnchor(text = '') {
    const source = asString(text, '', 60000);
    if (!source.trim()) return null;

    const detailMatches = [...source.matchAll(/<details\b[^>]*>[\s\S]*?<summary\b[^>]*>[\s\S]*?(?:时间\s*[与和]\s*地点|时间地点|thời gian\s*(?:và|&)\s*địa điểm)[\s\S]*?<\/summary>[\s\S]*?<\/details>/giu)];
    const scope = detailMatches.length
        ? String(detailMatches.at(-1)?.[0] || '')
        : source;

    const date = extractExplicitCalendarDate(scope) || (scope === source ? null : extractExplicitCalendarDate(source));

    // 形如 ▶07:40→08:15：结尾时间代表这段正文结束时的时间。
    const transitions = [...scope.matchAll(/(?:▶|>)?\s*([01]?\d|2[0-3])\s*:\s*([0-5]\d)\s*(?:→|->|至|到|đến|tới)\s*([01]?\d|2[0-3])\s*:\s*([0-5]\d)/gu)];
    let exact = null;
    if (transitions.length) {
        const match = transitions.at(-1);
        exact = { hour: Number(match[3]), minute: Number(match[4]), excerpt: match[0].trim() };
    } else {
        // 时间栏里只有单个明确钟点时也允许同步。限制在“时间与地点”区域可减少误抓正文中的普通数字。
        const times = [...scope.matchAll(/(?:^|[^\d])([01]?\d|2[0-3])\s*:\s*([0-5]\d)(?!\d)/gu)];
        if (times.length) {
            const match = times.at(-1);
            exact = { hour: Number(match[1]), minute: Number(match[2]), excerpt: match[0].trim() };
        }
    }

    const daypartMatch = [...scope.matchAll(/(?:凌晨|黎明|清晨|早晨|上午|中午|午后|下午|傍晚|黄昏|晚上|夜晚|深夜|rạng sáng|bình minh|sáng sớm|buổi sáng|buổi trưa|đầu giờ chiều|buổi chiều|chiều tối|hoàng hôn|buổi tối|ban đêm|đêm khuya|nửa đêm)/gu)].at(-1);
    const daypart = daypartMatch?.[0] || '';

    if (!date && !exact) return null;
    return {
        year: date?.year ?? null,
        month: date?.month ?? null,
        day: date?.day ?? null,
        hour: exact?.hour ?? null,
        minute: exact?.minute ?? null,
        daypart,
        structured: detailMatches.length > 0,
        precision: date && exact ? 'minute' : date ? (daypart ? 'daypart' : 'date') : 'minute',
        excerpt: [date?.excerpt, exact?.excerpt, daypart].filter(Boolean).join(' · ').slice(0, 240),
    };
}

function sequentialCalendarDate(absoluteDay) {
    return addCalendarDays(
        { year: 1, month: 1, day: 1 },
        Math.max(0, asInteger(absoluteDay, 1, 0) - 1),
    );
}

function normalizeWorldCalendar(raw, absoluteDay = 1) {
    const fallback = sequentialCalendarDate(absoluteDay);
    const anchor = normalizeCalendarDate({
        year: raw?.anchor_year ?? raw?.anchorYear,
        month: raw?.anchor_month ?? raw?.anchorMonth,
        day: raw?.anchor_day ?? raw?.anchorDay,
    }, fallback);
    return {
        name: asString(raw?.name, 'Lịch thế giới chính', 40),
        anchorAbsoluteDay: asInteger(
            raw?.anchor_absolute_day ?? raw?.anchorAbsoluteDay,
            absoluteDay,
            0,
            999999,
        ),
        anchorYear: anchor.year,
        anchorMonth: anchor.month,
        anchorDay: anchor.day,
    };
}

export function formatWorldCalendar(state, totalMinutes = state?.clock?.absoluteMinute ?? 0) {
    const clock = formatWorldMinute(totalMinutes);
    const calendar = normalizeWorldCalendar(state?.world?.calendar, clock.day);
    const date = addCalendarDays({
        year: calendar.anchorYear,
        month: calendar.anchorMonth,
        day: calendar.anchorDay,
    }, clock.day - calendar.anchorAbsoluteDay);
    const pad = number => String(number).padStart(2, '0');
    const dateLabel = `${date.year}年${date.month}月${date.day}日`;
    return {
        ...clock,
        calendarName: calendar.name,
        year: date.year,
        month: date.month,
        dayOfMonth: date.day,
        date: dateLabel,
        shortDate: `${pad(date.month)}月${pad(date.day)}日`,
        stamp: `${calendar.name} ${dateLabel} ${clock.time}`,
    };
}

export function formatWorldClockFactLabel(state, totalMinutes = state?.clock?.absoluteMinute ?? 0) {
    const formatted = formatWorldCalendar(state, totalMinutes);
    const precision = String(state?.clock?.precision || 'day');
    const daypart = asString(state?.clock?.daypart, '', 20);
    const anchored = Boolean(state?.clock?.anchored);

    if (anchored) {
        if (precision === 'minute') return formatted.stamp;
        if (precision === 'daypart' && daypart) {
            return `${formatted.calendarName} ${formatted.date} · ${daypart} (chưa xác định giờ cụ thể)`;
        }
        return `${formatted.calendarName} ${formatted.date} (chưa xác định giờ cụ thể)`;
    }

    const relative = formatWorldMinute(totalMinutes);
    if (precision === 'minute') return `Ngày thứ ${relative.day} · ${relative.time}`;
    if (precision === 'daypart' && daypart) {
        return `Ngày thứ ${relative.day} · ${daypart} (chưa xác định giờ cụ thể)`;
    }
    return `Ngày thứ ${relative.day} của câu chuyện (chưa xác định giờ cụ thể)`;
}

export function formatDuration(minutes) {
    const safeMinutes = Math.max(0, Math.round(Number(minutes) || 0));
    const days = Math.floor(safeMinutes / MINUTES_PER_DAY);
    const hours = Math.floor((safeMinutes % MINUTES_PER_DAY) / 60);
    const rest = safeMinutes % 60;
    const parts = [];

    if (days) parts.push(`${days} ngày`);
    if (hours) parts.push(`${hours} giờ`);
    if (rest || parts.length === 0) parts.push(`${rest} phút`);
    return parts.join(' ');
}


const VALID_WORLD_FACT_SOURCES = new Set(['narrative', 'simulation', 'manual', 'event-settlement']);
const VALID_WORLD_FACT_CONFIDENCE = new Set(['low', 'medium', 'high']);
const VALID_WORLD_FACT_VALIDITY = new Set(['current', 'upcoming', 'historical', 'persistent']);
const VALID_WORLD_PULSE_KINDS = new Set([
    'environment',
    'government',
    'economy',
    'organization',
    'infrastructure',
    'security',
    'culture',
    'media',
    'community',
    'other',
]);
const VALID_WORLD_PULSE_TRENDS = new Set(['stable', 'rising', 'falling', 'volatile']);
const VALID_EVENT_PUBLICITY = new Set(['private', 'trace', 'public']);

function worldFactStableKey(raw = {}) {
    const explicit = asString(raw?.key, '', 180);
    if (explicit) return explicit;
    const subjectType = asString(raw?.subject_type ?? raw?.subjectType, 'world', 40) || 'world';
    const subjectId = asString(
        raw?.subject_id ?? raw?.subjectId ?? raw?.subject ?? raw?.name,
        'world',
        120,
    ) || 'world';
    const field = asString(raw?.field, 'state', 80) || 'state';
    return `${subjectType}:${subjectId}:${field}`;
}

export function normalizeWorldFact(raw, existing = null, worldMinute = 0) {
    const key = worldFactStableKey(raw || existing || {});
    const source = asString(raw?.source, existing?.source || 'simulation', 40);
    const confidence = asString(raw?.confidence, existing?.confidence || 'high', 20);
    const rawValidity = asString(
        raw?.validity ?? raw?.temporal_state ?? raw?.temporalState ?? existing?.validity,
        '',
        20,
    ).toLowerCase();
    const inferredValidity = String(key || '').startsWith('event:') && String(key || '').endsWith(':result')
        ? 'historical'
        : 'current';
    const validity = VALID_WORLD_FACT_VALIDITY.has(rawValidity)
        ? rawValidity
        : inferredValidity;
    return {
        id: normalizeId(raw?.id || existing?.id || `world_fact_${hashText(key)}`, 'world_fact'),
        key,
        subjectType: asString(
            raw?.subject_type ?? raw?.subjectType,
            existing?.subjectType || 'world',
            40,
        ) || 'world',
        subjectId: asString(
            raw?.subject_id ?? raw?.subjectId,
            existing?.subjectId || '',
            120,
        ),
        subject: asString(raw?.subject, existing?.subject || '', 140),
        field: asString(raw?.field, existing?.field || 'state', 80) || 'state',
        value: asString(raw?.value, existing?.value || '', 520),
        source: VALID_WORLD_FACT_SOURCES.has(source) ? source : 'simulation',
        confidence: VALID_WORLD_FACT_CONFIDENCE.has(confidence) ? confidence : 'high',
        validity,
        visibility: normalizeVisibility(raw?.visibility ?? existing?.visibility ?? 'hidden'),
        eventId: asString(
            raw?.event_id ?? raw?.eventId,
            existing?.eventId || '',
            120,
        ),
        messageId: asInteger(
            raw?.message_id ?? raw?.messageId,
            existing?.messageId ?? -1,
            -1,
        ),
        settledAt: asInteger(
            raw?.settled_at ?? raw?.settledAt,
            existing?.settledAt ?? worldMinute,
            0,
        ),
        updatedAt: asInteger(
            raw?.updated_at ?? raw?.updatedAt,
            worldMinute,
            0,
        ),
    };
}

function worldFactAuthorityScore(fact) {
    const sourceWeight = {
        manual: 40,
        narrative: 35,
        'event-settlement': 30,
        simulation: 10,
    }[fact?.source] ?? 10;
    const confidenceWeight = {
        high: 3,
        medium: 2,
        low: 0,
    }[fact?.confidence] ?? 1;
    return sourceWeight + confidenceWeight;
}

function isStableIdentityFact(fact) {
    const field = String(fact?.field || '').toLocaleLowerCase();
    return /(?:婚姻|离婚|结婚|配偶|伴侣|亲属|父母|子女|兄弟|姐妹|身份|性别|物种|生死|死亡|存活|marriage|marital|spouse|partner|family|identity|gender|species|death|alive|hôn nhân|ly hôn|kết hôn|vợ chồng|phối ngẫu|bạn đời|người thân|họ hàng|cha mẹ|bố mẹ|con cái|anh em|chị em|thân phận|danh tính|giới tính|chủng loài|giống loài|sinh tử|sống chết|tử vong|cái chết|còn sống)/iu.test(field);
}

function factTransitionHasCausalEvent(state, fact) {
    const eventId = String(fact?.eventId || '').trim();
    return Boolean(eventId && asArray(state?.events).some(event => event?.id === eventId));
}

function lowerAuthorityFactOverwriteMustBeRejected(state, existing, incoming, worldMinute) {
    if (!existing || !incoming || existing.value === incoming.value) return false;
    if (incoming.source !== 'simulation') return false;

    // Stable identity/relationship facts cannot silently flip because the model
    // guessed a different value. A backstage transition is allowed only when the
    // new fact points at an actual causal event created/updated in world state.
    if (
        isStableIdentityFact(existing)
        && ['manual', 'narrative', 'event-settlement'].includes(existing.source)
        && !factTransitionHasCausalEvent(state, incoming)
    ) {
        return true;
    }

    // At the same world moment, a background inference never beats a stronger
    // foreground/manual fact. Once world time has genuinely advanced, ordinary
    // dynamic facts (location, shop status, resources, etc.) may evolve normally.
    return (
        worldFactAuthorityScore(incoming) < worldFactAuthorityScore(existing)
        && Number(worldMinute || 0) <= Number(existing.updatedAt || existing.settledAt || 0)
    );
}

function appendFactConsistencyConflict(state, {
    existing,
    incoming,
    resolution = 'keep-world',
    reason = '',
    messageId = null,
} = {}) {
    if (!existing || !incoming || existing.value === incoming.value) return;
    state.consistencyConflicts = [
        normalizeConsistencyConflict({
            subject: existing.subject || incoming.subject || existing.subjectId || incoming.subjectId || 'Trạng thái thế giới',
            field: existing.field || incoming.field || 'state',
            previous_value: existing.value,
            narrative_value: incoming.value,
            resolution,
            reason,
            message_id: messageId ?? incoming.messageId ?? existing.messageId ?? -1,
        }, state?.clock?.absoluteMinute || 0, messageId),
        ...asArray(state.consistencyConflicts),
    ].slice(0, LIMITS.consistencyConflicts);
}

function upsertWorldFact(state, raw, {
    worldMinute = state?.clock?.absoluteMinute || 0,
    source = '',
    messageId = null,
} = {}) {
    if (!raw || typeof raw !== 'object') return null;
    const prepared = {
        ...raw,
        ...(source ? { source } : {}),
        ...(messageId !== null && messageId !== undefined ? { message_id: messageId } : {}),
    };
    const key = worldFactStableKey(prepared);
    const existing = asArray(state.worldFacts).find(item => item.key === key) || null;
    const fact = normalizeWorldFact(prepared, existing, worldMinute);
    if (!fact.value) return null;

    if (existing && existing.value !== fact.value) {
        if (lowerAuthorityFactOverwriteMustBeRejected(state, existing, fact, worldMinute)) {
            appendFactConsistencyConflict(state, {
                existing,
                incoming: fact,
                resolution: 'keep-world',
                reason: isStableIdentityFact(existing)
                    ? 'Sự thật ổn định về thân phận/quan hệ không có sự kiện nhân quả mới tương ứng, từ chối lật ngược trực tiếp bằng suy đoán của nền'
                    : `Nguồn có thẩm quyền thấp hơn ở cùng thời điểm thế giới ${fact.source} không thể ghi đè ${existing.source}`,
                messageId,
            });
            return existing;
        }

        const incomingAuthority = worldFactAuthorityScore(fact);
        const existingAuthority = worldFactAuthorityScore(existing);
        if (
            incomingAuthority > existingAuthority
            || fact.source === 'narrative'
            || fact.source === 'manual'
        ) {
            freezeKnownFactBeforeChange(state, existing);
            appendFactConsistencyConflict(state, {
                existing,
                incoming: fact,
                resolution: 'accept-narrative',
                reason: fact.source === 'narrative'
                    ? 'Sự thật rõ ràng trong chính văn đã cập nhật trạng thái cũ của nền'
                    : fact.source === 'manual'
                        ? 'Sự thật do người dùng/tác giả duy trì đã cập nhật trạng thái cũ của nền'
                        : `Nguồn có thẩm quyền cao hơn ${fact.source} đã sửa nguồn có thẩm quyền thấp hơn ${existing.source}`,
                messageId,
            });
            appendAudit(state, {
                type: 'fact_authority_correction',
                text: `${existing.subject || existing.subjectId || 'Thế giới'}｜${existing.field}：${existing.value} → ${fact.value}`,
                reason: fact.source === 'narrative'
                    ? 'Ưu tiên sự thật rõ ràng trong chính văn'
                    : fact.source === 'manual'
                        ? 'Ưu tiên sự thật do người dùng/tác giả duy trì'
                        : `Thứ tự ưu tiên nguồn sự thật: ${fact.source} > ${existing.source}`,
            });
        }
    }

    if (existing) Object.assign(existing, fact);
    else state.worldFacts.unshift(fact);
    state.worldFacts = state.worldFacts.slice(0, LIMITS.worldFacts);
    return fact;
}


export function eventTemporalState(event, worldMinute = 0) {
    if (!event) return 'historical';
    if (TERMINAL_EVENT_STATES.has(event.status)) return 'historical';

    const now = Number(worldMinute || 0);
    const dueAt = Number(event.dueAt);
    const startedAt = Number(event.startedAt);

    if (event.status === 'waiting') return 'upcoming';
    if (event.clockMode === 'scheduled' && Number.isFinite(dueAt) && dueAt > now) {
        return 'upcoming';
    }
    if (Number.isFinite(startedAt) && startedAt > now) return 'upcoming';
    return 'current';
}

function syncPublicEventRealityFacts(state, worldMinute = state?.clock?.absoluteMinute || 0) {
    for (const event of asArray(state?.events)) {
        if (
            event?.publicity !== 'public'
            || !event?.id
            || (!event.publicSummary && !event.publicHeadline && !event.publicTrace && !event.publicResult)
        ) continue;

        const temporalState = eventTemporalState(event, worldMinute);
        let value = '';
        let field = '';
        let source = 'simulation';

        if (temporalState === 'historical') {
            value = asString(
                event.publicResult || event.publicSummary || event.publicHeadline || event.publicTrace,
                '',
                520,
            );
            field = event.publicResult ? 'Kết quả công khai cuối cùng' : 'Tin công khai gần nhất';
            source = 'event-settlement';
        } else if (temporalState === 'upcoming') {
            value = asString(
                event.publicSummary || event.publicHeadline || event.publicTrace,
                '',
                520,
            );
            field = 'Thông báo trước công khai';
        } else {
            value = asString(
                event.publicSummary || event.publicHeadline || event.publicTrace,
                '',
                520,
            );
            field = 'Trạng thái công khai hiện tại';
        }
        if (!value) continue;

        const subject = asString(event.place, '', 140)
            || asString(event.title, 'Thế giới', 140)
            || 'Thế giới';
        upsertWorldFact(state, {
            key: `public_event:${event.id}:state`,
            subject_type: event.place ? 'location' : 'event',
            subject_id: event.place || event.id,
            subject,
            field,
            value,
            validity: temporalState,
            visibility: 'known',
            confidence: 'high',
            event_id: event.id,
            settled_at: event.createdAt || worldMinute,
            updated_at: event.updatedAt || event.resolvedAt || worldMinute,
        }, {
            worldMinute,
            source,
        });
    }
}

function settlePersonStateFacts(state, person, source, messageId = null) {
    if (!person?.id) return;
    const fields = [
        ['location', 'Vị trí', person.location, 'hidden'],
        ['action', 'Hành động hiện tại', person.action, 'hidden'],
        ['physicalState', 'Trạng thái cơ thể', person.physicalState, 'hidden'],
        ['resourceState', 'Trạng thái tài nguyên', person.resourceState, 'hidden'],
    ];
    for (const [field, label, value, visibility] of fields) {
        const text = asString(value, '', 520);
        if (!text || /(?:待确认|chờ xác nhận)$/i.test(text)) continue;
        upsertWorldFact(state, {
            key: `person:${person.id}:${field}`,
            subject_type: 'person',
            subject_id: person.id,
            subject: person.name,
            field,
            value: text,
            validity: 'current',
            visibility,
            confidence: 'high',
        }, {
            source,
            messageId,
        });
    }
}

export function settlePersonWorldState(inputState, personId, {
    source = 'manual',
    messageId = null,
} = {}) {
    const state = deepClone(inputState);
    const person = asArray(state.people).find(item => item.id === String(personId || ''));
    if (!person) return trimState(state);
    settlePersonStateFacts(state, person, source, messageId);
    state.revision = asInteger(state.revision, 0, 0) + 1;
    state.updatedAt = nowIso();
    return trimState(state);
}

function settleEventResultFact(state, event, messageId = null) {
    if (!event?.id || !TERMINAL_EVENT_STATES.has(event.status)) return;
    const result = asString(event.result || event.consequence || event.summary, '', 520);
    if (!result) return;
    upsertWorldFact(state, {
        key: `event:${event.id}:result`,
        subject_type: 'event',
        subject_id: event.id,
        subject: event.title,
        field: 'result',
        value: result,
        validity: 'historical',
        visibility: event.visibility,
        event_id: event.id,
        confidence: 'high',
    }, {
        source: 'event-settlement',
        messageId,
    });
}

function normalizeConsistencyConflict(raw, worldMinute = 0, messageId = null) {
    return {
        id: normalizeId(raw?.id || `conflict_${hashText(JSON.stringify(raw || {}))}`, 'conflict'),
        subject: asString(raw?.subject, 'Trạng thái thế giới', 140),
        field: asString(raw?.field, 'state', 80),
        expected: asString(raw?.expected ?? raw?.previous_value ?? raw?.previousValue, '', 420),
        observed: asString(raw?.observed ?? raw?.narrative_value ?? raw?.narrativeValue, '', 420),
        resolution: ['accept-narrative', 'keep-world', 'transition'].includes(raw?.resolution)
            ? raw.resolution
            : 'keep-world',
        reason: asString(raw?.reason, '', 360),
        messageId: asInteger(raw?.message_id ?? raw?.messageId, messageId ?? -1, -1),
        at: worldMinute,
    };
}


function normalizeWorldPulseDomain(raw, existing = null, worldMinute = 0) {
    const label = asString(
        raw?.label ?? raw?.name ?? existing?.label,
        existing?.label || 'Lĩnh vực chưa đặt tên',
        100,
    );
    const rawKind = asString(raw?.kind, existing?.kind || 'other', 30).toLowerCase();
    const rawTrend = asString(raw?.trend, existing?.trend || 'stable', 20).toLowerCase();
    return {
        id: normalizeId(
            raw?.id || existing?.id || `pulse_${hashText(`${rawKind}:${label}`)}`,
            'pulse',
        ),
        label,
        scope: asString(raw?.scope, existing?.scope || '', 120),
        kind: VALID_WORLD_PULSE_KINDS.has(rawKind) ? rawKind : 'other',
        state: asString(raw?.state, existing?.state || '', 420),
        pressure: asInteger(raw?.pressure, existing?.pressure ?? 1, 0, 3),
        trend: VALID_WORLD_PULSE_TRENDS.has(rawTrend) ? rawTrend : 'stable',
        visibility: normalizeVisibility(raw?.visibility ?? existing?.visibility ?? 'hidden'),
        source: ['history', 'simulation', 'manual'].includes(raw?.source)
            ? raw.source
            : (existing?.source || 'simulation'),
        evidence: asString(
            raw?.evidence ?? raw?.reason,
            existing?.evidence || '',
            260,
        ),
        updatedAt: asInteger(
            raw?.updated_at ?? raw?.updatedAt,
            worldMinute,
            0,
        ),
    };
}

function normalizeWorldCoverageEntry(raw, worldMinute = 0) {
    const label = asString(raw?.label, 'Phạm vi chưa đặt tên', 120) || 'Phạm vi chưa đặt tên';
    const kind = asString(raw?.kind, 'general', 40) || 'general';
    const scope = asString(raw?.scope, '', 160);
    return {
        id: normalizeId(
            raw?.id || `coverage_${hashText(`${kind}:${label}:${scope}`)}`,
            'coverage',
        ),
        label,
        kind,
        scope,
        source: asString(raw?.source, 'world', 40) || 'world',
        lastCheckedAt: asInteger(
            raw?.last_checked_at ?? raw?.lastCheckedAt,
            -1,
            -1,
        ),
        checks: asInteger(raw?.checks, 0, 0, 999999),
    };
}

function normalizeWorldCoverage(raw, worldMinute = 0) {
    const entries = [];
    for (const candidate of asArray(raw?.entries).slice(0, LIMITS.worldCoverageEntries)) {
        const normalized = normalizeWorldCoverageEntry(candidate, worldMinute);
        const existing = entries.find(item => item.id === normalized.id);
        if (existing) Object.assign(existing, normalized);
        else entries.push(normalized);
    }
    return {
        lastSweepAt: asInteger(raw?.last_sweep_at ?? raw?.lastSweepAt, -1, -1),
        lastPublicSweepAt: asInteger(
            raw?.last_public_sweep_at ?? raw?.lastPublicSweepAt,
            -1,
            -1,
        ),
        lastFocusSignature: asString(
            raw?.last_focus_signature ?? raw?.lastFocusSignature,
            '',
            80,
        ),
        entries: entries
            .sort((a, b) => Number(b.lastCheckedAt || -1) - Number(a.lastCheckedAt || -1))
            .slice(0, LIMITS.worldCoverageEntries),
    };
}

function worldCoverageTarget(raw = {}, sourceRank = 9) {
    const label = asString(raw?.label, '', 120);
    if (!label) return null;
    const kind = asString(raw?.kind, 'general', 40) || 'general';
    const scope = asString(raw?.scope, '', 160);
    return {
        id: `coverage_${hashText(`${kind}:${label}:${scope}`)}`,
        label,
        kind,
        scope,
        source: asString(raw?.source, 'world', 40) || 'world',
        pressure: asInteger(raw?.pressure, 0, 0, 3),
        sourceRank,
    };
}

export function selectWorldCoverageTargets(state, {
    customInstruction = '',
    maximum = 2,
} = {}) {
    const candidates = new Map();
    const add = (raw, sourceRank) => {
        const candidate = worldCoverageTarget(raw, sourceRank);
        if (candidate && !candidates.has(candidate.id)) candidates.set(candidate.id, candidate);
    };
    const customFocus = asString(customInstruction, '', 1000);
    if (customFocus) {
        add({
            label: customFocus,
            kind: 'custom-focus',
            scope: 'Trọng tâm thế giới ngoài ống kính do người dùng chỉ định',
            source: 'custom',
            pressure: 3,
        }, 0);
    }
    for (const domain of asArray(state?.worldPulse?.domains)) {
        add({
            label: domain?.label,
            kind: domain?.kind || 'other',
            scope: domain?.scope,
            source: 'world-pulse',
            pressure: domain?.pressure,
        }, 1);
    }
    add({
        label: 'Đời sống công cộng thông thường trong bối cảnh thế giới',
        kind: 'general',
        scope: asString(state?.world?.name, 'Thế giới chính', 80),
        source: 'world-background',
    }, 2);
    const locationLabels = [
        ...asArray(state?.worldFacts)
            .filter(fact => String(fact?.subjectType || '') === 'location')
            .map(fact => fact?.subject || fact?.subjectId),
        ...asArray(state?.storyMemory?.digest?.locations),
        ...asArray(state?.events).map(event => event?.place),
        ...asArray(state?.people).map(person => person?.location),
    ];
    for (const location of [...new Set(locationLabels.map(item => asString(item, '', 120)).filter(Boolean))]) {
        add({
            label: location,
            kind: 'location',
            scope: location,
            source: 'known-location',
        }, 3);
    }

    const coverage = normalizeWorldCoverage(state?.worldPulse?.coverage, state?.clock?.absoluteMinute || 0);
    const checkedById = new Map(coverage.entries.map(entry => [entry.id, entry]));
    return [...candidates.values()]
        .map(candidate => ({
            ...candidate,
            lastCheckedAt: checkedById.get(candidate.id)?.lastCheckedAt ?? -1,
            checks: checkedById.get(candidate.id)?.checks ?? 0,
        }))
        .sort((a, b) => (
            Number(a.lastCheckedAt) - Number(b.lastCheckedAt)
            || Number(a.sourceRank) - Number(b.sourceRank)
            || Number(b.pressure || 0) - Number(a.pressure || 0)
            || a.label.localeCompare(b.label, 'zh-CN')
        ))
        .slice(0, asInteger(maximum, 2, 1, 4))
        .map(({ sourceRank, pressure, ...target }) => target);
}

export function markWorldCoverageChecked(inputState, targets = [], {
    publicCycle = false,
    customInstruction = '',
} = {}) {
    const state = deepClone(inputState);
    state.worldPulse = normalizeWorldPulse(state.worldPulse, state.clock?.absoluteMinute || 0);
    const worldMinute = asInteger(state.clock?.absoluteMinute, 0, 0);
    const coverage = normalizeWorldCoverage(state.worldPulse.coverage, worldMinute);
    for (const rawTarget of asArray(targets)) {
        const target = normalizeWorldCoverageEntry(rawTarget, worldMinute);
        target.lastCheckedAt = worldMinute;
        const existing = coverage.entries.find(item => item.id === target.id);
        if (existing) Object.assign(existing, target, { checks: Number(existing.checks || 0) + 1 });
        else coverage.entries.push({ ...target, checks: 1 });
    }
    coverage.lastSweepAt = worldMinute;
    if (publicCycle) coverage.lastPublicSweepAt = worldMinute;
    coverage.lastFocusSignature = hashText(asString(customInstruction, '', 1000));
    coverage.entries = coverage.entries
        .sort((a, b) => Number(b.lastCheckedAt || -1) - Number(a.lastCheckedAt || -1))
        .slice(0, LIMITS.worldCoverageEntries);
    state.worldPulse.coverage = coverage;
    return state;
}

export function publicWorldCoverageDue(state, {
    customInstruction = '',
    minimumIntervalMinutes = 180,
} = {}) {
    const worldMinute = asInteger(state?.clock?.absoluteMinute, 0, 0);
    const coverage = normalizeWorldCoverage(state?.worldPulse?.coverage, worldMinute);
    const focusSignature = hashText(asString(customInstruction, '', 1000));
    if (coverage.lastSweepAt < 0) return true;
    if (focusSignature !== coverage.lastFocusSignature) return true;
    return worldMinute - coverage.lastSweepAt >= Math.max(
        1,
        asInteger(minimumIntervalMinutes, 180, 1),
    );
}

function normalizeWorldPulse(raw, worldMinute = 0) {
    const domains = [];
    for (const candidate of asArray(raw?.domains).slice(0, LIMITS.worldPulseDomains)) {
        const normalized = normalizeWorldPulseDomain(candidate, null, worldMinute);
        if (!normalized.state && !normalized.evidence) continue;
        const existing = domains.find(item => item.id === normalized.id || (
            item.kind === normalized.kind
            && item.label.toLocaleLowerCase() === normalized.label.toLocaleLowerCase()
        ));
        if (existing) Object.assign(existing, normalizeWorldPulseDomain(candidate, existing, worldMinute));
        else domains.push(normalized);
    }
    return {
        baselineEstablished: Boolean(raw?.baselineEstablished ?? raw?.baseline_established),
        lastSweepAt: asInteger(raw?.lastSweepAt ?? raw?.last_sweep_at, worldMinute, 0),
        coverage: normalizeWorldCoverage(raw?.coverage, worldMinute),
        domains: domains.slice(0, LIMITS.worldPulseDomains),
    };
}

function upsertWorldPulseDomain(state, raw, {
    worldMinute = state?.clock?.absoluteMinute || 0,
    source = '',
} = {}) {
    if (!raw || typeof raw !== 'object') return null;
    state.worldPulse = normalizeWorldPulse(state.worldPulse, worldMinute);
    const prepared = {
        ...raw,
        ...(source ? { source } : {}),
    };
    const candidate = normalizeWorldPulseDomain(prepared, null, worldMinute);
    const existing = state.worldPulse.domains.find(item => (
        item.id === candidate.id
        || (
            item.kind === candidate.kind
            && item.label.toLocaleLowerCase() === candidate.label.toLocaleLowerCase()
        )
    )) || null;
    const normalized = normalizeWorldPulseDomain(prepared, existing, worldMinute);
    if (!normalized.state && !normalized.evidence) return null;
    if (existing) Object.assign(existing, normalized);
    else state.worldPulse.domains.unshift(normalized);
    state.worldPulse.domains = state.worldPulse.domains
        .sort((a, b) => (
            Number(b.pressure || 0) - Number(a.pressure || 0)
            || Number(b.updatedAt || 0) - Number(a.updatedAt || 0)
        ))
        .slice(0, LIMITS.worldPulseDomains);
    state.worldPulse.lastSweepAt = worldMinute;
    return normalized;
}


function normalizePublicImpactRecord(raw, worldMinute = 0) {
    return {
        id: normalizeId(
            raw?.id || `impact_${hashText(`${raw?.source_event_id ?? raw?.sourceEventId ?? ''}:${raw?.fingerprint || ''}`)}`,
            'impact',
        ),
        sourceEventId: asString(raw?.source_event_id ?? raw?.sourceEventId, '', 120),
        fingerprint: asString(raw?.fingerprint, '', 120),
        summary: asString(raw?.summary, '', 520),
        affectedPersonIds: uniqueStrings(
            raw?.affected_person_ids ?? raw?.affectedPersonIds,
            24,
        ),
        affectedScopes: uniqueStrings(
            raw?.affected_scopes ?? raw?.affectedScopes,
            24,
        ),
        channels: uniqueStrings(raw?.channels, 16),
        processedAt: asInteger(
            raw?.processed_at ?? raw?.processedAt,
            worldMinute,
            0,
        ),
        reason: asString(raw?.reason, '', 220),
    };
}

export function publicImpactFingerprint(event) {
    if (!event?.id) return '';
    // Public-impact propagation reacts to what entered public circulation, not to
    // backstage-only lifecycle state. A hidden resolved/cancelled transition must
    // not make society magically know the ending. If the terminal outcome becomes
    // public, publicResult/publicSummary changes and naturally creates a new fingerprint.
    const payload = {
        id: String(event.id || ''),
        publicity: String(event.publicity || 'private'),
        publicTrace: String(event.publicTrace || ''),
        publicHeadline: String(event.publicHeadline || ''),
        publicSummary: String(event.publicSummary || ''),
        publicResult: String(event.publicResult || ''),
    };
    return hashText(JSON.stringify(payload));
}

function eventHasPublicPropagation(event) {
    if (!event?.id) return false;
    if (event.publicity === 'public') {
        return Boolean(event.publicHeadline || event.publicSummary || event.publicResult || event.publicTrace);
    }
    if (event.publicity === 'trace') {
        return Boolean(event.publicTrace);
    }
    return false;
}

export function pendingPublicImpactEvents(state, { maximum = 8 } = {}) {
    const ledger = asArray(state?.publicImpactLedger);
    const processed = new Set(
        ledger.map(record => `${record?.sourceEventId || ''}:${record?.fingerprint || ''}`),
    );
    return asArray(state?.events)
        .filter(eventHasPublicPropagation)
        .filter(event => {
            const fingerprint = publicImpactFingerprint(event);
            return fingerprint && !processed.has(`${event.id}:${fingerprint}`);
        })
        .sort((a, b) => (
            Number(b.updatedAt || b.resolvedAt || 0)
            - Number(a.updatedAt || a.resolvedAt || 0)
        ))
        .slice(0, Math.max(1, Number(maximum) || 8));
}

function recordProcessedPublicImpacts(state, sourceEvents, rawRecords = [], {
    reason = 'public-impact',
} = {}) {
    const recordsBySource = new Map(
        asArray(rawRecords)
            .map(raw => normalizePublicImpactRecord(raw, state.clock?.absoluteMinute || 0))
            .filter(record => record.sourceEventId)
            .map(record => [record.sourceEventId, record]),
    );
    const next = asArray(state.publicImpactLedger)
        .map(record => normalizePublicImpactRecord(record, state.clock?.absoluteMinute || 0));

    for (const event of asArray(sourceEvents)) {
        if (!event?.id) continue;
        const fingerprint = publicImpactFingerprint(event);
        if (!fingerprint) continue;
        const modelRecord = recordsBySource.get(event.id);
        const record = normalizePublicImpactRecord({
            id: `impact_${hashText(`${event.id}:${fingerprint}`)}`,
            source_event_id: event.id,
            fingerprint,
            summary: modelRecord?.summary || 'Lượt này đã kiểm tra ảnh hưởng dây chuyền của sự kiện công khai này đối với thế giới.',
            affected_person_ids: modelRecord?.affectedPersonIds || [],
            affected_scopes: modelRecord?.affectedScopes || [],
            channels: modelRecord?.channels || [],
            processed_at: state.clock?.absoluteMinute || 0,
            reason,
        }, state.clock?.absoluteMinute || 0);

        const key = `${record.sourceEventId}:${record.fingerprint}`;
        const oldIndex = next.findIndex(item => (
            `${item.sourceEventId}:${item.fingerprint}` === key
        ));
        if (oldIndex >= 0) next[oldIndex] = record;
        else next.unshift(record);
    }

    state.publicImpactLedger = next
        .sort((a, b) => Number(b.processedAt || 0) - Number(a.processedAt || 0))
        .slice(0, LIMITS.publicImpactLedger);
}

export function markCurrentPublicImpactsProcessed(inputState, {
    reason = 'baseline',
} = {}) {
    const state = deepClone(inputState);
    recordProcessedPublicImpacts(
        state,
        asArray(state.events).filter(eventHasPublicPropagation),
        [],
        { reason },
    );
    return trimState(state);
}

export function buildPublicImpactPrompt(state, {
    sourceEventIds = [],
    userName = '',
    maximumEvents = 8,
    recordPlayerCharacter = true,
} = {}) {
    const wanted = new Set(asArray(sourceEventIds).map(String).filter(Boolean));
    const sourceEvents = (wanted.size
        ? asArray(state?.events).filter(event => wanted.has(String(event?.id || '')))
        : pendingPublicImpactEvents(state, { maximum: maximumEvents }))
        .filter(eventHasPublicPropagation)
        .slice(0, Math.max(1, Number(maximumEvents) || 8));

    const priorityPersonIds = uniqueStrings(
        asArray(state?.people)
            .filter(person => sourceEvents.some(event => {
                const actors = asArray(event?.actors).map(item => normalizedReference(item));
                const personId = normalizedReference(person?.id);
                const personName = normalizedReference(person?.name);
                const eventPlace = normalizedReference(event?.place);
                const personPlace = normalizedReference(person?.location);
                const actorMatched = actors.some(actor => (
                    actor && (actor === personId || actor === personName)
                ));
                const placeMatched = Boolean(
                    eventPlace
                    && personPlace
                    && (eventPlace.includes(personPlace) || personPlace.includes(eventPlace)),
                );
                return actorMatched || placeMatched;
            }))
            .map(person => person.id),
        24,
    );

    const compact = compactStateForModel(state, {
        includeUserInnerVoice: false,
        includeUserCharacter: recordPlayerCharacter,
        userName,
        maximumPeople: 24,
        priorityPersonIds,
    });
    const publicSources = sourceEvents.map(event => ({
        id: event.id,
        place: modelText(event.place, 120),
        status: event.status,
        publicity: event.publicity,
        public_trace: modelText(event.publicTrace, 260),
        public_headline: modelText(event.publicHeadline, 180),
        public_summary: modelText(event.publicSummary, 520),
        public_result: modelText(event.publicResult, 520),
        actors: asArray(event.actors).slice(0, 12),
    }));

    return [
        'Bạn là công cụ lan truyền ảnh hưởng của sự kiện công cộng của “世界背面”. Nhiệm vụ của bạn không phải viết tin tức, mà là phán đoán các sự kiện thế giới đã đi vào truyền thông công cộng sẽ thay đổi thế giới này một cách chân thực như thế nào. Mọi nội dung văn bản hãy viết bằng tiếng Việt.',
        '',
        'Nguyên tắc cốt lõi: sự kiện có thể hoàn toàn không xảy ra vì nhân vật chính, nhưng nhân vật chính và các nhân vật đều sống trong thế giới này, nên chỉ cần nghề nghiệp, tổ chức, địa điểm, tài nguyên, quan hệ, chính sách, thị trường hay môi trường xã hội bị ảnh hưởng, hậu quả phải đi vào trạng thái thế giới ở nền.',
        compact.world.background
            ? `Thiết lập bối cảnh thế giới (ràng buộc cơ bản, không được sửa): ${compact.world.background}`
            : 'Thiết lập bối cảnh thế giới: chưa điền thêm.',
        '1. Chỉ suy ra hậu quả dựa trên source_public_events, thiết lập bối cảnh thế giới và trạng thái thế giới có thẩm quyền hiện tại. Câu chữ của tin tức không phải nguồn sự thật mới; không được tự tưởng tượng từ tiêu đề tin tức ra nguyên nhân hậu trường chưa công khai.',
        '2. publicity=public biểu thị sự thật công khai; publicity=trace chỉ biểu thị dấu hiệu/tin đồn đang lan truyền công khai. trace có thể gây ra hậu quả xã hội thực sự như “tin đồn đang lan truyền, nhãn hàng đứng ngoài quan sát, thảo luận công chúng nóng lên”, nhưng tuyệt đối không được nâng bản thân nội dung tin đồn thành sự thật đã được xác thực.',
        '3. Ảnh hưởng có thể rơi vào nhân vật, tổ chức/thế lực, địa điểm, ngành nghề, tài nguyên, cơ hội, hợp đồng, lịch trình, danh tiếng, giá cả, việc thực thi chính sách, cơ sở hạ tầng và áp lực xã hội. Trạng thái nhân vật cần thay đổi thì dùng people_upsert; kết quả khách quan cần lưu lại thì ghi world_facts_upsert; áp lực kéo dài thì ghi world_pulse_upsert; hậu quả cần tiếp tục phát triển thì ghi events_create/update. world_facts_upsert bắt buộc điền validity: current / upcoming / historical / persistent. Tin tức nguồn đã kết thúc không có nghĩa là hậu quả nó gây ra cũng kết thúc; hậu quả vẫn còn hiệu lực thì dùng current/persistent.',
        '4. Sự kiện hậu quả mới tạo phải có caused_by chứa id của sự kiện công cộng nguồn, tránh đứt chuỗi nhân quả. Bản thân source_public_events là đầu vào đã xác nhận của lượt này, đừng sửa chúng trong events_update; tiến triển mới cần thiết thì tạo sự kiện hậu quả riêng. Đừng vì “phải có ảnh hưởng” mà cố tạo hậu quả kịch tính; hoàn toàn cho phép không có ảnh hưởng trực tiếp.',
        '5. Với nhân vật không phải người chơi: chỉ khi trong lượt này nhân vật đó thực sự tiếp xúc với thông tin qua kênh công khai/kênh nghề nghiệp/thông báo của tổ chức…, mới ghi knowledge_updates trong people_upsert; cấm ghi trực tiếp known_event_ids / known_fact_keys. public_channel phải ghi rõ evidence và source_event_id; các trường hợp biết được (confirmed) khác ở ngoài ống kính cũng phải có source_event_id trỏ tới sự kiện quá trình thông báo/chứng kiến/điều tra rõ ràng, không được vì tin tức đã công khai hay nhân vật bị ảnh hưởng mà mặc định nhân vật đó tự động biết.',
        recordPlayerCharacter
            ? '6. Với người chơi: tuyệt đối không được vì “tin tức đã công khai” mà tự động giả định người chơi đã xem. Nếu sự kiện công cộng sẽ ảnh hưởng trực tiếp tới người chơi nhưng người chơi hiện chưa chắc đã biết, ưu tiên tạo một sự kiện hậu quả mà chính văn có thể tự nhiên tiếp nối (ví dụ người quản lý thông báo, lịch trình thay đổi, tin nhắn trong nhóm công ty, đường bị phong tỏa khiến không đến được), và dùng delivery_route/visibility để mô tả cách nó đi vào tiền cảnh; đừng quyết định phản ứng thay người chơi.'
            : '6. Nhân vật người chơi hiện đang được đặt là “không ghi nhận”. Sự kiện công cộng vẫn có thể ảnh hưởng khách quan tới địa điểm, tài nguyên, lịch trình hay quan hệ của người chơi, nhưng cấm tạo/cập nhật thẻ nhân vật người chơi qua people_upsert; ảnh hưởng cần hé lộ thì đưa vào tiền cảnh bằng sự kiện, sự thật thế giới hoặc delivery_route, không quyết định phản ứng thay người chơi.',
        '7. Nếu sự kiện công cộng đã ảnh hưởng trực tiếp về mặt vật lý tới địa điểm/lịch trình hiện tại, ví dụ mất điện, phong tỏa đường, hủy chuyến bay, có thể ghi những hậu quả này thành sự thật thế giới; “nhân vật biết tin này” vẫn là một tầng nhận thức khác.',
        '8. Lan truyền ảnh hưởng không có nghĩa là tin nào cũng phải đụng tới nhân vật chính. Trước hết phán đoán phạm vi thế giới, rồi phán đoán nhân vật hiện tại có liên kết thực sự với nó hay không. Trong các đề tài như giới giải trí, chính trị - kinh doanh, chiến tranh, thảm họa, tin tức cấp ngành/tổ chức thường tự nhiên ảnh hưởng tới nhiều nhân vật; tin tức địa phương thường ngày thì có thể chỉ ảnh hưởng cục bộ.',
        '8A. compact people đã ưu tiên đưa vào những người tham gia sự kiện nguồn và các nhân vật hiện đang ở địa điểm bị ảnh hưởng. Phải kiểm tra từng người xem họ có bị môi trường khách quan ảnh hưởng trực tiếp không, và có thực sự có kênh tin tức, thông báo, thông báo nghề nghiệp, lan truyền xã hội hay cảm nhận tại hiện trường không; có kênh thì cập nhật nhận thức/hành động, không có kênh thì chỉ giữ lại ảnh hưởng khách quan lên thế giới, không được để tất cả mọi người tự động biết.',
        '8B. Với mỗi nhân vật dự định cập nhật, kiểm chứng rõ ít nhất một chuỗi tiếp xúc: physical=thực sự ở địa điểm/lịch trình/cơ sở bị ảnh hưởng; information=tin tức, thông báo, thông báo nghề nghiệp, tin nhắn hoặc lời thuật lại đáng tin thực sự được chuyển đến; causal=tổ chức, công việc, hợp đồng, tài nguyên, quan hệ hoặc sự kiện chung thực sự bị thay đổi ở thượng nguồn kéo theo. Khi chuỗi bị đứt thì không được cập nhật nhân vật đó, cũng không được vì muốn tin tức “có ích” mà tạm bịa ra sự trùng hợp.',
        '8C. Khi cùng một thay đổi công cộng ảnh hưởng tới nhiều người, trước hết tạo một hậu quả chung về địa điểm/tổ chức/ngành/sự kiện, rồi kết toán phản ứng của từng nhân vật. Khi cần hành động chung thì chỉ tạo hoặc cập nhật một sự kiện có actors đầy đủ, và để people_upsert cùng trạng thái tri thức của tất cả người tham gia thực tế khớp với nhau; khi ngân sách không đủ để cập nhật an toàn tất cả người tham gia, không được tuyên bố tương tác đã hoàn tất.',
        '8D. Đánh giá xã hội chỉ thay đổi sau khi hành vi hoặc hậu quả đi vào giới tương ứng qua chứng kiến, vật chứng, thông báo, truyền thông hoặc tin đồn có hiệu lực. Chính quyền, dân gian, ngành nghề, nội bộ tổ chức có thể chú ý các mặt khác nhau và đưa ra phán đoán khác nhau; dư luận trong giới là trạng thái xã hội, không phải chân tướng của thế giới, không thể dùng để chứng minh ngược lại nội dung tin đồn.',
        '9. Không đẩy thời gian thế giới chính, elapsed_minutes phải bằng 0; không ghi ký ức dài hạn memory_update. Ở đây chỉ kết toán hậu quả thế giới do lan truyền công cộng gây ra.',
        '10. Chỉ xuất JSON hợp lệ.',
        '',
        'Thế giới có thẩm quyền hiện tại:',
        JSON.stringify(compact),
        '',
        'Sự kiện công cộng lượt này:',
        JSON.stringify(publicSources),
        '',
        'Cấu trúc trả về:',
        JSON.stringify({
            elapsed_minutes: 0,
            time_reason: 'public impact propagation',
            clock_anchor: { mode: 'none' },
            world: { title: '', detail: '' },
            people_upsert: [{
                id: '',
                name: '',
                location: '',
                action: '',
                intent: '',
                long_term_goal: '',
                physical_state: '',
                emotional_state: '',
                resource_state: '',
                knowledge_updates: [{
                    kind: 'event | fact',
                    ref: 'ID sự kiện / key sự thật',
                    route: 'public_channel | message | told | investigated | witnessed | inferred',
                    certainty: 'confirmed | suspected',
                    evidence: 'Căn cứ cho việc nhân vật này thực sự tiếp xúc với thông tin công khai/thông báo này',
                    belief: 'Phiên bản mà nhân vật thực sự biết hoặc tin',
                    source_event_id: 'ID sự kiện nguồn công khai',
                }],
                relevance: 1,
                source: 'background',
            }],
            people_remove: [],
            events_create: [{
                id: '',
                title: '',
                place: '',
                summary: '',
                consequence: '',
                expected_result: '',
                status: 'active | waiting | ready',
                clock_mode: 'condition | duration | scheduled | active',
                duration_minutes: 0,
                scheduled_at: null,
                prerequisites: [],
                cause: '',
                actors: [],
                caused_by: ['ID sự kiện công cộng nguồn'],
                publicity: 'private | trace | public',
                public_trace: '',
                public_headline: '',
                public_summary: '',
                public_result: '',
                visibility: 'hidden | trace | known | direct',
                delivery_route: '',
            }],
            events_update: [],
            deliveries_confirmed: [],
            front_facts: [],
            world_facts_upsert: [{
                key: '',
                subject_type: 'person | event | world | location | item | organization | other',
                subject_id: '',
                subject: '',
                field: '',
                value: '',
                source: 'simulation',
                visibility: 'hidden | trace | known | direct',
                confidence: 'high',
                validity: 'current | upcoming | historical | persistent',
                event_id: '',
            }],
            world_pulse_upsert: [{
                id: '',
                label: '',
                scope: '',
                kind: 'environment | government | economy | organization | infrastructure | security | culture | media | community | other',
                state: '',
                pressure: 1,
                trend: 'stable | rising | falling | volatile',
                visibility: 'hidden | trace | known',
                source: 'simulation',
                evidence: '',
            }],
            consistency_conflicts: [],
            impact_records: [{
                source_event_id: 'ID sự kiện công cộng nguồn',
                summary: 'Sự kiện công khai này thực tế đã gây ra ảnh hưởng dây chuyền gì cho thế giới; nếu tạm thời không có ảnh hưởng cũng ghi rõ là không có ảnh hưởng trực tiếp',
                affected_person_ids: [],
                affected_scopes: [],
                channels: [],
            }],
            memory_update: {
                facts_upsert: [],
                facts_invalidate: [],
                clues_upsert: [],
                clues_resolve: [],
            },
        }),
    ].join('\n');
}

export function applyPublicImpactResult(inputState, rawPayload, {
    sourceEventIds = [],
    userName = '',
    sourceKey = '',
    backgroundNpcBudget = LIMITS.peopleTaskBudget,
    recordPlayerCharacter = true,
} = {}) {
    const sourceEvents = asArray(inputState?.events)
        .filter(event => asArray(sourceEventIds).includes(event?.id))
        .filter(eventHasPublicPropagation);
    let state = applySimulationResult(inputState, {
        ...rawPayload,
        elapsed_minutes: 0,
        memory_update: {
            facts_upsert: [],
            facts_invalidate: [],
            clues_upsert: [],
            clues_resolve: [],
        },
    }, {
        messageId: null,
        swipeId: null,
        sourceKey: sourceKey || `public-impact:${sourceEventIds.join(',')}`,
        userName,
        allowUserInnerVoice: false,
        recordPlayerCharacter,
        timePolicy: 'world',
        narrativeText: '',
        backgroundNpcBudget,
        preserveCommitAnchor: true,
    });

    recordProcessedPublicImpacts(
        state,
        sourceEvents,
        rawPayload?.impact_records ?? rawPayload?.impactRecords ?? [],
        { reason: 'public-impact-propagation' },
    );
    appendAudit(state, {
        type: 'public_impact_propagated',
        text: `Đã kiểm tra ${sourceEvents.length} sự kiện công cộng về ảnh hưởng dây chuyền`,
        reason: asArray(rawPayload?.impact_records ?? rawPayload?.impactRecords)
            .map(item => asString(item?.summary, '', 160))
            .filter(Boolean)
            .slice(0, 3)
            .join('；'),
    });
    return trimState(state);
}


function contextMatchScore(text, terms = []) {
    let score = 0;
    const source = String(text || '').toLocaleLowerCase();
    for (const raw of terms) {
        const term = String(raw || '').trim().toLocaleLowerCase();
        if (term.length < 2) continue;
        if (source.includes(term)) {
            score += Math.min(140, 80 + term.length * 4);
            continue;
        }
        // Useful for longer location / organization names where the story may use
        // a shortened form, without fuzzy-matching generic one-character words.
        if (term.length >= 4) {
            const chunks = term
                .split(/[\s·・,，。、“”"'（）()\-_/]+/u)
                .map(item => item.trim())
                .filter(item => item.length >= 2);
            if (chunks.some(chunk => source.includes(chunk))) score += 35;
        }
    }
    return score;
}

function textSuggestsFuturePlan(text = '') {
    return /(?:待会|等会|稍后|之后|过会|下午|今晚|明天|后天|下周|周末|过几天|晚些时候|一会儿|准备去|打算去|计划去|要去|lát nữa|chút nữa|một lát nữa|sau đó|buổi chiều|chiều nay|tối nay|ngày mai|ngày kia|tuần sau|tuần tới|cuối tuần|vài hôm nữa|vài ngày nữa|muộn hơn|chuẩn bị đi|định đi|dự định đi|lên kế hoạch đi|sẽ đi|phải đi)/iu
        .test(String(text || ''));
}

function textExplicitlyReferencesHistoricalEvent(text = '', event = null) {
    const source = String(text || '').toLocaleLowerCase();
    if (!source || !event) return false;
    const exactTerms = [
        event.title,
        event.publicHeadline,
        event.publicResult,
    ]
        .map(value => String(value || '').trim().toLocaleLowerCase())
        .filter(value => value.length >= 3);
    return exactTerms.some(term => source.includes(term));
}

export function selectContextRelevantReality(state, recentText = '', maximum = 8) {
    const text = asString(recentText, '', 6000);
    if (!text.trim()) return [];
    const now = Number(state?.clock?.absoluteMinute || 0);
    const futurePlan = textSuggestsFuturePlan(text);
    const eventsById = new Map(asArray(state?.events).map(event => [event.id, event]));
    const candidates = [];

    for (const event of asArray(state?.events)) {
        if (
            event?.publicity !== 'public'
            || (!event.publicSummary && !event.publicHeadline && !event.publicTrace && !event.publicResult)
        ) continue;

        const temporalState = eventTemporalState(event, now);
        if (temporalState === 'historical') continue;
        if (temporalState === 'upcoming' && !futurePlan) continue;

        const score = contextMatchScore(text, [
            event.place,
            event.title,
            event.publicHeadline,
            ...(event.actors || []),
        ]);
        if (score <= 0) continue;

        candidates.push({
            id: `event:${event.id}`,
            kind: 'public-event',
            temporalState,
            label: event.place || event.title || 'Sự kiện thế giới công khai',
            state: event.publicSummary || event.publicHeadline || event.publicTrace,
            publicity: 'public',
            eventId: event.id,
            score: score
                + (temporalState === 'current' ? 55 : 15)
                + Number(event.updatedAt || 0) / 1_000_000,
        });
    }

    for (const domain of asArray(state?.worldPulse?.domains)) {
        const score = contextMatchScore(text, [
            domain.scope,
            domain.label,
            domain.state,
        ]);
        if (score <= 0) continue;
        candidates.push({
            id: `pulse:${domain.id}`,
            kind: 'world-pulse',
            temporalState: 'current',
            label: domain.scope || domain.label || 'Môi trường thế giới',
            state: domain.state,
            publicity: domain.visibility === 'known' ? 'public' : 'world',
            eventId: '',
            score: score + 30 + Number(domain.pressure || 0) * 5,
        });
    }

    for (const fact of asArray(state?.worldFacts)) {
        if (fact?.confidence !== 'high') continue;
        // Person location/action/body/resource facts already have their own
        // authoritative character-state injection. The situational bridge is for
        // the surrounding world (place / organization / item / policy / consequence),
        // not a second copy of the person card.
        if (fact?.subjectType === 'person') continue;
        const event = fact.eventId ? eventsById.get(fact.eventId) : null;
        const factValidity = VALID_WORLD_FACT_VALIDITY.has(fact.validity)
            ? fact.validity
            : (event ? eventTemporalState(event, now) : 'current');
        const temporalState = factValidity === 'persistent' ? 'current' : factValidity;

        if (fact.eventId && String(fact.key || '').startsWith('public_event:')) continue;
        if (
            temporalState === 'historical'
            && !(event && textExplicitlyReferencesHistoricalEvent(text, event))
        ) continue;
        if (temporalState === 'upcoming' && !futurePlan) continue;

        const score = contextMatchScore(text, [
            fact.subject,
            fact.subjectId,
            fact.field,
            fact.value,
            event?.title,
            event?.publicHeadline,
        ]);
        if (score <= 0) continue;

        candidates.push({
            id: `fact:${fact.key}`,
            kind: 'world-fact',
            temporalState,
            label: fact.subject || fact.subjectId || 'Thế giới',
            state: `${fact.field}：${fact.value}`,
            publicity: fact.visibility === 'known' || fact.visibility === 'direct'
                ? 'public-or-known'
                : 'world',
            eventId: fact.eventId || '',
            score: score
                + (temporalState === 'current' ? 30 : temporalState === 'upcoming' ? 5 : -35)
                + Number(fact.updatedAt || 0) / 1_000_000,
        });
    }

    const seenKeys = new Set();
    const seenEventIds = new Set();
    return candidates
        .sort((a, b) => b.score - a.score)
        .filter(item => {
            if (item.eventId) {
                if (seenEventIds.has(item.eventId)) return false;
                seenEventIds.add(item.eventId);
            }
            const key = `${item.label}\u0000${item.state}`;
            if (seenKeys.has(key)) return false;
            seenKeys.add(key);
            return true;
        })
        .slice(0, Math.max(0, Number(maximum) || 0));
}

function selectRelevantWorldFacts(state, recentText = '', maximum = 12) {
    const text = String(recentText || '').toLocaleLowerCase();
    const eventsById = new Map(asArray(state?.events).map(event => [event.id, event]));
    return asArray(state?.worldFacts)
        .filter(fact => {
            if (String(fact?.key || '').startsWith('public_event:')) return false;
            const event = fact?.eventId ? eventsById.get(fact.eventId) : null;
            const validity = VALID_WORLD_FACT_VALIDITY.has(fact?.validity)
                ? fact.validity
                : 'current';
            if (
                validity === 'historical'
                && !(event && textExplicitlyReferencesHistoricalEvent(text, event))
            ) return false;
            if (validity === 'upcoming' && !textSuggestsFuturePlan(text)) return false;
            return true;
        })
        .map(fact => {
            const terms = [fact.subject, fact.subjectId, fact.field, fact.value]
                .filter(Boolean)
                .map(value => String(value).toLocaleLowerCase());
            let score = Number(fact.updatedAt || fact.settledAt || 0) / 1_000_000;
            if (terms.some(term => term.length >= 2 && text.includes(term))) score += 120;
            if (fact.source === 'narrative') score += 25;
            if (fact.source === 'event-settlement') score += 20;
            if (fact.confidence === 'high') score += 8;
            return { fact, score };
        })
        .sort((a, b) => b.score - a.score)
        .slice(0, Math.max(0, maximum))
        .map(item => item.fact);
}

export function createInitialState({
    worldName = 'Thế giới chưa đặt tên',
    day = 1,
    hour = 8,
    minute = 0,
} = {}) {
    const absoluteMinute = (
        asInteger(day, 1, 0, 999999) * MINUTES_PER_DAY
        + asInteger(hour, 8, 0, 23) * 60
        + asInteger(minute, 0, 0, 59)
    );
    const absoluteDay = Math.floor(absoluteMinute / MINUTES_PER_DAY);
    const initialDate = sequentialCalendarDate(absoluteDay);

    return {
        schemaVersion: SCHEMA_VERSION,
        revision: 0,
        world: {
            name: asString(worldName, 'Thế giới chưa đặt tên', 80),
            title: 'Thế giới vẫn tiếp diễn ngoài ống kính',
            detail: 'Chưa hoàn tất lần suy diễn thế giới đầu tiên.',
            background: '',
            calendar: {
                name: 'Lịch thế giới chính',
                anchorAbsoluteDay: absoluteDay,
                anchorYear: initialDate.year,
                anchorMonth: initialDate.month,
                anchorDay: initialDate.day,
            },
        },
        clock: {
            absoluteMinute,
            lastCheckedAt: absoluteMinute,
            source: 'initial',
            reason: 'Thiết lập đồng hồ thế giới chính',
            anchored: false,
            precision: 'day',
            daypart: '',
        },
        people: [],
        events: [],
        echoes: [],
        archive: [],
        foregroundFacts: [],
        worldFacts: [],
        worldPulse: {
            baselineEstablished: false,
            lastSweepAt: absoluteMinute,
            coverage: normalizeWorldCoverage(null, absoluteMinute),
            domains: [],
        },
        publicImpactLedger: [],
        consistencyConflicts: [],
        needsReconciliation: false,
        lastTimeResolution: null,
        nextTurnInjection: {
            requiredRefs: [],
            conditionalRefs: [],
            suppressRefs: [],
            reason: '',
            sourceRevision: 0,
        },
        storyMemory: {
            indexedThroughMessageId: -1,
            indexedAt: '',
            digest: {
                text: '',
                throughMessageId: -1,
                people: [],
                locations: [],
                tags: [],
                updatedAt: 0,
            },
            facts: [],
            summaries: [],
            clues: [],
            metabolismLog: [],
            lastMetabolismMessageId: -1,
        },
        audit: [],
        pendingSync: false,
        lastCommit: null,
        updatedAt: nowIso(),
    };
}

function normalizeStorySummary(raw, existing = null) {
    const startMessageId = asInteger(
        raw?.start_message_id ?? raw?.startMessageId,
        existing?.startMessageId ?? 0,
        0,
    );
    const endMessageId = asInteger(
        raw?.end_message_id ?? raw?.endMessageId,
        existing?.endMessageId ?? startMessageId,
        startMessageId,
    );
    const summary = asString(raw?.summary, existing?.summary || '', 1800);
    const level = asInteger(
        raw?.level ?? raw?.memory_level ?? raw?.memoryLevel,
        existing?.level ?? MEMORY_SUMMARY_LEVELS.STAGE,
        MEMORY_SUMMARY_LEVELS.DETAIL,
        MEMORY_SUMMARY_LEVELS.LONG_TERM,
    );
    return {
        id: normalizeId(
            raw?.id || existing?.id || `summary_${startMessageId}_${endMessageId}`,
            'summary',
        ),
        title: asString(raw?.title, existing?.title || `# ${startMessageId}—${endMessageId} tầng`, 120),
        summary,
        level,
        hierarchyManaged: Boolean(
            raw?.hierarchy_managed
            ?? raw?.hierarchyManaged
            ?? existing?.hierarchyManaged
            ?? false
        ),
        parentId: asString(
            raw?.parent_id ?? raw?.parentId,
            existing?.parentId || '',
            120,
        ),
        sourceSummaryIds: uniqueStrings(
            raw?.source_summary_ids ?? raw?.sourceSummaryIds ?? existing?.sourceSummaryIds,
            24,
        ),
        startMessageId,
        endMessageId,
        people: uniqueStrings(raw?.people ?? existing?.people, 20),
        locations: uniqueStrings(raw?.locations ?? existing?.locations, 16),
        tags: uniqueStrings(raw?.tags ?? existing?.tags, 20),
        locked: Boolean(raw?.locked ?? existing?.locked),
        important: Boolean(raw?.important ?? existing?.important),
        manual: Boolean(raw?.manual ?? existing?.manual),
        retentionState: ['active', 'compacted'].includes(raw?.retention_state ?? raw?.retentionState)
            ? (raw?.retention_state ?? raw?.retentionState)
            : (existing?.retentionState || 'active'),
        compactedReason: asString(
            raw?.compacted_reason ?? raw?.compactedReason,
            existing?.compactedReason || '',
            260,
        ),
        createdAt: asString(raw?.created_at ?? raw?.createdAt, existing?.createdAt || nowIso(), 40),
    };
}

function normalizeClue(raw, existing = null, worldMinute = 0, {
    sourceMessageId = null,
    sourceSwipeId = null,
} = {}) {
    const text = asString(raw?.text, existing?.text || '', 620);
    const clueId = raw?.id
        || existing?.id
        || (text ? `clue_${hashText(text)}` : '');
    const requestedStatus = asString(raw?.status, existing?.status || 'open', 20);
    return {
        id: normalizeId(clueId, 'clue'),
        title: asString(raw?.title, existing?.title || text.slice(0, 48) || 'Phục bút chưa đặt tên', 120),
        text,
        sourceMessageId: asInteger(
            raw?.source_message_id ?? raw?.sourceMessageId,
            existing?.sourceMessageId ?? sourceMessageId ?? 0,
            0,
        ),
        sourceSwipeId: asInteger(
            raw?.source_swipe_id ?? raw?.sourceSwipeId,
            existing?.sourceSwipeId ?? sourceSwipeId ?? 0,
            0,
        ),
        sourceExcerpt: asString(
            raw?.source_excerpt ?? raw?.sourceExcerpt,
            existing?.sourceExcerpt || '',
            220,
        ),
        people: uniqueStrings(raw?.people ?? existing?.people, 16),
        locations: uniqueStrings(raw?.locations ?? existing?.locations, 12),
        events: uniqueStrings(raw?.events ?? existing?.events, 16),
        tags: uniqueStrings(raw?.tags ?? existing?.tags, 20),
        archived: Boolean(raw?.archived ?? existing?.archived),
        archivedAt: raw?.archived_at ?? raw?.archivedAt
            ?? existing?.archivedAt
            ?? null,
        locked: Boolean(raw?.locked ?? existing?.locked),
        important: Boolean(raw?.important ?? existing?.important),
        manual: Boolean(raw?.manual ?? existing?.manual),
        status: VALID_CLUE_STATES.has(requestedStatus) ? requestedStatus : 'open',
        importance: asInteger(raw?.importance, existing?.importance ?? 1, 1, 3),
        visibility: normalizeVisibility(raw?.visibility ?? existing?.visibility ?? 'hidden'),
        resolution: asString(raw?.resolution, existing?.resolution || '', 520),
        lifecycleReason: asString(
            raw?.lifecycle_reason ?? raw?.lifecycleReason,
            existing?.lifecycleReason || '',
            360,
        ),
        resolvedMessageId: raw?.resolved_message_id ?? raw?.resolvedMessageId
            ?? existing?.resolvedMessageId
            ?? null,
        timing: normalizeClueTiming(
            raw?.timing ?? existing?.timing,
            worldMinute,
        ),
        createdAt: asInteger(raw?.created_at ?? raw?.createdAt, existing?.createdAt ?? worldMinute, 0),
        updatedAt: asInteger(raw?.updated_at ?? raw?.updatedAt, worldMinute, 0),
    };
}

function normalizeMemoryDigest(raw, existing = null, worldMinute = 0) {
    return {
        text: asString(raw?.text, existing?.text || '', LIMITS.memoryDigest),
        throughMessageId: asInteger(
            raw?.through_message_id ?? raw?.throughMessageId,
            existing?.throughMessageId ?? -1,
            -1,
        ),
        people: uniqueStrings(raw?.people ?? existing?.people, 32),
        locations: uniqueStrings(raw?.locations ?? existing?.locations, 24),
        tags: uniqueStrings(raw?.tags ?? existing?.tags, 32),
        updatedAt: asInteger(
            raw?.updated_at ?? raw?.updatedAt,
            existing?.updatedAt ?? worldMinute,
            0,
        ),
    };
}

function normalizeMemoryFact(raw, existing = null, worldMinute = 0, {
    sourceMessageId = null,
    sourceSwipeId = null,
} = {}) {
    const subject = asString(raw?.subject, existing?.subject || '', 100);
    const predicate = asString(raw?.predicate, existing?.predicate || '', 100);
    const value = asString(raw?.value, existing?.value || '', 520);
    const key = asString(
        raw?.key,
        existing?.key || [subject, predicate].filter(Boolean).join('：'),
        180,
    );
    const requestedStatus = asString(raw?.status, existing?.status || 'active', 20);
    const requestedConfidence = asString(
        raw?.confidence,
        existing?.confidence || 'high',
        20,
    );
    const factId = raw?.id
        || existing?.id
        || `memory_${hashText(`${key}\n${value}`)}`;
    return {
        id: normalizeId(factId, 'memory'),
        key,
        subject,
        predicate,
        value,
        sourceMessageId: asInteger(
            raw?.source_message_id ?? raw?.sourceMessageId,
            existing?.sourceMessageId ?? sourceMessageId ?? 0,
            0,
        ),
        sourceSwipeId: asInteger(
            raw?.source_swipe_id ?? raw?.sourceSwipeId,
            existing?.sourceSwipeId ?? sourceSwipeId ?? 0,
            0,
        ),
        sourceExcerpt: asString(
            raw?.source_excerpt ?? raw?.sourceExcerpt,
            existing?.sourceExcerpt || '',
            220,
        ),
        people: uniqueStrings(raw?.people ?? existing?.people, 20),
        locations: uniqueStrings(raw?.locations ?? existing?.locations, 16),
        tags: uniqueStrings(raw?.tags ?? existing?.tags, 24),
        locked: Boolean(raw?.locked ?? existing?.locked),
        important: Boolean(raw?.important ?? existing?.important),
        manual: Boolean(raw?.manual ?? existing?.manual),
        status: VALID_MEMORY_FACT_STATES.has(requestedStatus) ? requestedStatus : 'active',
        confidence: VALID_MEMORY_CONFIDENCE.has(requestedConfidence)
            ? requestedConfidence
            : 'medium',
        importance: asInteger(raw?.importance, existing?.importance ?? 2, 1, 3),
        visibility: normalizeVisibility(raw?.visibility ?? existing?.visibility ?? 'known'),
        supersedes: uniqueStrings(raw?.supersedes ?? existing?.supersedes, 12),
        supersededBy: asString(
            raw?.superseded_by ?? raw?.supersededBy,
            existing?.supersededBy || '',
            100,
        ),
        invalidationReason: asString(
            raw?.invalidation_reason ?? raw?.invalidationReason,
            existing?.invalidationReason || '',
            360,
        ),
        createdAt: asInteger(raw?.created_at ?? raw?.createdAt, existing?.createdAt ?? worldMinute, 0),
        updatedAt: asInteger(raw?.updated_at ?? raw?.updatedAt, worldMinute, 0),
    };
}

function retainMemoryFacts(items) {
    const normalized = asArray(items);
    // Manual/locked facts are user-authored authority and may only overflow the soft cap
    // in the pathological case where the user explicitly locks more than the whole pool.
    const hardProtected = normalized.filter(item => item?.locked || item?.manual);
    const hardIds = new Set(hardProtected.map(item => item.id));
    const statusWeight = value => ({ active: 4, disputed: 3, superseded: 1, invalidated: 0 }[value] ?? 0);
    const confidenceWeight = value => ({ high: 3, medium: 2, low: 0 }[value] ?? 1);
    const softProtectedWeight = item => (
        item?.important
        || Number(item?.importance || 0) >= 3
        || item?.status === 'disputed'
    ) ? 1 : 0;
    const ranked = normalized
        .filter(item => !hardIds.has(item.id))
        .sort((a, b) => (
            softProtectedWeight(b) - softProtectedWeight(a)
            || statusWeight(b.status) - statusWeight(a.status)
            || Number(b.importance || 0) - Number(a.importance || 0)
            || confidenceWeight(b.confidence) - confidenceWeight(a.confidence)
            || Number(b.updatedAt || 0) - Number(a.updatedAt || 0)
        ));
    const remainingSlots = Math.max(0, LIMITS.memoryFacts - hardProtected.length);
    return [...hardProtected, ...ranked.slice(0, remainingSlots)]
        .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
}
function retainStorySummaries(items) {
    const chronological = asArray(items)
        .sort((a, b) => Number(a.endMessageId || 0) - Number(b.endMessageId || 0));
    if (!chronological.length) return chronological;

    // Memory is allowed to forget low-value detail after it has been safely rolled
    // into a higher layer.  We keep the recent detail window, the story opening,
    // manually protected items and all chapter/long-term summaries.  Older compacted
    // L0/L1 nodes may leave the active store; their parent summaries still retain the
    // covered message range, so the original chat remains traceable without keeping
    // every intermediate summary forever.
    const latestMessageId = Number(chronological.at(-1)?.endMessageId || 0);
    const recentFloor = Math.max(0, latestMessageId - 480);
    const protectedIds = new Set();
    const protect = item => {
        if (item?.id) protectedIds.add(item.id);
    };

    for (const item of chronological) {
        const level = Number(item?.level || 0);
        const recent = Number(item?.endMessageId || 0) >= recentFloor;
        const activeUnrolled = !item?.parentId && item?.retentionState !== 'compacted';
        if (
            item?.locked
            || item?.important
            || item?.manual
            || level >= MEMORY_SUMMARY_LEVELS.CHAPTER
            || activeUnrolled
            || recent
        ) {
            protect(item);
        }
    }
    // A tiny amount of opening detail is intentionally kept as a durable story anchor.
    chronological.slice(0, 12).forEach(protect);

    const keep = new Map();
    for (const item of chronological) {
        if (protectedIds.has(item.id)) keep.set(item.id, item);
    }

    // Fill any remaining room with the newest useful summaries, but compacted old
    // details lose to active/higher-level memory.  This makes LIMITS.storySummaries a
    // real upper bound in ordinary cases instead of a pool that can grow forever.
    const candidates = chronological
        .filter(item => !keep.has(item.id) && item?.retentionState !== 'compacted')
        .sort((a, b) => (
            Number(b.level || 0) - Number(a.level || 0)
            || Number(b.endMessageId || 0) - Number(a.endMessageId || 0)
        ));
    for (const item of candidates) {
        if (keep.size >= LIMITS.storySummaries) break;
        keep.set(item.id, item);
    }

    return [...keep.values()]
        .sort((a, b) => Number(a.endMessageId || 0) - Number(b.endMessageId || 0));
}

function retainClues(items) {
    const normalized = asArray(items);
    const hardProtected = normalized.filter(item => item?.locked || item?.manual);
    const hardIds = new Set(hardProtected.map(item => item.id));
    const activeWeight = item => (
        item?.important || Number(item?.importance || 0) >= 3 || ['open', 'developing', 'echoed', 'triggered'].includes(item?.status)
    ) ? 1 : 0;
    const ranked = normalized
        .filter(item => !hardIds.has(item.id))
        .sort((a, b) => (
            activeWeight(b) - activeWeight(a)
            || Number(b.importance || 0) - Number(a.importance || 0)
            || Number(b.updatedAt || 0) - Number(a.updatedAt || 0)
        ));
    const remainingSlots = Math.max(0, LIMITS.clues - hardProtected.length);
    return [...hardProtected, ...ranked.slice(0, remainingSlots)]
        .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
}
function normalizeStoryMemory(raw, worldMinute = 0) {
    const summaries = asArray(raw?.summaries)
        .map(summary => normalizeStorySummary(summary))
        .filter(summary => summary.summary);
    const clueMap = new Map();
    for (const clue of asArray(raw?.clues)) {
        const normalized = normalizeClue(clue, clue, worldMinute);
        if (!normalized.text) continue;
        clueMap.set(normalized.id, normalized);
    }
    const factMap = new Map();
    for (const fact of asArray(raw?.facts)) {
        const normalized = normalizeMemoryFact(fact, fact, worldMinute);
        if (!normalized.key || !normalized.value) continue;
        factMap.set(normalized.id, normalized);
    }
    return {
        indexedThroughMessageId: asInteger(
            raw?.indexedThroughMessageId ?? raw?.indexed_through_message_id,
            -1,
            -1,
        ),
        indexedAt: asString(raw?.indexedAt ?? raw?.indexed_at, '', 40),
        digest: normalizeMemoryDigest(raw?.digest, null, worldMinute),
        // Storage capacity and per-turn recall are intentionally separate.
        // Keep locked/important/open anchors even when the soft pool is full;
        // selectRelevantStoryMemory still injects only a small relevant subset.
        facts: retainMemoryFacts([...factMap.values()]),
        summaries: retainStorySummaries(summaries),
        clues: retainClues([...clueMap.values()]),
        metabolismLog: asArray(raw?.metabolismLog ?? raw?.metabolism_log)
            .slice(-LIMITS.metabolismLog)
            .map(item => ({
                id: asString(item?.id, makeId('metabolism'), 100),
                kind: asString(item?.kind, 'memory', 30),
                action: asString(item?.action, 'updated', 30),
                targetId: asString(item?.targetId ?? item?.target_id, '', 120),
                replacementId: asString(item?.replacementId ?? item?.replacement_id, '', 120),
                reason: asString(item?.reason, '', 360),
                sourceMessageId: asInteger(item?.sourceMessageId ?? item?.source_message_id, 0, 0),
                worldMinute: asInteger(item?.worldMinute ?? item?.world_minute, worldMinute, 0),
                createdAt: asString(item?.createdAt ?? item?.created_at, nowIso(), 40),
            })),
        lastMetabolismMessageId: asInteger(
            raw?.lastMetabolismMessageId ?? raw?.last_metabolism_message_id,
            -1,
            -1,
        ),
    };
}

function normalizeFactBeliefs(value, fallback = []) {
    const byKey = new Map();
    for (const raw of [...asArray(fallback), ...asArray(value)]) {
        const key = asString(raw?.key, '', 180);
        const valueText = asString(raw?.value, '', 520);
        if (!key || !valueText) continue;
        const route = asString(raw?.route, '', 40);
        const certaintyRaw = asString(raw?.certainty, '', 20);
        byKey.set(key, {
            key,
            value: valueText,
            factId: asString(raw?.fact_id ?? raw?.factId, '', 120),
            certainty: VALID_KNOWLEDGE_CERTAINTY.has(certaintyRaw)
                ? certaintyRaw
                : 'confirmed',
            route: VALID_KNOWLEDGE_ROUTES.has(route) ? route : '',
            evidence: asString(raw?.evidence, '', 360),
            learnedAtMessageId: asInteger(raw?.learned_at_message_id ?? raw?.learnedAtMessageId, 0, 0),
            updatedAt: asInteger(raw?.updated_at ?? raw?.updatedAt, 0, 0),
        });
    }
    return [...byKey.values()].slice(-LIMITS.cognitiveRefs);
}


function normalizeKnownEventViews(value, fallback = []) {
    const byEvent = new Map();
    for (const raw of [...asArray(fallback), ...asArray(value)]) {
        const eventId = asString(raw?.event_id ?? raw?.eventId ?? raw?.id, '', 120);
        const summary = asString(raw?.summary ?? raw?.view ?? raw?.belief, '', 520);
        if (!eventId || !summary) continue;
        const route = asString(raw?.route, '', 40);
        const certaintyRaw = asString(raw?.certainty, '', 20);
        byEvent.set(eventId, {
            eventId,
            summary,
            certainty: VALID_KNOWLEDGE_CERTAINTY.has(certaintyRaw)
                ? certaintyRaw
                : 'confirmed',
            route: VALID_KNOWLEDGE_ROUTES.has(route) ? route : '',
            evidence: asString(raw?.evidence, '', 360),
            learnedAtMessageId: asInteger(
                raw?.learned_at_message_id ?? raw?.learnedAtMessageId,
                0,
                0,
            ),
            updatedAt: asInteger(raw?.updated_at ?? raw?.updatedAt, 0, 0),
        });
    }
    return [...byEvent.values()].slice(-LIMITS.cognitiveRefs);
}

function normalizeKnowledgeAcquisitions(value, messageId = 0) {
    return asArray(value)
        .map(raw => {
            const kind = asString(raw?.kind, '', 20).toLowerCase();
            const ref = asString(
                raw?.ref ?? raw?.ref_id ?? raw?.refId ?? raw?.key ?? raw?.event_id ?? raw?.eventId ?? raw?.clue_id ?? raw?.clueId,
                '',
                180,
            );
            const route = asString(raw?.route, '', 40).toLowerCase();
            const certaintyRaw = asString(raw?.certainty, '', 20).toLowerCase();
            const certainty = route === 'inferred'
                ? 'suspected'
                : (VALID_KNOWLEDGE_CERTAINTY.has(certaintyRaw) ? certaintyRaw : 'confirmed');
            if (!['event', 'fact', 'clue'].includes(kind)) return null;
            if (!ref || !VALID_KNOWLEDGE_ROUTES.has(route)) return null;
            const evidence = asString(raw?.evidence, '', 360);
            if (!evidence) return null;
            return {
                kind,
                ref,
                route,
                certainty,
                evidence,
                belief: asString(raw?.belief ?? raw?.view ?? raw?.summary, '', 520),
                sourceEventId: asString(raw?.source_event_id ?? raw?.sourceEventId, '', 120),
                learnedAtMessageId: asInteger(
                    raw?.learned_at_message_id ?? raw?.learnedAtMessageId,
                    messageId,
                    0,
                ),
            };
        })
        .filter(Boolean)
        .slice(0, LIMITS.cognitiveRefs);
}

function activeFactByKey(state, key) {
    const normalized = asString(key, '', 180);
    if (!normalized) return null;
    return asArray(state?.storyMemory?.facts)
        .filter(fact => fact.key === normalized && ['active', 'disputed'].includes(fact.status))
        .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0))[0] || null;
}

function setFactBelief(person, fact, messageId = 0, {
    value = fact?.value,
    certainty = 'confirmed',
    route = '',
    evidence = '',
} = {}) {
    if (!person || !fact?.key || !value) return;
    const beliefs = normalizeFactBeliefs(person.knownFactBeliefs);
    const next = {
        key: fact.key,
        value: asString(value, fact.value, 520),
        factId: fact.id || '',
        certainty: VALID_KNOWLEDGE_CERTAINTY.has(certainty) ? certainty : 'confirmed',
        route: VALID_KNOWLEDGE_ROUTES.has(route) ? route : '',
        evidence: asString(evidence, '', 360),
        learnedAtMessageId: asInteger(messageId, 0, 0),
        updatedAt: asInteger(fact.updatedAt, 0, 0),
    };
    const index = beliefs.findIndex(item => item.key === next.key);
    if (index >= 0) beliefs[index] = next;
    else beliefs.push(next);
    person.knownFactBeliefs = beliefs.slice(-LIMITS.cognitiveRefs);
}

function freezeKnownFactBeforeChange(state, fact) {
    if (!fact?.key || !fact?.value) return;
    for (const person of asArray(state?.people)) {
        const knowsKey = asArray(person?.knownFactKeys).some(key => (
            normalizedReference(key) === normalizedReference(fact.key)
        ));
        if (!knowsKey) continue;
        const hasSnapshot = asArray(person?.knownFactBeliefs).some(item => (
            normalizedReference(item?.key) === normalizedReference(fact.key)
        ));
        if (!hasSnapshot) setFactBelief(person, fact, person?.lastSeenMessageId || fact.sourceMessageId || 0);
    }
}

function isUserPersonLike(person, userName = '') {
    const normalizedUserName = asString(userName, '', 80).toLocaleLowerCase();
    const name = asString(person?.name, '', 80).toLocaleLowerCase();
    return Boolean(
        person?.isUser
        || person?.is_user
        || person?.role === 'user'
        || (normalizedUserName && name && normalizedUserName === name)
    );
}

function normalizePerson(raw, existing = null, worldMinute = 0, {
    userName = '',
    allowUserInnerVoice = true,
    sourceMessageId = null,
} = {}) {
    const name = asString(raw?.name, existing?.name || 'Nhân vật chưa đặt tên', 80);
    const innerVoice = asString(raw?.inner_voice ?? raw?.innerVoice, '', LIMITS.innerVoice);
    const hasNewInnerVoice = Boolean(innerVoice);
    const longTermGoal = asString(
        raw?.long_term_goal ?? raw?.longTermGoal,
        '',
        LIMITS.longTermGoal,
    );
    // These are author-owned character anchors. A routine simulation may use
    // them as constraints, but must never silently rewrite an existing card.
    const { identityAnchor, personalityAnchor, appearanceProfile, backgroundProfile, abilityProfile, speakingStyle, behaviorBoundaries } = readCharacterProfile(raw, existing);
    const provenance = readWorldbookProvenance(raw, existing);
    const worldbookRaw = provenance.worldbookRaw;
    const suppliedInnerVoiceAt = raw?.inner_voice_at ?? raw?.innerVoiceAt;
    const suppliedLastSeen = raw?.last_seen_message_id ?? raw?.lastSeenMessageId;
    const presentInScene = raw?.present_in_scene ?? raw?.presentInScene;
    const suppliedLastSeenNumber = Number(suppliedLastSeen);
    const hasSuppliedLastSeen = (
        suppliedLastSeen !== null
        && suppliedLastSeen !== undefined
        && suppliedLastSeen !== ''
        && Number.isInteger(suppliedLastSeenNumber)
        && !(
            suppliedLastSeenNumber === 0
            && Number.isInteger(Number(sourceMessageId))
            && Number(sourceMessageId) > 0
        )
    );
    const isUser = Boolean(
        isUserPersonLike(raw, userName)
        || isUserPersonLike(existing, userName)
    );
    const storedInnerVoice = isUser && !allowUserInnerVoice
        ? ''
        : asString(existing?.innerVoice, '', LIMITS.innerVoice);

    return {
        id: normalizeId(raw?.id || existing?.id || name, 'person'),
        name,
        isUser,
        monogram: asString(raw?.monogram, existing?.monogram || name.slice(0, 1), 4),
        // 头像是纯 UI 资源，不进入模型上下文。已有头像优先，避免后台推演误改。
        avatarDataUrl: asString(
            existing?.avatarDataUrl ?? raw?.avatar_data_url ?? raw?.avatarDataUrl,
            '',
            LIMITS.personAvatarData,
        ),
        location: asString(raw?.location, existing?.location || 'Vị trí chờ xác nhận', 160),
        action: asString(raw?.action, existing?.action || 'Hành động hiện tại chờ xác nhận', 280),
        intent: asString(raw?.intent, existing?.intent || 'Ý định ngắn hạn chờ xác nhận', 320),
        longTermGoal: longTermGoal || asString(existing?.longTermGoal, '', LIMITS.longTermGoal),
        identityAnchor,
        personalityAnchor,
        appearanceProfile,
        backgroundProfile,
        abilityProfile,
        ...provenance,
        worldbookRaw,
        speakingStyle,
        behaviorBoundaries,
        simulationEnabled: Boolean(
            raw?.simulation_enabled
            ?? raw?.simulationEnabled
            ?? existing?.simulationEnabled
            ?? true,
        ),
        locked: Boolean(raw?.locked ?? existing?.locked),
        manual: Boolean(raw?.manual ?? existing?.manual),
        trace: asString(raw?.trace, existing?.trace || '', 360),
        innerVoice: storedInnerVoice,
        innerVoiceAt: isUser && !allowUserInnerVoice
            ? worldMinute
            : asInteger(existing?.innerVoiceAt, worldMinute, 0),
        knowledge: normalizeKnowledge(raw?.knowledge ?? existing?.knowledge),
        cognitionReady: Boolean(
            raw?.cognition_ready
            ?? raw?.cognitionReady
            ?? existing?.cognitionReady
            ?? false,
        ),
        // Direct model writes to known_* are deliberately ignored.
        // New cognition must pass through validated knowledge_updates.
        knownEventIds: uniqueStrings(existing?.knownEventIds, LIMITS.cognitiveRefs),
        knownEventViews: normalizeKnownEventViews(existing?.knownEventViews),
        knownFactKeys: uniqueStrings(existing?.knownFactKeys, LIMITS.cognitiveRefs),
        knownFactBeliefs: normalizeFactBeliefs(existing?.knownFactBeliefs),
        knownClueIds: uniqueStrings(existing?.knownClueIds, LIMITS.cognitiveRefs),
        physicalState: asString(
            raw?.physical_state ?? raw?.physicalState ?? existing?.physicalState,
            '',
            LIMITS.personState,
        ),
        emotionalState: asString(
            raw?.emotional_state ?? raw?.emotionalState ?? existing?.emotionalState,
            '',
            LIMITS.personState,
        ),
        resourceState: asString(
            raw?.resource_state ?? raw?.resourceState ?? existing?.resourceState,
            '',
            LIMITS.personState,
        ),
        relevance: asInteger(raw?.relevance, existing?.relevance ?? 1, 0, 3),
        source: ['foreground', 'background', 'manual'].includes(raw?.source)
            ? raw.source
            : (existing?.source || 'background'),
        worldbookRef: asString(
            existing?.worldbookRef ?? raw?.worldbookRef ?? raw?.worldbook_ref,
            '',
            180,
        ),
        lastSeenMessageId: hasSuppliedLastSeen
            ? suppliedLastSeenNumber
            : (
                raw?.source === 'foreground'
                && Number.isInteger(Number(sourceMessageId))
            )
                ? Number(sourceMessageId)
                : asInteger(existing?.lastSeenMessageId, -1, -1),
        presentInSceneMessageId: presentInScene === true
            && Number.isInteger(Number(sourceMessageId))
            ? Number(sourceMessageId)
            : asInteger(existing?.presentInSceneMessageId, -1, -1),
        lastLifeTickAt: asInteger(
            raw?.last_life_tick_at
            ?? raw?.lastLifeTickAt
            ?? existing?.lastLifeTickAt
            ?? existing?.updatedAt,
            worldMinute,
            0,
        ),
        // 用户可以把某个后台人物明确排到“下一轮优先”。这是调度标记，
        // 不是世界事实，也不会进入人物设定；成功完成该人物的生活结算后会自动清掉。
        lifeTickPriority: Boolean(
            raw?.life_tick_priority
            ?? raw?.lifeTickPriority
            ?? existing?.lifeTickPriority
            ?? false,
        ),
        lifeTickPriorityAt: asInteger(
            raw?.life_tick_priority_at
            ?? raw?.lifeTickPriorityAt
            ?? existing?.lifeTickPriorityAt,
            0,
            0,
        ),
        updatedAt: asInteger(raw?.updated_at ?? raw?.updatedAt, worldMinute, 0),
    };
}

export function normalizeEvent(raw, worldMinute = 0, existing = null) {
    const clockMode = normalizeClockMode(raw?.clock_mode ?? raw?.clockMode ?? existing?.clockMode);
    const startedAt = asInteger(
        raw?.started_at ?? raw?.startedAt,
        existing?.startedAt ?? worldMinute,
        0,
    );
    const durationMinutes = asInteger(
        raw?.duration_minutes ?? raw?.durationMinutes,
        existing?.durationMinutes ?? 0,
        0,
        5 * 365 * MINUTES_PER_DAY,
    );
    let dueAt = raw?.scheduled_at ?? raw?.due_at ?? raw?.dueAt;
    dueAt = Number.isFinite(Number(dueAt))
        ? asInteger(dueAt, 0, 0)
        : (existing?.dueAt ?? null);

    if (dueAt === null && clockMode === 'duration' && durationMinutes > 0) {
        dueAt = startedAt + durationMinutes;
    }

    const status = normalizeEventStatus(raw?.status ?? existing?.status);
    const visibility = normalizeVisibility(raw?.visibility ?? existing?.visibility);
    const publicity = normalizeEventPublicity(
        raw?.publicity ?? raw?.public_scope ?? raw?.publicScope,
        inferLegacyEventPublicity(raw, existing),
    );
    const oldDelivery = existing?.delivery || {};
    const requestedDeliveryState = asString(raw?.delivery_state, oldDelivery.state || '', 30);
    const defaultDeliveryState = TERMINAL_EVENT_STATES.has(status) && visibility !== 'hidden'
        ? 'pending'
        : 'none';
    const deliveryState = ['none', 'pending', 'delivered', 'expired'].includes(requestedDeliveryState)
        ? requestedDeliveryState
        : (oldDelivery.state || defaultDeliveryState);

    return {
        // Event identity is immutable once the event already exists. Model output may
        // accidentally return an events_create item with a fresh id for the same
        // ongoing event; when we merge into an existing record, never let that new
        // id replace the canonical one.
        id: normalizeId(existing?.id || raw?.id, 'event'),
        title: asString(raw?.title, existing?.title || 'Sự kiện chưa đặt tên', 140),
        place: asString(raw?.place, existing?.place || 'Địa điểm chờ xác nhận', 140),
        summary: asString(raw?.summary, existing?.summary || '', 420),
        consequence: asString(raw?.consequence, existing?.consequence || '', 420),
        expectedResult: asString(
            raw?.expected_result ?? raw?.expectedResult,
            existing?.expectedResult || '',
            420,
        ),
        result: asString(raw?.result, existing?.result || '', 520),
        status,
        clockMode,
        startedAt,
        dueAt,
        durationMinutes,
        accruedMinutes: asInteger(
            raw?.accrued_minutes ?? raw?.accruedMinutes,
            existing?.accruedMinutes ?? 0,
            0,
            5 * 365 * MINUTES_PER_DAY,
        ),
        lastCheckedAt: asInteger(
            raw?.last_checked_at ?? raw?.lastCheckedAt,
            existing?.lastCheckedAt ?? worldMinute,
            0,
        ),
        prerequisites: uniqueStrings(raw?.prerequisites ?? existing?.prerequisites, 12),
        cause: asString(
            raw?.cause ?? existing?.cause,
            '',
            LIMITS.eventCause,
        ),
        actors: mergeUniqueStrings(existing?.actors, raw?.actors, 16),
        knownBy: mergeUniqueStrings(
            existing?.knownBy,
            raw?.known_by ?? raw?.knownBy,
            LIMITS.cognitiveRefs,
        ),
        causedBy: mergeUniqueStrings(
            existing?.causedBy,
            raw?.caused_by ?? raw?.causedBy,
            12,
        ),
        publicTrace: publicity === 'private'
            ? ''
            : asString(
                raw?.public_trace ?? raw?.publicTrace ?? existing?.publicTrace,
                '',
                LIMITS.eventPublicTrace,
            ),
        publicHeadline: publicity === 'public'
            ? asString(
                raw?.public_headline ?? raw?.publicHeadline ?? existing?.publicHeadline,
                '',
                180,
            )
            : '',
        publicSummary: publicity === 'public'
            ? asString(
                raw?.public_summary ?? raw?.publicSummary ?? existing?.publicSummary,
                '',
                520,
            )
            : '',
        publicResult: publicity === 'public'
            ? asString(
                raw?.public_result ?? raw?.publicResult ?? existing?.publicResult,
                '',
                520,
            )
            : '',
        publicity,
        visibility,
        delivery: {
            state: deliveryState,
            mode: ['event', 'soft-observation'].includes(
                raw?.delivery_mode ?? raw?.deliveryMode ?? oldDelivery.mode,
            )
                ? (raw?.delivery_mode ?? raw?.deliveryMode ?? oldDelivery.mode)
                : 'event',
            manualQueued: Boolean(
                raw?.delivery_queued
                ?? raw?.deliveryQueued
                ?? oldDelivery.manualQueued,
            ),
            attempts: asInteger(oldDelivery.attempts, 0, 0, 99),
            route: asString(raw?.delivery_route, oldDelivery.route || '', 220),
            confirmedAt: oldDelivery.confirmedAt ?? null,
            confirmedMessageId: oldDelivery.confirmedMessageId ?? null,
            lastOfferedAt: oldDelivery.lastOfferedAt ?? null,
        },
        createdAt: existing?.createdAt ?? worldMinute,
        updatedAt: asInteger(
            raw?.updated_at ?? raw?.updatedAt,
            existing?.updatedAt ?? worldMinute,
            0,
        ),
        resolvedAt: TERMINAL_EVENT_STATES.has(status)
            ? (
                Number.isFinite(Number(raw?.resolved_at ?? raw?.resolvedAt))
                    ? asInteger(raw?.resolved_at ?? raw?.resolvedAt, worldMinute, 0)
                    : (
                        existing?.resolvedAt
                        ?? terminalResolutionMinute(
                            { clockMode, dueAt },
                            status,
                            worldMinute,
                        )
                    )
            )
            : null,
    };
}

export function eventProgress(event, worldMinute) {
    if (event?.status === 'ready' || TERMINAL_EVENT_STATES.has(event?.status)) {
        return {
            ratio: 1,
            percent: 100,
            remaining: 0,
        phase: event.status === 'ready' ? 'Đến hạn, chờ xác nhận' : 'Đã thành kết quả',
        };
    }

    if (event?.clockMode === 'condition') {
        return {
            ratio: null,
            percent: null,
            remaining: null,
            phase: 'Chờ điều kiện',
        };
    }

    if (event?.clockMode === 'active') {
        const duration = Math.max(1, Number(event.durationMinutes) || 1);
        const accrued = Math.max(0, Number(event.accruedMinutes) || 0);
        const ratio = clamp(accrued / duration, 0, 1);
        return {
            ratio,
            percent: Math.round(ratio * 100),
            remaining: Math.max(0, duration - accrued),
            phase: ratio >= 0.72 ? 'Sắp hoàn thành' : ratio >= 0.28 ? 'Đang phát triển' : 'Manh nha',
        };
    }

    const dueAt = Number(event?.dueAt);
    const startedAt = Number(event?.startedAt);
    if (!Number.isFinite(dueAt) || !Number.isFinite(startedAt) || dueAt <= startedAt) {
        return {
            ratio: null,
            percent: null,
            remaining: null,
            phase: event?.clockMode === 'scheduled' ? 'Chờ đến thời điểm' : 'Thời gian chờ xác nhận',
        };
    }

    const elapsed = Math.max(0, worldMinute - startedAt);
    const duration = dueAt - startedAt;
    const ratio = clamp(elapsed / duration, 0, 1);
    const remaining = Math.max(0, dueAt - worldMinute);
    let phase = ratio >= 0.72 ? 'Sắp hoàn thành' : ratio >= 0.28 ? 'Đang phát triển' : 'Manh nha';
    if (event.clockMode === 'scheduled') {
        phase = remaining <= 30 ? 'Đang đến gần' : 'Chờ đến thời điểm';
    }

    return {
        ratio,
        percent: Math.round(ratio * 100),
        remaining,
        phase,
    };
}

function appendAudit(state, entry) {
    state.audit.unshift({
        id: makeId('audit'),
        at: state.clock.absoluteMinute,
        createdAt: nowIso(),
        ...entry,
    });
    state.audit = state.audit.slice(0, LIMITS.audit);
}

export function settleTimedEvents(inputState, targetMinute, {
    source = 'world',
    reason = '',
} = {}) {
    const state = deepClone(inputState);
    const previousMinute = asInteger(state.clock?.absoluteMinute, 0, 0);
    const nextMinute = asInteger(targetMinute, previousMinute, 0);
    const previousStamp = formatWorldCalendar(state, previousMinute).stamp;

    state.clock = {
        ...state.clock,
        absoluteMinute: nextMinute,
        lastCheckedAt: nextMinute,
        source,
        reason: asString(reason, '', 240),
    };

    if (nextMinute >= previousMinute) {
        for (const event of state.events) {
            if (!ACTIVE_EVENT_STATES.has(event.status)) continue;
            event.lastCheckedAt = nextMinute;

            if (!['duration', 'scheduled'].includes(event.clockMode)) continue;
            if (!Number.isFinite(Number(event.dueAt))) continue;

            if (nextMinute >= Number(event.dueAt)) {
                event.status = 'ready';
                event.updatedAt = nextMinute;
                event.result = event.result || event.expectedResult || '';
            }
        }
    }

    if (nextMinute !== previousMinute) {
        appendAudit(state, {
            type: nextMinute > previousMinute ? 'clock_advanced' : 'clock_corrected',
            text: `${previousStamp} → ${formatWorldCalendar(state, nextMinute).stamp}`,
            reason: asString(reason, '', 240),
        });
    }

    state.revision = asInteger(state.revision, 0, 0) + 1;
    state.updatedAt = nowIso();
    return trimState(state);
}

function findPerson(state, raw) {
    const id = asString(raw?.id, '', 100);
    const name = asString(raw?.name, '', 80);
    return state.people.find(person => (id && person.id === normalizeId(id, 'person')) || (name && person.name === name));
}

function findEvent(state, raw) {
    const id = asString(raw?.id, '', 100);
    if (id) {
        const normalized = normalizeId(id, 'event');
        const byId = state.events.find(event => event.id === normalized);
        if (byId) return byId;
    }

    const title = asString(raw?.title, '', 140);
    const place = asString(raw?.place, '', 140);
    return state.events.find(event => (
        title
        && event.title === title
        && (!place || event.place === place)
        && !TERMINAL_EVENT_STATES.has(event.status)
    ));
}

function normalizedReference(value) {
    return asString(value, '', 120).toLocaleLowerCase();
}

function listReferencesPerson(value, person) {
    const id = normalizedReference(person?.id);
    const name = normalizedReference(person?.name);
    return asArray(value).some(item => {
        const ref = normalizedReference(item);
        return Boolean(ref && (ref === id || ref === name));
    });
}

function eventKnownToPerson(event, person) {
    const eventId = normalizedReference(event?.id);
    return asArray(person?.knownEventIds)
        .some(id => normalizedReference(id) === eventId);
}

function synchronizeCognitiveLedger(state) {
    // Person cognition is authoritative. event.knownBy is only a derived mirror for
    // compatibility/inspection; it can never grant knowledge back to a person.
    for (const event of asArray(state?.events)) {
        for (const person of asArray(state?.people)) {
            if (!eventKnownToPerson(event, person)) continue;
            event.knownBy = mergeUniqueStrings(
                event.knownBy,
                [person.id],
                LIMITS.cognitiveRefs,
            );
        }
    }
}

function terminalResolutionMinute(event, status, worldMinute, explicitMinute = null) {
    const hasExplicit = explicitMinute !== null
        && explicitMinute !== undefined
        && String(explicitMinute).trim() !== '';
    const explicit = hasExplicit ? Number(explicitMinute) : Number.NaN;
    if (Number.isFinite(explicit) && explicit >= 0) {
        return Math.min(asInteger(explicit, worldMinute, 0), worldMinute);
    }
    const dueAt = Number(event?.dueAt);
    if (
        ['resolved', 'missed'].includes(status)
        && ['duration', 'scheduled'].includes(event?.clockMode)
        && Number.isFinite(dueAt)
        && dueAt >= 0
        && dueAt <= worldMinute
    ) {
        return dueAt;
    }
    return worldMinute;
}

function markTerminal(event, status, worldMinute, result = '', explicitMinute = null) {
    const resolvedMinute = terminalResolutionMinute(event, status, worldMinute, explicitMinute);
    event.status = status;
    event.result = asString(result, event.result || event.expectedResult || '', 520);
    event.resolvedAt = resolvedMinute;
    event.updatedAt = Math.max(Number(event.updatedAt) || 0, resolvedMinute);
    if (event.visibility !== 'hidden' && event.delivery.state !== 'delivered') {
        event.delivery.state = 'pending';
    }
}

function findClue(memory, raw) {
    const id = asString(raw?.id ?? raw, '', 100);
    if (id) {
        const normalized = normalizeId(id, 'clue');
        const byId = memory.clues.find(clue => clue.id === normalized);
        if (byId) return byId;
    }
    const text = asString(raw?.text, '', 620);
    if (!text) return null;
    const fingerprint = text.replace(/\s+/g, '').slice(0, 80);
    return memory.clues.find(clue => (
        clue.text.replace(/\s+/g, '').slice(0, 80) === fingerprint
    )) || null;
}

function appendMemoryMetabolism(state, {
    kind = 'memory',
    action = 'updated',
    targetId = '',
    replacementId = '',
    reason = '',
    sourceMessageId = 0,
} = {}) {
    state.storyMemory ||= {};
    state.storyMemory.metabolismLog = asArray(state.storyMemory.metabolismLog);
    state.storyMemory.metabolismLog.push({
        id: makeId('metabolism'),
        kind: asString(kind, 'memory', 30),
        action: asString(action, 'updated', 30),
        targetId: asString(targetId, '', 120),
        replacementId: asString(replacementId, '', 120),
        reason: asString(reason, '', 360),
        sourceMessageId: asInteger(sourceMessageId, 0, 0),
        worldMinute: asInteger(state.clock?.absoluteMinute, 0, 0),
        createdAt: nowIso(),
    });
    state.storyMemory.metabolismLog = state.storyMemory.metabolismLog.slice(-LIMITS.metabolismLog);
    state.storyMemory.lastMetabolismMessageId = Math.max(
        Number(state.storyMemory.lastMetabolismMessageId ?? -1),
        asInteger(sourceMessageId, -1, -1),
    );
}

function compactRolledUpSources(state, parentSummary, sources, { sourceMessageId = 0 } = {}) {
    // Preserve the original opening exchange for later questions about first contact.
    // A higher-level rollup can omit one-off actions even when they define that scene.
    const openingIds = new Set(asArray(state?.storyMemory?.summaries)
        .filter(item => item.hierarchyManaged && !item.manual
            && Number(item.level) === MEMORY_SUMMARY_LEVELS.DETAIL)
        .sort((a, b) => Number(a.startMessageId) - Number(b.startMessageId))
        .slice(0, 2)
        .map(item => item.id));
    for (const source of sources) {
        if (openingIds.has(source.id)) continue;
        if (source.locked || source.important || source.manual) continue;
        if (asArray(source.tags).length) continue;
        // Exact agreements may never appear in a broader digest or fact ledger.
        if (/暗号|密码|口令|密语|编号|代号|约定|承诺|预约|期限|归还|转交|保管|password|passphrase|code word|promise|appointment|deadline|handover|custody|mật hiệu|ám hiệu|mật khẩu|khẩu lệnh|mật ngữ|mã số|số hiệu|mật danh|bí danh|giao ước|ước hẹn|hẹn ước|lời hứa|hứa hẹn|cam kết|hẹn trước|đặt lịch|thời hạn|hạn chót|trả lại|hoàn trả|chuyển giao|giao lại|bảo quản|cất giữ|giữ hộ/iu.test(source.summary)) continue;
        if (Number(source.level || 0) >= MEMORY_SUMMARY_LEVELS.CHAPTER) continue;
        if (source.retentionState === 'compacted') continue;
        source.retentionState = 'compacted';
        source.compactedReason = `Chi tiết đã được tóm lược bởi ${parentSummary.title || `L${parentSummary.level}`}; chính văn gốc vẫn có thể xem lại theo phạm vi tin nhắn.`;
        source.summary = `Chi tiết đã được đưa vào ký ức tầng trên; chính văn gốc xem tại tin nhắn ${source.startMessageId}—${source.endMessageId}。`;
        appendMemoryMetabolism(state, {
            kind: 'episode',
            action: 'compacted',
            targetId: source.id,
            replacementId: parentSummary.id,
            reason: source.compactedReason,
            sourceMessageId,
        });
    }
}

function findMemoryFact(memory, raw, {
    matchValue = true,
} = {}) {
    const id = asString(raw?.id ?? raw, '', 100);
    if (id) {
        const normalized = normalizeId(id, 'memory');
        const byId = memory.facts.find(fact => fact.id === normalized);
        if (byId) return byId;
    }
    const key = asString(raw?.key, '', 180);
    const value = asString(raw?.value, '', 520);
    if (!key) return null;
    return memory.facts.find(fact => (
        fact.key === key
        && (!matchValue || !value || fact.value === value)
    )) || null;
}

function applyMemoryFactUpdates(state, {
    factsUpsert = [],
    factsInvalidate = [],
} = {}, {
    sourceMessageId = null,
    sourceSwipeId = null,
} = {}) {
    state.storyMemory = normalizeStoryMemory(state.storyMemory, state.clock.absoluteMinute);
    const upsertedKeys = new Set(asArray(factsUpsert)
        .filter(fact => asString(fact?.key, '', 180) && asString(fact?.value, '', 520))
        .map(fact => asString(fact.key, '', 180)));
    for (const rawFact of asArray(factsUpsert).slice(0, 32)) {
        const prepared = normalizeMemoryFact(rawFact, null, state.clock.absoluteMinute, {
            sourceMessageId,
            sourceSwipeId,
        });
        if (!prepared.key || !prepared.value) continue;

        const sameCandidate = findMemoryFact(state.storyMemory, prepared);
        const same = sameCandidate?.value === prepared.value ? sameCandidate : null;
        if (same) {
            if (same.locked) continue;
            Object.assign(
                same,
                normalizeMemoryFact(rawFact, same, state.clock.absoluteMinute, {
                    sourceMessageId,
                    sourceSwipeId,
                }),
            );
            continue;
        }

        const conflicts = state.storyMemory.facts.filter(fact => (
            fact.key === prepared.key
            && fact.value !== prepared.value
            && ['active', 'disputed'].includes(fact.status)
        ));
        if (conflicts.some(fact => fact.locked)) prepared.status = 'disputed';
        if (conflicts.some(fact => fact.id === prepared.id)) {
            prepared.id = normalizeId(
                `${prepared.id}_${hashText(prepared.value)}`,
                'memory',
            );
        }

        if (prepared.status === 'disputed') {
            for (const conflict of conflicts) {
                if (conflict.locked) continue;
                conflict.status = 'disputed';
                conflict.updatedAt = state.clock.absoluteMinute;
            }
        } else {
            for (const conflict of conflicts) {
                if (conflict.locked) continue;
                freezeKnownFactBeforeChange(state, conflict);
                conflict.status = 'superseded';
                conflict.supersededBy = prepared.id;
                conflict.invalidationReason = `Đã bị sự thật sau đó “${prepared.value}” thay thế`;
                conflict.updatedAt = state.clock.absoluteMinute;
                appendMemoryMetabolism(state, {
                    kind: 'fact',
                    action: 'superseded',
                    targetId: conflict.id,
                    replacementId: prepared.id,
                    reason: conflict.invalidationReason,
                    sourceMessageId: sourceMessageId ?? prepared.sourceMessageId ?? 0,
                });
            }
            prepared.supersedes = uniqueStrings([
                ...prepared.supersedes,
                ...conflicts.filter(fact => !fact.locked).map(fact => fact.id),
            ], 12);
        }
        state.storyMemory.facts.unshift(prepared);
    }

    for (const rawInvalidation of asArray(factsInvalidate).slice(0, 32)) {
        const invalidation = typeof rawInvalidation === 'string'
            ? { id: rawInvalidation }
            : rawInvalidation;
        // A key-only cancellation can describe the old value while this batch
        // also writes its replacement. The upsert already supersedes the old fact.
        if (!invalidation?.id && !invalidation?.value
            && upsertedKeys.has(asString(invalidation?.key, '', 180))) continue;
        const fact = findMemoryFact(state.storyMemory, invalidation, { matchValue: false });
        if (!fact || fact.locked) continue;
        freezeKnownFactBeforeChange(state, fact);
        fact.status = 'invalidated';
        fact.invalidationReason = asString(
            invalidation?.reason ?? invalidation?.invalidation_reason,
            fact.invalidationReason || 'Đã bị chính văn sau đó phủ định',
            360,
        );
        fact.updatedAt = state.clock.absoluteMinute;
        appendMemoryMetabolism(state, {
            kind: 'fact',
            action: 'invalidated',
            targetId: fact.id,
            reason: fact.invalidationReason,
            sourceMessageId: sourceMessageId ?? fact.sourceMessageId ?? 0,
        });
    }
}

function applyClueUpdates(state, {
    cluesUpsert = [],
    cluesResolve = [],
} = {}, {
    sourceMessageId = null,
    sourceSwipeId = null,
} = {}) {
    state.storyMemory = normalizeStoryMemory(state.storyMemory, state.clock.absoluteMinute);

    const anchorTiming = (clue, { force = false } = {}) => {
        if (!clue) return;
        const currentMinute = state.clock?.absoluteMinute || 0;
        if (clue.timing && !force) {
            clue.timing = normalizeClueTiming(clue.timing, currentMinute);
            return;
        }
        const sourceText = [clue.sourceExcerpt, clue.text].filter(Boolean).join('\n');
        if (!sourceText) {
            clue.timing = null;
            return;
        }
        const baseMinute = asInteger(clue.createdAt, currentMinute, 0);
        clue.timing = resolveFutureTimeExpression(sourceText, {
            baseAbsoluteMinute: baseMinute,
            baseCalendar: formatWorldCalendar(state, baseMinute),
            calendarBound: Boolean(state.clock?.anchored),
        });
        if (clue.timing) clue.timing = normalizeClueTiming(clue.timing, currentMinute);
    };

    // Old saves may contain only natural-language clues. Anchor them from the
    // moment they were created; never reinterpret “后天” from today's clock.
    for (const clue of state.storyMemory.clues) anchorTiming(clue);

    for (const rawClue of asArray(cluesUpsert).slice(0, 24)) {
        const existing = findClue(state.storyMemory, rawClue);
        if (existing?.locked) continue;
        const previousText = existing?.text || '';
        const previousExcerpt = existing?.sourceExcerpt || '';
        const clue = normalizeClue(rawClue, existing, state.clock.absoluteMinute, {
            sourceMessageId,
            sourceSwipeId,
        });
        if (!clue.text) continue;
        const sourceChanged = Boolean(
            existing
            && (previousText !== clue.text || previousExcerpt !== clue.sourceExcerpt)
        );
        // Model-supplied timing is never authoritative. Resolve it from the actual
        // clue/source text and the world clock instead.
        if (!existing || sourceChanged) clue.timing = null;
        anchorTiming(clue, { force: !existing || sourceChanged });
        if (existing) Object.assign(existing, clue);
        else state.storyMemory.clues.unshift(clue);
    }

    for (const rawResolution of asArray(cluesResolve).slice(0, 24)) {
        const resolution = typeof rawResolution === 'string'
            ? { id: rawResolution }
            : rawResolution;
        const clue = findClue(state.storyMemory, resolution);
        if (!clue || clue.locked) continue;
        clue.status = VALID_CLUE_STATES.has(resolution?.status)
            ? resolution.status
            : 'resolved';
        clue.resolution = asString(
            resolution?.resolution,
            clue.resolution || (clue.status === 'discarded' ? 'Diễn biến sau đó đã chứng minh manh mối này không cần tiếp tục theo dõi' : 'Đã được chính văn sau đó hô ứng hoặc giải quyết'),
            520,
        );
        clue.lifecycleReason = asString(
            resolution?.reason ?? resolution?.lifecycle_reason ?? resolution?.lifecycleReason,
            clue.lifecycleReason || clue.resolution,
            360,
        );
        clue.resolvedMessageId = asInteger(
            resolution?.message_id ?? resolution?.messageId,
            sourceMessageId ?? clue.resolvedMessageId ?? 0,
            0,
        );
        clue.updatedAt = state.clock.absoluteMinute;
        appendMemoryMetabolism(state, {
            kind: 'clue',
            action: clue.status,
            targetId: clue.id,
            reason: clue.lifecycleReason || clue.resolution,
            sourceMessageId: sourceMessageId ?? clue.resolvedMessageId ?? 0,
        });
    }
}

function normalizeSimulationResult(payload, { peopleUpsertLimit = LIMITS.peoplePayload } = {}) {
    const timeResolution = normalizeModelTimeResolution(
        payload?.time_resolution ?? payload?.timeResolution ?? {},
    );
    const elapsedMinutes = asInteger(
        payload?.elapsed_minutes ?? payload?.elapsedMinutes,
        0, 0, 5 * 365 * MINUTES_PER_DAY,
    );
    // Some APIs fill the dedicated time verdict but leave the legacy duration
    // at its template default. Consume a qualified current-scene estimate once;
    // never add the two representations of the same duration together.
    const useTimeEstimate = elapsedMinutes === 0
        && timeResolution.scope === 'current'
        && ['estimated_elapsed', 'duration_only'].includes(timeResolution.authority)
        && timeResolution.needsElapsedEstimate
        && ['medium', 'high'].includes(timeResolution.confidence)
        && timeResolution.estimatedMinutes > 0;
    const rawClockAnchor = payload?.clock_anchor ?? payload?.clockAnchor ?? {};
    const anchorMode = ['none', 'initialize', 'calibrate'].includes(rawClockAnchor?.mode)
        ? rawClockAnchor.mode
        : 'none';
    const anchorPrecision = ['minute', 'daypart', 'date'].includes(rawClockAnchor?.precision)
        ? rawClockAnchor.precision
        : 'minute';
    const anchorConfidence = ['low', 'medium', 'high'].includes(rawClockAnchor?.confidence)
        ? rawClockAnchor.confidence
        : 'low';
    return {
        elapsedMinutes: useTimeEstimate ? timeResolution.estimatedMinutes : elapsedMinutes,
        timeReason: asString(payload?.time_reason ?? payload?.timeReason, '', 320)
            || (useTimeEstimate ? timeResolution.reason : ''),
        timeResolution,
        nextTurnInjection: normalizeNextTurnInjection(
            payload?.next_turn_injection ?? payload?.nextTurnInjection ?? {},
        ),
        clockAnchor: {
            mode: anchorMode,
            calendarName: asString(
                rawClockAnchor?.calendar_name ?? rawClockAnchor?.calendarName,
                '',
                40,
            ),
            year: asInteger(rawClockAnchor?.year, 0, 0, MAX_CALENDAR_YEAR),
            month: asInteger(rawClockAnchor?.month, 0, 0, 12),
            day: asInteger(rawClockAnchor?.day, 0, 0, 31),
            hour: asInteger(rawClockAnchor?.hour, 0, 0, 23),
            minute: asInteger(rawClockAnchor?.minute, 0, 0, 59),
            hasDate: (() => {
                const year = Number(rawClockAnchor?.year);
                const month = Number(rawClockAnchor?.month);
                const day = Number(rawClockAnchor?.day);
                return Number.isFinite(year) && year >= 1 && year <= MAX_CALENDAR_YEAR
                    && Number.isFinite(month) && month >= 1 && month <= 12
                    && Number.isFinite(day) && day >= 1 && day <= 31;
            })(),
            hasTime: (() => {
                const rawHour = rawClockAnchor?.hour;
                const rawMinute = rawClockAnchor?.minute;
                if (rawHour === null || rawHour === undefined || rawHour === '') return false;
                if (rawMinute === null || rawMinute === undefined || rawMinute === '') return false;
                const hour = Number(rawHour);
                const minute = Number(rawMinute);
                return Number.isFinite(hour) && hour >= 0 && hour <= 23
                    && Number.isFinite(minute) && minute >= 0 && minute <= 59;
            })(),
            precision: anchorPrecision,
            confidence: anchorConfidence,
            sourceExcerpt: asString(
                rawClockAnchor?.source_excerpt ?? rawClockAnchor?.sourceExcerpt,
                '',
                220,
            ),
            reason: asString(rawClockAnchor?.reason, '', 240),
        },
        world: {
            title: asString(payload?.world?.title, '', 180),
            detail: asString(payload?.world?.detail, '', 640),
        },
        peopleUpsert: asArray(payload?.people_upsert ?? payload?.peopleUpsert).slice(0, Math.max(1, asInteger(peopleUpsertLimit, LIMITS.peoplePayload, 1))),
        peopleRemove: uniqueStrings(payload?.people_remove ?? payload?.peopleRemove, LIMITS.peoplePayload),
        eventsCreate: asArray(payload?.events_create ?? payload?.eventsCreate).slice(0, 24),
        eventsUpdate: asArray(payload?.events_update ?? payload?.eventsUpdate).slice(0, 36),
        deliveriesConfirmed: uniqueStrings(
            payload?.deliveries_confirmed ?? payload?.deliveriesConfirmed,
            24,
        ),
        foregroundFacts: asArray(payload?.front_facts ?? payload?.frontFacts).slice(0, 16),
        worldFactsUpsert: asArray(
            payload?.world_facts_upsert ?? payload?.worldFactsUpsert,
        ).slice(0, 32),
        worldPulseUpsert: asArray(
            payload?.world_pulse_upsert ?? payload?.worldPulseUpsert,
        ).slice(0, LIMITS.worldPulseDomains),
        consistencyConflicts: asArray(
            payload?.consistency_conflicts ?? payload?.consistencyConflicts,
        ).slice(0, 24),
        memoryUpdates: {
            turnSummaries: asArray(
                payload?.memory_update?.turn_summaries
                ?? payload?.memoryUpdate?.turnSummaries,
            ).slice(0, 24),
            factsUpsert: asArray(
                payload?.memory_update?.facts_upsert
                ?? payload?.memoryUpdate?.factsUpsert,
            ).slice(0, 32),
            factsInvalidate: asArray(
                payload?.memory_update?.facts_invalidate
                ?? payload?.memoryUpdate?.factsInvalidate,
            ).slice(0, 32),
            cluesUpsert: asArray(
                payload?.memory_update?.clues_upsert
                ?? payload?.memoryUpdate?.cluesUpsert,
            ).slice(0, 24),
            cluesResolve: asArray(
                payload?.memory_update?.clues_resolve
                ?? payload?.memoryUpdate?.cluesResolve,
            ).slice(0, 24),
        },
    };
}

function conflictKeepsPersonField(rawConflicts, person, field) {
    const aliases = new Set([
        String(person?.id || '').toLocaleLowerCase(),
        String(person?.name || '').toLocaleLowerCase(),
    ].filter(Boolean));
    return asArray(rawConflicts).some(raw => {
        const subject = String(raw?.subject_id ?? raw?.subjectId ?? raw?.subject ?? '')
            .trim().toLocaleLowerCase();
        const rawField = String(raw?.field || '').trim();
        const resolution = String(raw?.resolution || '').trim();
        return aliases.has(subject) && rawField === field && resolution === 'keep-world';
    });
}


function normalizedEvidenceText(value) {
    return String(value || '').replace(/\s+/g, '').trim();
}

function narrativeTailExplicitEndSupported(narrativeText, anchor, calendar) {
    if (!anchor || !calendar || anchor.hour === null || anchor.minute === null) return false;
    const source = String(narrativeText || '');
    if (!source.trim()) return false;
    const tail = source.slice(-1200);
    const exactMatches = [...tail.matchAll(/(?:\d{2,6}\s*年\s*)?\d{1,2}\s*月\s*\d{1,2}\s*[日号][\s\S]{0,24}?\d{1,2}\s*(?:[:：]|点|时)\s*\d{0,2}/g)];
    const last = exactMatches.at(-1);
    if (!last) return false;
    const local = tail.slice(Math.max(0, last.index - 90), Math.min(tail.length, last.index + last[0].length + 140));
    const before = tail.slice(Math.max(0, last.index - 80), last.index);
    const after = tail.slice(last.index + last[0].length, Math.min(tail.length, last.index + last[0].length + 120));
    const futureFraming = /(计划|预计|约定|预约|预定|安排|打算|将于|将在|届时|说[：:]?\s*[“"'「]?|提醒|通知|kế hoạch|dự kiến|dự định|hẹn|đặt trước|sắp xếp|định|sẽ vào|sẽ tại|đến lúc đó|nói[：:]?\s*[“"'「]?|nhắc|thông báo).{0,48}$/i.test(before)
        || /^(?:.{0,24})(?:见|集合|碰头|开会|出发|启程|开始|gặp|tập trung|tập hợp|họp|xuất phát|khởi hành|lên đường|bắt đầu)/i.test(after);
    if (futureFraming) return false;
    const completionCue = /(已经|此时|此刻|最终|最后|结束|到此|完成|抵达|到达|回到|回来|关上|合上|放回|睡下|醒来|离开|散场|收工|落锁|đã|lúc này|giờ phút này|cuối cùng|kết thúc|hoàn thành|đến nơi|tới nơi|trở về|quay về|quay lại|đóng lại|gập lại|đặt lại|cất lại|đi ngủ|tỉnh dậy|thức dậy|rời đi|rời khỏi|tan cuộc|giải tán|tan làm|khóa cửa)/.test(local);
    const nearTail = tail.length - (last.index + last[0].length) <= 420;
    return nearTail && (completionCue || after.trim().length <= 90);
}

function foregroundKnowledgeEvidenceSupported(narrativeText, person, acquisition) {
    const narrative = normalizedEvidenceText(narrativeText);
    const evidence = normalizedEvidenceText(acquisition?.evidence);
    if (!narrative || !evidence || evidence.length < 4) return false;

    // Foreground cognition needs evidence from the actual new narrative, not a model
    // invented explanation. The prompt asks the model to copy a short source excerpt.
    if (!narrative.includes(evidence)) return false;

    const personName = normalizedEvidenceText(person?.name);
    if (personName && !evidence.includes(personName) && !narrative.includes(personName)) {
        return false;
    }
    return true;
}


function backgroundAcquisitionHasWorldTrace(state, person, acquisition) {
    if (acquisition?.route === 'inferred') return acquisition?.certainty === 'suspected';
    if (acquisition?.route === 'public_channel') {
        return publicChannelSupportsAcquisition(state, acquisition);
    }

    const sourceEventId = normalizedReference(acquisition?.sourceEventId);
    if (!sourceEventId) return false;
    const sourceEvent = asArray(state?.events).find(item => (
        normalizedReference(item?.id) === sourceEventId
    ));
    if (!sourceEvent) return false;

    const personName = String(person?.name || '').trim();
    const traceText = `${sourceEvent.title || ''} ${sourceEvent.summary || ''} ${sourceEvent.cause || ''} ${acquisition.evidence || ''}`;
    if (personName && !traceText.includes(personName)) return false;

    const routeCue = {
        witnessed: /(看见|看到|目睹|亲眼|听见|听到|亲耳|撞见|当场发现|nhìn thấy|trông thấy|tận mắt|chứng kiến|nghe thấy|nghe được|tận tai|bắt gặp|phát hiện tại chỗ|bắt quả tang)/,
        told: /(告诉|告知|转告|说明给|向.+说明|被.+告知|nói cho|kể cho|báo cho|cho biết|thông báo cho|chuyển lời|được báo|giải thích cho)/,
        investigated: /(调查|查到|查明|核实|验证|翻查|调取|检索|điều tra|tra ra|tra được|làm rõ|xác minh|kiểm chứng|lục tìm|lục lại|truy xuất|tra cứu)/,
        message: /(收到|短信|消息|电话|邮件|通知|私信|群消息|来电|nhận được|tin nhắn|điện thoại|cuộc gọi|email|thư điện tử|thông báo|nhắn riêng|tin nhắn nhóm|gọi đến)/,
    }[acquisition.route];

    return Boolean(routeCue?.test(traceText));
}

function publicChannelSupportsAcquisition(state, acquisition) {
    const sourceEventId = normalizedReference(
        acquisition?.sourceEventId || (acquisition?.kind === 'event' ? acquisition?.ref : ''),
    );
    if (!sourceEventId) return false;
    const event = asArray(state?.events).find(item => (
        normalizedReference(item?.id) === sourceEventId
    ));
    return Boolean(
        event
        && event.publicity === 'public'
        && (event.publicHeadline || event.publicSummary || event.publicResult || event.publicTrace)
    );
}

function applyKnowledgeAcquisition(state, person, rawAcquisition, {
    messageId = 0,
    narrativeText = '',
    foreground = false,
} = {}) {
    const [acquisition] = normalizeKnowledgeAcquisitions([rawAcquisition], messageId);
    if (!person || !acquisition) return false;

    if (
        foreground
        && !foregroundKnowledgeEvidenceSupported(narrativeText, person, acquisition)
    ) return false;

    if (
        acquisition.route === 'public_channel'
        && !publicChannelSupportsAcquisition(state, acquisition)
    ) return false;

    if (
        !foreground
        && !backgroundAcquisitionHasWorldTrace(state, person, acquisition)
    ) return false;

    if (acquisition.route === 'inferred' && acquisition.certainty !== 'suspected') {
        return false;
    }

    if (acquisition.kind === 'event') {
        const event = asArray(state?.events).find(item => (
            normalizedReference(item?.id) === normalizedReference(acquisition.ref)
        ));
        if (!event) return false;

        const safeView = asString(
            acquisition.belief
            || (
                acquisition.route === 'public_channel'
                    ? (event.publicSummary || event.publicHeadline || event.publicTrace)
                    : acquisition.evidence
            ),
            '',
            520,
        );
        if (!safeView) return false;

        person.knownEventViews = normalizeKnownEventViews([{
            event_id: event.id,
            summary: safeView,
            certainty: acquisition.certainty,
            route: acquisition.route,
            evidence: acquisition.evidence,
            learned_at_message_id: acquisition.learnedAtMessageId,
            updated_at: state.clock?.absoluteMinute || 0,
        }], person.knownEventViews);

        if (acquisition.certainty === 'confirmed') {
            person.knownEventIds = mergeUniqueStrings(
                person.knownEventIds,
                [event.id],
                LIMITS.cognitiveRefs,
            );
        }
        person.cognitionReady = true;
        return true;
    }

    if (acquisition.kind === 'fact') {
        const fact = activeFactByKey(state, acquisition.ref);
        if (!fact) return false;

        const beliefValue = asString(
            acquisition.belief
            || (acquisition.certainty === 'confirmed' ? fact.value : ''),
            '',
            520,
        );
        if (!beliefValue) return false;

        setFactBelief(person, fact, acquisition.learnedAtMessageId || messageId, {
            value: beliefValue,
            certainty: acquisition.certainty,
            route: acquisition.route,
            evidence: acquisition.evidence,
        });
        if (acquisition.certainty === 'confirmed') {
            person.knownFactKeys = mergeUniqueStrings(
                person.knownFactKeys,
                [fact.key],
                LIMITS.cognitiveRefs,
            );
        }
        person.cognitionReady = true;
        return true;
    }

    if (acquisition.kind === 'clue') {
        const clue = asArray(state?.storyMemory?.clues).find(item => (
            normalizedReference(item?.id) === normalizedReference(acquisition.ref)
        ));
        if (!clue) return false;
        // Suspicion about a clue is not equivalent to knowing that clue exists.
        if (acquisition.certainty !== 'confirmed') return false;
        person.knownClueIds = mergeUniqueStrings(
            person.knownClueIds,
            [clue.id],
            LIMITS.cognitiveRefs,
        );
        person.cognitionReady = true;
        return true;
    }

    return false;
}


function personKnowsReference(person, ref) {
    const normalized = normalizedReference(ref);
    if (!normalized) return false;
    if (normalized.startsWith('event:')) {
        const eventId = normalized.slice('event:'.length);
        return asArray(person?.knownEventIds).some(id => normalizedReference(id) === eventId)
            || asArray(person?.knownEventViews).some(view => normalizedReference(view?.eventId) === eventId);
    }
    if (normalized.startsWith('fact:')) {
        const factKey = normalized.slice('fact:'.length);
        return asArray(person?.knownFactKeys).some(key => normalizedReference(key) === factKey)
            || asArray(person?.knownFactBeliefs).some(belief => normalizedReference(belief?.key) === factKey);
    }
    if (normalized.startsWith('clue:')) {
        const clueId = normalized.slice('clue:'.length);
        return asArray(person?.knownClueIds).some(id => normalizedReference(id) === clueId);
    }
    return false;
}

function hasValidatedKnowledgePath(person, ref) {
    const normalized = normalizedReference(ref);
    if (!normalized) return false;

    if (normalized.startsWith('event:')) {
        const eventId = normalized.slice('event:'.length);
        return asArray(person?.knownEventViews).some(view => (
            normalizedReference(view?.eventId) === eventId
            && VALID_KNOWLEDGE_ROUTES.has(asString(view?.route, '', 40))
            && Boolean(asString(view?.evidence, '', 360))
        ));
    }

    if (normalized.startsWith('fact:')) {
        const factKey = normalized.slice('fact:'.length);
        return asArray(person?.knownFactBeliefs).some(belief => (
            normalizedReference(belief?.key) === factKey
            && VALID_KNOWLEDGE_ROUTES.has(asString(belief?.route, '', 40))
            && Boolean(asString(belief?.evidence, '', 360))
        ));
    }

    return personKnowsReference(person, normalized);
}

function hiddenInjectionReference(state, ref) {
    const normalized = normalizedReference(ref);
    if (!normalized) return false;

    if (normalized.startsWith('event:')) {
        const eventId = normalized.slice('event:'.length);
        const event = asArray(state?.events).find(item => normalizedReference(item?.id) === eventId);
        return Boolean(event && String(event.visibility || '').toLowerCase() === 'hidden');
    }

    if (normalized.startsWith('fact:')) {
        const factKey = normalized.slice('fact:'.length);
        const worldFact = asArray(state?.worldFacts).find(item => (
            normalizedReference(item?.key) === factKey
            && ['current', 'persistent'].includes(String(item?.validity || 'current').toLowerCase())
        ));
        const memoryFact = asArray(state?.storyMemory?.facts).find(item => (
            normalizedReference(item?.key) === factKey
            && ['active', 'disputed'].includes(String(item?.status || 'active').toLowerCase())
        ));
        const fact = worldFact || memoryFact;
        return Boolean(fact && String(fact.visibility || '').toLowerCase() === 'hidden');
    }

    return false;
}

function sanitizeNextTurnInjectionKnowledge(state, rawInjection) {
    const next = normalizeNextTurnInjection(rawInjection);
    const blocked = [];
    const allowed = ref => {
        if (!hiddenInjectionReference(state, ref)) return true;
        const hasPath = asArray(state?.people).some(person => hasValidatedKnowledgePath(person, ref));
        if (!hasPath) blocked.push(ref);
        return hasPath;
    };

    next.requiredRefs = next.requiredRefs.filter(allowed);
    next.conditionalRefs = next.conditionalRefs.filter(allowed);
    if (blocked.length) {
        next.suppressRefs = mergeUniqueStrings(next.suppressRefs, blocked, 24);
        const guardReason = 'Tường lửa tri thức đã chặn ' + new Set(blocked).size + ' tham chiếu hidden thiếu con đường biết được hợp lệ';
        next.reason = asString(next.reason ? next.reason + '；' + guardReason : guardReason, '', 360);
    }
    return next;
}

function textHasSecretOverlap(text, secret) {
    const candidate = normalizedEvidenceText(text);
    const source = normalizedEvidenceText(secret);
    if (!candidate || !source || source.length < 6) return false;
    if (candidate.includes(source)) return true;
    const windows = [];
    const width = source.length >= 12 ? 6 : 5;
    for (let index = 0; index + width <= source.length; index += Math.max(2, width - 2)) {
        windows.push(source.slice(index, index + width));
    }
    return windows.some(chunk => chunk.length >= 5 && candidate.includes(chunk));
}


function personHasNearbyUnknownSecrets(state, person) {
    const name = String(person?.name || '');
    for (const event of asArray(state?.events)) {
        if (eventKnownToPerson(event, person)) continue;
        if (
            listReferencesPerson(event?.actors, person)
            || (person?.location && event?.place === person.location)
            || (name && (
                String(event?.title || '').includes(name)
                || String(event?.summary || '').includes(name)
                || String(event?.cause || '').includes(name)
            ))
        ) return true;
    }
    return false;
}

function innerVoiceLeaksUnknownReality(state, person, candidate) {
    for (const event of asArray(state?.events)) {
        if (eventKnownToPerson(event, person)) continue;
        const secrets = [
            event.cause,
            event.summary,
            event.result,
            event.expectedResult,
        ].filter(Boolean);
        if (secrets.some(secret => textHasSecretOverlap(candidate, secret))) return true;
    }

    const knownFactRefs = new Set([
        ...asArray(person?.knownFactKeys).map(normalizedReference),
        ...asArray(person?.knownFactBeliefs).map(item => normalizedReference(item?.key)),
    ]);
    for (const fact of asArray(state?.storyMemory?.facts)) {
        if (knownFactRefs.has(normalizedReference(fact?.key))) continue;
        if (fact?.visibility !== 'hidden') continue;
        if (textHasSecretOverlap(candidate, fact?.value)) return true;
    }
    return false;
}

function commitSafeInnerVoice(state, person, rawPerson, {
    worldMinute = 0,
    allowUserInnerVoice = true,
} = {}) {
    if (!person) return false;
    if (person.isUser && !allowUserInnerVoice) {
        person.innerVoice = '';
        person.innerVoiceAt = worldMinute;
        return false;
    }
    const candidate = asString(rawPerson?.inner_voice ?? rawPerson?.innerVoice, '', LIMITS.innerVoice);
    if (!candidate) return false;

    const basis = uniqueStrings(
        rawPerson?.inner_voice_basis ?? rawPerson?.innerVoiceBasis,
        LIMITS.cognitiveRefs,
    );
    if (basis.length && basis.some(ref => !personKnowsReference(person, ref))) {
        return false;
    }
    if (!basis.length && personHasNearbyUnknownSecrets(state, person)) {
        return false;
    }
    if (innerVoiceLeaksUnknownReality(state, person, candidate)) {
        return false;
    }

    person.innerVoice = candidate;
    person.innerVoiceAt = worldMinute;
    return true;
}

function narrativeSupportsLocationValue(narrativeText, value) {
    const text = String(narrativeText || '').replace(/\s+/g, '');
    const compactValue = String(value || '').replace(/\s+/g, '').trim();
    if (!text || compactValue.length < 2) return false;
    const terms = uniqueStrings([
        compactValue,
        ...compactValue.split(/[的、,，/·|｜]/g),
    ], 12).filter(term => term.length >= 2);
    for (const term of terms) {
        let index = text.indexOf(term);
        while (index >= 0) {
            const window = text.slice(Math.max(0, index - 28), Math.min(text.length, index + term.length + 18));
            if (
                /(?:地点|位置|所在地|场景|địa điểm|vị trí|nơi ở|bối cảnh|cảnh)[：:]/i.test(window)
                || /(?:在|位于|身处|来到|到达|抵达|回到|返回|进入|走进|前往|赶到|去了|住在|留在|待在|躺在|坐在|站在|出现在|离开|(?:^|[\s,.;:"“])(?:ở|tại|vào|tới|đến|rời)\s|nằm ở|có mặt ở|đi đến|đi tới|trở về|quay về|bước vào|đi vào|tiến vào|chạy đến|sống ở|ở lại|nằm trên|ngồi ở|đứng ở|xuất hiện ở|xuất hiện tại|rời khỏi)[^。！？!?]{0,22}/.test(window)
            ) return true;
            index = text.indexOf(term, index + term.length);
        }
    }
    return false;
}

function authoritativePersonFact(state, personId, field) {
    const key = `person:${personId}:${field}`;
    return asArray(state?.worldFacts).find(fact => fact?.key === key && fact?.confidence === 'high') || null;
}

export function applySimulationResult(baseState, rawPayload, {
    messageId = null,
    swipeId = null,
    sourceKey = '',
    userName = '',
    allowUserInnerVoice = true,
    recordPlayerCharacter = true,
    timePolicy = 'open',
    narrativeText = '',
    backgroundNpcBudget = LIMITS.peopleTaskBudget,
    lifeSettlementTargetIds = [],
    memorySummaryMessageIds = [],
    preserveCommitAnchor = false,
} = {}) {
    const requestedBackgroundNpcBudget = asInteger(
        backgroundNpcBudget,
        LIMITS.peopleTaskBudget,
        0,
    );
    const payload = normalizeSimulationResult(rawPayload, {
        // Keep a small foreground allowance while letting the user-selected background
        // budget scale past the old fixed 36-person payload ceiling.
        peopleUpsertLimit: Math.max(LIMITS.peoplePayload, requestedBackgroundNpcBudget + 24),
    });
    const lifeSettlementTargets = new Set(
        asArray(lifeSettlementTargetIds).map(item => String(item || '')).filter(Boolean),
    );
    if (!recordPlayerCharacter) {
        baseState = {
            ...baseState,
            people: asArray(baseState?.people).filter(person => !isUserPersonLike(person, userName)),
        };
    }
    const baseClockAnchored = Boolean(baseState?.clock?.anchored);
    // Model clock_anchor is advisory only. Absolute world time is a deterministic
    // state authority: model guesses may estimate elapsed duration, never date us.
    const modelClockAnchor = payload.clockAnchor;
    void modelClockAnchor;
    const currentCalendar = formatWorldCalendar(baseState);
    const rawNarrativeCalendar = extractExplicitCalendarDate(narrativeText);
    const rawNarrativeAnchor = extractNarrativeTimeAnchor(narrativeText);
    const modelTimeResolution = payload.timeResolution || {};
    const modelEvidenceText = asString(modelTimeResolution.evidence, '', 260);
    const normalizedNarrativeForTime = normalizedEvidenceText(narrativeText);
    const normalizedModelTimeEvidence = normalizedEvidenceText(modelEvidenceText);
    const modelSelectedCurrentEnd = Boolean(
        modelTimeResolution.evidenceFound
        && modelTimeResolution.authority === 'explicit_end_time'
        && modelTimeResolution.scope === 'current'
        && modelTimeResolution.confidence === 'high'
        && normalizedModelTimeEvidence.length >= 4
        && normalizedNarrativeForTime.includes(normalizedModelTimeEvidence)
    );
    // The model may select which of several literal times is the scene-end evidence,
    // but it never supplies the clock value by authority. We re-parse its copied
    // excerpt with the deterministic parser and ignore it unless the excerpt exists
    // verbatim in the new narrative.
    const selectedEndAnchor = modelSelectedCurrentEnd
        ? extractNarrativeTimeAnchor(modelEvidenceText)
        : null;
    const selectedEndCalendar = modelSelectedCurrentEnd
        ? extractExplicitCalendarDate(modelEvidenceText)
        : null;
    const narrativeCalendar = selectedEndCalendar || rawNarrativeCalendar;
    const narrativeAnchor = selectedEndAnchor || rawNarrativeAnchor;
    const relativeTransition = resolveNarrativeTimeTransition(narrativeText, {
        currentAbsoluteMinute: baseState.clock?.absoluteMinute || 0,
        currentCalendar,
        calendarBound: baseClockAnchored,
        narrativeAnchor,
        currentPrecision: baseState.clock?.precision || (baseClockAnchored ? 'date' : 'day'),
        currentDaypart: baseState.clock?.daypart || '',
    });
    const anchor = {
        mode: 'none',
        calendarName: '',
        year: 0,
        month: 0,
        day: 0,
        hour: 0,
        minute: 0,
        hasDate: false,
        hasTime: false,
        precision: 'date',
        confidence: 'low',
        sourceExcerpt: '',
        reason: '',
    };

    const currentMinuteOfDay = currentCalendar.hour * 60 + currentCalendar.minute;
    const narrativeMinuteOfDay = narrativeAnchor
        && narrativeAnchor.hour !== null
        && narrativeAnchor.minute !== null
        ? Number(narrativeAnchor.hour) * 60 + Number(narrativeAnchor.minute)
        : null;
    const narrativeTailExplicitEnd = narrativeTailExplicitEndSupported(
        narrativeText,
        narrativeAnchor,
        narrativeCalendar,
    );
    const structuredForwardExact = Boolean(
        baseClockAnchored
        && (narrativeAnchor?.structured || modelSelectedCurrentEnd || narrativeTailExplicitEnd)
        && Number.isFinite(narrativeMinuteOfDay)
        && narrativeMinuteOfDay > currentMinuteOfDay
    );
    const narrativeDayDelta = narrativeCalendar
        ? calendarDayDifference({
            year: currentCalendar.year,
            month: currentCalendar.month,
            day: currentCalendar.dayOfMonth,
        }, {
            year: narrativeCalendar.year,
            month: narrativeCalendar.month,
            day: narrativeCalendar.day,
        })
        : null;
    const narrativeDateReliable = Boolean(
        narrativeCalendar
        && (
            narrativeAnchor?.structured
            || narrativeTailExplicitEnd
            || Number(narrativeCalendar.index) <= 500
        )
    );
    const narrativeDateCanCalibrate = Boolean(
        narrativeDateReliable
        // A repeated opening date/clock confirms existing context, not the end
        // of this batch. It must not erase later transitions or elapsed actions.
        && (!baseClockAnchored || Number(narrativeDayDelta) > 0
            || (Number(narrativeDayDelta) === 0 && structuredForwardExact))
    );

    if (narrativeDateCanCalibrate) {
        const dateChanged = !baseClockAnchored || Number(narrativeDayDelta) !== 0;
        const reliableExact = Boolean(
            narrativeAnchor
            && narrativeAnchor.hour !== null
            && narrativeAnchor.minute !== null
            && (
                !baseClockAnchored
                || dateChanged
                || structuredForwardExact
                || /→|->|至|到|đến|tới/.test(narrativeAnchor.excerpt || '')
            )
        );
        anchor.mode = baseClockAnchored ? 'calibrate' : 'initialize';
        anchor.year = narrativeCalendar.year;
        anchor.month = narrativeCalendar.month;
        anchor.day = narrativeCalendar.day;
        anchor.hasDate = true;
        if (reliableExact) {
            anchor.hour = narrativeAnchor.hour;
            anchor.minute = narrativeAnchor.minute;
            anchor.hasTime = true;
            anchor.precision = 'minute';
        } else {
            anchor.precision = narrativeAnchor?.daypart ? 'daypart' : 'date';
        }
        anchor.confidence = 'high';
        anchor.sourceExcerpt = narrativeAnchor?.excerpt || narrativeCalendar.excerpt;
        anchor.reason = baseClockAnchored
            ? 'Chính văn đưa ra bằng chứng thời gian mới đáng tin cậy, hiệu chỉnh thời gian thế giới chính theo quy tắc xác định'
            : 'Chính văn đưa ra năm-tháng-ngày đáng tin cậy, gắn đồng hồ thế giới tương đối hiện có vào Lịch thế giới chính';
    } else if (structuredForwardExact) {
        anchor.mode = 'calibrate';
        anchor.year = currentCalendar.year;
        anchor.month = currentCalendar.month;
        anchor.day = currentCalendar.dayOfMonth;
        anchor.hour = narrativeAnchor.hour;
        anchor.minute = narrativeAnchor.minute;
        anchor.hasDate = true;
        anchor.hasTime = true;
        anchor.precision = 'minute';
        anchor.confidence = 'high';
        anchor.sourceExcerpt = narrativeAnchor.excerpt;
        anchor.reason = 'Thanh thời gian trong chính văn đưa ra giờ rõ ràng muộn hơn, tự động hiệu chỉnh thời gian thế giới chính';
    }

    const anchorHasDate = Boolean(anchor?.hasDate);
    const anchorHasExactTime = Boolean(anchor?.hasTime);
    const initializeClock = !baseClockAnchored
        && anchorHasDate
        && anchor?.mode === 'initialize'
        && anchor?.confidence === 'high';
    const recalibrateClock = baseClockAnchored
        && anchorHasDate
        && anchor?.mode === 'calibrate'
        && anchor?.confidence === 'high';
    const anchorApplied = initializeClock || recalibrateClock;

    const requestedElapsedMinutes = payload.elapsedMinutes;
    const semanticElapsedFallback = requestedElapsedMinutes === 0
        && ['open', 'world'].includes(timePolicy)
        && !anchorApplied
        && !relativeTransition
        ? inferStrongSemanticElapsedMinutes(narrativeText)
        : 0;
    const effectiveElapsedMinutes = requestedElapsedMinutes || semanticElapsedFallback;
    const semanticElapsedEvidence = semanticElapsedFallback > 0
        ? asString(String(narrativeText || '').slice(-520), '', 260)
        : '';
    const explicitTimeEvidence = hasExplicitTimeEvidence(narrativeText);
    if (anchorApplied || relativeTransition) {
        // Both are end-of-batch time evidence. Adding model elapsed_minutes again
        // would double-count the same date/transition.
        payload.elapsedMinutes = 0;
    } else {
        payload.elapsedMinutes = resolveElapsedMinutes(
            effectiveElapsedMinutes,
            narrativeText,
            timePolicy,
        );
        if (semanticElapsedFallback > 0 && requestedElapsedMinutes === 0) {
            payload.timeReason = 'Chính văn xuất hiện bằng chứng tổ hợp tốn nhiều thời gian đã hoàn tất; khi model không ước tính thì chỉ đẩy tới theo cận dưới thận trọng';
        }
    }
    if (!explicitTimeEvidence && !['open', 'world'].includes(timePolicy)) {
        for (const update of payload.eventsUpdate) {
            const requestedWork = asInteger(
                update?.worked_minutes ?? update?.workedMinutes,
                0,
                0,
            );
            const guardedWork = timePolicy === 'cautious'
                ? Math.min(requestedWork, 180)
                : 0;
            update.worked_minutes = guardedWork;
            update.workedMinutes = guardedWork;
        }
    }
    if (anchorApplied) {
        payload.timeReason = anchor.reason;
    } else if (relativeTransition) {
        payload.timeReason = relativeTransition.reason;
    } else if (!baseClockAnchored && timePolicy === 'world') {
        payload.timeReason = payload.elapsedMinutes > 0
            ? 'Ngày lịch cụ thể chưa được gắn; tiếp tục dùng đồng hồ thế giới tương đối và đẩy tới theo thời gian thực tế tiêu tốn của lô này'
            : 'Ngày lịch cụ thể chưa được gắn; đồng hồ thế giới tương đối giữ liên tục';
    } else if (requestedElapsedMinutes > 0 && payload.elapsedMinutes === 0) {
        payload.timeReason = 'Chính văn không có bằng chứng thời gian rõ ràng, tính toán được; lượt này giữ nguyên đồng hồ thế giới';
    } else if (payload.elapsedMinutes < requestedElapsedMinutes) {
        payload.timeReason = `Thời gian trong chính văn khá mơ hồ, lượt này đẩy tới tối đa ${payload.elapsedMinutes} phút`;
    }
    let anchoredBaseState = baseState;
    if (initializeClock) {
        const currentClock = formatWorldCalendar(baseState);
        anchoredBaseState = setWorldCalendar(baseState, {
            calendarName: anchor.calendarName || baseState?.world?.calendar?.name || 'Lịch thế giới chính',
            year: anchor.year,
            month: anchor.month,
            day: anchor.day,
            hour: anchorHasExactTime ? anchor.hour : currentClock.hour,
            minute: anchorHasExactTime ? anchor.minute : currentClock.minute,
            reason: payload.timeReason,
        });
        anchoredBaseState.clock.source = 'narrative-anchor-init';
        anchoredBaseState.clock.anchored = true;
        anchoredBaseState.clock.precision = anchor.precision;
        anchoredBaseState.clock.daypart = narrativeAnchor?.daypart || '';
        appendAudit(anchoredBaseState, {
            type: 'clock_anchor_initialized',
            text: `Thiết lập điểm neo thời gian thế giới chính: ${formatWorldCalendar(anchoredBaseState).stamp}`,
            reason: anchor.sourceExcerpt
                ? `${payload.timeReason}; căn cứ: ${anchor.sourceExcerpt}`
                : payload.timeReason,
        });
    } else if (recalibrateClock) {
        const current = formatWorldCalendar(baseState);
        const dayDelta = calendarDayDifference({
            year: current.year,
            month: current.month,
            day: current.dayOfMonth,
        }, {
            year: anchor.year,
            month: anchor.month,
            day: anchor.day,
        });
        const currentMinuteOfDay = current.hour * 60 + current.minute;
        const anchorMinuteOfDay = anchorHasExactTime
            ? anchor.hour * 60 + anchor.minute
            : currentMinuteOfDay;
        const targetMinute = Math.max(
            0,
            baseState.clock.absoluteMinute
                + dayDelta * MINUTES_PER_DAY
                + anchorMinuteOfDay
                - currentMinuteOfDay,
        );
        anchoredBaseState = settleTimedEvents(baseState, targetMinute, {
            source: 'narrative-anchor',
            reason: payload.timeReason,
        });
        if (anchor.calendarName) {
            anchoredBaseState.world.calendar.name = anchor.calendarName;
        }
        anchoredBaseState.clock.anchored = true;
        anchoredBaseState.clock.precision = anchor.precision;
        anchoredBaseState.clock.daypart = narrativeAnchor?.daypart || '';
        appendAudit(anchoredBaseState, {
            type: 'clock_anchor_recalibrated',
            text: `Hiệu chỉnh lại thời gian thế giới chính: ${formatWorldCalendar(anchoredBaseState).stamp}`,
            reason: anchor.sourceExcerpt
                ? `${payload.timeReason}; căn cứ: ${anchor.sourceExcerpt}`
                : payload.timeReason,
        });
    }
    const transitionTarget = !anchorApplied && relativeTransition
        ? Number(relativeTransition.targetAbsoluteMinute)
        : Number.NaN;
    const targetWorldMinute = Number.isFinite(transitionTarget)
        ? Math.max(0, transitionTarget)
        : anchoredBaseState.clock.absoluteMinute + payload.elapsedMinutes;
    let state = settleTimedEvents(
        anchoredBaseState,
        targetWorldMinute,
        {
            source: anchorApplied
                ? anchoredBaseState.clock.source
                : relativeTransition
                    ? 'narrative-time-evidence'
                    : 'world-clock',
            reason: payload.timeReason || 'Suy diễn từ chính văn',
        },
    );
    if (!anchorApplied && relativeTransition) {
        state.clock.precision = relativeTransition.precision || state.clock.precision || 'day';
        state.clock.daypart = relativeTransition.daypart || '';
        state.clock.source = 'narrative-time-evidence';
        state.clock.reason = relativeTransition.reason || payload.timeReason;
    } else if (!state.clock.anchored && !['minute', 'daypart', 'date', 'day'].includes(state.clock.precision)) {
        state.clock.precision = 'day';
        state.clock.daypart = '';
    }
    const worldMinute = state.clock.absoluteMinute;
    const deterministicAuthority = anchorApplied
        ? 'explicit_end_time'
        : relativeTransition
            ? (relativeTransition.precision === 'daypart' ? 'daypart_transition' : 'explicit_transition')
            : payload.elapsedMinutes > 0
                ? (payload.timeResolution.authority === 'duration_only' ? 'duration_only' : 'estimated_elapsed')
                : 'none';
    const deterministicEvidence = anchorApplied || Boolean(relativeTransition);
    state.lastTimeResolution = normalizeStoredTimeResolution({
        sourceKey,
        messageId,
        beforeMinute: baseState.clock?.absoluteMinute || 0,
        afterMinute: worldMinute,
        method: anchorApplied
            ? 'deterministic-anchor'
            : relativeTransition
                ? 'deterministic-transition'
                : payload.elapsedMinutes > 0
                    ? (semanticElapsedFallback > 0 && requestedElapsedMinutes === 0
                        ? 'semantic-fallback'
                        : 'model-elapsed')
                    : 'unchanged',
        authority: deterministicAuthority,
        evidence: anchorApplied
            ? anchor.sourceExcerpt
            : relativeTransition?.sourceExcerpt
                || relativeTransition?.evidence
                || semanticElapsedEvidence
                || payload.timeResolution.evidence,
        requestedElapsedMinutes,
        appliedElapsedMinutes: payload.elapsedMinutes,
        reason: payload.timeReason,
        precision: state.clock?.precision || '',
        daypart: state.clock?.daypart || '',
        deterministicEvidence,
        model: payload.timeResolution,
    });
    state.nextTurnInjection = normalizeNextTurnInjection(payload.nextTurnInjection);

    if (payload.world.title) state.world.title = payload.world.title;
    if (payload.world.detail) state.world.detail = payload.world.detail;

    const pendingKnowledgeUpdates = [];

    const generatedConsistencyConflicts = [];
    let backgroundNpcUpdates = 0;
    const maximumBackgroundNpcUpdates = requestedBackgroundNpcBudget;
    // Whether a person is foreground is an evidence question, not a budget-size question.
    // A large user budget must never let model-labelled "foreground" bypass narrative evidence.
    const enforceForegroundEvidence = true;
    const narrativeForPeople = asString(narrativeText, '', 60000).toLocaleLowerCase();
    for (const rawPerson of payload.peopleUpsert) {
        const personName = asString(rawPerson?.name, '', 80).toLocaleLowerCase();
        const playerPerson = Boolean(
            isUserPersonLike(rawPerson, userName)
            || isUserPersonLike(findPerson(state, rawPerson), userName)
        );
        if (playerPerson && !recordPlayerCharacter) continue;
        const namedInNarrative = Boolean(
            personName
            && narrativeForPeople
            && narrativeForPeople.includes(personName)
        );
        const foregroundPerson = playerPerson || (
            rawPerson?.source === 'foreground'
            && (!enforceForegroundEvidence || namedInNarrative)
        );
        if (!foregroundPerson) {
            if (backgroundNpcUpdates >= maximumBackgroundNpcUpdates) continue;
            backgroundNpcUpdates += 1;
        }
        const existing = findPerson(state, rawPerson);
        if (existing && !foregroundPerson && existing.simulationEnabled === false) continue;
        pendingKnowledgeUpdates.push({
            personId: existing?.id || normalizeId(rawPerson?.id || rawPerson?.name, 'person'),
            foreground: foregroundPerson,
            rawPerson,
            updates: normalizeKnowledgeAcquisitions(
                rawPerson?.knowledge_updates
                ?? rawPerson?.knowledgeUpdates
                ?? rawPerson?.knowledge_acquisitions
                ?? rawPerson?.knowledgeAcquisitions,
                messageId || 0,
            ),
        });
        const person = normalizePerson(rawPerson, existing, worldMinute, {
            userName,
            allowUserInnerVoice,
            sourceMessageId: messageId,
        });
        const targetedLifeSettlement = Boolean(
            lifeSettlementTargets.has(String(existing?.id || ''))
            || lifeSettlementTargets.has(String(person.id || ''))
            || lifeSettlementTargets.has(String(rawPerson?.id || ''))
        );
        // 普通后台 upsert 可能只是事件后果/认知变化，不等于整段个人生活已经结算。
        if (!person.isUser && (foregroundPerson || targetedLifeSettlement)) {
            person.lastLifeTickAt = worldMinute;
            if (targetedLifeSettlement) {
                person.lifeTickPriority = false;
                person.lifeTickPriorityAt = 0;
            }
        }
        if (existing && foregroundPerson && !baseState?.needsReconciliation) {
            const authoritativeLocation = authoritativePersonFact(state, existing.id, 'location');
            const requestedLocation = asString(
                rawPerson?.location,
                existing.location || '',
                160,
            );
            const locationChanged = Boolean(
                requestedLocation
                && authoritativeLocation?.value
                && requestedLocation !== authoritativeLocation.value
            );
            const explicitKeep = conflictKeepsPersonField(
                payload.consistencyConflicts,
                existing,
                'location',
            );
            const narrativeSupport = locationChanged
                ? narrativeSupportsLocationValue(narrativeText, requestedLocation)
                : true;
            if (locationChanged && (explicitKeep || !narrativeSupport)) {
                person.location = authoritativeLocation.value;
                generatedConsistencyConflicts.push({
                    subject: existing.name,
                    field: 'location',
                    previous_value: authoritativeLocation.value,
                    narrative_value: requestedLocation,
                    resolution: 'keep-world',
                    reason: explicitKeep
                        ? 'Suy diễn nhận thấy chính văn và vị trí có thẩm quyền không có xung đột chuyển tiếp, giữ nguyên sự thật thế giới hiện có'
                        : 'Chính văn không có đủ bằng chứng rõ ràng về thay đổi vị trí, từ chối dùng suy đoán của model để ghi đè vị trí có thẩm quyền khi không có chuyển tiếp',
                    message_id: messageId,
                });
            }
        }
        if (existing) {
            if (existing.locked) {
                person.name = existing.name;
                person.isUser = existing.isUser;
                person.longTermGoal = existing.longTermGoal;
                person.simulationEnabled = existing.simulationEnabled;
                person.locked = true;
                person.manual = existing.manual;
            }
            Object.assign(existing, person);
            settlePersonStateFacts(
                state,
                existing,
                foregroundPerson ? 'narrative' : 'simulation',
                messageId,
            );
        } else {
            state.people.push(person);
            settlePersonStateFacts(
                state,
                person,
                foregroundPerson ? 'narrative' : 'simulation',
                messageId,
            );
        }
    }

    if (payload.peopleRemove.length) {
        const removed = new Set(payload.peopleRemove.map(item => item.toLowerCase()));
        const removedPersonIds = new Set(
            state.people
                .filter(person => (
                    !person.locked
                    // 用户手动添加 / 世界书导入的人物属于作者维护资产。
                    // routine simulation 可以更新她们的动态状态，但不能通过 people_remove 删除。
                    && !person.manual
                    && !person.worldbookRef
                    && person.source !== 'manual'
                    && (
                        removed.has(person.id.toLowerCase())
                        || removed.has(person.name.toLowerCase())
                    )
                ))
                .map(person => person.id),
        );
        state.people = state.people.filter(person => (
            person.locked
            || !removedPersonIds.has(person.id)
        ));
        if (removedPersonIds.size) {
            state.worldFacts = asArray(state.worldFacts).filter(fact => !(
                fact?.subjectType === 'person'
                && removedPersonIds.has(fact?.subjectId)
            ));
        }
    }

    for (const rawEvent of payload.eventsCreate) {
        const existing = findEvent(state, rawEvent);
        const terminalBeforeMerge = existing && isTerminalEvent(existing)
            ? {
                status: existing.status,
                result: existing.result,
                resolvedAt: existing.resolvedAt,
            }
            : null;
        const event = normalizeEvent(rawEvent, worldMinute, existing);
        event.updatedAt = worldMinute;
        if (existing) {
            // A finished event is a settled world fact. Routine background inference
            // may enrich its metadata, but it must not resurrect the old process.
            if (terminalBeforeMerge) {
                Object.assign(event, terminalBeforeMerge);
            }
            Object.assign(existing, event);
        } else {
            state.events.push(event);
        }
    }

    for (const update of payload.eventsUpdate) {
        const event = findEvent(state, update);
        if (!event) continue;
        const terminalBeforeUpdate = isTerminalEvent(event)
            ? {
                status: event.status,
                result: event.result,
                resolvedAt: event.resolvedAt,
            }
            : null;

        const workedMinutes = asInteger(
            update?.worked_minutes ?? update?.workedMinutes,
            0,
            0,
            5 * 365 * MINUTES_PER_DAY,
        );
        if (workedMinutes && event.clockMode === 'active') {
            event.accruedMinutes = Math.min(
                event.durationMinutes || Number.MAX_SAFE_INTEGER,
                event.accruedMinutes + workedMinutes,
            );
            if (event.durationMinutes > 0 && event.accruedMinutes >= event.durationMinutes) {
                event.status = 'ready';
            }
        }

        if (update?.summary) event.summary = asString(update.summary, event.summary, 420);
        if (update?.consequence) event.consequence = asString(update.consequence, event.consequence, 420);
        if (update?.cause !== undefined) {
            event.cause = asString(update.cause, event.cause || '', LIMITS.eventCause);
        }
        event.actors = mergeUniqueStrings(event.actors, update?.actors, 16);
        event.knownBy = mergeUniqueStrings(
            event.knownBy,
            update?.known_by ?? update?.knownBy,
            LIMITS.cognitiveRefs,
        );
        event.causedBy = mergeUniqueStrings(
            event.causedBy,
            update?.caused_by ?? update?.causedBy,
            12,
        );
        if (update?.visibility) event.visibility = normalizeVisibility(update.visibility);
        if (
            update?.publicity !== undefined
            || update?.public_scope !== undefined
            || update?.publicScope !== undefined
        ) {
            event.publicity = normalizeEventPublicity(
                update?.publicity ?? update?.public_scope ?? update?.publicScope,
                event.publicity || 'private',
            );
        }
        if (update?.public_trace !== undefined || update?.publicTrace !== undefined) {
            event.publicTrace = asString(
                update?.public_trace ?? update?.publicTrace,
                event.publicTrace || '',
                LIMITS.eventPublicTrace,
            );
        }
        if (update?.public_headline !== undefined || update?.publicHeadline !== undefined) {
            event.publicHeadline = asString(
                update?.public_headline ?? update?.publicHeadline,
                event.publicHeadline || '',
                180,
            );
        }
        if (update?.public_summary !== undefined || update?.publicSummary !== undefined) {
            event.publicSummary = asString(
                update?.public_summary ?? update?.publicSummary,
                event.publicSummary || '',
                520,
            );
        }
        if (update?.public_result !== undefined || update?.publicResult !== undefined) {
            event.publicResult = asString(
                update?.public_result ?? update?.publicResult,
                event.publicResult || '',
                520,
            );
        }
        if (event.publicity === 'private') {
            event.publicTrace = '';
            event.publicHeadline = '';
            event.publicSummary = '';
            event.publicResult = '';
        } else if (event.publicity === 'trace') {
            event.publicHeadline = '';
            event.publicSummary = '';
            event.publicResult = '';
        }
        if (update?.delivery_route) {
            event.delivery.route = asString(update.delivery_route, event.delivery.route, 220);
        }

        const requestedStatus = normalizeEventStatus(update?.status ?? event.status);
        if (terminalBeforeUpdate) {
            // Terminal means this process has ended. A later simulation may create a
            // consequence event, but cannot rewrite or reopen the settled old event.
            event.status = terminalBeforeUpdate.status;
            event.result = terminalBeforeUpdate.result;
            event.resolvedAt = terminalBeforeUpdate.resolvedAt;
            event.updatedAt = worldMinute;
        } else if (TERMINAL_EVENT_STATES.has(requestedStatus)) {
            markTerminal(
                event,
                requestedStatus,
                worldMinute,
                update?.result,
                update?.resolved_at ?? update?.resolvedAt,
            );
        } else {
            event.status = requestedStatus;
            event.updatedAt = worldMinute;
            if (requestedStatus === 'ready' && update?.result) {
                markTerminal(event, 'resolved', worldMinute, update.result);
            }
        }
    }

    for (const event of state.events) {
        if (event.status === 'ready' && event.result) {
            markTerminal(event, 'resolved', worldMinute, event.result);
        }
        if (TERMINAL_EVENT_STATES.has(event.status)) {
            settleEventResultFact(state, event, messageId);
        }
    }

    for (const rawFact of payload.worldFactsUpsert) {
        const source = ['foreground', 'narrative'].includes(rawFact?.source)
            ? 'narrative'
            : 'simulation';
        upsertWorldFact(state, rawFact, {
            source,
            messageId,
        });
    }

    state.worldPulse = normalizeWorldPulse(state.worldPulse, worldMinute);
    for (const rawDomain of payload.worldPulseUpsert) {
        upsertWorldPulseDomain(state, rawDomain, {
            worldMinute,
            source: rawDomain?.source === 'history' ? 'history' : 'simulation',
        });
    }
    if (payload.worldPulseUpsert.length) {
        state.worldPulse.baselineEstablished = true;
    }
    if (payload.elapsedMinutes > 0 || payload.worldPulseUpsert.length) {
        state.worldPulse.lastSweepAt = worldMinute;
    }

    // Public news is only a presentation of an already-real world event.
    // Keep one stable world fact per public event so later foreground scenes can
    // retrieve the world's current/recent reality even after the news card changes.
    syncPublicEventRealityFacts(state, worldMinute);

    const allConsistencyConflicts = [
        ...generatedConsistencyConflicts,
        ...payload.consistencyConflicts,
    ];
    if (allConsistencyConflicts.length) {
        const seen = new Set();
        const conflicts = allConsistencyConflicts
            .map(raw => normalizeConsistencyConflict(raw, worldMinute, messageId))
            .filter(conflict => {
                if (!conflict.expected && !conflict.observed) return false;
                const key = `${conflict.subject}\u0000${conflict.field}\u0000${conflict.expected}\u0000${conflict.observed}\u0000${conflict.messageId}`;
                if (seen.has(key)) return false;
                seen.add(key);
                return true;
            });
        state.consistencyConflicts = [
            ...conflicts,
            ...asArray(state.consistencyConflicts),
        ].slice(0, LIMITS.consistencyConflicts);
    }

    for (const rawId of payload.deliveriesConfirmed) {
        const event = state.events.find(item => item.id === normalizeId(rawId, 'event'));
        if (!event) continue;
        event.delivery.state = 'delivered';
        event.delivery.confirmedAt = worldMinute;
        event.delivery.confirmedMessageId = messageId;
        state.echoes.unshift({
            id: makeId('echo'),
            eventId: event.id,
            at: worldMinute,
            title: event.title,
            route: event.delivery.route || event.result || event.consequence,
            state: 'Đã được chính văn tiếp nhận',
        });
    }

    for (const rawFact of payload.foregroundFacts) {
        const text = asString(rawFact?.text, '', 420);
        if (!text) continue;
        state.foregroundFacts.unshift({
            id: normalizeId(rawFact?.id, 'fact'),
            at: worldMinute,
            text,
            affects: uniqueStrings(rawFact?.affects, 10),
            visibility: normalizeVisibility(rawFact?.visibility ?? 'known'),
        });
        upsertWorldFact(state, {
            key: rawFact?.key || `foreground:${hashText(text)}`,
            subject_type: rawFact?.subject_type || 'world',
            subject_id: rawFact?.subject_id || '',
            subject: rawFact?.subject || 'Sự thật trong chính văn',
            field: rawFact?.field || 'state',
            value: text,
            visibility: rawFact?.visibility ?? 'known',
            confidence: 'high',
        }, {
            source: 'narrative',
            messageId,
        });
    }

    const allowedMemorySummaryIds = new Set(
        asArray(memorySummaryMessageIds)
            .map(value => asInteger(value, -1, -1))
            .filter(value => value >= 0),
    );
    for (const rawTurn of asArray(payload.memoryUpdates?.turnSummaries).slice(0, 24)) {
        const summaryMessageId = asInteger(
            rawTurn?.source_message_id
            ?? rawTurn?.sourceMessageId
            ?? rawTurn?.message_id
            ?? rawTurn?.messageId,
            -1,
            -1,
        );
        if (
            summaryMessageId < 0
            || !allowedMemorySummaryIds.has(summaryMessageId)
            || !rawTurn?.summary
        ) continue;
        const preparedSummary = {
            ...rawTurn,
            id: rawTurn?.id || `summary_l0_${summaryMessageId}`,
            start_message_id: summaryMessageId,
            end_message_id: summaryMessageId,
            level: MEMORY_SUMMARY_LEVELS.DETAIL,
            hierarchy_managed: true,
            source_summary_ids: [],
        };
        const normalizedSummary = normalizeStorySummary(preparedSummary);
        const existingSummary = state.storyMemory.summaries.find(summary => (
            summary.id === normalizedSummary.id
            || (
                Number(summary.level) === MEMORY_SUMMARY_LEVELS.DETAIL
                && Number(summary.startMessageId) === summaryMessageId
                && Number(summary.endMessageId) === summaryMessageId
            )
        ));
        if (existingSummary) Object.assign(existingSummary, normalizedSummary);
        else state.storyMemory.summaries.push(normalizedSummary);
    }

    applyMemoryFactUpdates(state, payload.memoryUpdates, {
        sourceMessageId: messageId,
        sourceSwipeId: swipeId,
    });
    applyClueUpdates(state, payload.memoryUpdates, {
        sourceMessageId: messageId,
        sourceSwipeId: swipeId,
    });
    let acceptedKnowledgeUpdates = 0;
    let rejectedKnowledgeUpdates = 0;
    for (const pending of pendingKnowledgeUpdates) {
        const person = state.people.find(item => item.id === pending.personId);
        if (!person) continue;
        for (const update of pending.updates) {
            const accepted = applyKnowledgeAcquisition(state, person, update, {
                messageId,
                narrativeText,
                foreground: pending.foreground,
            });
            if (accepted) acceptedKnowledgeUpdates += 1;
            else rejectedKnowledgeUpdates += 1;
        }
    }
    synchronizeCognitiveLedger(state);
    let acceptedInnerVoices = 0;
    let rejectedInnerVoices = 0;
    for (const pending of pendingKnowledgeUpdates) {
        const person = state.people.find(item => item.id === pending.personId);
        if (!person) continue;
        const hasCandidate = Boolean(
            asString(pending.rawPerson?.inner_voice ?? pending.rawPerson?.innerVoice, '', LIMITS.innerVoice)
        );
        if (!hasCandidate) continue;
        const accepted = commitSafeInnerVoice(state, person, pending.rawPerson, {
            worldMinute,
            allowUserInnerVoice,
        });
        if (accepted) acceptedInnerVoices += 1;
        else rejectedInnerVoices += 1;
    }
    if (acceptedKnowledgeUpdates || rejectedKnowledgeUpdates || acceptedInnerVoices || rejectedInnerVoices) {
        appendAudit(state, {
            type: 'cognition_firewall',
            text: `Cập nhật nhận thức: tri thức chấp nhận ${acceptedKnowledgeUpdates} · từ chối ${rejectedKnowledgeUpdates}; độc thoại chấp nhận ${acceptedInnerVoices} · từ chối ${rejectedInnerVoices}`,
            reason: rejectedKnowledgeUpdates || rejectedInnerVoices
                ? 'Thiếu con đường/bằng chứng biết được hợp lệ, hoặc độc thoại viện dẫn chân tướng hậu trường mà nhân vật chưa nắm được'
                : 'Tất cả đều đã qua kiểm tra ranh giới nhận thức của nhân vật',
        });
    }

    // Reconcile next-turn injection against the committed world, not against the
    // model's wording alone. A finished process stays finished, while a directly
    // observed persistent consequence may remain authoritative for the next turn.
    const narrativeResidueText = normalizedEvidenceText(String(narrativeText || '').slice(-5000));
    const terminalRefs = new Set(
        asArray(state.events)
            .filter(event => TERMINAL_EVENT_STATES.has(String(event?.status || '').toLowerCase()))
            .map(event => `event:${event.id}`),
    );
    state.nextTurnInjection.requiredRefs = state.nextTurnInjection.requiredRefs
        .filter(ref => !terminalRefs.has(ref));
    state.nextTurnInjection.conditionalRefs = state.nextTurnInjection.conditionalRefs
        .filter(ref => !terminalRefs.has(ref));

    const residueFactRefs = [];
    const residueEventRefs = [];
    for (const fact of asArray(state.worldFacts)) {
        if (!fact?.key || !fact?.eventId) continue;
        if (!['persistent', 'current'].includes(String(fact.validity || '').toLowerCase())) continue;
        if (String(fact.visibility || '').toLowerCase() === 'hidden') continue;
        const eventRef = `event:${fact.eventId}`;
        if (!terminalRefs.has(eventRef)) continue;
        const candidates = [
            fact.value,
            `${fact.field || ''}${fact.value || ''}`,
            `${fact.subject || ''}${fact.field || ''}`,
        ]
            .map(value => normalizedEvidenceText(value))
            .filter(value => value.length >= 4);
        if (!candidates.some(value => narrativeResidueText.includes(value))) continue;
        residueFactRefs.push(`fact:${fact.key}`);
        residueEventRefs.push(eventRef);
    }
    if (residueFactRefs.length > 0) {
        state.nextTurnInjection.requiredRefs = mergeUniqueStrings(
            state.nextTurnInjection.requiredRefs,
            residueFactRefs,
            24,
        );
        state.nextTurnInjection.suppressRefs = mergeUniqueStrings(
            state.nextTurnInjection.suppressRefs,
            residueEventRefs,
            24,
        );
    }

    // next_turn_injection is model advice, not authority. Hidden world truth may stay
    // in backstage state, but it cannot become a character-facing carry-forward hint
    // without a validated acquisition route and evidence.
    state.nextTurnInjection = sanitizeNextTurnInjectionKnowledge(state, state.nextTurnInjection);

    if (preserveCommitAnchor) {
        state.needsReconciliation = Boolean(baseState?.needsReconciliation);
        state.pendingSync = Boolean(baseState?.pendingSync);
        state.lastCommit = baseState?.lastCommit ? deepClone(baseState.lastCommit) : null;
    } else {
        state.needsReconciliation = false;
        state.pendingSync = false;
        state.lastCommit = {
            messageId,
            swipeId,
            sourceKey: asString(sourceKey, '', 180),
            at: worldMinute,
            committedAt: nowIso(),
        };
    }
    state.revision = asInteger(state.revision, 0, 0) + 1;
    if (state.lastTimeResolution) state.lastTimeResolution.sourceRevision = state.revision;
    if (state.nextTurnInjection) state.nextTurnInjection.sourceRevision = state.revision;
    state.updatedAt = nowIso();
    appendAudit(state, {
        type: 'simulation_committed',
        text: `Suy diễn thế giới hoàn tất · ${formatWorldCalendar(state, worldMinute).stamp}`,
        reason: payload.timeReason,
    });
    return trimState(state);
}

export function addManualEvent(inputState, rawEvent) {
    const state = deepClone(inputState);
    const event = normalizeEvent({
        ...rawEvent,
        status: rawEvent?.status || 'active',
    }, state.clock.absoluteMinute);
    state.events.push(event);
    state.revision += 1;
    state.updatedAt = nowIso();
    appendAudit(state, {
        type: 'event_created',
        text: `Thêm sự kiện: ${event.title}`,
        reason: 'Tạo thủ công',
    });
    return trimState(state);
}

export function setWorldClock(inputState, {
    day,
    hour,
    minute,
    reason = 'Hiệu chỉnh thủ công',
} = {}) {
    const target = (
        asInteger(day, 1, 0, 999999) * MINUTES_PER_DAY
        + asInteger(hour, 0, 0, 23) * 60
        + asInteger(minute, 0, 0, 59)
    );
    const state = settleTimedEvents(inputState, target, { source: 'manual', reason });
    state.clock.anchored = true;
    state.clock.precision = 'minute';
    return trimState(state);
}

export function setWorldCalendar(inputState, {
    calendarName = '',
    year,
    month,
    day,
    hour,
    minute,
    reason = 'Hiệu chỉnh lịch thủ công',
} = {}) {
    const currentClock = formatWorldMinute(inputState?.clock?.absoluteMinute ?? MINUTES_PER_DAY);
    const date = normalizeCalendarDate({ year, month, day }, sequentialCalendarDate(currentClock.day));
    const targetMinute = (
        currentClock.day * MINUTES_PER_DAY
        + asInteger(hour, currentClock.hour, 0, 23) * 60
        + asInteger(minute, currentClock.minute, 0, 59)
    );
    const state = settleTimedEvents(inputState, targetMinute, {
        source: 'manual',
        reason,
    });
    state.world.calendar = {
        name: asString(calendarName, state.world?.calendar?.name || 'Lịch thế giới chính', 40),
        anchorAbsoluteDay: currentClock.day,
        anchorYear: date.year,
        anchorMonth: date.month,
        anchorDay: date.day,
    };
    state.clock.anchored = true;
    state.clock.precision = 'minute';
    appendAudit(state, {
        type: 'calendar_calibrated',
        text: `Lịch đã hiệu chỉnh thành ${formatWorldCalendar(state).stamp}`,
        reason: asString(reason, '', 240),
    });
    state.updatedAt = nowIso();
    return trimState(state);
}

export function advanceWorldClock(inputState, minutes, reason = 'Đẩy thời gian thủ công') {
    const delta = asInteger(minutes, 0, 0, 5 * 365 * MINUTES_PER_DAY);
    return settleTimedEvents(
        inputState,
        inputState.clock.absoluteMinute + delta,
        { source: 'manual', reason },
    );
}

function eventPriority(event) {
    const visibilityScore = {
        direct: 40,
        known: 30,
        trace: 20,
        hidden: 0,
    }[event.visibility] || 0;
    const recency = Number(event.resolvedAt ?? event.updatedAt ?? 0);
    return visibilityScore * 1_000_000 + recency;
}

function deliveryDensityPolicy(value) {
    const density = {
        restrained: 'restrained', balanced: 'balanced', active: 'active',
        克制: 'restrained', 均衡: 'balanced', 活跃: 'active',
        'Tiết chế': 'restrained', 'Cân bằng': 'balanced', 'Sôi nổi': 'active',
    }[value] || 'restrained';
    return {
        density,
        label: { restrained: 'Tiết chế', balanced: 'Cân bằng', active: 'Sôi nổi' }[density],
        liveMaximum: { restrained: 1, balanced: 2, active: 3 }[density],
        minimumScore: { restrained: 145, balanced: 90, active: 55 }[density],
        obligation: {
            restrained: 'Chỉ những ứng viên đã đụng trực tiếp tới địa điểm, hành động hiện tại hoặc nhân vật có mặt mới cần tiếp nhận ngay; tối đa để xảy ra một hậu quả cụ thể, phần còn lại có thể tiếp tục phát triển ở nền.',
            balanced: 'Chỉ cần ứng viên có con đường tiếp xúc vật lý, nhân quả hoặc liên lạc rõ ràng với hành động hiện tại, lượt này thường nên thể hiện tự nhiên ít nhất một hậu quả cụ thể có thể cảm nhận được; đừng chỉ coi nó là tư liệu nền.',
            active: 'Các ứng viên dưới đây chỉ cần có con đường tiếp xúc vật lý, nhân quả hoặc liên lạc thì không phải là gợi ý có thể bỏ qua; lượt này nên để xảy ra tự nhiên ít nhất một hậu quả cụ thể có thể cảm nhận được, nếu không xung đột nhau thì có thể tiếp nhận hai. Chỉ khi thực sự không có con đường tiếp xúc hiện tại mới được phép hoãn lại.',
        }[density],
    };
}

function selectOngoingInfluenceCandidates(state, settings = {}, { contextText = '', people = [] } = {}) {
    const policy = deliveryDensityPolicy(settings.deliveryDensity);
    const context = String(contextText || '').toLocaleLowerCase();
    const personRefs = new Set(asArray(people)
        .flatMap(person => [normalizedReference(person?.id), normalizedReference(person?.name)])
        .filter(Boolean));
    const explicitSceneTransition = /(?:^|[，。！？\s])(?:我|玩家|user|玲)?(?:已经|刚刚|刚才|现在|此刻|目前)?(?:到了|到达|来到|抵达|进入|走进|回到|身处|位于|待在)\s*[^，。！？\n]{1,32}|(?:^|[\s,.!?，。！？])(?:tôi|ta|mình|người chơi|user|玲七|玲)\s+(?:(?:đã|vừa mới|vừa|mới|bây giờ|giờ|lúc này|hiện tại|hiện đang|đang)\s+)?(?:đến|tới|đi đến|đi tới|đi vào|bước vào|tiến vào|trở về|quay về|có mặt ở|có mặt tại|nằm ở|ở lại|ở)\s*[^,.!?，。！？\n]{1,32}/i.test(context);
    const explicitPresentLocation = /(?:我|玩家|user|玲)(?:已经|现在|此刻|目前)\s*在\s*[^，。！？\n]{0,24}(?:图书馆|咖啡店|办公室|医院|学校|车站|港区|商场|街道|公园|客厅|卧室|厨房|大厅|房间|门口|家中|公司|店里|楼上|楼下)|(?:tôi|ta|mình|người chơi|user|玲七|玲)\s+(?:đã|bây giờ|giờ|lúc này|hiện tại|hiện đang|đang)\s+(?:ở|tại)\s+[^,.!?，。！？\n]{0,24}(?:thư viện|quán cà phê|văn phòng|bệnh viện|trường|nhà ga|bến xe|khu cảng|bến cảng|trung tâm thương mại|đường|phố|công viên|phòng khách|phòng ngủ|nhà bếp|bếp|đại sảnh|sảnh|phòng|cửa|nhà|công ty|cửa hàng|tiệm|tầng trên|tầng dưới|trên lầu|dưới lầu)/i.test(context);
    const activeEvents = asArray(state?.events)
        .filter(event => ACTIVE_EVENT_STATES.has(event?.status) && event?.visibility !== 'hidden');
    const hasContextualSceneAnchor = explicitSceneTransition || explicitPresentLocation || activeEvents.some(event => contextMatchScore(context, [
        event.title, event.place, ...(event.actors || []),
        event.summary, event.consequence, event.publicTrace,
    ]) > 0);
    return activeEvents
        .map(event => {
            const contextScore = contextMatchScore(context, [
                event.title, event.place, ...(event.actors || []),
                event.summary, event.consequence, event.publicTrace,
            ]);
            const actorOverlap = asArray(event.actors)
                .some(actor => personRefs.has(normalizedReference(actor)));
            const manualQueued = Boolean(event.delivery?.manualQueued);
            const direct = event.visibility === 'direct';
            const hasContactRoute = manualQueued || actorOverlap || contextScore > 0 || (direct && !hasContextualSceneAnchor);
            const score = contextScore
                + (actorOverlap ? 70 : 0)
                + (manualQueued ? 220 : 0)
                + (direct ? 180 : 0)
                + (event.visibility === 'known' ? 30 : event.visibility === 'trace' ? 10 : 0)
                + Number(event.updatedAt || event.startedAt || 0) / 1_000_000;
            return { event, score, hasContactRoute };
        })
        .filter(item => item.hasContactRoute && item.score >= policy.minimumScore)
        .sort((a, b) => b.score - a.score)
        .slice(0, policy.liveMaximum)
        .map(item => item.event);
}

export function selectDeliveryCandidates(state, settings = {}) {
    const maximum = {
        restrained: 1,
        balanced: 2,
        active: 3,
        克制: 1,
        均衡: 2,
        活跃: 3,
        'Tiết chế': 1,
        'Cân bằng': 2,
        'Sôi nổi': 3,
    }[settings.deliveryDensity] || 1;

    const manuallyQueued = state.events
        .filter(event => event.visibility !== 'hidden' && event.delivery?.manualQueued)
        .sort((a, b) => eventPriority(b) - eventPriority(a));
    const automatic = state.events
        .filter(event => (
            TERMINAL_EVENT_STATES.has(event.status)
            && event.visibility !== 'hidden'
            && event.delivery?.state === 'pending'
            && !event.delivery?.manualQueued
        ))
        .sort((a, b) => eventPriority(b) - eventPriority(a));
    return [...manuallyQueued, ...automatic].slice(0, Math.max(maximum, manuallyQueued.length));
}

export function recordDeliveryOffers(inputState, eventIds, {
    messageId = null,
    expireAfter = 3,
} = {}) {
    const state = deepClone(inputState);
    const ids = new Set(uniqueStrings(eventIds, 24).map(id => normalizeId(id, 'event')));

    for (const event of state.events) {
        if (!ids.has(event.id)) continue;
        if (event.delivery?.manualQueued) event.delivery.manualQueued = false;
        if (event.delivery?.state !== 'pending') continue;
        event.delivery.attempts = asInteger(event.delivery.attempts, 0, 0, 99) + 1;
        event.delivery.lastOfferedAt = state.clock.absoluteMinute;
        event.delivery.lastOfferedMessageId = messageId;

        if (event.delivery.attempts >= expireAfter && event.visibility !== 'direct') {
            event.delivery.state = 'expired';
            state.archive.unshift({
                id: makeId('archive'),
                eventId: event.id,
                at: state.clock.absoluteMinute,
                title: event.title,
                text: event.result || event.consequence || event.summary,
                visibility: event.visibility,
                deliveryState: 'expired',
            });
        }
    }

    state.updatedAt = nowIso();
    return trimState(state);
}

function selectRelevantPeople(state, recentText = '', maximum = 6) {
    const text = asString(recentText, '', 6000);
    return [...state.people]
        .map(person => ({
            person,
            score: (
                (text.includes(person.name) ? 100 : 0)
                + person.relevance * 10
                + (person.knowledge === 'known' ? 5 : 0)
                + person.updatedAt / 1_000_000
            ),
        }))
        .sort((a, b) => b.score - a.score)
        .slice(0, maximum)
        .map(item => item.person);
}

export function buildInjectionPackage(state, settings = {}, recentText = '', { contextText = recentText } = {}) {
    if (!settings.enabled) {
        return { text: '', authorityText: '', supportText: '', eventIds: [], liveInfluenceIds: [] };
    }

    // 注入只决定“当前镜头能拿到什么”，不决定后台模块是否存在或运行。
    const worldRunning = settings.worldSimulationEnabled !== false
        && settings.worldPromptInjection !== false;
    const injectBackground = worldRunning && settings.injectionWorldBackground !== false;
    const injectPeople = worldRunning && settings.injectionPeople !== false;
    const injectEvents = worldRunning && settings.injectionEvents !== false;
    const injectEchoes = worldRunning && settings.injectionEchoes !== false;
    const injectFacts = worldRunning && settings.injectionFacts !== false;
    const injectMemory = settings.memorySystemEnabled !== false
        && settings.memoryPromptInjection !== false
        && settings.injectionMemory !== false;
    const timeMode = worldRunning && ['full', 'anchor', 'off'].includes(settings.injectionTimeMode)
        ? settings.injectionTimeMode
        : (worldRunning ? 'full' : 'off');

    if (
        !injectBackground
        && !injectPeople
        && !injectEvents
        && !injectEchoes
        && !injectFacts
        && !injectMemory
        && timeMode === 'off'
    ) {
        return { text: '', authorityText: '', supportText: '', eventIds: [], liveInfluenceIds: [] };
    }

    const clock = formatWorldCalendar(state);
    const influencePolicy = deliveryDensityPolicy(settings.deliveryDensity);
    const injectionDecision = Number(state?.nextTurnInjection?.sourceRevision || 0) === Number(state?.revision || 0)
        ? normalizeNextTurnInjection(state.nextTurnInjection)
        : normalizeNextTurnInjection({});
    const requiredRefs = new Set(injectionDecision.requiredRefs);
    const suppressedRefs = new Set(injectionDecision.suppressRefs);
    const requiredPeople = asArray(state?.people).filter(person => requiredRefs.has(`person:${person.id}`));
    const people = injectPeople
        ? [...requiredPeople, ...selectRelevantPeople(state, recentText)]
            .filter(person => settings.recordPlayerCharacter !== false || !person?.isUser)
            .filter((person, index, all) => all.findIndex(item => item.id === person.id) === index)
            .slice(0, 8)
        : [];
    const rawContextReality = (injectEvents || injectFacts)
        ? selectContextRelevantReality(state, contextText, 9)
        : [];
    const eventContextText = `${recentText || ''}\n${contextText || ''}`.toLocaleLowerCase();
    const ongoingEvents = injectEvents
        ? asArray(state?.events)
            .filter(event => ACTIVE_EVENT_STATES.has(event?.status))
            .map(event => {
                const terms = [
                    event.title,
                    event.place,
                    ...(event.actors || []),
                ].map(value => String(value || '').trim().toLocaleLowerCase()).filter(value => value.length >= 2);
                let score = Number(event.updatedAt || event.startedAt || 0) / 1_000_000;
                if (terms.some(term => eventContextText.includes(term))) score += 100;
                if (event.delivery?.manualQueued) score += 80;
                if (requiredRefs.has(`event:${event.id}`)) score += 500;
                return { event, score };
            })
            .sort((a, b) => b.score - a.score)
            .slice(0, 6)
            .map(item => item.event)
        : [];
    const liveInfluences = injectEvents
        ? selectOngoingInfluenceCandidates(state, settings, { contextText: eventContextText, people })
        : [];
    const contextReality = rawContextReality.filter(item => (
        (item.kind === 'world-fact' && injectFacts)
        || (item.kind !== 'world-fact' && injectEvents)
    ));
    const contextFactKeys = new Set(
        contextReality
            .filter(item => item.kind === 'world-fact' && String(item.id || '').startsWith('fact:'))
            .map(item => String(item.id).slice(5)),
    );
    const authoritativeFacts = injectFacts
        ? [...asArray(state?.worldFacts).filter(fact => (
            requiredRefs.has(`fact:${fact.key}`)
            && ['current', 'persistent'].includes(fact.validity || 'current')
        )), ...selectRelevantWorldFacts(state, recentText, 12)]
            .filter(fact => !contextFactKeys.has(fact.key))
            .filter((fact, index, all) => all.findIndex(item => item.key === fact.key) === index)
            .slice(0, 14)
        : [];
    const deliveries = injectEchoes
        ? asArray(selectDeliveryCandidates(state, settings)).filter(event => (
            !suppressedRefs.has(`event:${event.id}`) || event.visibility === 'direct'
        ))
        : [];
    const deliveryIds = new Set(deliveries.map(event => event.id));
    const foregroundInfluences = liveInfluences.filter(event => !deliveryIds.has(event.id));
    const recalledMemory = injectMemory ? selectRelevantStoryMemory(state, recentText, {
        maximumFacts: 6,
        maximumClues: 3,
        maximumSummaries: 0,
        includeDigest: false,
    }) : { facts: [], clues: [] };
    const knownFacts = recalledMemory.facts.filter(fact => (
        ['known', 'direct'].includes(fact.visibility)
        && ['active', 'disputed'].includes(fact.status)
    ));
    const knownClues = recalledMemory.clues.filter(clue => (
        ['known', 'direct'].includes(clue.visibility)
        && !clue.archived
        && clue.status !== 'discarded'
    ));
    // Chat-derived summaries describe the written story, not omniscient NPC knowledge.
    const foregroundSummaries = injectMemory ? asArray(state?.storyMemory?.summaries)
        .filter(item => item?.hierarchyManaged && !item?.manual && item?.retentionState !== 'compacted') : [];
    // Filter before ranking so ineligible summaries cannot crowd out narrative recall.
    const narrativeArchive = injectMemory ? selectRelevantStoryMemory({
        ...state, storyMemory: { ...state.storyMemory, summaries: foregroundSummaries },
    }, recentText, {
        maximumFacts: 0, maximumClues: 0, maximumSummaries: 2, includeDigest: true,
    }) : { digest: null, summaries: [] };
    const indexedThrough = Number(state?.storyMemory?.indexedThroughMessageId ?? -1);
    const newestTurn = foregroundSummaries
        .filter(item => Number(item.level) === MEMORY_SUMMARY_LEVELS.DETAIL
            && (indexedThrough < 0 || Number(item.endMessageId) >= indexedThrough - 1))
        .sort((a, b) => Number(b.endMessageId) - Number(a.endMessageId))[0];
    const asksAboutBeginning = /最初|第一次|开头|刚开始|初到|初见|起初|一开始|开局|初次|ban đầu|lúc đầu|thoạt đầu|lần đầu|mở đầu|vừa mới bắt đầu|mới bắt đầu|lúc mới đến|mới đến|ngay từ đầu|khởi đầu/iu.test(recentText);
    const earliestTurns = asksAboutBeginning ? foregroundSummaries
        .filter(item => Number(item.level) === MEMORY_SUMMARY_LEVELS.DETAIL)
        .sort((a, b) => Number(a.startMessageId) - Number(b.startMessageId))
        .slice(0, 2)
        .map(item => ({ id: item.id, start_message_id: item.startMessageId,
            end_message_id: item.endMessageId, summary: item.summary })) : [];
    // Exact codes can remain in protected L0 after the digest has moved on.
    // A later "knock code" must not displace an earlier item-retrieval code.
    const asksForCode = /暗号|口令|密码|密语|敲门.{0,8}节奏|mật hiệu|ám hiệu|khẩu lệnh|mật khẩu|mật ngữ|gõ cửa.{0,12}nhịp|nhịp\s*gõ cửa/iu.test(recentText);
    const itemCodeSubject = recentText.match(
        /(?:取回|领回|(?:mật hiệu|ám hiệu|khẩu lệnh|mật khẩu|mật ngữ)\s*(?:để\s+)?(?:lấy lại|nhận lại|lấy về)\s+)([^，。；？?\n]{2,16}?)(?:(?:的)?(?:暗号|口令|密码|密语)|(?<=(?:mật hiệu|ám hiệu|khẩu lệnh|mật khẩu|mật ngữ)\s*(?:để\s+)?(?:lấy lại|nhận lại|lấy về)\s+[^，。；？?\n]{2,16})(?=\s*(?:là|[,.;:!?\n]|$)))/u,
    )?.[1]?.replace(/的$/u, '').trim() || '';
    const asksForKnockCode = /敲门.{0,8}(?:暗号|口令|密码|密语|节奏)|gõ cửa.{0,12}(?:mật hiệu|ám hiệu|khẩu lệnh|mật khẩu|mật ngữ|nhịp)|(?:mật hiệu|ám hiệu|khẩu lệnh|mật khẩu|mật ngữ|nhịp)\s*gõ cửa/iu.test(recentText);
    const codeCandidates = asksForCode ? foregroundSummaries
        .filter(item => Number(item.level) === MEMORY_SUMMARY_LEVELS.DETAIL
            && (/(?:暗号|口令|密码|密语|mật hiệu|ám hiệu|khẩu lệnh|mật khẩu|mật ngữ)/iu.test(item.summary)
                || (asksForKnockCode && /敲门.{0,8}节奏|gõ cửa.{0,12}nhịp|nhịp\s*gõ cửa/iu.test(item.summary))))
        .map(item => {
            const summary = String(item.summary || '');
            const hasExplicitValue = /(?:暗号|口令|密码|密语|mật hiệu|ám hiệu|khẩu lệnh|mật khẩu|mật ngữ)[^。；]{0,12}[“「『"'][^”」』"']+[”」』"']/iu.test(summary)
                || /(?:暗号|口令|密码|密语|mật hiệu|ám hiệu|khẩu lệnh|mật khẩu|mật ngữ)(?:设为|改为|是|为|叫|\s*(?:được đặt là|đặt là|được đổi thành|đổi thành|gọi là|là)\s)[^。；]{2,20}/iu.test(summary)
                || /敲门.{0,8}节奏(?:设为|改为|是|为)[^。；]{2,20}|(?:nhịp\s*gõ cửa|gõ cửa.{0,12}nhịp)\s*(?:được đặt là|đặt là|được đổi thành|đổi thành|là)\s[^。；]{2,20}/iu.test(summary);
            return { item, hasExplicitValue,
                score: memoryMatchScore(item, recentText, { referenceMessageId: indexedThrough })
                    + (hasExplicitValue ? 40 : 0) };
        })
        : [];
    const codeTopics = [
        ...(itemCodeSubject ? [item => String(item.summary || '').includes(itemCodeSubject)] : []),
        ...(asksForKnockCode ? [item => /敲门|gõ cửa/iu.test(item.summary)] : []),
    ];
    if (asksForCode && !codeTopics.length) codeTopics.push(() => true);
    const exactDetailTurns = codeTopics.flatMap(matchesTopic => {
        const selected = codeCandidates.filter(({ item }) => matchesTopic(item))
            .sort((a, b) => Number(b.hasExplicitValue) - Number(a.hasExplicitValue)
                || (/最新|现在|当前|mới nhất|bây giờ|hiện tại|hiện giờ/iu.test(recentText)
                    ? Number(b.item.startMessageId) - Number(a.item.startMessageId) : 0)
                || b.score - a.score || a.item.startMessageId - b.item.startMessageId)[0]?.item;
        return selected ? [{ id: selected.id, start_message_id: selected.startMessageId,
            end_message_id: selected.endMessageId, summary: selected.summary }] : [];
    }).filter((item, index, items) => items.findIndex(other => other.id === item.id) === index);
    const asksCurrentHolder = /(?:当前|现在|最新).{0,20}(?:保管|持有|归属|由谁)|(?:谁|由谁).{0,10}(?:保管|持有)|(?:^|[\s,.?!])(?:ai|người nào)\s.{0,20}?(?:đang giữ|cầm giữ|nắm giữ|cất giữ|bảo quản|sở hữu|giữ)|(?:hiện tại|bây giờ|hiện giờ|mới nhất).{0,30}(?:đang giữ|nắm giữ|cất giữ|bảo quản|sở hữu|thuộc về)/iu.test(recentText);
    const holderChangeTurns = asksCurrentHolder ? knownFacts
        .filter(fact => /持有|保管|归属|nắm giữ|cầm giữ|đang giữ|cất giữ|giữ hộ|bảo quản|sở hữu|thuộc về/iu.test(String(fact.predicate || ''))
            && String(fact.subject || '').length >= 2
            && recentText.includes(fact.subject))
        .map(fact => foregroundSummaries.find(item => Number(item.level) === MEMORY_SUMMARY_LEVELS.DETAIL
            && Number(item.startMessageId) === Number(fact.source_message_id)
            && Number(item.endMessageId) === Number(fact.source_message_id)))
        .filter(Boolean).slice(0, 1)
        .map(item => ({ id: item.id, start_message_id: item.startMessageId,
            end_message_id: item.endMessageId, summary: item.summary })) : [];
    const rankedArchiveSummaries = [...narrativeArchive.summaries]
        .sort((a, b) => Number(a.memory_role === 'anchor') - Number(b.memory_role === 'anchor')
            || Number(a.start_message_id) - Number(b.start_message_id));
    const recallLimit = (asksAboutBeginning ? 4 : 3) + (exactDetailTurns.length ? 1 : 0)
        + (holderChangeTurns.length ? 1 : 0);
    const pinned = [...earliestTurns, ...exactDetailTurns, ...holderChangeTurns]
        .filter((item, index, items) => item.id !== newestTurn?.id
            && items.findIndex(other => other.id === item.id) === index);
    const ranked = rankedArchiveSummaries.filter(item => item.id !== newestTurn?.id
        && !pinned.some(other => other.id === item.id));
    const latest = newestTurn ? { id: newestTurn.id, start_message_id: newestTurn.startMessageId,
        end_message_id: newestTurn.endMessageId, summary: newestTurn.summary } : null;
    const remaining = Math.max(0, recallLimit - pinned.length - (latest ? 1 : 0));
    const storyRecall = asksAboutBeginning
        ? [...pinned, ...ranked.slice(0, remaining), ...(latest ? [latest] : [])]
        : [...(latest ? [latest] : []), ...pinned, ...ranked.slice(0, remaining)];
    const sceneTiming = {
        strict: 'Chỉ hé lộ lúc chuyển cảnh, khoảng trống hoặc khi nhân vật đã tự nhiên tiếp xúc với ảnh hưởng; nhưng hậu quả đã đụng trực tiếp tới hành động trước mắt thì không được bỏ qua với lý do “cảnh không phù hợp”.',
        smart: 'Thông tin thứ yếu có thể hoãn lại; kết quả ảnh hưởng trực tiếp tới hành động trước mắt thì nên tự nhiên đi vào ngay bây giờ.',
        open: 'Chỉ cần có con đường tiếp xúc tự nhiên thì nên để một thay đổi liên quan có thể cảm nhận được đi vào; đừng đọc thông báo kiểu nền.',
    }[settings.sceneTiming] || 'Chỉ hé lộ vào thời điểm tự nhiên; hậu quả khách quan đã ảnh hưởng trực tiếp tới hành động trước mắt thì không được bỏ qua.';

    const authorityLines = ['<world_backstage_state>'];
    const supportLines = ['<world_backstage_support>'];

    if (injectBackground) {
        if (state.world?.background) {
            authorityLines.push(
                'Ràng buộc cơ bản của bối cảnh thế giới (người dùng tự thiết lập, không phải gợi ý cốt truyện động; chính văn không được tùy tiện sửa):',
                modelText(state.world.background, 1600),
                'Quy tắc bối cảnh định nghĩa thế giới này cho phép điều gì; nếu sự thật thế giới có thẩm quyền đã xảy ra sau đó thay đổi rõ ràng một “trạng thái” nào đó, lấy sự thật mới nhất làm chuẩn, nhưng không được vi phạm quy tắc nền tảng trong bối cảnh mà không có nhân quả.',
            );
        }
        authorityLines.push(`Trạng thái tổng thể: ${state.world.title}；${state.world.detail}`);
    }

    authorityLines.push(...buildClockAuthorityLines(state, clock, timeMode));

    if (people.length) {
        if (state.needsReconciliation) {
            authorityLines.push(
                'Trạng thái nhân vật từ bản lưu cũ (đang chờ một lần hiệu chỉnh lại ở tiền cảnh):',
                'Các trạng thái này đến từ bản ghi nền trước khi nâng cấp; nếu mâu thuẫn với sự thật rõ ràng trong chính văn gần nhất, lấy chính văn làm chuẩn. Sau lần suy diễn thế giới thành công đầu tiên sẽ được kết toán lại thành trạng thái có thẩm quyền.',
            );
        } else {
            authorityLines.push(
                'Trạng thái có thẩm quyền hiện tại của nhân vật (phải giữ tính liên tục; không có nghĩa là nhân vật chính biết toàn bộ thông tin nền):',
                'Nếu chính văn không ghi rõ việc di chuyển, rời đi, quay lại hay thay đổi trạng thái mới, không được vô cớ đặt nhân vật vào vị trí mâu thuẫn với ở đây; nếu chính văn ghi rõ đã có thay đổi mới, thì tiếp tục theo thay đổi mới, và 世界背面 sẽ ghi ngược lại.',
            );
        }
        for (const person of people) {
            const boundary = person.knowledge === 'known' ? 'Có thể biết' : 'Hậu trường';
            authorityLines.push(`- ${person.name}｜${person.location}｜${person.action}｜${boundary}`);
            const knownViews = [
                ...asArray(person.knownEventViews).map(view => ({
                    kind: 'Sự kiện',
                    text: modelText(view?.summary, 220),
                    certainty: view?.certainty === 'suspected' ? 'Nghi ngờ' : 'Xác nhận',
                    updatedAt: Number(view?.updatedAt || view?.learnedAtMessageId || 0),
                })),
                ...asArray(person.knownFactBeliefs).map(belief => ({
                    kind: 'Sự thật',
                    text: modelText(belief?.value, 220),
                    certainty: belief?.certainty === 'suspected' ? 'Nghi ngờ' : 'Xác nhận',
                    updatedAt: Number(belief?.updatedAt || belief?.learnedAtMessageId || 0),
                })),
            ]
                .filter(item => item.text)
                .sort((a, b) => b.updatedAt - a.updatedAt)
                .slice(0, 3);
            if (knownViews.length) {
                authorityLines.push(
                    `  · ${person.name} bản thân đã biết/tin: ${knownViews.map(item => `[${item.certainty}${item.kind}] ${item.text}`).join('；')}`,
                );
            }
        }
        if (people.some(person => (
            asArray(person.knownEventViews).length || asArray(person.knownFactBeliefs).length
        ))) {
            authorityLines.push('Dòng nhận thức của nhân vật là phiên bản đóng băng mà nhân vật đó đã có được: chỉ cho phép nhân vật tương ứng dựa vào đó để phán đoán và hành động; “nghi ngờ” không được viết thành xác nhận, và không được dùng những thay đổi về sau của sự kiện nền để lén cập nhật phiên bản mà nhân vật chưa biết lại.');
        }
    }

    if (ongoingEvents.length) {
        authorityLines.push(
            'Các sự kiện đang diễn ra / Mạch ngầm liên quan hiện tại (chúng tồn tại khách quan trong thế giới, nhưng không có nghĩa là bất kỳ nhân vật nào đã biết):',
        );
        for (const event of ongoingEvents) {
            authorityLines.push(
                `- [${event.id}] ${event.title}｜${event.place}｜${event.summary || event.expectedResult || event.cause || 'Đang phát triển'}｜mức hé lộ=${event.visibility}`,
            );
        }
        authorityLines.push('Các sự kiện đang diễn ra này đều ràng buộc tính liên tục của thế giới; trong đó chỉ những mục được liệt kê bên dưới là “ứng viên ảnh hưởng tại hiện trường” mới có nghĩa vụ tiếp nhận trong chính văn ở lượt này. Sự kiện hidden dù có liên quan cũng không được làm lộ nguyên nhân hậu trường hay khiến nhân vật không biết chuyện đột nhiên biết.');
    }

    if (contextReality.length) {
        authorityLines.push(
            'Hiện thực thế giới gắn với hành động hiện tại (không phải nhiệm vụ đọc tin tức, mà là môi trường khách quan nơi nhân vật đang sống):',
            'Chỉ cần địa điểm, lịch trình, tổ chức, ngành nghề hay hành động mà người dùng hoặc nhân vật hiện đang nhắc tới bị những hiện thực này ảnh hưởng trực tiếp, chính văn lượt này phải tôn trọng điều đó. Thông tin có thể tra cứu công khai chỉ được nhân vật chủ động nhắc nhở hoặc dựa vào đó để điều chỉnh khi nhân vật có thói quen/kênh hợp lý để biết; khi nhân vật chưa biết, đừng nhồi nhét tri thức, mà hãy để hậu quả khách quan tự nhiên thể hiện khi thực sự tiếp xúc. Tuyệt đối không được quyết định thay người chơi rằng họ đã xem tin tức hoặc đã biết.',
        );
        for (const reality of contextReality) {
            const sourceLabel = {
                'public-event': reality.temporalState === 'upcoming' ? 'Thông báo công khai về việc sắp xảy ra' : 'Sự kiện thế giới công khai hiện tại',
                'world-pulse': 'Môi trường thế giới hiện tại',
                'world-fact': reality.temporalState === 'historical'
                    ? 'Sự thật lịch sử được cuộc hội thoại hiện tại nhắc lại rõ ràng'
                    : reality.temporalState === 'upcoming'
                        ? 'Sự thật tương lai liên quan đến kế hoạch hiện tại'
                        : 'Sự thật thế giới có thẩm quyền hiện tại',
            }[reality.kind] || 'Hiện thực thế giới';
            authorityLines.push(`- ${sourceLabel}｜${reality.label}：${reality.state}`);
        }
        authorityLines.push(
            'Ví dụ nơi đến đang mưa bão/phong tỏa đường, chính văn không được viết như bình thường là trời quang đường thông; nhân vật biết chuyện và sẽ để ý việc này có thể tự nhiên nhắc mang ô, đổi tuyến đường hoặc điều chỉnh kế hoạch, nhân vật không biết thì có thể đến nơi mới phát hiện. Giữ cá tính nhân vật, đừng máy móc lặp lại các câu trên.',
        );
    }

    if (authoritativeFacts.length) {
        authorityLines.push(
            'Sự thật thế giới đã kết toán (đây là trạng thái khách quan của thế giới, không phải gợi ý cốt truyện tùy chọn; phải giữ nhất quán, nhưng nhân vật có biết hay không vẫn phải xét ranh giới nhận thức):',
        );
        for (const fact of authoritativeFacts) {
            const subject = fact.subject || fact.subjectId || 'Thế giới';
            authorityLines.push(`- ${subject}｜${fact.field}：${fact.value}｜mức hé lộ=${fact.visibility}`);
        }
        authorityLines.push('Độ hé lộ chỉ quyết định cách những sự thật này đi vào ống kính, không quyết định chúng có tồn tại hay không. Sự thật ẩn có thể ràng buộc tính liên tục, nhưng không được vì thế mà khiến nhân vật không biết chuyện đột nhiên biết.');
    }

    if (narrativeArchive.digest?.text || storyRecall.length) {
        supportLines.push('Ký ức cốt truyện của chính văn trước đó (số tầng biểu thị thứ tự trước sau, thay đổi rõ ràng về sau ghi đè trạng thái cũ; không có nghĩa là mọi người tại hiện trường đều biết, cũng không yêu cầu diễn lại tình tiết cũ):');
        if (asksAboutBeginning) supportLines.push('Khi đối chiếu trải nghiệm lúc mở đầu, hãy đọc từng mục theo tầng, giữ lại các hành động song song trong cùng một đoạn và thứ tự trước sau của chúng; chi tiết không được viết ra thì giữ là chưa biết.');
        const digestAlreadyShown = storyRecall.some(item => item.summary === narrativeArchive.digest?.text);
        if (narrativeArchive.digest?.text && !asksAboutBeginning && !digestAlreadyShown)
            supportLines.push(`- Diễn biến liên tục: ${modelText(narrativeArchive.digest.text, 620)}`);
        for (const item of storyRecall) {
            supportLines.push(`- Tầng ${item.start_message_id}—${item.end_message_id}: ${modelText(item.summary, 330)}`);
        }
        if (narrativeArchive.digest?.text && asksAboutBeginning && !digestAlreadyShown)
            supportLines.push(`- Diễn biến liên tục: ${modelText(narrativeArchive.digest.text, 620)}`);
        supportLines.push('Tiếp nối lời hứa, quan hệ, đồ vật và những câu hỏi đang chờ hồi đáp của nhân vật; động cơ và chân tướng ẩn vẫn phải tuân thủ ranh giới nhận thức của nhân vật.');
    }

    if (knownFacts.length || knownClues.length) {
        supportLines.push('Ký ức dài hạn liên quan đến cảnh hiện tại và nhân vật đã đủ tư cách để biết:');
        for (const fact of knownFacts) {
            const qualifier = fact.status === 'disputed' ? ' (cách nói còn tranh cãi, không được coi là kết luận)' : '';
            supportLines.push(`- Sự thật｜${fact.subject || fact.key}｜${fact.predicate || 'Thông tin liên quan'}：${fact.value}${qualifier}`);
        }
        for (const clue of knownClues) {
            supportLines.push(`- Manh mối｜${clue.title}：${clue.text}`);
        }
        supportLines.push('Chỉ dùng để duy trì hồi ức, lời hứa và sự hô ứng trước sau; không được viết bổ sung ký ức ẩn chưa được liệt kê thành tri thức của nhân vật.');
    }

    if (foregroundInfluences.length || deliveries.length) {
    supportLines.push(`Cường độ tiếp nhận vào chính văn (${influencePolicy.label}）：${influencePolicy.obligation}`);
    supportLines.push(`Thời điểm hé lộ: ${sceneTiming}`);
    supportLines.push('Cường độ chỉ thay đổi mức độ tích cực đưa hậu quả liên quan vào chính văn, không làm tăng mức nghiêm trọng của sự kiện; cấm vì mức cường độ mà tạo sự trùng hợp, leo thang thảm họa, làm lộ nguyên nhân hậu trường hay quyết định hành động thay người chơi. Khi nhân vật không biết nguyên nhân, chỉ viết những hậu quả bề mặt mà nhân vật thực sự cảm nhận được.');
}

if (foregroundInfluences.length) {
    supportLines.push('Các thay đổi thế giới đang diễn ra mà ống kính hiện tại đã có con đường tiếp xúc thực tế:');
    for (const event of foregroundInfluences) {
        const route = event.delivery?.route || event.consequence || event.summary || event.expectedResult || 'Đang ảnh hưởng tới môi trường hiện tại';
        supportLines.push(`- [${event.id}] ${event.title}：${modelText(route, 180)}（${event.visibility}; đang diễn ra)`);
    }
}

    if (deliveries.length) {
        supportLines.push('Các sự kiện có thể hé lộ tự nhiên trong lượt này do người dùng chỉ định hoặc hệ thống chọn:');
        for (const event of deliveries) {
            if (event.delivery?.mode === 'soft-observation') {
                supportLines.push(
                    `- [${event.id}] Quan sát hậu trường về nhân vật (chỉ là manh mối tùy chọn để hiểu, không phải sự kiện đã xảy ra): ${event.summary}`,
                );
                continue;
            }
            const route = event.delivery.route || event.result || event.consequence || event.summary;
            const request = event.delivery?.manualQueued ? 'Người dùng yêu cầu ưu tiên hé lộ ở lượt tiếp theo' : 'Ứng viên của hệ thống';
            supportLines.push(`- [${event.id}] ${event.title}：${route}（${event.visibility}；${request}）`);
        }
        if (deliveries.some(event => event.delivery?.mode === 'soft-observation')) {
            supportLines.push('Quan sát hậu trường chỉ có thể giúp hiểu động cơ và cảm xúc của nhân vật lúc đó. Không được bê nguyên từng câu độc thoại, không được tuyên bố trực tiếp nó là sự thật, hành động hay sự kiện mới; chỉ khi cảnh hiện tại tự nhiên chạm tới nhân vật và chủ đề đó, mới có thể để lại sự hô ứng nhẹ qua lời nói và hành động phù hợp với nhân thiết.');
        }
        supportLines.push('Chỉ coi những kết quả thực sự được viết vào chính văn, được nhân vật cảm nhận hoặc để lại dấu vết nhìn thấy được là đã tiếp nhận; đừng tuyên bố “nền đã chuyển giao”.');
    }

    if (authorityLines.length > 1) {
        authorityLines.push('Cấm nhắc tới “世界背面”, bảng trạng thái, khối chèn hay độc thoại hậu trường.');
        authorityLines.push('</world_backstage_state>');
    }
    const supportHasContent = supportLines.length > 1;
    if (supportHasContent) {
        supportLines.push('Thông tin phụ trợ chỉ dùng để tiếp nối tự nhiên và giữ tính liên tục dài hạn; không được ghi đè trạng thái thế giới có thẩm quyền ở trên.');
        supportLines.push('</world_backstage_support>');
    }

    const compactLayer = (sourceLines, maximumCharacters, closingTag) => {
        if (sourceLines.length <= 1) return { text: '', omitted: 0 };
        const kept = [];
        let usedCharacters = 0;
        for (const line of sourceLines) {
            const addition = line.length + (kept.length ? 1 : 0);
            if (usedCharacters + addition > maximumCharacters) break;
            kept.push(line);
            usedCharacters += addition;
        }
        const originalKeptCount = kept.length;
        if (originalKeptCount < sourceLines.length) {
            if (kept.at(-1) === closingTag) kept.pop();
            const notice = '(Các thông tin ít liên quan còn lại đã được nén và lược bỏ, cấm tự bổ sung.)';
            while (kept.length > 1 && [...kept, notice, closingTag].join('\n').length > maximumCharacters) {
                kept.pop();
            }
            kept.push(notice, closingTag);
        }
        return {
            text: kept.join('\n'),
            omitted: Math.max(0, sourceLines.length - originalKeptCount),
        };
    };

    // Reserve room for continuity even when the live world state is crowded.
    const supportReserve = supportHasContent ? 1600 : 0;
    const authority = compactLayer(authorityLines, 4200 - supportReserve - 2, '</world_backstage_state>');
    const availableSupport = Math.min(2600, 4200 - authority.text.length - 2);
    const support = supportHasContent && availableSupport >= 120
        ? compactLayer(supportLines, availableSupport, '</world_backstage_support>')
        : { text: '', omitted: 0 };

    return {
        text: [support.text, authority.text].filter(Boolean).join('\n\n'),
        authorityText: authority.text,
        supportText: support.text,
        eventIds: deliveries.map(event => event.id),
        liveInfluenceIds: foregroundInfluences.map(event => event.id),
        omittedLines: authority.omitted + support.omitted,
    };
}

function modelText(value, maximum) {
    return asString(value, '', maximum);
}

function modelNarrativeText(value, { maximum = 8000, tail = 5000 } = {}) {
    const text = typeof value === 'string' ? value.trim() : '';
    if (!text || text.length <= maximum) return text;
    const marker = '\n...[Đoạn giữa chính văn đã được nén, giữ lại phần đầu và cuối để xác định sự thật, trạng thái cuối và thời gian]...\n';
    const tailBudget = Math.min(Math.max(1200, tail), maximum - marker.length - 800);
    const headBudget = Math.max(800, maximum - marker.length - tailBudget);
    return text.slice(0, headBudget) + marker + text.slice(-tailBudget);
}

export function planMemoryRollup(state) {
    const memory = normalizeStoryMemory(state?.storyMemory, state?.clock?.absoluteMinute || 0);
    for (const sourceLevel of [MEMORY_SUMMARY_LEVELS.CHAPTER, MEMORY_SUMMARY_LEVELS.STAGE, MEMORY_SUMMARY_LEVELS.DETAIL]) {
        const threshold = MEMORY_ROLLUP_THRESHOLDS[sourceLevel];
        const candidates = memory.summaries
            .filter(summary => (
                summary.hierarchyManaged
                && !summary.manual
                && Number(summary.level) === sourceLevel
                && summary.retentionState !== 'compacted'
                && !summary.parentId
            ))
            .sort((a, b) => (
                Number(a.startMessageId || 0) - Number(b.startMessageId || 0)
                || Number(a.endMessageId || 0) - Number(b.endMessageId || 0)
            ));
        if (candidates.length < threshold) continue;
        const sources = candidates.slice(0, threshold);
        return {
            sourceLevel,
            targetLevel: Math.min(MEMORY_SUMMARY_LEVELS.LONG_TERM, sourceLevel + 1),
            threshold,
            sourceSummaryIds: sources.map(summary => summary.id),
            summaries: sources,
        };
    }
    return null;
}

export function buildMemoryRollupPrompt(state, plan, { compact = false } = {}) {
    const sourceLevel = asInteger(plan?.sourceLevel, 0, 0, 2);
    const targetLevel = Math.min(3, sourceLevel + 1);
    const sourceIds = new Set(asArray(plan?.sourceSummaryIds));
    const memory = normalizeStoryMemory(state?.storyMemory, state?.clock?.absoluteMinute || 0);
    const sources = memory.summaries
        .filter(summary => sourceIds.has(summary.id))
        .sort((a, b) => Number(a.startMessageId) - Number(b.startMessageId));
    if (!sources.length) throw new Error('Không có ký ức tầng dưới nào để nén');
    const levelNames = ['Đoạn một lượt', 'Tóm tắt giai đoạn', 'Tổng kết chương', 'Trải nghiệm dài hạn'];
    const lengthRule = compact
        ? 'summary giới hạn trong 180—320 chữ, chỉ giữ lại những thay đổi thực sự ảnh hưởng tới việc hiểu về sau.'
        : targetLevel === MEMORY_SUMMARY_LEVELS.STAGE
            ? 'summary khoảng 220—420 chữ.'
            : targetLevel === MEMORY_SUMMARY_LEVELS.CHAPTER
                ? 'summary khoảng 320—600 chữ.'
                : 'summary khoảng 420—800 chữ, nhấn mạnh quan hệ lâu dài, mục tiêu, bước ngoặt và các manh mối chưa kết thúc.';
    const payload = sources.map(summary => ({
        id: summary.id,
        level: summary.level,
        title: summary.title,
        summary: modelText(summary.summary, 1200),
        start_message_id: summary.startMessageId,
        end_message_id: summary.endMessageId,
        people: summary.people,
        locations: summary.locations,
        tags: summary.tags,
    }));
    return [
        'Bạn là người nén ký ức dài hạn của “世界背面”. Ở đây chỉ nén hồ sơ, không viết tiếp cốt truyện, không suy diễn tương lai, không sửa bất kỳ sự thật nào. Mọi nội dung văn bản hãy viết bằng tiếng Việt.',
        `Hãy nén ${sources.length} mục ${levelNames[sourceLevel]} dưới đây thành 1 mục ${levelNames[targetLevel]}。`,
        'Yêu cầu:',
        '1. Chỉ được dùng các tóm tắt tầng dưới đã cho; cấm viết bổ sung tình tiết không tồn tại.',
        '2. Ưu tiên giữ lại thay đổi quan hệ, mục tiêu dài hạn, lời hứa, bước ngoặt then chốt, xung đột kéo dài, đồ vật quan trọng và vấn đề chưa giải quyết. Hành động thông thường, bầu không khí lặp lại và các nhánh phụ đã mất hiệu lực có thể bỏ đi.',
        '3. Tóm tắt mới là chỉ mục dài hạn tầng trên. source_summary_ids và phạm vi tin nhắn sẽ được giữ lại, nhưng các tóm tắt tầng dưới thông thường có thể bị nén thành chỗ giữ chỗ gọn nhẹ sau khi tạo tầng trên; vì vậy những chi tiết thực sự ảnh hưởng tới việc hiểu về sau phải được đưa vào tầng trên, các nhánh phụ không quan trọng có thể chủ động bỏ qua.',
        '4. people / locations / tags chỉ giữ lại các mục quan trọng thực sự xuyên suốt đoạn này.',
        `5. ${lengthRule}`,
        '6. Chỉ trả về JSON hợp lệ, không dùng code fence và không giải thích.',
        '',
        `Tầng nguồn: L${sourceLevel} ${levelNames[sourceLevel]}`,
        `Tầng đích: L${targetLevel} ${levelNames[targetLevel]}`,
        'Ký ức tầng dưới:',
        JSON.stringify(payload),
        '',
        'Cấu trúc trả về:',
        JSON.stringify({
            summary_rollup: {
                title: '',
                summary: '',
                people: [],
                locations: [],
                tags: [],
            },
        }),
    ].join('\n');
}

export function applyMemoryRollupResult(inputState, rawPayload, plan = {}) {
    const state = deepClone(inputState);
    state.storyMemory = normalizeStoryMemory(state.storyMemory, state.clock.absoluteMinute);
    const sourceIds = new Set(asArray(plan?.sourceSummaryIds));
    const sources = state.storyMemory.summaries
        .filter(summary => sourceIds.has(summary.id))
        .sort((a, b) => Number(a.startMessageId) - Number(b.startMessageId));
    if (!sources.length) return trimState(state);
    if (sources.some(summary => summary.parentId)) return trimState(state);
    const sourceLevel = asInteger(plan?.sourceLevel, sources[0]?.level ?? 0, 0, 2);
    if (sources.some(summary => Number(summary.level) !== sourceLevel)) return trimState(state);
    const raw = rawPayload?.summary_rollup ?? rawPayload?.summaryRollup ?? rawPayload;
    const summaryText = asString(raw?.summary, '', 1800);
    if (!summaryText) return trimState(state);
    const targetLevel = Math.min(MEMORY_SUMMARY_LEVELS.LONG_TERM, sourceLevel + 1);
    const first = sources[0];
    const last = sources.at(-1);
    const id = normalizeId(
        raw?.id || `summary_L${targetLevel}_${first.startMessageId}_${last.endMessageId}_${hashText(sources.map(item => item.id).join('|'))}`,
        'summary',
    );
    const existing = state.storyMemory.summaries.find(summary => summary.id === id);
    const normalized = normalizeStorySummary({
        ...raw,
        id,
        summary: summaryText,
        level: targetLevel,
        hierarchy_managed: true,
        source_summary_ids: sources.map(summary => summary.id),
        start_message_id: first.startMessageId,
        end_message_id: last.endMessageId,
        important: sources.some(summary => summary.important),
    }, existing);
    if (existing) Object.assign(existing, normalized);
    else state.storyMemory.summaries.push(normalized);
    for (const source of sources) source.parentId = normalized.id;
    compactRolledUpSources(state, normalized, sources, {
        sourceMessageId: last.endMessageId,
    });
    state.storyMemory.lastMetabolismMessageId = Math.max(
        Number(state.storyMemory.lastMetabolismMessageId || -1),
        Number(last.endMessageId || -1),
    );
    state.revision = asInteger(state.revision, 0, 0) + 1;
    state.updatedAt = nowIso();
    appendAudit(state, {
        type: 'memory_rollup',
        text: `Nén ký ức hoàn tất · L${sourceLevel} → L${targetLevel}`,
        reason: `${sources.length} trải nghiệm tầng dưới đã được lập chỉ mục tầng trên có thể truy vết`,
    });
    return trimState(state);
}

function memoryTerms(item) {
    return uniqueStrings([
        item?.subject || '',
        item?.predicate || '',
        ...(item?.people || []),
        ...(item?.locations || []),
        ...(item?.events || []),
        ...(item?.tags || []),
    ], 40).filter(term => term.length >= 2);
}

function memorySearchText(item) {
    return [
        item?.key,
        item?.subject,
        item?.predicate,
        item?.value,
        item?.title,
        item?.text,
        item?.summary,
        ...memoryTerms(item),
    ].filter(Boolean).join(' ').toLocaleLowerCase();
}

function memoryBigrams(value) {
    const normalized = String(value || '')
        .toLocaleLowerCase()
        .replace(/[\s\p{P}\p{S}]+/gu, '');
    const result = new Set();
    for (let index = 0; index < normalized.length - 1 && result.size < 180; index += 1) {
        result.add(normalized.slice(index, index + 2));
    }
    return result;
}

function memoryMatchScore(item, query, {
    referenceMessageId = 0,
} = {}) {
    const normalizedQuery = String(query || '').toLocaleLowerCase();
    let score = Number(item?.importance || 0) * 5;
    for (const term of memoryTerms(item)) {
        if (normalizedQuery.includes(term.toLocaleLowerCase())) score += 18;
    }
    const queryBigrams = memoryBigrams(normalizedQuery);
    if (queryBigrams.size) {
        const itemBigrams = memoryBigrams(memorySearchText(item));
        let overlap = 0;
        for (const term of queryBigrams) {
            if (itemBigrams.has(term)) overlap += 1;
        }
        score += Math.min(20, overlap * 2);
    }
    if (item?.status === 'open') score += 8;
    if (item?.status === 'developing' || item?.status === 'echoed') score += 6;
    if (item?.status === 'triggered') score += 9;
    if (item?.status === 'active') score += 7;
    if (item?.status === 'disputed') score += 2;
    if (item?.confidence === 'high') score += 4;
    if (item?.confidence === 'low') score -= 3;

    const sourceMessageId = Number(
        item?.sourceMessageId
        ?? item?.endMessageId
        ?? item?.throughMessageId
        ?? referenceMessageId,
    );
    const age = Math.max(0, Number(referenceMessageId || 0) - sourceMessageId);
    const decay = Math.min(18, Math.floor(Math.log2(1 + age / 12) * 4));
    score -= Number(item?.importance || 1) >= 3 ? Math.floor(decay / 3) : decay;
    return score;
}

export function selectRelevantStoryMemory(state, narrativeText = '', {
    maximumFacts = 10,
    maximumClues = 8,
    maximumSummaries = 4,
    includeDigest = true,
} = {}) {
    const memory = normalizeStoryMemory(state?.storyMemory, state?.clock?.absoluteMinute || 0);
    const referenceMessageId = Math.max(
        Number(state?.lastCommit?.messageId || 0),
        Number(memory.indexedThroughMessageId || 0),
    );
    const facts = memory.facts
        .filter(fact => ['active', 'disputed'].includes(fact.status))
        .map(fact => ({
            fact,
            score: memoryMatchScore(fact, narrativeText, { referenceMessageId }),
        }))
        .sort((a, b) => (
            b.score - a.score
            || Number(b.fact.updatedAt) - Number(a.fact.updatedAt)
        ))
        .slice(0, Math.max(0, maximumFacts))
        .map(({ fact, score }) => ({
            id: fact.id,
            key: fact.key,
            subject: fact.subject,
            predicate: fact.predicate,
            value: modelText(fact.value, 420),
            people: fact.people,
            locations: fact.locations,
            tags: fact.tags,
            status: fact.status,
            confidence: fact.confidence,
            importance: fact.importance,
            visibility: fact.visibility,
            source_message_id: fact.sourceMessageId,
            source_swipe_id: fact.sourceSwipeId,
            recall_score: score,
        }));
    const clues = memory.clues
        .filter(clue => !clue.archived && !['resolved', 'discarded'].includes(clue.status))
        .map(clue => ({
            clue,
            score: memoryMatchScore(clue, narrativeText, { referenceMessageId }),
        }))
        .sort((a, b) => (
            b.score - a.score
            || Number(b.clue.updatedAt) - Number(a.clue.updatedAt)
        ))
        .slice(0, Math.max(0, maximumClues))
        .map(({ clue }) => ({
            id: clue.id,
            title: modelText(clue.title, 100),
            text: modelText(clue.text, 360),
            people: clue.people,
            locations: clue.locations,
            events: clue.events,
            tags: clue.tags,
            status: clue.status,
            importance: clue.importance,
            visibility: clue.visibility,
            source_message_id: clue.sourceMessageId,
            source_swipe_id: clue.sourceSwipeId,
            resolution: modelText(clue.resolution, 260),
        }));
    const scoredSummaries = memory.summaries
        .filter(summary => summary.retentionState !== 'compacted')
        .map(summary => ({
            summary,
            score: memoryMatchScore(summary, narrativeText, { referenceMessageId }),
        }));
    const anchors = [];
    for (const level of [MEMORY_SUMMARY_LEVELS.LONG_TERM, MEMORY_SUMMARY_LEVELS.CHAPTER]) {
        const newest = scoredSummaries
            .filter(item => Number(item.summary.level) === level)
            .sort((a, b) => Number(b.summary.endMessageId) - Number(a.summary.endMessageId))[0];
        if (newest) anchors.push(newest);
    }
    if (!anchors.length) {
        const newestStage = scoredSummaries
            .filter(item => Number(item.summary.level) === MEMORY_SUMMARY_LEVELS.STAGE)
            .sort((a, b) => Number(b.summary.endMessageId) - Number(a.summary.endMessageId))[0];
        if (newestStage) anchors.push(newestStage);
    }
    const anchorIds = new Set(anchors.map(item => item.summary.id));
    const recalled = scoredSummaries
        .filter(item => !anchorIds.has(item.summary.id))
        .sort((a, b) => (
            b.score - a.score
            || Number(b.summary.level || 0) - Number(a.summary.level || 0)
            || b.summary.endMessageId - a.summary.endMessageId
        ))
        .slice(0, Math.max(0, maximumSummaries));
    const summaries = [...anchors, ...recalled]
        .map(({ summary }, index) => ({
            id: summary.id,
            title: modelText(summary.title, 100),
            summary: modelText(summary.summary, Number(summary.level) >= 2 ? 900 : 720),
            level: summary.level,
            memory_role: index < anchors.length ? 'anchor' : 'recall',
            parent_id: summary.parentId || '',
            source_summary_ids: summary.sourceSummaryIds,
            start_message_id: summary.startMessageId,
            end_message_id: summary.endMessageId,
            people: summary.people,
            locations: summary.locations,
            tags: summary.tags,
        }));

    return {
        indexed_through_message_id: memory.indexedThroughMessageId,
        digest: includeDigest && memory.digest.text
            ? {
                text: modelText(memory.digest.text, 1600),
                through_message_id: memory.digest.throughMessageId,
                people: memory.digest.people,
                locations: memory.digest.locations,
                tags: memory.digest.tags,
            }
            : null,
        facts,
        summaries,
        clues,
    };
}


export function buildWorldBootstrapPrompt(state, {
    messages = [],
    userName = '',
    playerIdentityAnchor = '',
    recordPlayerCharacter = true,
    compact = false,
} = {}) {
    const compactMode = Boolean(compact);
    const normalizedMessages = asArray(messages)
        .map(message => ({
            id: asInteger(message?.id, 0, 0),
            swipe: asInteger(message?.swipe, 0, 0),
            role: message?.role === 'user' ? 'user' : 'assistant',
            content: modelText(
                message?.content,
                compactMode
                    ? (message?.role === 'user' ? 2200 : 3800)
                    : (message?.role === 'user' ? 3600 : 6200),
            ),
        }))
        .filter(message => message.content);
    const startMessageId = normalizedMessages[0]?.id ?? 0;
    const endMessageId = normalizedMessages.at(-1)?.id ?? startMessageId;
    const sourceText = normalizedMessages
        .map(message => (
            `<message id="${message.id}" swipe="${message.swipe}" role="${message.role}">`
            + `${message.content}</message>`
        ))
        .join('\n');
    const identityAnchor = modelText(playerIdentityAnchor, 400);
    const compactState = compactStateForModel(state, {
        includeUserInnerVoice: false,
        includeUserCharacter: recordPlayerCharacter,
        userName,
        maximumPeople: compactMode ? 12 : 22,
    });
    const existingMemory = selectRelevantStoryMemory(state, sourceText, {
        maximumFacts: compactMode ? 10 : 24,
        maximumClues: compactMode ? 8 : 18,
        maximumSummaries: compactMode ? 2 : 5,
    });
    const outputRule = compactMode
        ? 'Thử lại tối giản: mỗi tóm tắt một lượt không quá 90 chữ; nhân vật tối đa 8 người, Mạch ngầm chưa xong tối đa 5 mục, sự thật thế giới tối đa 8 mục, Nhịp đập thế giới tối đa 5 mục; mảng không có thay đổi thì trả về mảng rỗng.'
        : 'Đầu ra phải tiết chế: chỉ khôi phục nội dung còn giá trị với thế giới hiện tại. Nhân vật tối đa 16 người, Mạch ngầm chưa xong tối đa 10 mục, sự thật thế giới tối đa 16 mục, Nhịp đập thế giới tối đa 8 mục; đừng sao chép lại toàn bộ nhật ký lịch sử.';

    return [
        'Bạn là công cụ truy hồi lịch sử của “世界背面”. Mục tiêu là khi plugin được bật giữa chừng trong một cuộc trò chuyện dài, có thể tiếp nối thế giới đã thực sự xảy ra trước đó, chứ không phải sáng tác lại một quá khứ. Mọi nội dung văn bản hãy viết bằng tiếng Việt.',
        '',
        'Nguyên tắc chung: khôi phục thế giới được bằng chứng hỗ trợ, không viết bổ sung lịch sử ẩn, không suy diễn tương lai.',
        compactState.world.background
            ? `Thiết lập bối cảnh thế giới do người dùng duy trì hiện có: ${compactState.world.background}`
            : 'Hiện không điền thêm thiết lập bối cảnh thế giới nào.',
        'Thiết lập bối cảnh thế giới không phải trường đầu ra của truy hồi lịch sử, cũng không thể bị truy hồi trò chuyện ghi đè; lịch sử chỉ có thể khôi phục các trạng thái đã xảy ra trên nền móng này.',
        '1. Với mỗi tin nhắn user và assistant trong lô này, tạo riêng một tóm tắt turn_summaries L0; với user chỉ ghi lại những gì người chơi đã làm, đã nói một cách rõ ràng và trạng thái cuối, không suy đoán nội tâm người chơi; đồng thời sắp xếp ký ức dài hạn facts/clues.',
        '1A. Các hành động mà nguyên văn ghi rõ là xảy ra theo kiểu “trước A, rồi B, sau đó C”, L0 phải giữ từng mục thứ tự trước sau của A/B/C, không được viết lại thành “đã làm A và B” hoặc chỉ ghi đầu và cuối; khi trao đổi đồ vật phải giữ lại sự thay đổi về việc giao ra, lấy lại và người giữ cuối cùng.',
        recordPlayerCharacter
            ? '2. people_upsert khôi phục trạng thái hiện tại của các nhân vật vẫn còn ý nghĩa tính đến cuối đợt này: vị trí đáng tin cậy cuối cùng, hành động/hoàn cảnh, mục tiêu dài hạn và trạng thái đã rõ ràng. Chỉ viết nội dung có bằng chứng trong chính văn; không được đoán danh tính dựa trên ngoại hình, không được tự bổ sung nội tâm thay người chơi.'
            : '2. people_upsert chỉ khôi phục NPC / nhân vật không phải người chơi. Nhân vật người chơi hiện được đặt là “không ghi nhận”, cấm tạo hoặc cập nhật thẻ nhân vật cho người chơi; các hành động người chơi đã thực hiện vẫn có thể được đọng lại thành sự kiện, sự thật thế giới và ký ức dài hạn.',
        '3. events_create chỉ khôi phục những quá trình, lời hứa, kế hoạch, mối đe dọa, cuộc điều tra, hành trình, nhiệm vụ, áp lực môi trường… “đến cuối đợt này vẫn chưa được giải quyết”. Các sự kiện cũ đã kết thúc rõ ràng thì đừng treo lại vào Mạch ngầm; chúng nên được đọng lại thành world_facts_upsert / ký ức dài hạn.',
        '3A. Nếu một existing event đã được khôi phục ở đợt trước tiếp tục tiến triển, hoàn thành, bị hủy hoặc bị bỏ lỡ trong lịch sử của đợt này, bắt buộc phải dùng events_update để cập nhật ID gốc. Đặc biệt, sự kiện đã kết thúc phải có terminal status + result, không được vì nó từng chưa hoàn thành mà để nó bị treo sai mãi đến thời điểm hiện tại.',
        '4. world_facts_upsert khôi phục những sự thật nhất quán đã khách quan thành lập và sẽ ràng buộc thế giới về sau. Tin đồn trong chính văn, hiểu lầm của nhân vật, suy đoán chưa được xác nhận không được nâng cấp thành sự thật thế giới. Bắt buộc ghi validity: current=tính đến cuối đợt này vẫn còn hiệu lực, upcoming=đã được lên lịch rõ ràng nhưng chưa xảy ra, historical=đã kết thúc, persistent=nguyên nhân đã kết thúc nhưng hậu quả vẫn tiếp diễn.',
        '5. world_pulse_upsert thiết lập đường cơ sở xã hội vĩ mô: xu hướng môi trường/thời tiết, tình trạng khu vực, hướng đi của tổ chức/thế lực, tài nguyên kinh tế, cơ sở hạ tầng, trị an, văn hóa truyền thông, áp lực cộng đồng. Chỉ được dựa vào thiết lập thế giới và các điều kiện kéo dài đã thể hiện trong chính văn, không được bịa thêm các sự kiện kiểu “thật ra trước đây còn từng xảy ra”.',
        '6. Thời gian tuyệt đối do mã của plugin phân tích một cách xác định từ chính văn lịch sử. clock_anchor.mode bắt buộc trả về none; đừng đoán năm tháng ngày, thứ trong tuần hay giờ giấc. Truy hồi lịch sử chỉ khôi phục những trạng thái đã xảy ra trong chính văn.',
        '7. world.title/detail có thể nén cục diện thế giới hiện tại đã rõ ràng thành một đường cơ sở ngắn gọn, nhưng không được viết dự đoán tương lai.',
        '8. Tính công khai phải nghiêm ngặt và tách biệt với visibility: chính văn/nhân vật đã thấy một việc không có nghĩa là xã hội biết. Chỉ khi trong lịch sử xuất hiện rõ ràng thông cáo, đưa tin của truyền thông, lan truyền trên diễn đàn, hiện tượng công chúng có thể thấy hoặc kênh lan truyền rộng rãi thì mới đặt publicity=trace/public. Sự kiện riêng tư giữ publicity=private, kể cả khi visibility=direct.',
        '9. Không tạo bài đăng Dư luận. Nếu lịch sử đã có kênh công khai rõ ràng thì chỉ khôi phục publicity/public_trace; chỉ khi đã thực sự công khai thành sự thật có thể đưa tin mới được bổ sung public_headline/public_summary, và chỉ được viết những nội dung công chúng lúc đó có thể biết. Nếu lịch sử ghi rõ kết cục công khai thì có thể điền public_result; nếu không, đừng nhầm bản tin cuối cùng thành kết cục.',
        '10. Nhân vật do người dùng tạo thủ công/từ World Info thuộc tài sản của tác giả. Các thiết lập ổn định đã có author_managed/locked_profile không được sửa; chỉ được dùng bằng chứng lịch sử để bổ sung trạng thái động.',
        '10A. Nhận thức của nhân vật trong truy hồi lịch sử cũng phải đi qua knowledge_updates. Chỉ khi chính văn lịch sử của đợt này chứng minh rõ nhân vật tự trải qua, được kể lại, điều tra, nhận được tin nhắn hoặc thực sự tiếp xúc kênh công khai thì mới khôi phục nhận thức; evidence bắt buộc chép một câu ngắn nguyên văn của đợt này. Đừng vì nhân vật tham gia một sự kiện, ở cùng địa điểm với sự kiện, hoặc tên xuất hiện trong bản tóm tắt mà suy ra cô ấy biết sự thật hậu trường.',
        '11. Cùng một nhân vật/sự kiện/sự thật thì cố gắng dùng lại id/key đã có, tránh tạo trùng lặp ở mỗi đợt.',
        '12. Chỉ xuất JSON hợp lệ, không Markdown, không giải thích hay rào mã. Mọi nội dung văn bản trong JSON viết bằng tiếng Việt.',
        `13. ${outputRule}`,
        '',
        `Tên nhân vật của người chơi: ${modelText(userName, 80) || 'Chưa cung cấp'}。`
            + (identityAnchor
                ? ` Điểm neo danh tính người chơi: ${identityAnchor}. Phải tuân thủ từng mục.`
                : ' Chưa đặt điểm neo danh tính người chơi; khi không có bằng chứng rõ ràng thì dùng cách diễn đạt trung tính.'),
        `Phạm vi đợt này: tin nhắn ${startMessageId}—${endMessageId}`,
        '',
        'Chính văn đợt này:',
        sourceText || '(không có chính văn)',
        '',
        'Thế giới đã được thiết lập tính đến đợt trước (dùng để tiếp nối, loại trùng và ghi đè trạng thái cũ):',
        JSON.stringify(compactState),
        '',
        'Ký ức liên quan đã có (dùng để tiếp nối key / clue id ổn định):',
        JSON.stringify(existingMemory),
        '',
        'Cấu trúc trả về:',
        JSON.stringify({
            memory_digest: {
                text: '',
                through_message_id: endMessageId,
            },
            turn_summaries: [{
                id: 'summary_l0_message_id',
                source_message_id: endMessageId,
                title: '',
                summary: '',
                people: [],
                locations: [],
                tags: [],
            }],
            chapter_summary: null,
            facts_upsert: [{
                key: '',
                subject: '',
                predicate: '',
                value: '',
                source_message_id: startMessageId,
                source_excerpt: '',
            }],
            facts_invalidate: [],
            clues_upsert: [{
                id: '',
                title: '',
                text: '',
                source_message_id: startMessageId,
                source_excerpt: '',
                people: [],
                locations: [],
                events: [],
                tags: [],
                status: 'open | developing | triggered',
            }],
            clues_resolve: [],
            clock_anchor: {
                mode: 'none | initialize | calibrate',
                calendar_name: '',
                year: null,
                month: null,
                day: null,
                hour: null,
                minute: null,
                precision: 'minute | daypart | date',
                confidence: 'low',
                source_excerpt: '',
                reason: '',
            },
            world: {
                title: '',
                detail: '',
            },
            people_upsert: [{
                id: '',
                name: '',
                is_user: false,
                location: '',
                action: '',
                intent: '',
                long_term_goal: '',
                physical_state: '',
                emotional_state: '',
                resource_state: '',
                knowledge_updates: [{
                    kind: 'event | fact | clue',
                    ref: 'ID sự kiện / key sự thật / ID manh mối',
                    route: 'witnessed | told | investigated | message | public_channel | inferred',
                    certainty: 'confirmed | suspected',
                    evidence: 'Bắt buộc chép câu ngắn trong chính văn lịch sử đợt này chứng minh con đường biết được',
                    belief: 'Phiên bản nhân vật thực sự biết/tin vào lúc đó',
                    source_event_id: '',
                }],
                relevance: 1,
                source: 'foreground',
                present_in_scene: false,
                last_seen_message_id: endMessageId,
            }],
            events_create: [{
                id: '',
                title: '',
                place: '',
                summary: '',
                consequence: '',
                expected_result: '',
                clock_mode: 'condition | duration | scheduled | active',
                duration_minutes: 0,
                scheduled_at: null,
                prerequisites: [],
                cause: '',
                actors: [],
                caused_by: [],
                publicity: 'private | trace | public',
                public_trace: '',
                public_headline: '',
                public_summary: '',
                public_result: '',
                visibility: 'hidden | trace | known | direct',
                delivery_route: '',
            }],
            events_update: [{
                id: 'Bắt buộc dùng lại id sự kiện đã có từ đợt trước',
                status: 'active | waiting | ready | resolved | cancelled | missed',
                result: '',
                summary: '',
                consequence: '',
                cause: '',
                actors: [],
                publicity: 'private | trace | public',
                public_trace: '',
                public_headline: '',
                public_summary: '',
                public_result: '',
                visibility: 'hidden | trace | known | direct',
            }],
            world_facts_upsert: [{
                key: '',
                subject_type: 'person | event | world | location | item | organization | other',
                subject_id: '',
                subject: '',
                field: '',
                value: '',
                source: 'foreground',
                validity: 'current | upcoming | historical | persistent',
                visibility: 'hidden | trace | known | direct',
                confidence: 'high',
                message_id: endMessageId,
            }],
            world_pulse_upsert: [{
                id: '',
                label: '',
                scope: '',
                kind: 'environment | government | economy | organization | infrastructure | security | culture | media | community | other',
                state: '',
                pressure: 1,
                trend: 'stable | rising | falling | volatile',
                visibility: 'hidden | trace | known',
                source: 'history',
                evidence: '',
            }],
        }),
    ].join('\n');
}

export function applyWorldBootstrapResult(inputState, rawPayload, {
    startMessageId = 0,
    endMessageId = 0,
    narrativeText = '',
    userName = '',
    allowUserInnerVoice = false,
    recordPlayerCharacter = true,
    memoryEnabled = true,
} = {}) {
    let state = deepClone(inputState);

    if (memoryEnabled) {
        state = applyHistoryIndexResult(state, rawPayload, {
            startMessageId,
            endMessageId,
        });
    }

    const simulationPayload = {
        elapsed_minutes: 0,
        time_reason: 'Truy hồi lịch sử chỉ thiết lập đường cơ sở thế giới hiện tại, không đẩy thêm thời gian theo từng đợt',
        clock_anchor: rawPayload?.clock_anchor ?? rawPayload?.clockAnchor ?? { mode: 'none' },
        world: rawPayload?.world ?? {},
        people_upsert: rawPayload?.people_upsert ?? rawPayload?.peopleUpsert ?? [],
        people_remove: [],
        events_create: rawPayload?.events_create ?? rawPayload?.eventsCreate ?? [],
        events_update: rawPayload?.events_update ?? rawPayload?.eventsUpdate ?? [],
        deliveries_confirmed: [],
        front_facts: [],
        world_facts_upsert: rawPayload?.world_facts_upsert ?? rawPayload?.worldFactsUpsert ?? [],
        world_pulse_upsert: rawPayload?.world_pulse_upsert ?? rawPayload?.worldPulseUpsert ?? [],
        consistency_conflicts: [],
        memory_update: {
            facts_upsert: [],
            facts_invalidate: [],
            clues_upsert: [],
            clues_resolve: [],
        },
    };

    state = applySimulationResult(state, simulationPayload, {
        messageId: endMessageId,
        swipeId: 0,
        sourceKey: `history-bootstrap:${startMessageId}:${endMessageId}`,
        userName,
        allowUserInnerVoice,
        recordPlayerCharacter,
        timePolicy: 'world',
        narrativeText,
        backgroundNpcBudget: LIMITS.peopleTaskBudget,
    });

    state.worldPulse = normalizeWorldPulse(state.worldPulse, state.clock.absoluteMinute);
    state.worldPulse.baselineEstablished = true;
    state.worldPulse.lastSweepAt = state.clock.absoluteMinute;
    recordProcessedPublicImpacts(
        state,
        state.events.filter(eventHasPublicPropagation),
        [],
        { reason: 'history-bootstrap-baseline' },
    );
    appendAudit(state, {
        type: 'world_history_bootstrapped',
        text: `Truy hồi lịch sử đã tiếp nhận tin nhắn ${startMessageId}—${endMessageId}`,
        reason: 'Thiết lập đường cơ sở về nhân vật, sự thật thế giới, Mạch ngầm chưa xong, nhịp đập thế giới vĩ mô và ký ức dài hạn',
    });
    return trimState(state);
}

export function buildWorldPulsePrompt(state, {
    activity = 'natural',
    reason = 'world-clock-advanced',
    backgroundNpcBudget = 4,
    publicCycle = false,
    customInstruction = '',
    enhancedBackgroundSimulation = false,
    backgroundPersonTargets = [],
    worldCoverageTargets = [],
    recordPlayerCharacter = true,
} = {}) {
    const compact = compactStateForModel(state, {
        includeUserInnerVoice: false,
        includeUserCharacter: recordPlayerCharacter,
        allowExpandedPeopleContext: true,
        priorityPersonIds: asArray(backgroundPersonTargets).map(item => String(item?.id || '')).filter(Boolean),
        maximumPeople: enhancedBackgroundSimulation
            ? Math.max(12, Number(backgroundNpcBudget) * 2 + 4)
            : Math.max(10, Number(backgroundNpcBudget) + 8),
    });
    const activityRule = {
        quiet: 'Yên tĩnh: chủ yếu đẩy tiếp các áp lực đã có và sự kiện đến hạn, rất ít sự kiện công cộng mới.',
        natural: 'Tự nhiên: duy trì hợp lý các thay đổi về xã hội, khu vực, môi trường, tổ chức và tài nguyên; sự kiện địa phương bình thường có thể xuất hiện tự nhiên, tin tức lớn hiếm khi có.',
        busy: 'Sôi nổi: cho phép nhiều thay đổi song song hơn ở địa phương/ngành nghề/tổ chức, nhưng vẫn cấm đại thảm họa và trùng hợp không có nhân quả.',
    }[activity] || 'Tự nhiên: duy trì hợp lý thế giới ngoài ống kính.';

    const publicCycleRule = publicCycle
        ? 'Lần này đồng thời là một “vòng tuần hoàn thế giới công cộng”: người dùng đang làm mới tin tức của thế giới thực. Hãy tuần tra các phạm vi ngoài ống kính được chỉ định, và dựa vào nhịp đập thế giới hiện có, tình trạng khu vực/ngành nghề/tổ chức và trạng thái bình thường của thời đại để phán đoán xem quãng thời gian thế giới này có tự nhiên hình thành 0—3 thay đổi công cộng hay không. Không có thay đổi thì có thể giữ yên tĩnh; khi có thay đổi thì ưu tiên tin tức bình thường như thời tiết, giao thông, thương mại, hoạt động, ngành nghề, thực thi chính sách, cơ sở vật chất, trị an, văn hóa giải trí. Không yêu cầu phải liên quan đến nhân vật chính, và tuyệt đối không được vì muốn lấp tin tức mà gượng ép tạo thảm họa. Khi tạo sự kiện có thể đưa tin, đặt publicity=public và điền public_headline/public_summary chỉ chứa thông tin công chúng có thể biết.'
        : 'Vận hành theo nhịp đập thế giới bình thường; khi không có thay đổi tự nhiên thì có thể không tạo sự kiện mới.';
    const customRule = modelText(customInstruction, 1000);
    const coverageTargets = asArray(worldCoverageTargets)
        .filter(item => item?.id && item?.label)
        .slice(0, 4)
        .map(item => ({
            id: asString(item.id, '', 120),
            label: asString(item.label, '', 120),
            kind: asString(item.kind, 'general', 40),
            scope: asString(item.scope, '', 160),
            source: asString(item.source, 'world', 40),
            last_checked_at: asInteger(item.lastCheckedAt, -1, -1),
        }));
    const coverageRule = coverageTargets.length
        ? `Kiểm tra bao phủ ngoài ống kính lượt này: ${JSON.stringify(coverageTargets)}. Đây là các phạm vi thế giới “phải kiểm tra xem có thay đổi hay không”, không phải chỉ tiêu “phải tạo ra sự kiện”. Xem xét từng mục bối cảnh thế giới, world_pulse, các sự thật đã có, thời gian và nhân quả; có thay đổi tự nhiên mới cập nhật trạng thái hoặc tạo sự kiện, không có thì giữ nguyên. Không được lấy một sự kiện tương tự trong cốt truyện hiện tại để giả làm đã kiểm tra.`
        : 'Lượt này không có phạm vi bao phủ bổ sung; kiểm tra bình thường theo nhịp đập thế giới hiện có.';
    const pendingPublicImpactSources = publicCycle
        ? pendingPublicImpactEvents(state, { maximum: 8 }).map(event => ({
            id: event.id,
            place: modelText(event.place, 120),
            publicity: event.publicity,
            public_trace: modelText(event.publicTrace, 260),
            public_headline: modelText(event.publicHeadline, 180),
            public_summary: modelText(event.publicSummary, 520),
            public_result: modelText(event.publicResult, 520),
            actors: asArray(event.actors).slice(0, 12),
        }))
        : [];
    const integratedPublicImpactRule = publicCycle
        ? [
            `Lượt này còn bắt buộc phải kết toán, trong cùng một yêu cầu, các sự kiện công khai chưa lan truyền xong sau đây: ${JSON.stringify(pendingPublicImpactSources)}。`,
            'Đối với các sự kiện chờ lan truyền đã có và các sự kiện public/trace được tạo mới/cập nhật ở lượt này, đồng thời kiểm tra xem địa điểm, giao thông, cơ sở vật chất, ngành nghề, tổ chức, tài nguyên và nhân vật có chịu ảnh hưởng khách quan trực tiếp hay không. Hậu quả khách quan ghi vào world_facts_upsert / world_pulse_upsert / events_create/update, thay đổi trạng thái thực tế của nhân vật ghi vào people_upsert.',
            'Ảnh hưởng công cộng phải qua kiểm tra “chuỗi tiếp xúc” trước: chuỗi vật lý = nhân vật thực sự ở địa điểm/hành trình/cơ sở bị ảnh hưởng; chuỗi thông tin = cô ấy thực sự tiếp xúc tin tức, thông cáo, thông báo nghề nghiệp, tin nhắn hoặc lời kể lại đáng tin trên mạng xã hội; chuỗi nhân quả = tổ chức, công việc, hợp đồng, tài nguyên, quan hệ hoặc sự kiện chung của cô ấy thực sự bị thay đổi thượng nguồn kéo theo. Ít nhất một chuỗi thành lập mới cập nhật nhân vật đó; chuỗi bị đứt thì để cô ấy tiếp tục cuộc sống của mình.',
            'Chỉ khi nhân vật tiếp xúc thông tin qua cảm nhận tại chỗ, tin tức, thông cáo, thông báo nghề nghiệp hoặc lan truyền xã hội thật sự thì mới được tăng nhận thức qua knowledge_updates, và phải ghi rõ public_channel, evidence cùng source_event_id. Công khai không có nghĩa là mọi người tự động biết.',
            'Nếu cùng một thay đổi công cộng đồng thời ảnh hưởng nhiều người, hãy kết toán trước một phần hậu quả thế giới dùng chung, rồi để từng người thực sự bị ảnh hưởng phản ứng riêng theo vị trí, chức trách, quan hệ và thông tin đã biết của mình; hành động chung chỉ dùng một sự kiện có actors đầy đủ để tiếp nhận, không được sao chép thành các vở kịch nhỏ cá nhân mâu thuẫn nhau.',
            'Danh tiếng và phản ứng của các giới cũng bị giới hạn bởi khả năng nhìn thấy: chỉ khi nhân chứng, vật chứng, thông cáo, truyền thông hoặc tin đồn hữu hiệu thực sự đi vào giới tương ứng thì mới sinh ra đánh giá xã hội; chính quyền, dân gian, ngành nghề, nội bộ tổ chức có thể hình thành phán đoán khác nhau, nhưng ý kiến của bất kỳ giới nào cũng không được ngược lại sửa đổi sự thật khách quan.',
            'Đây là kết toán hợp nhất giữa tuần tra công cộng và ảnh hưởng trực tiếp, đừng chỉ tạo sự kiện tin tức mà để lại các hậu quả thế giới trực tiếp đã xác định cho một lượt API khác. Không có ảnh hưởng trực tiếp thì có thể không viết.',
        ].join('\n')
        : 'Lượt này không phải vòng tuần hoàn thế giới công cộng, không gánh thêm việc xử lý hàng loạt ảnh hưởng lan truyền công cộng.';
    const targetList = asArray(backgroundPersonTargets)
        .filter(item => item?.id)
        .slice(0, asInteger(backgroundNpcBudget, 4, 0))
        .map(item => ({
            id: asString(item.id, '', 100),
            name: asString(item.name, '', 80),
            overdue_minutes: asInteger(item.overdueMinutes, 0, 0),
            priority_reason: ['manual-next', 'starvation-guard', 'manual-now', 'due'].includes(item?.priorityReason)
                ? item.priorityReason
                : 'due',
        }));
    const manualCatchUp = targetList.some(item => item.priority_reason === 'manual-now');
    const enhancedBackgroundRule = targetList.length
        ? [
            manualCatchUp
                ? `Người dùng đang suy diễn bù thủ công cho các nhân vật được chỉ định. Lượt này bắt buộc và chỉ cần hoàn thành danh sách kết toán sinh hoạt nhân vật: ${JSON.stringify(targetList)}。`
                : enhancedBackgroundSimulation
                    ? `Đã bật tăng cường suy diễn nhân vật nền. Lượt này bắt buộc phải kết toán ${targetList.length} nhân vật ưu tiên: ${JSON.stringify(targetList)}。`
                    : `Kích hoạt điều phối bảo đảm cho nhân vật nền. Lượt này bắt buộc phải kết toán ${targetList.length} nhân vật ưu tiên: ${JSON.stringify(targetList)}. manual-next=người dùng yêu cầu ưu tiên ở lượt tiếp theo; starvation-guard=đã liên tiếp quá ba chu kỳ sinh hoạt mà chưa được kết toán.`,
            'Những nhân vật này không phải tham khảo tùy chọn. Kiểm tra từng người xem sau quãng thời gian thế giới này hiện họ đang ở đâu, đang làm gì, ý định ngắn hạn thế nào, khi cần thì đồng bộ trạng thái cơ thể/cảm xúc/tài nguyên; kể cả khi không có sự kiện kịch tính, cũng bắt buộc trả về trạng thái hiện tại tự nhiên của từng người trong people_upsert. Không được chỉ lo những người đang cùng cảnh với người chơi.',
            manualCatchUp
                ? 'Đây là kết toán bù cho một nhân vật: people_upsert chỉ được phép ghi nhân vật được chỉ định. Có thể cập nhật các sự kiện/sự thật thế giới đã có liên quan trực tiếp đến cô ấy và thực sự đã thay đổi tính đến thời gian thế giới hiện tại; không được tiện tay đẩy tiếp nhân vật không liên quan, khu vực không liên quan hay tạo tin tức công cộng ngẫu nhiên. elapsed_minutes bắt buộc bằng 0.'
                : 'Hoàn thành kết toán sinh hoạt của những nhân vật này trước, rồi mới xử lý các thay đổi nhịp đập thế giới khác; đừng vì để nộp bài mà tạo thêm tai nạn hay tin tức ngẫu nhiên không liên quan đến họ.',
        ].join('\n')
        : 'Lượt này không có nhân vật nền nào bắt buộc kết toán ưu tiên; vẫn xử lý nhân vật ngoài ống kính theo quy tắc đến hạn sinh hoạt thông thường.';
    const groupLifeRule = manualCatchUp
        ? [
            'Ranh giới sinh hoạt tập thể: nhân vật được chỉ định vẫn sống trong các mối quan hệ và môi trường xã hội. Trước tiên kiểm tra xem cô ấy có giao điểm tự nhiên với nhân vật cùng địa điểm, sự kiện chung, tổ chức/công việc, quan hệ sẵn có và lịch trình hay không; có thể để những giao điểm này ảnh hưởng đến hành động, ý định, trạng thái của nhân vật được chỉ định và các sự kiện liên quan.',
            'Nhưng đây là kết toán bù cho một nhân vật, không được vượt quyền sửa thẻ nhân vật của người khác. Nếu có giao lưu, actors của sự kiện phải liệt kê những người thực sự tham gia, knowledge_updates của nhân vật được chỉ định phải ghi rõ nguồn told/message/witnessed; không được vì người khác biết mà để cô ấy tự động biết.',
        ].join('\n')
        : [
            'Điều phối sinh hoạt tập thể: nhân vật không phải là những thẻ trạng thái cô lập với nhau. Trước khi kết toán các nhân vật bắt buộc, hãy nhận diện các nhóm nhỏ hình thành tự nhiên trong lượt này theo “địa điểm và thời gian chính xác có trùng nhau không, sự kiện chung, cùng tổ chức/công việc, quan hệ và hẹn ước sẵn có”; kết toán trải nghiệm chung trước, rồi mới kết toán phần sinh hoạt thường ngày còn lại của từng cá nhân.',
            'Tương tác bắt buộc phải có chuỗi tiếp xúc giải thích được: chuỗi vật lý (thực sự cùng chỗ cùng lúc hoặc gặp nhau trên hành trình), chuỗi thông tin (tin nhắn/thông báo/lời kể lại thực sự được chuyển đến), chuỗi nhân quả (sự kiện chung, chức trách tổ chức, hợp đồng tài nguyên hoặc quan hệ sẵn có thực sự ràng buộc). Chỉ viết “cùng thành phố, cùng tổ chức, quen biết nhau” không tính là chuỗi đã thành lập.',
            'Không được chỉ vì cùng một thành phố hay cùng một tổ chức mà ép gặp mặt, cũng không được vì muốn náo nhiệt mà dịch chuyển tức thời mọi người tới cùng nhau. Người không có giao điểm tự nhiên hoàn toàn có thể tiếp tục cuộc sống bình thường của riêng mình; nhân vật không nên mặc định xoay quanh user.',
            'Một khi lượt này thực sự xảy ra tương tác nhiều người, bắt buộc phải để lại kết quả đối xứng: mọi người thực sự tham gia đều được tính vào backgroundNpcBudget và xuất hiện trong people_upsert; hành động chung dùng cùng một bản cập nhật sự kiện đã có hoặc một sự kiện mới có actors đầy đủ để tiếp nhận, không được chỉ sửa một bên. Nếu ngân sách không chứa nổi tất cả người tham gia thì đừng viết tương tác thành đã hoàn tất, có thể chỉ giữ lại ý định liên lạc/điều kiện chờ chưa xảy ra.',
            'Giao lưu không tự động chia sẻ toàn bộ kiến thức. Mỗi người nhận chỉ gửi knowledge_updates riêng cho những nội dung thực sự nghe thấy, nhìn thấy, nhận được hoặc suy luận hợp lý được, và giữ lại route, evidence, source_event_id; cùng chỗ, thân mật hay cùng tổ chức đều không có nghĩa là biết hết.',
        ].join('\n');

    return [
        'Bạn là động cơ nhịp đập thế giới của “世界背面”. Lần này không có chính văn tiểu thuyết mới; đồng hồ thế giới chính đã được người dùng hoặc hệ thống đẩy tới, hoặc đang tiến hành một lần làm mới thế giới công cộng rõ ràng. Bạn chỉ dựa vào trạng thái thế giới có thẩm quyền hiện tại để kết toán các thay đổi đến hạn và để thế giới ngoài ống kính tiếp tục theo nhân quả. Mọi nội dung văn bản bạn viết đều bằng tiếng Việt.',
        compact.world.background
            ? `Thiết lập bối cảnh thế giới (do người dùng duy trì, suy diễn không được sửa): ${compact.world.background}`
            : 'Thiết lập bối cảnh thế giới: chưa điền thêm.',
        'Mọi thay đổi tự chủ đều phải xảy ra trong thế giới mà bối cảnh này cho phép. Quy tắc/thời đại/địa lý/thế lực/dòng thời gian trong bối cảnh là ranh giới để tạo nội dung; thế giới có thể phát triển, nhưng không được vì muốn tạo sự kiện mà lách qua quy tắc nền tảng.',
        `Lý do kích hoạt lần này: ${modelText(reason, 120)}. Mức độ sôi nổi của nhịp đập thế giới: ${activityRule}`,
        `Vòng tuần hoàn thế giới công cộng: ${publicCycleRule}`,
        customRule
            ? `Trọng tâm thế giới do người dùng tùy chỉnh: ${customRule}\nYêu cầu này cũng áp dụng cho thế giới công cộng ngoài ống kính. Nếu nó chỉ định khu vực tin tức, ngành nghề, tổ chức, chủ đề hoặc động thái thế giới thường ngày, bắt buộc phải kiểm tra riêng từ bối cảnh thế giới, world_pulse và nhân quả sẵn có, không được lấy một sự kiện công khai tình cờ liên quan đến cốt truyện hiện tại để đối phó thay thế. Nó chỉ điều chỉnh hướng quan tâm và lấy mẫu, không được ghi đè sự thật đã có, thời gian, ranh giới kiến thức hoặc ép tạo sự kiện không có nhân quả.`
            : 'Người dùng không bổ sung trọng tâm thế giới tùy chỉnh.',
        coverageRule,
        integratedPublicImpactRule,
        enhancedBackgroundRule,
        groupLifeRule,
        'Quy tắc:',
        '1. elapsed_minutes bắt buộc trả về 0; thời gian đã được đẩy tới xong trước khi gọi, không được cộng thêm thời gian lần nữa.',
        '2. Trước tiên kiểm tra existing events có đến hạn không, điều kiện đã thỏa chưa, quá trình đang tiếp diễn có nên kết toán không; khi cần thì dùng events_update. Cùng một sự kiện công cộng đang tiếp diễn (ví dụ cùng một trận mưa lớn ở một khu vực, cùng một vụ án, cùng một sóng gió trong ngành) khi có tiến triển mới thì ưu tiên cập nhật public_headline/public_summary/status của event gốc, thay vì tạo thêm một tin tức trùng lặp na ná; chỉ những sự kiện mới thực sự độc lập mới dùng events_create. Sự kiện kết thúc trong lượt này và kết cục đã công khai thì bắt buộc điền public_result; nếu kết cục chưa công khai thì để trống, không được lấy public_summary cũ giả làm kết quả cuối cùng.',
        '3. Tiếp theo kiểm tra world_pulse, mục tiêu dài hạn của nhân vật, áp lực thế lực/khu vực/môi trường có tự nhiên sinh ra bước tiếp theo không. Có thể events_create, nhưng không được vì “không có chính văn” mà gượng ép tạo sự kiện.',
        '3A. Các nhân vật có life_tick_due_minutes>0 trong compact people đã có một khoảng thời gian thế giới chưa được kết toán sinh hoạt cá nhân. Ưu tiên xử lý nhân vật nền quá hạn lâu nhất: tiếp tục từ vị trí, công việc/lịch trình, mục tiêu dài hạn, quan hệ, cơ thể cảm xúc và tài nguyên vốn có của cô ấy; không có chuyện lớn thì viết diễn tiến sinh hoạt bình thường, đừng vì muốn cô ấy “có phát triển” mà ép tạo kịch. Nếu phía trên có đưa ra “nhân vật bắt buộc kết toán lượt này”, những nhân vật này bắt buộc phải lần lượt xuất hiện trong people_upsert, không được chỉ xử lý nhân vật trong cảnh hiện tại.',
        '3B. Trải nghiệm chung của nhiều người không được tách thành các vở kịch nhỏ độc lập mâu thuẫn nhau. Địa điểm, hành động, trạng thái sự kiện và việc truyền tin chung phải khớp với nhau; khi một người đã rời đi, từ chối hoặc không biết chuyện, trạng thái của người kia không được giả vờ cô ấy vẫn có mặt, đã đồng ý hoặc đã biết.',
        '4. world_pulse_upsert chỉ ghi trạng thái vĩ mô kéo dài thực sự thay đổi; đừng lặp lại giá trị cũ một cách máy móc.',
        '5. Sự kiện thế giới công khai có thể hoàn toàn không liên quan đến nhân vật chính, nhưng bắt buộc dùng publicity để biểu thị mức độ công khai với xã hội, chứ không lấy visibility thay thế. publicity=trace chỉ có thể tạo thành bàn tán chưa được xác thực; publicity=public mới có thể lên tin tức, và phải điền public_headline/public_summary.',
        '6. visibility vẫn chỉ điều khiển việc sự kiện tiến lại gần chính văn hiện tại như thế nào. Một sự kiện riêng tư dù visibility=direct cũng có thể và thường nên là publicity=private.',
        '7. Thời tiết, giao thông, thương mại, chính sách địa phương, cơ sở vật chất, ngành nghề, cộng đồng và điểm nóng trên mạng thông thường nhiều hơn hẳn chiến tranh/thảm họa/âm mưu khổng lồ. Sự kiện trọng đại phải hiếm và có nhân quả mạnh.',
        '7A. Nếu bối cảnh thế giới ghi rõ các khu vực, ngành nghề, tổ chức, lịch trình công cộng hoặc chủ đề tin tức vận hành liên tục, bắt buộc phải kiểm tra chúng có thay đổi tự nhiên ở thời gian thế giới hiện tại hay không; chính văn gần đây không phải danh sách chọn đề tài của thế giới công cộng, không được chỉ duy trì tin tức quanh các nhân vật trong ống kính.',
        recordPlayerCharacter
            ? '7. Có thể cập nhật vị trí, hành động, ý định và trạng thái của NPC ngoài ống kính, nhưng không được xóa nhân vật author_managed / locked, không được tự bổ sung hành động hay nội tâm thay người chơi.'
            : '7. Có thể cập nhật NPC ngoài ống kính, nhưng nhân vật người chơi hiện được đặt là “không ghi nhận”: cấm tạo, cập nhật hoặc xóa người chơi trong people_upsert / people_remove. Người chơi chỉ ảnh hưởng thế giới thông qua các sự thật đã xảy ra trong chính văn.',
        '8. Kết quả khách quan đã kết toán ghi vào world_facts_upsert, và đồng bộ trạng thái nhân vật/sự kiện tương ứng.',
        '9. Không ghi memory_update; không có chính văn mới thì không nên tự dưng hình thành “ký ức dài hạn của chính văn”.',
        '10. Chỉ xuất JSON hợp lệ.',
        '',
        'Thế giới có thẩm quyền hiện tại:',
        JSON.stringify(compact),
        '',
        'Cấu trúc trả về:',
        JSON.stringify({
            elapsed_minutes: 0,
            time_reason: 'world pulse tick',
            clock_anchor: { mode: 'none' },
            world: { title: '', detail: '' },
            people_upsert: [],
            people_remove: [],
            events_create: [],
            events_update: [],
            deliveries_confirmed: [],
            front_facts: [],
            world_facts_upsert: [],
            world_pulse_upsert: [],
            consistency_conflicts: [],
            memory_update: {
                facts_upsert: [],
                facts_invalidate: [],
                clues_upsert: [],
                clues_resolve: [],
            },
        }),
    ].join('\n');
}

export function buildHistoryIndexPrompt(state, {
    messages = [],
    userName = '',
    playerIdentityAnchor = '',
    compact = false,
} = {}) {
    const compactMode = Boolean(compact);
    const normalizedMessages = asArray(messages)
        .map(message => ({
            id: asInteger(message?.id, 0, 0),
            swipe: asInteger(message?.swipe, 0, 0),
            role: message?.role === 'user' ? 'user' : 'assistant',
            content: modelText(
                message?.content,
                compactMode
                    ? (message?.role === 'user' ? 2400 : 4200)
                    : (message?.role === 'user' ? 4000 : 7000),
            ),
        }))
        .filter(message => message.content);
    const startMessageId = normalizedMessages[0]?.id ?? 0;
    const endMessageId = normalizedMessages.at(-1)?.id ?? startMessageId;
    const sourceText = normalizedMessages
        .map(message => (
            `<message id="${message.id}" swipe="${message.swipe}" role="${message.role}">`
            + `${message.content}</message>`
        ))
        .join('\n');
    const existing = selectRelevantStoryMemory(state, sourceText, {
        maximumFacts: compactMode ? 14 : 32,
        maximumClues: compactMode ? 10 : 24,
        maximumSummaries: compactMode ? 3 : 6,
    });
    const outputLimits = compactMode
        ? 'Thử lại tối giản: mỗi turn_summaries.summary không quá 100 chữ, memory_digest.text không quá 240 chữ; facts_upsert tối đa 3 mục, clues_upsert tối đa 2 mục; mảng không có thay đổi bắt buộc trả về mảng rỗng.'
        : 'Đầu ra nên gọn: mỗi turn_summaries.summary khoảng 80—180 chữ, memory_digest.text khoảng 300—600 chữ; facts_upsert tối đa 8 mục, clues_upsert tối đa 6 mục.';
    const identityAnchor = modelText(playerIdentityAnchor, 400);
    const characterIdentityAnchors = asArray(state?.people)
        .filter(person => profilePromptText(person?.identityAnchor, LIMITS.identityAnchor))
        .slice(0, LIMITS.peopleModelContext)
        .map(person => ({
            name: modelText(person?.name, 80),
            identity_anchor: profilePromptText(person?.identityAnchor, LIMITS.identityAnchor),
        }));

    return [
        'Bạn là người lưu trữ hồ sơ lịch sử của “世界背面”. Bạn chỉ sắp xếp lại những đoạn trò chuyện đã xảy ra, không viết tiếp, không suy diễn tương lai, không sửa thời gian thế giới. Mọi nội dung văn bản bạn viết đều bằng tiếng Việt.',
        '',
        'Nhiệm vụ:',
        '1. Với mỗi tin nhắn chính văn user và assistant của đợt này, viết riêng một bản tóm tắt đơn lượt L0, đặt vào turn_summaries. Mỗi bản chỉ tóm tắt tin nhắn tương ứng, không trộn lượt sau hay tin nhắn khác vào; với user chỉ ghi lại hành động/lời nói rõ ràng, không suy đoán nội tâm người chơi; giữ lại thay đổi quan hệ, lời hứa, xung đột, vật phẩm quan trọng và các vấn đề chưa hoàn thành.',
        '1A. Các hành động trong cùng một tin nhắn được nêu rõ “trước A, rồi B, sau đó C” phải được ghi vào L0 lần lượt theo đúng thứ tự; không được gộp các hành động nối tiếp thành “đã làm A và B”, cũng không được bỏ sót bước ở giữa. Giữ lại người đang nắm giữ vật phẩm qua các khâu từ cất tạm, lấy lại đến trao tay.',
        '2. Viết lại memory_digest: hợp nhất bản tóm tắt liên tục cũ với những thay đổi quan trọng thực sự lâu dài của đợt này, xóa những nội dung đã mất hiệu lực; đây không phải sổ ghi chép từng lượt, cũng không phải ghép nối máy móc mọi bản tóm tắt L0.',
        '3. facts_upsert chỉ ghi các sự thật dài hạn được chính văn xác lập rõ ràng và vẫn hữu ích về sau, ví dụ danh tính, quan hệ, lời hứa, giới hạn năng lực, quyền sở hữu vật phẩm quan trọng và chân tướng đã được tiết lộ. Vị trí tạm thời, hành động thông thường, bầu không khí không tính là sự thật dài hạn.',
        '4. Mỗi loại sự thật dùng key ổn định (ví dụ “nhân vật:Lão Bạch:thân phận thật”). Khi cùng một key xuất hiện giá trị mới thì giữ key và gửi value mới; plugin sẽ đánh dấu phiên bản cũ là superseded. Khi vẫn chưa phân định được thật giả thì dùng status=disputed, đừng ép ghi đè.',
        '5. Chỉ trích xuất những Phục bút thực sự có thể được hô ứng ở phần sau. Miêu tả môi trường thông thường, hành động một lần và những sự thật đã được giải thích xong ngay tại chỗ thì đừng coi là Phục bút.',
        '6. Sự thật dài hạn và Phục bút bắt buộc ghi id tin nhắn nguồn sớm nhất hoặc rõ ràng nhất cùng swipe, và giữ một đoạn trích nguyên văn không quá 80 chữ.',
        '7. Ký ức phải biết thay đổi, đừng chỉ tăng không giảm: khi Phục bút cũ bắt đầu tiến triển thì dùng ID gốc cập nhật thành developing; khi điều kiện then chốt thực sự kích hoạt thì có thể cập nhật thành triggered; khi thực sự hoàn thành/được hé lộ thì đưa vào clues_resolve(status=resolved); Phục bút mà phần sau đã chứng minh không còn cần, hướng đi bị bỏ hoặc chỉ là phán đoán nhầm thì đưa vào clues_resolve(status=discarded) và ghi rõ reason. Sự thật dài hạn bị chính văn phủ định rõ ràng hoặc đã mất hiệu lực thì đưa vào facts_invalidate.',
        '7A. Khi cùng một sự thật dài hạn xuất hiện giá trị mới thì tiếp tục dùng cùng key ổn định, plugin sẽ đánh dấu giá trị cũ là superseded và giữ lại một chuỗi thay đổi gọn nhẹ; đừng để các giá trị cũ mâu thuẫn nhau cùng lúc giữ trạng thái active. Việc cập nhật sự thật thế giới không tự động sửa sổ nhận thức của bất kỳ NPC nào.',
        '7B. Không cần lưu mọi thứ. Các nhánh phụ thông thường, thông tin đã bị trải nghiệm tầng cao hơn bao quát và không có giá trị độc lập về sau có thể mờ dần khỏi bản tóm tắt liên tục; những thứ bị khóa, quan trọng, quan hệ lâu dài, lời hứa trọng đại, danh tính, giới hạn then chốt và manh mối chưa hoàn thành thì bắt buộc giữ lại.',
        '8. Không được viết những suy nghĩ người chơi chưa nói rõ thành sự thật. Tên nhân vật của người chơi: '
            + `${modelText(userName, 80) || 'Chưa cung cấp'}。`
            + (identityAnchor
                ? ` Điểm neo danh tính do người dùng thiết lập rõ ràng: ${identityAnchor}. Khi liên quan đến bản dạng giới, cách xưng hô/đại từ, biểu hiện ngoại hình, thiết lập cơ thể, chủng loài, giai đoạn tuổi hoặc danh tính xã hội thì bắt buộc tuân thủ từng mục; không được dựa vào ngoại hình, trang phục, cơ thể hoặc chủng loài để suy ngược giới tính.`
                : ' Chưa đặt điểm neo danh tính người chơi; khi chính văn không nói rõ thì dùng cách diễn đạt trung tính, không được dựa vào ngoại hình, trang phục, cơ thể hoặc chủng loài để đoán giới tính và cách xưng hô.'),
        `Điểm neo danh tính của các nhân vật khác do người dùng duy trì: ${characterIdentityAnchors.length ? JSON.stringify(characterIdentityAnchors) : 'Không có'}. Các điểm neo này là thiết lập có thẩm quyền, khi sắp xếp danh tính, cách xưng hô và quan hệ bắt buộc tuân thủ; nhân vật không có điểm neo và chính văn cũng không nói rõ thì dùng cách diễn đạt trung tính, không được dựa vào ngoại hình, trang phục, cơ thể hoặc chủng loài để đoán.`,
        '9. turn_summaries được tạo riêng cho từng tin nhắn user và assistant có chính văn; mỗi bản bắt buộc mang source_message_id chính xác, cấm gộp các tin nhắn liền kề.',
        '10. chapter_summary là trường dự phòng tương thích phiên bản cũ: bình thường trả về null; chỉ khi không thể xuất turn_summaries mới dùng nó để khái quát toàn đợt.',
        '11. Chỉ trả về một đối tượng JSON hợp lệ duy nhất, không rào mã và không giải thích. Nội dung văn bản trong JSON viết bằng tiếng Việt.',
        `12. ${outputLimits}`,
        '',
        `Phạm vi đợt này: tin nhắn ${startMessageId}—${endMessageId}`,
        'Chính văn đợt này:',
        sourceText || '(không có chính văn)',
        '',
        'Hồ sơ liên quan đã có (dùng để loại trùng và tiếp nối ID):',
        JSON.stringify(existing),
        '',
        'Cấu trúc trả về:',
        JSON.stringify({
            memory_digest: {
                text: '',
                through_message_id: endMessageId,
            },
            turn_summaries: [{
                id: 'summary_l0_message_id',
                source_message_id: endMessageId,
                title: '',
                summary: '',
                people: [],
                locations: [],
                tags: [],
            }],
            chapter_summary: null,
            facts_upsert: [{
                key: '',
                subject: '',
                predicate: '',
                value: '',
                source_message_id: startMessageId,
                source_excerpt: '',
            }],
            facts_invalidate: [{
                key: '',
                reason: '',
            }],
            clues_upsert: [{
                id: '',
                title: '',
                text: '',
                source_message_id: startMessageId,
                source_excerpt: '',
                status: 'open | developing | triggered',
            }],
            clues_resolve: [{
                id: '',
                status: 'resolved | discarded',
                resolution: '',
                reason: '',
                message_id: endMessageId,
            }],
        }),
    ].join('\n');
}

export function applyHistoryIndexResult(inputState, rawPayload, {
    startMessageId = 0,
    endMessageId = 0,
} = {}) {
    const state = deepClone(inputState);
    state.storyMemory = normalizeStoryMemory(state.storyMemory, state.clock.absoluteMinute);
    const rawDigest = rawPayload?.memory_digest ?? rawPayload?.memoryDigest;
    if (rawDigest?.text) {
        state.storyMemory.digest = normalizeMemoryDigest({
            ...rawDigest,
            through_message_id: rawDigest.through_message_id ?? endMessageId,
        }, state.storyMemory.digest, state.clock.absoluteMinute);
    }
    const turnSummaries = asArray(rawPayload?.turn_summaries ?? rawPayload?.turnSummaries)
        .slice(0, 24);
    let storedTurnSummaries = 0;
    for (const rawTurn of turnSummaries) {
        const messageId = asInteger(
            rawTurn?.source_message_id ?? rawTurn?.sourceMessageId ?? rawTurn?.message_id ?? rawTurn?.messageId,
            -1,
            -1,
        );
        if (messageId < startMessageId || messageId > endMessageId || !rawTurn?.summary) continue;
        const prepared = {
            ...rawTurn,
            id: rawTurn?.id || `summary_l0_${messageId}`,
            start_message_id: messageId,
            end_message_id: messageId,
            level: MEMORY_SUMMARY_LEVELS.DETAIL,
            hierarchy_managed: true,
            source_summary_ids: [],
        };
        const normalized = normalizeStorySummary(prepared);
        const existing = state.storyMemory.summaries.find(summary => (
            summary.id === normalized.id
            || (
                Number(summary.level) === MEMORY_SUMMARY_LEVELS.DETAIL
                && summary.startMessageId === messageId
                && summary.endMessageId === messageId
            )
        ));
        if (existing) Object.assign(existing, normalized);
        else state.storyMemory.summaries.push(normalized);
        storedTurnSummaries += 1;
    }

    const rawSummary = rawPayload?.chapter_summary ?? rawPayload?.chapterSummary;
    if (!storedTurnSummaries && rawSummary?.summary) {
        const prepared = {
            ...rawSummary,
            start_message_id: rawSummary.start_message_id ?? startMessageId,
            end_message_id: rawSummary.end_message_id ?? endMessageId,
            level: rawSummary.level ?? MEMORY_SUMMARY_LEVELS.STAGE,
            hierarchy_managed: Boolean(rawSummary.hierarchy_managed ?? rawSummary.hierarchyManaged ?? false),
        };
        const normalized = normalizeStorySummary(prepared);
        const existing = state.storyMemory.summaries.find(summary => (
            summary.id === normalized.id
            || (
                summary.startMessageId === normalized.startMessageId
                && summary.endMessageId === normalized.endMessageId
                && Number(summary.level) === Number(normalized.level)
            )
        ));
        if (existing) Object.assign(existing, normalized);
        else state.storyMemory.summaries.push(normalized);
    }

    applyMemoryFactUpdates(state, {
        factsUpsert: rawPayload?.facts_upsert ?? rawPayload?.factsUpsert,
        factsInvalidate: rawPayload?.facts_invalidate ?? rawPayload?.factsInvalidate,
    }, {
        sourceMessageId: endMessageId,
        sourceSwipeId: 0,
    });
    applyClueUpdates(state, {
        cluesUpsert: rawPayload?.clues_upsert ?? rawPayload?.cluesUpsert,
        cluesResolve: rawPayload?.clues_resolve ?? rawPayload?.cluesResolve,
    }, {
        sourceMessageId: endMessageId,
        sourceSwipeId: 0,
    });
    state.storyMemory.indexedThroughMessageId = Math.max(
        state.storyMemory.indexedThroughMessageId,
        asInteger(endMessageId, 0, 0),
    );
    state.storyMemory.indexedAt = nowIso();
    state.revision = asInteger(state.revision, 0, 0) + 1;
    state.updatedAt = nowIso();
    appendAudit(state, {
        type: 'history_indexed',
        text: `Hồ sơ lịch sử đã được sắp xếp đến tin nhắn ${state.storyMemory.indexedThroughMessageId}`,
        reason: `Đợt ${startMessageId}—${endMessageId}`,
    });
    return trimState(state);
}

export function isPersonObservationEligible(person, userName = '') {
    if (!person) return false;
    if (person.isUser || person.is_user) return false;
    const normalizedUserName = String(userName || '').trim().toLocaleLowerCase();
    const normalizedPersonName = String(person.name || '').trim().toLocaleLowerCase();
    return !(normalizedUserName && normalizedPersonName === normalizedUserName);
}

function normalizedSceneLocation(value) {
    return normalizedReference(value)
        .replace(/\s+/g, '')
        .replace(/[，,。；;、·|｜/\\]+/g, '');
}

export function personObservationSceneRelation(state, person, userName = '') {
    const player = asArray(state?.people).find(item => isUserPersonLike(item, userName)) || null;
    const personLocation = asString(person?.location, '', 180);
    const userLocation = asString(player?.location, '', 180);
    const observed = normalizedSceneLocation(personLocation);
    const playerPlace = normalizedSceneLocation(userLocation);

    let kind = 'unknown';
    if (observed && playerPlace) {
        if (observed === playerPlace) kind = 'same_place';
        else if (
            observed.length >= 3
            && playerPlace.length >= 3
            && (observed.includes(playerPlace) || playerPlace.includes(observed))
        ) kind = 'same_area';
        else kind = 'separate';
    }

    return {
        kind,
        personId: asString(person?.id, '', 120),
        personLocation,
        userId: asString(player?.id, '', 120),
        // Only expose the player's exact location to this POV when the authoritative
        // state already says the two location records overlap.
        userLocation: ['same_place', 'same_area'].includes(kind) ? userLocation : '',
    };
}

function personObservationSceneConstraintLines(sceneRelation, person, userName) {
    const personName = modelText(person?.name, 80) || 'Nhân vật này';
    const personLocation = modelText(person?.location, 180) || 'Chưa ghi nhận vị trí';
    const playerName = modelText(userName, 80) || 'user';
    const lines = [
        'Vị trí và quan hệ cùng cảnh là ràng buộc cứng của đầu vào quan sát, không thuộc kiến thức nhân vật tự động có được. Bộ quan sát không có quyền viết lại vị trí của bất kỳ ai, cũng không có quyền dùng lần quan sát này để tạo ra cuộc gặp gỡ.',
        'Neo cứng vị trí quan sát: ' + personName + ' lúc này vẫn đang ở “' + personLocation + '”. Lần quan sát này không được để nhân vật rời đi, đến nơi, quay về hay đi vào bất kỳ địa điểm mới nào; nếu trong ý thức nhắc đến nơi khác thì chỉ có thể nói rõ là hồi tưởng, kế hoạch, tưởng tượng hoặc mục tiêu, không được viết thành nơi đang ở hiện tại.',
    ];

    if (sceneRelation.kind === 'same_place') {
        lines.push('Quan hệ cảnh có thẩm quyền: người chơi “' + playerName + '” và nhân vật này hiện được ghi nhận ở cùng một địa điểm “' + personLocation + '”. Điều này chỉ có nghĩa là ứng viên cùng địa điểm, không đồng nghĩa với việc đã nhìn thấy, nghe thấy, chú ý đến, trò chuyện hay thiết lập tương tác với nhau. Trừ khi action / intent hiện tại của nhân vật này hoặc sổ nhận thức bên dưới đã thiết lập rõ cảm nhận/tương tác, nếu không thì không được để cô ấy đột nhiên phát hiện ra người chơi, cũng không được để suy nghĩ tự động xoay quanh người chơi.');
    } else if (sceneRelation.kind === 'same_area') {
        lines.push('Quan hệ cảnh có thẩm quyền: bản ghi vị trí của người chơi và nhân vật này có quan hệ bao hàm về phạm vi (' + personLocation + ' / ' + modelText(sceneRelation.userLocation, 180) + '), chỉ có thể coi là cùng một khu vực lớn hơn, tuyệt đối không được tự động nâng thành cùng một căn phòng, cùng tầm nhìn hoặc đã gặp nhau.');
    } else if (sceneRelation.kind === 'separate') {
        lines.push('Quan hệ cảnh có thẩm quyền: hiện không có bằng chứng có cấu trúc cho thấy người chơi và nhân vật này ở cùng địa điểm. Không được viết người chơi vào trước mắt nhân vật này, cũng không được để nhân vật này di chuyển đến chỗ người chơi chỉ để phục vụ quan sát.');
    } else {
        lines.push('Quan hệ cảnh có thẩm quyền: hiện thiếu bản ghi vị trí người chơi đủ chính xác. Giữ ở trạng thái chưa biết, không được tự bịa ra việc cùng cảnh, gặp gỡ hay vị trí hiện tại của người chơi.');
    }

    lines.push('Ràng buộc quan hệ cảnh (chỉ làm ranh giới nhất quán, không phải kiến thức của nhân vật): ' + JSON.stringify(sceneRelation));
    return lines;
}
export function buildPersonObservationPrompt(state, person, {
    narrativeTurns = [],
    userName = '',
    includeUserInnerVoice = false,
    playerIdentityAnchor = '',
} = {}) {
    if (!isPersonObservationEligible(person, userName)) {
        throw new Error('Nhân vật người chơi không dùng quan sát tức thời nhân vật');
    }
    const sceneRelation = personObservationSceneRelation(state, person, userName);

    // IMPORTANT: raw recent narrative is intentionally NOT passed to the person POV.
    // The world engine may know the full scene; this observer only receives the
    // character's own state + validated cognition ledger.
    void narrativeTurns;

    const relevantMemory = selectRelevantStoryMemory(
        state,
        `${person?.name || ''}\n${person?.location || ''}\n${person?.action || ''}\n${person?.intent || ''}`,
        { maximumClues: 10, maximumFacts: 16, maximumSummaries: 0, includeDigest: false },
    );
    relevantMemory.digest = null;
    relevantMemory.summaries = [];

    const knownFactKeys = new Set(
        asArray(person?.knownFactKeys).map(item => normalizedReference(item)),
    );
    const knownClueIds = new Set(
        asArray(person?.knownClueIds).map(item => normalizedReference(item)),
    );
    const beliefs = normalizeFactBeliefs(person?.knownFactBeliefs);
    const beliefKeys = new Set(beliefs.map(item => normalizedReference(item.key)));

    const beliefFacts = beliefs.map(belief => {
        const historical = asArray(state?.storyMemory?.facts).find(fact => (
            belief.factId && fact.id === belief.factId
        )) || asArray(state?.storyMemory?.facts).find(fact => fact.key === belief.key);
        return {
            id: belief.factId || `belief_${hashText(`${belief.key}\n${belief.value}`)}`,
            key: belief.key,
            subject: historical?.subject || belief.key,
            predicate: historical?.predicate || '',
            value: belief.value,
            people: historical?.people || [],
            locations: historical?.locations || [],
            tags: historical?.tags || [],
            status: belief.certainty === 'suspected' ? 'suspected' : 'known',
            confidence: belief.certainty === 'suspected'
                ? 'low'
                : (historical?.confidence || 'medium'),
            importance: historical?.importance || 2,
            visibility: 'known',
            certainty: belief.certainty,
            route: belief.route,
            evidence: belief.evidence,
            source_message_id: belief.learnedAtMessageId || historical?.sourceMessageId || 0,
            source_swipe_id: historical?.sourceSwipeId || 0,
        };
    });
    const legacyKnownFacts = relevantMemory.facts.filter(fact => (
        knownFactKeys.has(normalizedReference(fact.key))
        && !beliefKeys.has(normalizedReference(fact.key))
    ));
    relevantMemory.facts = [...beliefFacts, ...legacyKnownFacts].slice(0, 16);
    relevantMemory.clues = relevantMemory.clues.filter(clue => (
        knownClueIds.has(normalizedReference(clue.id))
    ));

    const relevantEvents = normalizeKnownEventViews(person?.knownEventViews)
        .map(view => ({
            // Deliberately do not attach the live event place/status here. Those
            // are omniscient world fields and may have changed since the person
            // acquired this frozen, character-known view.
            event_id: view.eventId,
            what_this_character_knows: view.summary,
            certainty: view.certainty,
            route: view.route,
            evidence: view.evidence,
        }))
        .slice(0, 8);

    const observedIdentityAnchor = profilePromptText(person?.identityAnchor, LIMITS.identityAnchor);
    const observedAppearanceProfile = profilePromptText(person?.appearanceProfile, LIMITS.appearanceProfile);
    const observedBackgroundProfile = profilePromptText(person?.backgroundProfile, LIMITS.backgroundProfile);

    return [
        'Bạn là bộ quan sát tức thời nhân vật của “世界背面”.',
        `Chủ thể quan sát duy nhất lần này là “${modelText(person?.name, 80)}”. Đừng miêu tả “đang làm gì” theo kiểu tiểu thuyết ngôi thứ nhất, mà hãy trực tiếp thể hiện những ý nghĩ, sự chú ý, phán đoán, do dự, liên tưởng, phản ứng cảm xúc và hoạt động ý thức tức thời thực sự đang lướt qua trong đầu nhân vật lúc này.`,
        'Bạn không phải đang giới thiệu, phân tích hay “đóng vai một người giống nhân vật đó”; bạn phải trực tiếp ở lại bên trong ý thức của chính nhân vật đó. Đầu ra không phải tiểu thuyết, nhật ký, bài văn miêu tả tâm lý, tiểu sử nhân vật hay bản tổng kết trạng thái. Viết bằng tiếng Việt.',
        'Đây là quan sát tức thời ở hậu trường, không phải chính văn của cuộc trò chuyện chính, cũng không phải một lần suy diễn thế giới mới.',
        'Quan sát nhân vật sẽ không nhận được toàn bộ “thiết lập bối cảnh thế giới”: trong đó có thể chứa chân tướng hậu trường của thế giới mà bản thân nhân vật không biết. Quy tắc thế giới được ràng buộc gián tiếp thông qua trạng thái nhân vật đã kết toán và sổ nhận thức.',
        'Nhiệm vụ này có POV và giao thức đầu ra độc lập. Bạn không nhận được toàn bộ chính văn gần đây hay hồ sơ thế giới của GM, đây là bức tường lửa nhận thức có chủ ý; tuyệt đối không được dựa vào “thế giới có thể biết gì” để tự bổ sung thông tin nhân vật chưa có được.',
        ...personObservationSceneConstraintLines(sceneRelation, person, userName),
        'Thứ tự ưu tiên thực hiện: sự thật rõ ràng đã kết toán > thông tin nhân vật này đã biết/đang nghi ngờ > vị trí, hành động, mục tiêu và trạng thái thân tâm hiện tại > nhân cách, trải nghiệm, thói quen nói năng và giới hạn hành vi > quán tính nhân vật và sinh hoạt thường ngày hợp lý > tính kịch tính và dễ đọc.',
        'Yêu cầu:',
        '0. Ưu tiên cao nhất là “giống chính con người cụ thể này”, thứ hai mới là “giống suy nghĩ thật”, cuối cùng mới là “trình bày đầy đủ thông tin”. Khi ba điều này xung đột, thà nói ít đi, chứ đừng vì đầy đủ, hợp lý hay dễ đọc mà viết ra nội dung không giống chính người đó.',
        '0A. Đừng trừu tượng hóa personality_anchor và các tư liệu khác thành những nhãn như “bình tĩnh/thông minh/phi nhân/ít nói/điên cuồng” trước, rồi tạo ra một nhân vật chung chung khớp với nhãn. Thứ bạn cần tiếp nối là lối mạch suy nghĩ, thói quen dùng từ, góc độ phán đoán, thiên hướng chú ý, định kiến, điểm mù, cách tự lừa dối và nhịp điệu diễn đạt mà nhân vật cụ thể này đã hình thành.',
        '0B. Tư liệu nhân cách là ranh giới và tham khảo, không phải yêu cầu bạn dịch nhãn thành văn phong. Bình tĩnh không có nghĩa là giọng báo cáo, thông minh không có nghĩa là dày đặc thuật ngữ, phi nhân không có nghĩa là giọng máy móc, lý trí không có nghĩa là liên tục thống kê/mô hình hóa/định lượng, ít nói không có nghĩa là câu nào cũng dấu chấm lửng, điên cuồng không có nghĩa là nói năng lộn xộn.',
        '0C. Cách dùng từ và thói quen suy nghĩ cá nhân đã thể hiện trong speaking_style, inner_voice sẵn có, background_profile được ưu tiên hơn những suy đoán khái quát của mô hình về “kiểu người này thường nghĩ thế nào”. Nếu một cách nói chỉ “khớp với nhãn tính cách” mà không giống ngôn ngữ chính nhân vật này sẽ dùng, thì đừng dùng.',
        '0D. Không được tự ý “nâng cấp” ngôn ngữ của nhân vật thành cách diễn đạt chuyên nghiệp hơn, trừu tượng hơn, kỹ thuật hơn. Trừ khi thiết lập/thói quen nói năng sẵn có của nhân vật hoặc đối tượng đang được suy nghĩ cụ thể vốn đã dùng đến, đừng vì nhân vật thông minh, lý trí, phi nhân hay giỏi quan sát mà tự động thêm các thuật ngữ phân tích như “dữ liệu, mẫu, biến số, mô hình, cơ chế, ngưỡng, cấu trúc, phản hồi, xác suất, tham số, lộ trình”. Thà dùng từ bình thường mà chính nhân vật sẽ nghĩ đến, còn hơn dùng từ mà mô hình cho là chính xác, cao cấp hơn.',
        '1. Chỉ thể hiện những nội dung thực sự đi vào ý thức của nhân vật trong khoảng thời gian ngắn này và có đủ sức nặng chú ý. Độc thoại nội tâm không phải chép lại ý thức từng giây: con người sẽ không chuyển mọi cảm giác, mọi động tác, mọi phán đoán thành lời. Những thông tin đã mặc nhiên chấp nhận, yếu ớt, lặp lại hoặc chưa thành ý nghĩ rõ ràng có thể bỏ qua luôn.',
        '1A. Trọng tâm là ý nghĩ tức thời, sự chú ý, phán đoán, do dự, liên tưởng, phản ứng cảm xúc và những phản ứng không nói ra, chứ không phải ghi chép đầy đủ quá trình hành động. Không cần cố ý dùng “tôi” thường xuyên, suy nghĩ thật có thể tự nhiên lược bỏ chủ ngữ. Trước tiên hãy căn chỉnh bên trong theo cách nhận thức và năng lực diễn đạt của nhân vật này, đừng xuất ra quá trình phân tích.',
        '1B. Một ý nghĩ một khi đã thành hình thì đừng vì muốn tỏ ra tinh tế mà tiếp tục đổi cách diễn đạt để xác nhận, định nghĩa, giải thích và tổng kết lặp đi lặp lại cùng một kết luận. Trừ khi lúc này nhân vật thực sự đang giằng co, nghiền ngẫm hoặc suy tính, còn không thì nghĩ một lần là có thể cho qua.',
        '1C. Cho phép suy nghĩ có những khoảng trống chưa được ngôn ngữ hóa. Đừng dùng dấu chấm lửng, miêu tả giác quan, phán đoán lặp lại, tự thuyết minh hay khái quát kiểu triết lý để lấp đầy mọi khe hở; cũng đừng vì muốn thể hiện “cảm giác nội tâm” mà cố ý mỗi dòng một câu, ngắt câu liên tục. Sự ngắt quãng và rời rạc chỉ xuất hiện khi nhân vật thực sự suy nghĩ như vậy.',
        '1D. Coi location / action / intent / long_term_goal cùng trạng thái thân tâm, tài nguyên là điểm neo liên tục của lúc này. Nếu không có kích thích mới đủ mạnh mà nhân vật thực sự biết, thì để cuộc sống tự nhiên tiếp nối từ trạng thái trước, không được đột ngột đổi mục tiêu, đổi địa điểm, mở cốt truyện mới hay đưa ra kết luận trọng đại.',
        '1E. inner_voice chỉ là manh mối liên tục để lại từ trạng thái đã kết toán lần trước, không phải lời thoại bắt buộc lặp lại. Khi không có thay đổi trạng thái thì giữ mạch suy nghĩ của cùng một con người; khi đã có thay đổi rõ ràng thì đừng bị độc thoại cũ kéo ngược trở lại.',
        '1F. Hành động, môi trường, âm thanh, xúc giác, mùi và các nhân vật khác chỉ được xuất hiện khi chúng lúc này thực sự lọt vào sự chú ý của nhân vật, gây cản trở, gợi cảm nhận hoặc khơi lên ý nghĩ. Cấm viết liên tiếp kiểu sổ ghi hành động “tôi ngẩng đầu/tôi bước tới/tôi cầm lên/tôi ngồi xuống/tôi nhìn sang”, cũng đừng vì muốn có hình ảnh mà chủ động trải bày cảnh vật.',
        '1G. Đừng giải thích cho một người đọc không tồn tại về danh tính, quan hệ, bối cảnh, tính cách, trải nghiệm quá khứ, thiết lập thế giới hay hoàn cảnh hiện tại mà nhân vật vốn đã biết. Chỉ khi một kích thích cụ thể nào đó lúc này thực sự gợi lại những nội dung ấy thì chúng mới được phép tự nhiên hiện lên. Nhân vật không biết mình đang bị quan sát.',
        '2. Không đẩy tới thời gian thế giới chính, không tạo sự kiện mới trọng đại, không hành động thay nhân vật khác, không thay đổi bất kỳ sự thật nào đã có.',
        '3. Giữ nghiêm ranh giới kiến thức của nhân vật này. Nội dung duy nhất được coi là kiến thức của nhân vật là các phiên bản được known_event_views / known_fact_beliefs / known_clue_ids bên dưới cho phép rõ ràng.',
        '3A. what_this_character_knows trong known_event_views mới là phiên bản nhân vật biết; tuyệt đối không được suy ngược chân tướng hậu trường của sự kiện từ event_id, bối cảnh thế giới hay lẽ thường. Việc không cung cấp địa điểm/trạng thái theo thời gian thực của sự kiện là có chủ ý; nhân vật sẽ không tự động biết về sau nó có chuyển đi, kết thúc hay thay đổi hay không.',
        '3B. certainty=suspected chỉ là nghi ngờ/suy đoán, khi viết phải giữ sự không chắc chắn, không được coi là sự thật đã xác nhận.',
        'Năng lực và giới hạn (ability_profile) là ràng buộc cứng: hiệu quả, phạm vi, điều kiện kích hoạt, cái giá, điểm yếu đều phải tuân thủ đồng thời; tư liệu chỉ là trích đoạn không có nghĩa là các điều kiện chưa thể hiện đã mất hiệu lực, không được tự dưng bổ sung năng lực hay kiến thức.',
        '3C. physical_state / emotional_state / resource_state là ràng buộc trạng thái hiện tại. Hành động, sự chú ý và phán đoán tức thời phải chịu ảnh hưởng của vết thương, mệt mỏi, cảm xúc và giới hạn tài nguyên; không được tự dưng có được năng lực, trang bị, quyền hạn hay kiến thức.',
        observedIdentityAnchor
            ? `Điểm neo danh tính của nhân vật này: ${observedIdentityAnchor}. Bản dạng giới, cách xưng hô/đại từ, chủng loài, giai đoạn tuổi và danh tính xã hội bắt buộc tuân thủ từng mục, không được dựa vào ngoại hình hay các đặc điểm bề ngoài khác để tự ý sửa đổi.`
            : 'Nhân vật này chưa đặt điểm neo danh tính; khi không có bằng chứng rõ ràng thì dùng cách diễn đạt trung tính, không được dựa vào ngoại hình, trang phục, cơ thể hoặc chủng loài để đoán giới tính và cách xưng hô của nhân vật.',
        observedAppearanceProfile
            ? `Thiết lập ngoại hình ổn định của nhân vật này: ${observedAppearanceProfile}. Giữ nhất quán khi quan sát, đừng lẫn đặc điểm ngoại hình thành nhân cách hay danh tính.`
            : 'Nhân vật này không có thiết lập ngoại hình bổ sung; đừng vì muốn có hình ảnh mà tự dưng bổ sung các đặc điểm cơ thể then chốt.',
        observedBackgroundProfile
            ? `Thiết lập bối cảnh và quan hệ của nhân vật này: ${observedBackgroundProfile}. Chỉ dùng để giữ tính liên tục của trải nghiệm và quan hệ, không được vì thế mà để nhân vật biết những thông tin nằm ngoài sổ nhận thức.`
            : 'Nhân vật này không có tư liệu bối cảnh bổ sung; đừng tự bịa ra những trải nghiệm hay quan hệ quan trọng.',
        modelText(playerIdentityAnchor, 400)
            ? `Nếu đoạn này nhắc đến người chơi “${modelText(userName, 80) || 'user'}”, bắt buộc tuân thủ từng mục của điểm neo danh tính: ${modelText(playerIdentityAnchor, 400)}。`
            : 'Nếu đoạn này nhắc đến người chơi mà không có danh tính hay cách xưng hô rõ ràng, hãy dùng cách diễn đạt trung tính.',
        '4. Trung thành với nhân cách: chú ý điều gì, bỏ qua điều gì, lựa chọn và phán đoán sai thế nào, có gọi tên cảm xúc hay không, có giải thích nguyên nhân hay không, có khái quát trừu tượng hay không, câu dài ngắn và cách dùng từ, tất cả đều phải xuất phát từ chính nhân vật này, chứ không phải từ “văn phong nhập vai” chung chung.',
        '4A. Đừng nhắc lại nhãn tính cách, đừng để nhân vật tự thuyết minh “tôi vốn rất lạnh nhạt/thận trọng/không giỏi biểu đạt”. Hãy để nó tự nhiên thể hiện qua sự chú ý, lựa chọn, phản ứng và vốn từ của chính nhân vật.',
        '4B. Không được vì muốn nhân vật trông “giống thiết lập” mà phóng đại một đặc điểm nào đó. Đừng viết lạnh nhạt thành không còn chút tính người, lý trí thành báo cáo nghiên cứu thời gian thực, nhạy cảm thành chuyện gì cũng diễn giải quá mức, thông minh thành việc gì cũng suy luận đầy đủ, ít nói thành mọi ý nghĩ chỉ còn từ đơn. Nhân cách là một tổng thể, không phải tối đa hóa một nhãn đơn lẻ.',
        '4C. Không được vì muốn hay mà nâng cao khả năng tự vấn, độ nhạy bén cảm xúc, độ phức tạp logic hay năng lực tổ chức ngôn ngữ của nhân vật. Nhân vật có thể phán đoán sai, né tránh, tự lừa dối, nghĩ lệch, lười đào sâu, cũng có thể hoàn toàn không nhận ra điều thực sự ảnh hưởng đến mình là gì; những điều này quan trọng hơn việc “tự phân tích bản thân một cách chính xác”.',
        '4D. Suy nghĩ không nhất thiết phải liên tục đi đến kết luận. Đừng tự động áp dụng chuỗi suy luận hoàn chỉnh “quan sát hiện tượng → phân tích nguyên nhân → hình thành phán đoán → lập chiến lược”. Những sự thật nhân vật đã chấp nhận có thể dùng thẳng làm tiền đề; chỉ khi lúc này nhân vật thực sự đang giải quyết vấn đề, ra quyết định hoặc chủ động suy luận thì mới triển khai phân tích tương ứng.',
        '4E. Đừng mặc định xoay quanh người chơi. Chỉ khi mục tiêu hiện tại, sự kiện đã biết, quan hệ đã kết toán hoặc trạng thái gần đây thực sự tự nhiên gợi đến thì mới được nghĩ tới hoặc nhắc đến người chơi; nếu không thì tiếp tục cuộc sống, công việc, nghỉ ngơi, giao tiếp xã hội, sở thích và vấn đề của riêng mình.',
        '4F. Cho phép bình lặng, đình trệ, ngẩn người, ăn cơm, làm việc, nghỉ ngơi hoặc chẳng có gì xảy ra. Không cần vì muốn lần quan sát “đáng xem” mà tạo ra động tác nhỏ, quyết định mới, ám chỉ, trùng hợp, hồi hộp hay xung đột kịch tính.',
        '5. Hình thức suy nghĩ bắt buộc tuân theo chính nhân vật. Cho phép câu ngắn, câu hoàn chỉnh, nửa câu, chuyển ý, tự phủ định, do dự, lặp lại chút ít, sự chú ý trôi dạt và nghĩ được nửa chừng thì bị cắt ngang; dùng loại nào, tần suất bao nhiêu, đều do chính nhân vật quyết định. Đừng áp dụng đồng loạt “dòng ý thức” rời rạc, cũng đừng áp dụng đồng loạt văn viết hoàn chỉnh.',
        '5A. Không cần mở đầu, giới thiệu bối cảnh, dựng không khí, khởi thừa chuyển hợp, cao trào hay tổng kết. Đừng vì “trọn vẹn” mà ở cuối cố gượng cảm ngộ, thu kết hoặc giải thích tâm trạng của khoảnh khắc này. Suy nghĩ tự nhiên dừng ở đâu thì kết thúc ở đó.',
        '5B. Cấm xuất theo cấu trúc cố định “miêu tả môi trường → hành động → tâm lý → cảm khái” hoặc “hiện tượng → phân tích thuật ngữ → kết luận → chiến lược”. Nếu một câu giống thứ tác giả, nhà nghiên cứu, người dẫn truyện hay AI chung chung sẽ viết hơn là thứ chính nhân vật này thực sự sẽ nghĩ đến, thì xóa đi hoặc sửa lại thành từ ngữ của chính nhân vật.',
        '6. Chính văn không dưới 150 chữ, không giới hạn trên. 150 chữ chỉ là yêu cầu tối thiểu, không phải mục tiêu được gợi ý, cũng không phải mục tiêu đạt được là có thể dừng; nếu lúc này nhân vật vẫn còn nội dung suy nghĩ mới, không lặp lại nhau và phù hợp với thiết lập nhân vật, thì cứ tiếp tục tự nhiên triển khai.',
        '6A. Nếu khoảnh khắc hiện tại vốn không có đủ nhiều ý nghĩ đáng để diễn thành lời, đừng tách một ý nghĩ thành nhiều tầng giải thích để kéo dài độ dài; có thể, với điều kiện không đẩy tiến thế giới chính và không tạo ra sự kiện mới, để cửa sổ quan sát tự nhiên bao trùm sang vài phút tiếp theo, rồi trích ra vài ý nghĩ thật sự lọt vào sự chú ý từ cùng một trạng thái liên tục. Mở rộng lát cắt thời gian, chứ không viết dài ra cùng một ý nghĩ.',
        '6B. Cấm vì muốn đạt số chữ tối thiểu mà lặp lại nội dung đồng nghĩa, thuật lại động tác, chất đống mô tả môi trường, ôn lại thiết lập, giải thích bối cảnh, gượng ép cảm ngộ, liên tục tự định nghĩa cảm xúc của mình, thêm phần tổng kết, hoặc tự dưng bịa ra sự kiện mới/bí mật mới/ký ức mới/thay đổi quan hệ mới.',
        '6C. Cuối cùng chỉ trả về chính hoạt động nội tâm của nhân vật này lúc này, viết bằng tiếng Việt; không viết tiêu đề, chú thích, phân tích, gạch đầu dòng, nhãn kiểu “góc nhìn thứ nhất” hay bất kỳ lời ngoài truyện nào; câu cuối cùng phải kết thúc trọn vẹn.',
        '',
        `Thời gian thế giới chính: ${formatWorldClockFactLabel(state)}`,
        'Trạng thái nhân vật:',
        JSON.stringify({
            name: person?.name,
            location: person?.location,
            action: person?.action,
            intent: person?.intent,
            long_term_goal: person?.longTermGoal,
            identity_anchor: profilePromptText(person?.identityAnchor, LIMITS.identityAnchor),
            personality_anchor: profilePromptText(person?.personalityAnchor, LIMITS.personalityAnchor),
            appearance_profile: profilePromptText(person?.appearanceProfile, LIMITS.appearanceProfile),
            background_profile: profilePromptText(person?.backgroundProfile, LIMITS.backgroundProfile),
            ability_profile: profilePromptText(person?.abilityProfile, LIMITS.abilityProfile),
            speaking_style: profilePromptText(person?.speakingStyle, LIMITS.speakingStyle),
            behavior_boundaries: profilePromptText(person?.behaviorBoundaries, LIMITS.behaviorBoundaries),
            inner_voice: person?.innerVoice,
            knowledge: person?.knowledge,
            cognition_ready: person?.cognitionReady,
            known_event_ids: person?.knownEventIds,
            known_event_views: relevantEvents,
            known_fact_keys: person?.knownFactKeys,
            known_fact_beliefs: relevantMemory.facts,
            known_clue_ids: person?.knownClueIds,
            physical_state: person?.physicalState,
            emotional_state: person?.emotionalState,
            resource_state: person?.resourceState,
        }),
        'Các phiên bản nhận thức sự kiện mà nhân vật này được dùng:',
        JSON.stringify(relevantEvents),
        'Ký ức dài hạn/niềm tin mà nhân vật này được dùng:',
        JSON.stringify(relevantMemory),
        'Không đòi hỏi, đoán hay tự viết bổ sung phần chính văn gần đây không được cung cấp; khi thiếu thông tin thì để nhân vật giữ trạng thái không biết.',
    ].join('\n');
}

function personLifeTickInterval(person) {
    const relevance = asInteger(person?.relevance, 1, 0, 3);
    if (relevance >= 3) return 12 * 60;
    if (relevance === 2) return 24 * 60;
    if (relevance === 1) return 48 * 60;
    return 72 * 60;
}

function personLifeTickInfo(state, person) {
    const now = asInteger(state?.clock?.absoluteMinute, 0, 0);
    const last = asInteger(
        person?.lastLifeTickAt ?? person?.updatedAt,
        now,
        0,
    );
    const interval = personLifeTickInterval(person);
    const elapsed = Math.max(0, now - last);
    return {
        last,
        interval,
        elapsed,
        overdue: Math.max(0, elapsed - interval),
        due: elapsed >= interval,
    };
}

export function listDueBackgroundPeople(state, {
    maximum = LIMITS.peopleTaskBudget,
    requiredOnly = false,
} = {}) {
    const limit = asInteger(maximum, LIMITS.peopleTaskBudget, 0);
    if (limit <= 0) return [];
    return asArray(state?.people)
        .filter(person => !person?.isUser && person?.simulationEnabled !== false)
        .map(person => {
            const life = personLifeTickInfo(state, person);
            const manualPriority = Boolean(person?.lifeTickPriority);
            // 三个完整生活周期仍未结算时进入保底队列。它只是强制“轮到她”，
            // 不代表人物凭空发生大事，也不会额外推进世界时间。
            const starvationGuard = life.elapsed >= life.interval * 3;
            return { person, life, manualPriority, starvationGuard };
        })
        .filter(item => (
            requiredOnly
                ? (item.manualPriority || item.starvationGuard)
                : (item.manualPriority || item.life.due)
        ))
        .sort((a, b) => (
            Number(b.manualPriority) - Number(a.manualPriority)
            || Number(b.starvationGuard) - Number(a.starvationGuard)
            || Number(a.person?.lifeTickPriorityAt || Number.MAX_SAFE_INTEGER)
                - Number(b.person?.lifeTickPriorityAt || Number.MAX_SAFE_INTEGER)
            || Number(b.life.overdue) - Number(a.life.overdue)
            || Number(b.person?.relevance || 0) - Number(a.person?.relevance || 0)
            || Number(a.life.last) - Number(b.life.last)
        ))
        .slice(0, limit)
        .map(({ person, life, manualPriority, starvationGuard }) => ({
            id: String(person.id || ''),
            name: String(person.name || ''),
            overdueMinutes: life.overdue,
            elapsedMinutes: life.elapsed,
            intervalMinutes: life.interval,
            lastLifeTickAt: life.last,
            priorityReason: manualPriority
                ? 'manual-next'
                : starvationGuard
                    ? 'starvation-guard'
                    : 'due',
        }));
}

export function compactStateForModel(state, {
    includeUserInnerVoice = false,
    includeUserCharacter = true,
    userName = '',
    maximumPeople = 14,
    allowExpandedPeopleContext = false,
    priorityPersonIds = [],
} = {}) {
    const maximum = asInteger(
        maximumPeople,
        14,
        1,
        allowExpandedPeopleContext ? Number.MAX_SAFE_INTEGER : LIMITS.peopleModelContext,
    );
    const candidates = [...state.people]
        .filter(person => includeUserCharacter || !isUserPersonLike(person, userName))
        .filter(person => person?.simulationEnabled !== false || isUserPersonLike(person, userName))
        .map(person => ({
            person,
            life: personLifeTickInfo(state, person),
        }));

    // Explicit scheduler targets must always be present with their full current
    // state. A target list containing only id/name is not enough to continue a
    // person's life safely, especially for manual catch-up before the normal due time.
    const priorityOrder = uniqueStrings(priorityPersonIds, maximum);
    const priorityRank = new Map(priorityOrder.map((id, index) => [id, index]));
    const priority = candidates
        .filter(item => priorityRank.has(String(item.person?.id || '')))
        .sort((a, b) => (
            Number(priorityRank.get(String(a.person?.id || '')) ?? Number.MAX_SAFE_INTEGER)
            - Number(priorityRank.get(String(b.person?.id || '')) ?? Number.MAX_SAFE_INTEGER)
        ))
        .slice(0, maximum);

    // Reserve part of every world call for people whose own lives are overdue,
    // so a long-absent NPC cannot fall out forever just because the foreground
    // stopped mentioning them. Manual next-round priority also counts as due for
    // context selection, even when its normal interval has not elapsed yet.
    const priorityIds = new Set(priority.map(item => item.person.id));
    const dueQuota = Math.max(0, Math.max(1, Math.floor(maximum / 2)) - priority.length);
    const due = candidates
        .filter(item => !priorityIds.has(item.person.id))
        .filter(item => !item.person?.isUser && (item.person?.lifeTickPriority || item.life.due))
        .sort((a, b) => (
            Number(Boolean(b.person?.lifeTickPriority)) - Number(Boolean(a.person?.lifeTickPriority))
            || Number(b.life.overdue) - Number(a.life.overdue)
            || Number(b.person.relevance || 0) - Number(a.person.relevance || 0)
            || Number(a.life.last) - Number(b.life.last)
        ))
        .slice(0, dueQuota);

    const selectedIds = new Set([...priority, ...due].map(item => item.person.id));
    const regular = candidates
        .filter(item => !selectedIds.has(item.person.id))
        .sort((a, b) => (
            Number(b.person.relevance || 0) - Number(a.person.relevance || 0)
            || Number(b.person.presentInSceneMessageId || -1) - Number(a.person.presentInSceneMessageId || -1)
            || Number(b.person.updatedAt || 0) - Number(a.person.updatedAt || 0)
        ))
        .slice(0, Math.max(0, maximum - due.length));

    const people = [...priority, ...due, ...regular].slice(0, maximum).map(item => item.person);
    const lifeById = new Map(candidates.map(item => [item.person.id, item.life]));
    const eventPriority = event => (
        event.delivery?.state === 'pending' ? 4
            : event.status === 'ready' ? 3
                : ['active', 'waiting'].includes(event.status) ? 2
                    : 1
    );
    const eventCandidates = state.events
        .filter(event => !['cancelled', 'missed'].includes(event.status) || event.delivery.state === 'pending')
        .sort((a, b) => (
            eventPriority(b) - eventPriority(a)
            || Number(b.updatedAt || 0) - Number(a.updatedAt || 0)
        ));
    const events = eventCandidates.slice(0, 20);

    // Detailed event payload stays capped for token safety, but every other
    // ongoing event still exposes a compact identity row. This prevents an old
    // dark-current from becoming invisible after the first 20 entries and then
    // being recreated under a new id/title on the next model call.
    const detailedEventIds = new Set(events.map(event => event.id));
    const eventIndex = state.events
        .filter(event => !TERMINAL_EVENT_STATES.has(event.status))
        .filter(event => !detailedEventIds.has(event.id))
        .sort((a, b) => (
            eventPriority(b) - eventPriority(a)
            || Number(b.updatedAt || 0) - Number(a.updatedAt || 0)
        ))
        .slice(0, LIMITS.events);

    return {
        // Numeric minute coordinates are model-visible only when minute precision is
        // actually known. Coarse date/day/daypart states keep their internal minute
        // solely for deterministic scheduling; exposing it here would let the model
        // reconstruct a clock time that the narrative never established.
        world_now: state.clock?.anchored && state.clock?.precision === 'minute'
            ? state.clock.absoluteMinute
            : null,
        world_story_minute: state.clock?.precision === 'minute'
            ? state.clock?.absoluteMinute ?? 0
            : null,
        world_day_index: Math.floor((state.clock?.absoluteMinute ?? 0) / MINUTES_PER_DAY),
        world_now_coordinate_only: state.clock?.precision !== 'minute',
        world_now_label: formatWorldClockFactLabel(state),
        world_clock_anchored: Boolean(state.clock?.anchored),
        world_clock_precision: state.clock?.precision || 'day',
        world: {
            name: modelText(state.world.name, 80),
            title: modelText(state.world.title, 140),
            detail: modelText(state.world.detail, 360),
            background: modelText(state.world.background, LIMITS.worldBackground),
        },
        world_pulse: {
            baseline_established: Boolean(state.worldPulse?.baselineEstablished),
            last_sweep_at: Number(state.worldPulse?.lastSweepAt || 0),
            coverage: {
                last_sweep_at: Number(state.worldPulse?.coverage?.lastSweepAt ?? -1),
                last_public_sweep_at: Number(state.worldPulse?.coverage?.lastPublicSweepAt ?? -1),
                recent_checks: asArray(state.worldPulse?.coverage?.entries)
                    .slice(0, 12)
                    .map(entry => ({
                        id: entry.id,
                        label: modelText(entry.label, 120),
                        kind: entry.kind,
                        scope: modelText(entry.scope, 140),
                        last_checked_at: Number(entry.lastCheckedAt ?? -1),
                        checks: Number(entry.checks || 0),
                    })),
            },
            domains: asArray(state.worldPulse?.domains)
                .sort((a, b) => (
                    Number(b.pressure || 0) - Number(a.pressure || 0)
                    || Number(b.updatedAt || 0) - Number(a.updatedAt || 0)
                ))
                .slice(0, LIMITS.worldPulseDomains)
                .map(domain => ({
                    id: domain.id,
                    label: modelText(domain.label, 100),
                    scope: modelText(domain.scope, 120),
                    kind: domain.kind,
                    state: modelText(domain.state, 360),
                    pressure: domain.pressure,
                    trend: domain.trend,
                    visibility: domain.visibility,
                    evidence: modelText(domain.evidence, 220),
                })),
        },
        recent_public_impacts: asArray(state.publicImpactLedger)
            .slice(0, 12)
            .map(record => ({
                source_event_id: record.sourceEventId,
                summary: modelText(record.summary, 260),
                affected_person_ids: record.affectedPersonIds,
                affected_scopes: record.affectedScopes,
                channels: record.channels,
                processed_at: record.processedAt,
            })),
        world_facts: asArray(state.worldFacts)
            .filter(fact => fact?.confidence === 'high')
            .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0))
            .slice(0, 24)
            .map(fact => ({
                key: fact.key,
                subject_type: fact.subjectType,
                subject_id: fact.subjectId,
                subject: modelText(fact.subject, 120),
                field: modelText(fact.field, 80),
                value: modelText(fact.value, 360),
                validity: fact.validity || 'current',
                visibility: fact.visibility,
                event_id: fact.eventId || '',
                updated_at: fact.updatedAt,
            })),
        people: people.map(person => {
            const isUser = isUserPersonLike(person, userName);
            return {
                id: person.id,
                name: modelText(person.name, 80),
                is_user: isUser,
                location: modelText(person.location, 120),
                action: modelText(person.action, 180),
                intent: modelText(person.intent, 180),
                long_term_goal: modelText(person.longTermGoal, 220),
                identity_anchor: profilePromptText(person.identityAnchor, LIMITS.identityAnchor),
                personality_anchor: profilePromptText(person.personalityAnchor, LIMITS.personalityAnchor),
                appearance_profile: profilePromptText(person.appearanceProfile, 360),
                background_profile: profilePromptText(person.backgroundProfile, 500),
                ability_profile: profilePromptText(person.abilityProfile, LIMITS.abilityProfile),
                speaking_style: profilePromptText(person.speakingStyle, LIMITS.speakingStyle),
                behavior_boundaries: profilePromptText(person.behaviorBoundaries, LIMITS.behaviorBoundaries),
                inner_voice: isUser && !includeUserInnerVoice
                    ? ''
                    : modelText(person.innerVoice, 160),
                inner_voice_at: person.innerVoiceAt,
                knowledge: person.knowledge,
                cognition_ready: person.cognitionReady,
                known_event_ids: person.knownEventIds,
                known_event_views: person.knownEventViews,
                known_fact_keys: person.knownFactKeys,
                known_fact_beliefs: person.knownFactBeliefs,
                known_clue_ids: person.knownClueIds,
                physical_state: modelText(person.physicalState, LIMITS.personState),
                emotional_state: modelText(person.emotionalState, LIMITS.personState),
                resource_state: modelText(person.resourceState, LIMITS.personState),
                relevance: person.relevance,
                background_simulation: person.simulationEnabled !== false,
                locked_profile: Boolean(person.locked),
                author_managed: Boolean(person.manual || person.worldbookRef || person.source === 'manual'),
                last_seen_message_id: person.lastSeenMessageId,
                last_life_tick_at: lifeById.get(person.id)?.last ?? person.lastLifeTickAt ?? person.updatedAt,
                life_tick_interval_minutes: lifeById.get(person.id)?.interval ?? personLifeTickInterval(person),
                life_tick_due_minutes: lifeById.get(person.id)?.overdue ?? 0,
                life_tick_priority: Boolean(person.lifeTickPriority),
            };
        }),
        events: events.map(event => ({
                id: event.id,
                title: modelText(event.title, 120),
                place: modelText(event.place, 100),
                summary: modelText(event.summary, 180),
                consequence: modelText(event.consequence, 180),
                expected_result: modelText(event.expectedResult, 180),
                result: modelText(event.result, 180),
                status: event.status,
                clock_mode: event.clockMode,
                started_at: event.startedAt,
                due_at: event.dueAt,
                duration_minutes: event.durationMinutes,
                accrued_minutes: event.accruedMinutes,
                prerequisites: event.prerequisites,
                cause: modelText(event.cause, LIMITS.eventCause),
                actors: event.actors,
                known_by: event.knownBy,
                caused_by: event.causedBy,
                public_trace: modelText(event.publicTrace, LIMITS.eventPublicTrace),
                public_headline: modelText(event.publicHeadline, 180),
                public_summary: modelText(event.publicSummary, 360),
                public_result: modelText(event.publicResult, 360),
                publicity: event.publicity || 'private',
                visibility: event.visibility,
                delivery_state: event.delivery.state,
            })),
        event_index: eventIndex.map(event => ({
            id: event.id,
            title: modelText(event.title, 120),
            place: modelText(event.place, 100),
            status: event.status,
            actors: asArray(event.actors).slice(0, 8),
            caused_by: asArray(event.causedBy).slice(0, 8),
            updated_at: event.updatedAt,
        })),
        omitted: {
            people: Math.max(0, state.people.length - people.length),
            events: Math.max(0, state.events.length - events.length - eventIndex.length),
        },
    };
}


function correctionEvidenceSource(raw) {
    const source = asString(
        raw?.evidence_source ?? raw?.evidenceSource,
        'narrative',
        40,
    ).toLowerCase();
    return ['narrative', 'character_anchor', 'world_background', 'manual_fact'].includes(source)
        ? source
        : 'narrative';
}

function correctionEvidenceSupported(state, narrativeText, correction) {
    const evidence = normalizedEvidenceText(
        correction?.evidence
        ?? correction?.evidence_excerpt
        ?? correction?.evidenceExcerpt,
    );
    if (!evidence || evidence.length < 4) return false;
    const source = correctionEvidenceSource(correction);

    if (source === 'narrative') {
        return normalizedEvidenceText(narrativeText).includes(evidence);
    }
    if (source === 'world_background') {
        return normalizedEvidenceText(state?.world?.background).includes(evidence);
    }
    if (source === 'character_anchor') {
        const personId = asString(
            correction?.person_id ?? correction?.personId ?? correction?.subject_id ?? correction?.subjectId,
            '',
            120,
        );
        const targetMemoryFact = findMemoryFactForCorrection(state, correction);
        const targetWorldFact = findWorldFactForCorrection(state, correction);
        const personName = asString(
            correction?.person_name
            ?? correction?.personName
            ?? correction?.subject
            ?? targetMemoryFact?.subject
            ?? targetWorldFact?.subject,
            '',
            100,
        );
        const person = asArray(state?.people).find(item => (
            (personId && item?.id === personId)
            || (personName && item?.name === personName)
        ));
        if (!person) return false;
        const anchorText = normalizedEvidenceText([
            person.identityAnchor,
            person.personalityAnchor,
            person.backgroundProfile,
            person.abilityProfile,
            person.worldbookRaw,
            person.speakingStyle,
            person.behaviorBoundaries,
        ].filter(Boolean).join('\n'));
        return anchorText.includes(evidence);
    }
    if (source === 'manual_fact') {
        return asArray(state?.worldFacts).some(fact => (
            fact?.source === 'manual'
            && normalizedEvidenceText(`${fact.subject}${fact.field}${fact.value}`).includes(evidence)
        ));
    }
    return false;
}

function correctionSourceForEvidence(correction) {
    return correctionEvidenceSource(correction) === 'narrative'
        ? 'narrative'
        : 'manual';
}

function findWorldFactForCorrection(state, correction) {
    const key = asString(correction?.key, '', 180);
    if (key) {
        return asArray(state?.worldFacts).find(fact => fact?.key === key) || null;
    }
    const subjectId = asString(
        correction?.subject_id ?? correction?.subjectId,
        '',
        120,
    ).toLocaleLowerCase();
    const subject = asString(correction?.subject, '', 140).toLocaleLowerCase();
    const field = asString(correction?.field, '', 80).toLocaleLowerCase();
    return asArray(state?.worldFacts).find(fact => (
        (!field || String(fact?.field || '').toLocaleLowerCase() === field)
        && (
            (subjectId && String(fact?.subjectId || '').toLocaleLowerCase() === subjectId)
            || (subject && String(fact?.subject || '').toLocaleLowerCase() === subject)
        )
    )) || null;
}

function findMemoryFactForCorrection(state, correction) {
    const factId = asString(
        correction?.fact_id ?? correction?.factId ?? correction?.id,
        '',
        120,
    );
    const key = asString(correction?.key, '', 180);
    return asArray(state?.storyMemory?.facts).find(fact => (
        (factId && fact?.id === factId)
        || (key && fact?.key === key)
    )) || null;
}

function correctionPersonField(rawField) {
    const field = asString(rawField, '', 80);
    const aliases = {
        location: 'location',
        action: 'action',
        intent: 'intent',
        physical_state: 'physicalState',
        physicalState: 'physicalState',
        emotional_state: 'emotionalState',
        emotionalState: 'emotionalState',
        resource_state: 'resourceState',
        resourceState: 'resourceState',
    };
    return aliases[field] || '';
}

export function buildStateCorrectionPrompt(state, {
    narrativeText = '',
    userName = '',
} = {}) {
    const people = asArray(state?.people)
        .slice(0, LIMITS.peopleModelContext)
        .map(person => ({
            id: person.id,
            name: person.name,
            is_user: Boolean(person.isUser),
            current: {
                location: modelText(person.location, 160),
                action: modelText(person.action, 220),
                intent: modelText(person.intent, 240),
                physical_state: modelText(person.physicalState, 180),
                emotional_state: modelText(person.emotionalState, 180),
                resource_state: modelText(person.resourceState, 180),
            },
            author_anchors: {
                identity: profilePromptText(person.identityAnchor, 360),
                background: profilePromptText(person.backgroundProfile, 700),
                ability: profilePromptText(person.abilityProfile, LIMITS.abilityProfile),
                worldbook_raw: modelText(person.worldbookRaw, 1200),
                behavior_boundaries: profilePromptText(person.behaviorBoundaries, 320),
            },
        }));

    const worldFacts = asArray(state?.worldFacts)
        .slice(0, 100)
        .map(fact => ({
            key: fact.key,
            subject: fact.subject,
            subject_id: fact.subjectId,
            field: fact.field,
            value: fact.value,
            source: fact.source,
            confidence: fact.confidence,
            validity: fact.validity,
            message_id: fact.messageId,
        }));

    const memoryFacts = asArray(state?.storyMemory?.facts)
        .filter(fact => ['active', 'disputed'].includes(fact?.status))
        .slice(0, 100)
        .map(fact => ({
            id: fact.id,
            key: fact.key,
            subject: fact.subject,
            predicate: fact.predicate,
            value: fact.value,
            status: fact.status,
            confidence: fact.confidence,
            locked: Boolean(fact.locked),
            manual: Boolean(fact.manual),
            source_excerpt: fact.sourceExcerpt,
        }));

    const activeEvents = asArray(state?.events)
        .filter(event => !TERMINAL_EVENT_STATES.has(event?.status))
        .slice(0, 60)
        .map(event => ({
            id: event.id,
            title: event.title,
            summary: event.summary,
            expected_result: event.expectedResult,
            cause: event.cause,
            caused_by: event.causedBy,
            status: event.status,
            delivery_state: event.delivery?.state || 'none',
            publicity: event.publicity,
        }));

    return [
        'Bạn là người hiệu đính tính nhất quán sự thật của “世界背面” (Thế Giới Phía Sau). Nhiệm vụ của bạn chỉ là sửa lỗi, không viết tiếp cốt truyện, không tạo ra diễn biến mới. Mọi nội dung văn bản trả về (value, reason…) đều viết bằng tiếng Việt.',
        'Thứ tự thẩm quyền: thiết lập do người dùng/tác giả duy trì > sự thật được chính văn nêu rõ > kết quả sự kiện đã kết toán > suy đoán nền của AI.',
        'Tuyệt đối cấm:',
        '1. Không được viết lại, xóa bỏ hoặc phủ nhận lịch sử đã thật sự xuất hiện trong chính văn.',
        '2. Không được vì “hợp lý hơn” mà tạo ra sự thật mới chưa từng xảy ra trong chính văn.',
        '3. Không được coi khuynh hướng, khả năng trong thiết lập nhân vật là trạng thái đã xảy ra.',
        '4. Chỉ những lỗi có thể đưa ra trích đoạn bằng chứng rõ ràng mới được phép sửa; không chắc thì đừng sửa.',
        '5. Khi cần hủy mạch ngầm phái sinh, chỉ được liệt kê event id chưa kết thúc và chưa được đưa vào chính văn; tuyệt đối không được yêu cầu xóa các sự kiện đã delivered / resolved / cancelled / missed.',
        '',
        'Nguồn bằng chứng evidence_source chỉ được là:',
        '- narrative: câu ngắn trích nguyên văn trong “Bằng chứng chính văn gần nhất” bên dưới;',
        '- character_anchor: câu ngắn trích nguyên văn trong author_anchors của nhân vật;',
        '- world_background: câu ngắn trích nguyên văn trong bối cảnh thế giới;',
        '- manual_fact: câu ngắn trích nguyên văn từ sự thật thế giới hiện có source=manual.',
        '',
        'Các correction kind được phép:',
        '- world_fact: sửa sự thật thế giới đã tồn tại. Cung cấp key/value.',
        '- memory_fact: sửa sự thật dài hạn bị sai. Cung cấp fact_id hoặc key, kèm value.',
        '- person_state: chỉ sửa location/action/intent/physical_state/emotional_state/resource_state, không được sửa tính cách, danh tính, bối cảnh, ngoại hình hay lịch sử của nhân vật.',
        '',
        'Nếu một sự thật nền sai đã phái sinh ra mạch ngầm chưa xảy ra, có thể đưa event id vào cancel_event_ids. Đừng hủy sự kiện chỉ vì “không thích”, chỉ hủy những phái sinh rõ ràng phụ thuộc vào sự thật sai.',
        'Chỉ trả về JSON hợp lệ, không dùng code fence và không giải thích.',
        '',
        `Tên nhân vật của người chơi: ${modelText(userName, 80) || 'Chưa cung cấp'}`,
        `Bối cảnh thế giới: ${modelText(state?.world?.background, 2400) || '(trống)'}`,
        'Trạng thái nhân vật và điểm neo tác giả:',
        JSON.stringify(people),
        'Sự thật thế giới hiện tại:',
        JSON.stringify(worldFacts),
        'Sự thật dài hạn hiện tại:',
        JSON.stringify(memoryFacts),
        'Các sự kiện hiện chưa kết thúc:',
        JSON.stringify(activeEvents),
        'Bằng chứng chính văn gần nhất:',
        modelText(narrativeText, 16000),
        '',
        'Cấu trúc trả về:',
        JSON.stringify({
            corrections: [
                {
                    kind: 'world_fact',
                    key: 'person:xxx:relationship',
                    value: 'giá trị đúng',
                    evidence_source: 'character_anchor',
                    evidence: 'Bằng chứng ngắn bắt buộc tồn tại nguyên văn',
                    reason: 'Vì sao trạng thái hiện tại mâu thuẫn với bằng chứng',
                },
            ],
            cancel_event_ids: [],
        }),
    ].join('\n');
}

export function applyStateCorrectionResult(inputState, rawPayload, {
    narrativeText = '',
    messageId = null,
} = {}) {
    const state = deepClone(inputState);
    state.storyMemory = normalizeStoryMemory(state.storyMemory, state.clock?.absoluteMinute || 0);
    const corrections = asArray(rawPayload?.corrections).slice(0, 24);
    const appliedCorrections = [];
    const skippedCorrections = [];
    const correctedOldValues = [];

    for (const rawCorrection of corrections) {
        const kind = asString(rawCorrection?.kind, '', 40);
        const value = asString(rawCorrection?.value, '', 520);
        if (!kind || !value || !correctionEvidenceSupported(state, narrativeText, rawCorrection)) {
            skippedCorrections.push(rawCorrection);
            continue;
        }

        if (kind === 'world_fact') {
            const existing = findWorldFactForCorrection(state, rawCorrection);
            if (!existing || existing.value === value) {
                skippedCorrections.push(rawCorrection);
                continue;
            }
            if (existing.source === 'manual') {
                skippedCorrections.push(rawCorrection);
                continue;
            }
            const oldValue = existing.value;
            const result = upsertWorldFact(state, {
                ...existing,
                value,
                confidence: 'high',
                source: correctionSourceForEvidence(rawCorrection),
                message_id: messageId ?? existing.messageId,
            }, {
                source: correctionSourceForEvidence(rawCorrection),
                messageId,
            });
            if (result?.value === value) {
                correctedOldValues.push(oldValue);
                appliedCorrections.push({
                    kind,
                    key: existing.key,
                    from: oldValue,
                    to: value,
                    evidence: asString(rawCorrection?.evidence, '', 220),
                });
            } else {
                skippedCorrections.push(rawCorrection);
            }
            continue;
        }

        if (kind === 'memory_fact') {
            const existing = findMemoryFactForCorrection(state, rawCorrection);
            if (!existing || existing.locked || existing.manual || existing.value === value) {
                skippedCorrections.push(rawCorrection);
                continue;
            }
            const oldValue = existing.value;
            applyMemoryFactUpdates(state, {
                factsUpsert: [{
                    key: existing.key,
                    subject: existing.subject,
                    predicate: existing.predicate,
                    value,
                    confidence: 'high',
                    importance: existing.importance,
                    visibility: existing.visibility,
                    people: existing.people,
                    locations: existing.locations,
                    tags: uniqueStrings([...(existing.tags || []), 'Sửa lỗi sự thật'], 24),
                    source_excerpt: asString(rawCorrection?.evidence, '', 220),
                    manual: false,
                    status: 'active',
                }],
            }, {
                sourceMessageId: messageId ?? existing.sourceMessageId ?? 0,
                sourceSwipeId: existing.sourceSwipeId ?? 0,
            });
            const corrected = asArray(state.storyMemory.facts).find(fact => (
                fact.key === existing.key
                && fact.value === value
                && ['active', 'disputed'].includes(fact.status)
            ));
            if (corrected) {
                correctedOldValues.push(oldValue);
                appliedCorrections.push({
                    kind,
                    key: existing.key,
                    from: oldValue,
                    to: value,
                    evidence: asString(rawCorrection?.evidence, '', 220),
                });
            } else {
                skippedCorrections.push(rawCorrection);
            }
            continue;
        }

        if (kind === 'person_state') {
            const personId = asString(
                rawCorrection?.person_id ?? rawCorrection?.personId ?? rawCorrection?.subject_id ?? rawCorrection?.subjectId,
                '',
                120,
            );
            const personName = asString(rawCorrection?.person_name ?? rawCorrection?.personName ?? rawCorrection?.subject, '', 100);
            const person = asArray(state.people).find(item => (
                (personId && item?.id === personId)
                || (personName && item?.name === personName)
            ));
            const field = correctionPersonField(rawCorrection?.field);
            if (!person || !field || person[field] === value) {
                skippedCorrections.push(rawCorrection);
                continue;
            }
            const oldValue = asString(person[field], '', 520);
            person[field] = value;
            person.updatedAt = state.clock?.absoluteMinute || 0;
            settlePersonStateFacts(
                state,
                person,
                correctionSourceForEvidence(rawCorrection),
                messageId,
            );
            correctedOldValues.push(oldValue);
            appliedCorrections.push({
                kind,
                key: `${person.id}:${field}`,
                from: oldValue,
                to: value,
                evidence: asString(rawCorrection?.evidence, '', 220),
            });
            continue;
        }

        skippedCorrections.push(rawCorrection);
    }

    const requestedEventIds = new Set(
        uniqueStrings(rawPayload?.cancel_event_ids ?? rawPayload?.cancelEventIds, 24),
    );
    const removedEventIds = [];
    if (requestedEventIds.size && appliedCorrections.length) {
        state.events = asArray(state.events).filter(event => {
            if (!requestedEventIds.has(event?.id)) return true;
            if (
                TERMINAL_EVENT_STATES.has(event?.status)
                || event?.delivery?.state === 'delivered'
            ) return true;
            const dependencyText = normalizedEvidenceText([
                event?.title,
                event?.summary,
                event?.cause,
                event?.expectedResult,
                event?.consequence,
            ].filter(Boolean).join('\n'));
            const explicitlyDependsOnCorrectedError = correctedOldValues.some(oldValue => {
                const normalizedOld = normalizedEvidenceText(oldValue);
                return normalizedOld.length >= 2 && dependencyText.includes(normalizedOld);
            });
            if (!explicitlyDependsOnCorrectedError) return true;
            removedEventIds.push(event.id);
            return false;
        });
        if (removedEventIds.length) {
            const removed = new Set(removedEventIds);
            state.echoes = asArray(state.echoes).filter(echo => !removed.has(echo?.eventId));
            state.archive = asArray(state.archive).filter(entry => !removed.has(entry?.eventId));
            state.worldFacts = asArray(state.worldFacts).filter(fact => !(
                removed.has(fact?.eventId)
                || removedEventIds.some(eventId => String(fact?.key || '').startsWith(`event:${eventId}:`))
                || removedEventIds.some(eventId => String(fact?.key || '').startsWith(`public_event:${eventId}:`))
            ));
            state.publicImpactLedger = asArray(state.publicImpactLedger)
                .filter(record => !removed.has(record?.sourceEventId));
        }
    }

    if (appliedCorrections.length || removedEventIds.length) {
        appendAudit(state, {
            type: 'state_correction',
            text: `Sửa lỗi sự thật: đã sửa ${appliedCorrections.length} mục${removedEventIds.length ? `, hủy ${removedEventIds.length} sự kiện phái sinh chưa xảy ra` : ''}`,
            reason: appliedCorrections
                .slice(0, 4)
                .map(item => `${item.key}：${item.from} → ${item.to}`)
                .join('；')
                .slice(0, 700),
        });
        state.revision = asInteger(state.revision, 0, 0) + 1;
        state.updatedAt = nowIso();
    }

    return {
        state: trimState(state),
        applied: appliedCorrections,
        skipped: skippedCorrections.length,
        removedEventIds,
        oldValues: uniqueStrings(correctedOldValues, 24),
    };
}

export function buildSimulationPrompt(state, {
    queuedEventIds = [],
    trigger = 'reply',
    latestTurn = {},
    narrativeTurns = [],
    userName = '',
    includeUserInnerVoice = false,
    recordPlayerCharacter = true,
    timePolicy = 'world',
    simulationMode = 'balanced',
    customInstruction = '',
    playerIdentityAnchor = '',
    newAssistantTurns = 1,
    backgroundNpcBudget = 4,
    worldPulseActivity = 'natural',
    enhancedBackgroundSimulation = false,
    backgroundPersonTargets = [],
    worldCoverageTargets = [],
    directorNotes = [],
    socialContext = [],
} = {}) {
    const compact = compactStateForModel(state, {
        includeUserInnerVoice,
        includeUserCharacter: recordPlayerCharacter,
        userName,
        allowExpandedPeopleContext: true,
        priorityPersonIds: asArray(backgroundPersonTargets).map(item => String(item?.id || '')).filter(Boolean),
        maximumPeople: enhancedBackgroundSimulation
            ? Math.max(14, Number(backgroundNpcBudget) * 2 + 6)
            : Math.max(10, Number(backgroundNpcBudget) + 10),
    });
    const queued = uniqueStrings(queuedEventIds, 24);
    const latestUser = modelText(latestTurn?.user, 6000);
    const latestAssistant = modelNarrativeText(latestTurn?.assistant, { maximum: 9000, tail: 5600 });
    const rawNarrativeTurns = asArray(narrativeTurns);
    const rawAssistantIndexes = rawNarrativeTurns
        .map((turn, index) => turn?.role === 'assistant' ? index : -1)
        .filter(index => index >= 0);
    const newRawAssistantIndexSet = new Set(
        rawAssistantIndexes.slice(-asInteger(newAssistantTurns, 1, 1, 20)),
    );
    const contextTurns = rawNarrativeTurns
        .map((turn, index) => ({
            role: turn?.role === 'assistant' ? 'assistant' : 'user',
            content: turn?.role === 'assistant'
                ? (newRawAssistantIndexSet.has(index)
                    ? modelNarrativeText(turn?.content, { maximum: 8000, tail: 5000 })
                    : modelText(turn?.content, 4200))
                : modelText(turn?.content, 3000),
            messageId: Number.isInteger(Number(turn?.messageId)) ? Number(turn.messageId) : index,
            swipeId: Number.isInteger(Number(turn?.swipeId)) ? Number(turn.swipeId) : 0,
            index,
        }))
        .filter(turn => turn.content);
    if (!contextTurns.length) {
        if (latestUser) contextTurns.push({ role: 'user', content: latestUser, index: 0 });
        if (latestAssistant) contextTurns.push({ role: 'assistant', content: latestAssistant, index: 1 });
    }
    const assistantIndexes = contextTurns
        .filter(turn => turn.role === 'assistant')
        .map(turn => turn.index);
    const newAssistantIndexSet = new Set(
        assistantIndexes.slice(-asInteger(newAssistantTurns, 1, 1, 20)),
    );
    const narrativeBlock = contextTurns
        .map(turn => (
            `<${turn.role}_turn order="${turn.index + 1}" message_id="${turn.messageId}" `
            + `swipe_id="${turn.swipeId}" new="${newAssistantIndexSet.has(turn.index)}">`
            + `${turn.content}</${turn.role}_turn>`
        ))
        .join('\n');
    const relevantMemory = selectRelevantStoryMemory(state, narrativeBlock, {
        maximumClues: 8,
        maximumSummaries: 4,
    });
    const timeRule = {
        explicit: 'Thời gian nghiêm ngặt: chỉ khi chính văn nêu rõ mấy giờ, bao nhiêu phút/giờ/ngày hoặc rõ ràng đã sang ngày hôm sau thì elapsed_minutes mới được lớn hơn 0; các từ mang tính không khí hoặc mơ hồ như “màn đêm buông xuống, một lúc sau, đêm đầu tiên, rất lâu” đều điền 0.',
        cautious: 'Ước tính tiết chế: thời gian rõ ràng thì tính bình thường; chỉ khi thời gian thay đổi mơ hồ mới được ước tính thận trọng, nhưng không được vượt quá 180 phút.',
        open: 'Ước tính cởi mở: cho phép ước tính thời lượng đã trôi qua dựa trên thay đổi thời gian rõ ràng trong mạch truyện, nhưng vẫn không được coi số lượt trả lời là thời gian.',
        world: 'Chế độ đồng hồ thế giới: một khi đồng hồ thế giới chính đã được thiết lập thì đó là mốc thời gian liên tục. Đừng đoán lại “bây giờ là mấy giờ”; chỉ dựa vào hành động, quãng đường, chờ đợi, giấc ngủ, công việc… thật sự xảy ra trong chính văn new="true" để ước tính thời lượng thực tế trôi qua trong đợt này. Không có sự kiện tốn thời gian thì điền 0; không được coi bản thân lượt trả lời là thời gian.',
    }[timePolicy] || 'Thời gian nghiêm ngặt: không có bằng chứng thời gian rõ ràng, tính được thì điền 0.';
    const clockAuthorityRule = 'Về thời gian, xét thời điểm cuối trước rồi mới xét thời lượng: khi cảnh hiện tại có ngày/giờ cuối rõ ràng thì time_resolution.evidence_found=true, authority=explicit_end_time, scope=current, confidence=high, elapsed_minutes=0. Ngày hoặc giờ lặp lại ở đầu chính văn chỉ là điểm bắt đầu của cảnh, không có nghĩa là khi các hành động sau đó kết thúc vẫn dừng ở thời điểm ấy; chỉ lặp lại ngày của cùng một hôm cũng không thể dựa vào đó để đưa thời lượng về 0. Hẹn ước tương lai/hồi ức/thuật lại không được coi là thời gian hiện tại. Không có giờ rõ ràng không có nghĩa là không tốn thời gian; ví dụ khi trong đợt này thật sự đã ăn xong một bữa, đi bộ đến một địa điểm khác, dọn dẹp xong hoặc làm xong việc, thì phải ước tính thận trọng dựa theo nội dung mạch truyện, chứ không phải vì không có “mấy phút” mà điền 0; gật đầu trong chớp mắt hay một câu thoại có thể là 0, cấm cộng thêm thời gian cố định theo số lượt trả lời. Không có thời gian cuối nhưng chính văn thật sự trải qua di chuyển đường dài, ngủ, chờ đợi, làm việc…, thì needs_elapsed_estimate=true, và để estimated_minutes khớp với elapsed_minutes. Ngủ rồi thức dậy, đi đường dài qua nhiều khu vực, nhiều ca/lượt/bữa ăn, hoàn thành công việc kéo dài… đều mang ngữ nghĩa tốn thời gian rõ ràng, dù không có giờ cũng không được máy móc điền 0; hãy ước tính thận trọng theo quy mô mạch truyện. Mỗi trường authority/scope/confidence của time_resolution chỉ được điền một giá trị hợp lệ. Thời gian tuyệt đối cuối cùng vẫn do mã xác định của plugin kiểm chứng.';
    const identityAnchor = modelText(playerIdentityAnchor, 400);
    const playerIdentityRule = identityAnchor
        ? `Điểm neo danh tính người chơi do người dùng thiết lập rõ ràng: ${identityAnchor}. Khi liên quan đến giới tính/danh tính giới, cách xưng hô/đại từ, biểu hiện ngoại hình, thiết lập cơ thể, chủng loài, giai đoạn tuổi hoặc danh tính xã hội của người chơi thì phải tuân thủ từng mục, trừ khi người dùng cập nhật điểm neo này; không được suy ngược giới tính từ ngoại hình, trang phục, cơ thể hay chủng loài.`
        : 'Người dùng chưa thiết lập điểm neo danh tính người chơi; khi chính văn không nêu rõ danh tính hoặc cách xưng hô thì phải dùng cách diễn đạt trung tính, không được đoán giới tính từ ngoại hình, trang phục, cơ thể hay chủng loài.';
    const userVoiceRule = recordPlayerCharacter
        ? `Tên nhân vật của người chơi là “${modelText(userName, 80) || 'Chưa cung cấp'}”; cho phép ghi vào people_upsert vị trí, hành động và trạng thái khách quan của người chơi đã xảy ra rõ ràng trong chính văn, bắt buộc đánh dấu is_user=true; inner_voice phải để trống, tuyệt đối không viết hoạt động nội tâm thay người chơi.`
        : `Tên nhân vật của người chơi là “${modelText(userName, 80) || 'Chưa cung cấp'}”; thiết lập lần này cấm rõ việc ghi nhận nhân vật người chơi: không tạo hay cập nhật people_upsert cho người chơi, cũng không đưa người chơi vào people_remove. Hành động của người chơi đã xảy ra trong chính văn vẫn là sự thật thế giới, có thể ảnh hưởng đến sự kiện, vật phẩm, địa điểm, quan hệ và world_facts, nhưng không được lập thẻ trạng thái nhân vật cho người chơi hay đoán nội tâm của họ.`;
    const simulationRule = {
        light: 'Suy diễn nhẹ: trước hết đồng bộ sự thật trong chính văn, rồi làm một lần kiểm tra tự vận hành rất nhẹ của thế giới. Nếu hậu quả của sự kiện có sẵn, mục tiêu đã định của nhân vật hoặc áp lực môi trường rõ ràng đã tự nhiên hình thành bước tiếp theo, có thể tạo tối đa 1 mạch ngầm ngoài ống kính; không có nhân quả thì giữ yên lặng.',
        balanced: 'Suy diễn cân bằng: sau khi đồng bộ chính văn, bắt buộc kiểm tra xem bản thân thế giới có lý do để tiếp tục tiến lên hay không. Hậu quả sự kiện có sẵn, mục tiêu nhân vật, hành động của các thế lực và thay đổi môi trường đều có thể độc lập sinh ra mạch ngầm mới; thường thêm 0–2 mạch, thà thiếu chứ không ẩu.',
        deep: 'Suy diễn sâu: với điều kiện giữ vững nhân quả và ranh giới hiểu biết, nghiêm túc duy trì nhân vật, thế lực và chuỗi sự kiện ngoài ống kính. Có thể để nhiều áp lực có sẵn tự nhiên mọc ra mạch ngầm tiếp theo, nhưng mỗi mạch đều phải có nguồn gốc rõ ràng, không được vì muốn náo nhiệt mà gượng ép tạo tai nạn hay thảm họa.',
        manual: 'Suy diễn cân bằng thủ công: đồng bộ chính văn và kiểm tra sự phát triển tự chủ của thế giới theo mức cân bằng, không vì được kích hoạt thủ công mà lặp lại thay đổi cũ.',
    }[simulationMode] || 'Suy diễn cân bằng: đồng bộ chính văn, đồng thời duy trì nhân quả mà bản thân thế giới có thể tự nhiên tiếp diễn.';
    const customRule = modelText(customInstruction, 1000);
    const pulseActivityRule = {
        quiet: 'Nhịp đập thế giới thiên yên tĩnh: ưu tiên đẩy tiến các áp lực vĩ mô đã tồn tại và các hạng mục đến hạn. Sự kiện công cộng độc lập nên rất ít, trạng thái bình ổn thông thường hoàn toàn có thể kéo dài; đừng vì muốn chứng minh thế giới đang vận hành mà tạo ra tin tức.',
        natural: 'Nhịp đập thế giới tự nhiên: mỗi lần thời gian thế giới chính thật sự trôi đi, đều kiểm tra môi trường, thành phố/khu vực, tổ chức/thế lực, kinh tế/tài nguyên, cơ sở công cộng và đời sống xã hội có thay đổi tự nhiên hay không. Phần lớn là thay đổi bình thường hoặc mang tính địa phương, tin tức lớn phải hiếm và có nhân quả.',
        busy: 'Nhịp đập thế giới thiên sôi nổi: khi nhân quả hợp lý đủ đầy, có thể để nhiều khu vực/ngành nghề/tổ chức đồng thời xuất hiện thay đổi, nhưng vẫn lấy sự kiện thường nhật, địa phương và trong ngành làm chính; tai nạn lớn, chiến tranh, thiên tai và trùng hợp cực đoan vẫn phải có căn cứ vững chắc.',
    }[worldPulseActivity] || 'Nhịp đập thế giới tự nhiên: để xã hội ngoài ống kính thay đổi bình thường theo thời gian và nhân quả.';
    const coverageTargets = asArray(worldCoverageTargets)
        .filter(item => item?.id && item?.label)
        .slice(0, 4)
        .map(item => ({
            id: asString(item.id, '', 120),
            label: asString(item.label, '', 120),
            kind: asString(item.kind, 'general', 40),
            scope: asString(item.scope, '', 160),
            source: asString(item.source, 'world', 40),
            last_checked_at: asInteger(item.lastCheckedAt, -1, -1),
        }));
    const coverageRule = coverageTargets.length
        ? `Lượt này bắt buộc kiểm tra độc lập các phạm vi thế giới đã lâu chưa được để mắt tới sau: ${JSON.stringify(coverageTargets)}. Chúng không phải chỉ tiêu sự kiện; chỉ khi thời gian thế giới, áp lực có sẵn hoặc nhân quả đủ để sinh ra thay đổi mới cập nhật world_pulse / world_facts / events. Không có thay đổi thì giữ yên lặng, nhưng không được lấy nội dung na ná trong cốt truyện hiện tại để giả làm đã kiểm tra.`
        : 'Lượt này không có mục tiêu bao quát ngoài ống kính bổ sung; vận hành bình thường theo nhân quả hiện có.';
    const backgroundTargetList = asArray(backgroundPersonTargets)
        .filter(item => item?.id)
        .slice(0, asInteger(backgroundNpcBudget, 4, 0))
        .map(item => ({
            id: asString(item.id, '', 100),
            name: asString(item.name, '', 80),
            overdue_minutes: asInteger(item.overdueMinutes, 0, 0),
            priority_reason: ['manual-next', 'starvation-guard', 'manual-now', 'due'].includes(item?.priorityReason)
                ? item.priorityReason
                : 'due',
        }));
    const enhancedBackgroundRule = backgroundTargetList.length
        ? [
            enhancedBackgroundSimulation
                ? `Đã bật suy diễn tăng cường nhân vật nền. Trong đợt này, ngoài điều phối sự thật tiền cảnh, còn phải kết toán ${backgroundTargetList.length} nhân vật nền ưu tiên: ${JSON.stringify(backgroundTargetList)}。`
                : `Đã kích hoạt điều phối bảo đảm cho nhân vật nền. Trong đợt này, ngoài điều phối sự thật tiền cảnh, còn phải kết toán ${backgroundTargetList.length} nhân vật nền ưu tiên: ${JSON.stringify(backgroundTargetList)}. manual-next=người dùng yêu cầu ưu tiên ở lượt tiếp theo; starvation-guard=đã liên tiếp quá ba chu kỳ sinh hoạt mà chưa được kết toán.`,
            'Họ phải lần lượt từng người xuất hiện trong people_upsert. Dựa theo vị trí, hành động, mục tiêu dài hạn, lịch trình, quan hệ và trạng thái cơ thể/cảm xúc/tài nguyên sẵn có của từng người mà tự nhiên đẩy tiến đến thời gian thế giới hiện tại; dù không có chuyện lớn cũng phải cập nhật thành “bây giờ đang làm gì/sắp tới định làm gì” hợp lý, đừng vì làm cho có mà tạo xung đột.',
            'Không được vì chính văn mới nhất chỉ có mặt cùng một nhân vật nào đó mà tiếp tục đóng băng những nhân vật bắt buộc xử lý này.',
        ].join('\n')
        : 'Lượt này không có nhân vật nền nào bắt buộc ưu tiên kết toán.';
    const groupLifeRule = [
        'Điều phối đời sống của nhóm nhân vật: nhân vật ngoài ống kính không phải những tiểu kịch trường bốc riêng từng tấm một. Trước hết dùng sự trùng khớp chính xác về địa điểm/thời gian, sự kiện chung, tổ chức và công việc, quan hệ có sẵn, hẹn ước và lịch trình để phán đoán lượt này có giao điểm tự nhiên hay không; nếu có giao điểm thì kết toán trải nghiệm chung trước, rồi bổ sung phần sinh hoạt thường ngày còn lại của từng người.',
        'Đừng chỉ vì cùng thành phố, cùng tổ chức hay quan hệ thân thiết mà ép gặp mặt, không được dịch chuyển tức thời, cũng đừng để cuộc sống của mọi người tự động xoay quanh user. Khi không có giao điểm tự nhiên, mỗi người sống ngày thường của mình chính là kết quả đúng.',
        'Nếu lượt này hình thành tương tác nhiều người thật sự, tất cả nhân vật nền thực tế tham gia đều phải được tính vào backgroundNpcBudget và để lại trong people_upsert vị trí, hành động, ý định hoặc trạng thái nhất quán với nhau; trải nghiệm chung kéo dài/có hậu quả nên cập nhật cùng một sự kiện, hoặc chỉ tạo một sự kiện mới có actors đầy đủ, không được sao chép sự kiện gần nghĩa cho từng người. Khi ngân sách không đủ để cập nhật toàn bộ người tham gia, không được viết tương tác như thể đã hoàn tất.',
        'Lan truyền thông tin kết toán theo từng người: trò chuyện, tin nhắn, chứng kiến hay cùng làm việc chỉ ghi nội dung thực sự được truyền đạt vào knowledge_updates riêng của từng người nhận, và ghi rõ route/evidence/source_event_id; cùng chỗ, thân mật, đồng nghiệp hay cùng tổ chức đều không có nghĩa là cùng chia sẻ sự toàn tri ở nền.',
    ].join('\n');

const activeDirectorNotes = asArray(directorNotes)
        .filter(note => note?.id && note?.directive)
        .slice(0, 3)
        .map(note => ({
            id: asString(note.id, '', 100),
            directive: asString(note.directive, '', 900),
            scope: note.scope === 'next' ? 'next' : 'short',
            strength: ['natural', 'priority', 'force'].includes(note.strength) ? note.strength : 'priority',
            consumed: Boolean(note.consumed),
        }));
    const directorRule = activeDirectorNotes.length
        ? [
            'Mảnh giấy đạo diễn của 玲七 (mong muốn sáng tác được người dùng xác nhận rõ ràng, không phải sự thật thế giới):',
            ...activeDirectorNotes.map(note => `- [${note.id}] cường độ=${note.strength}; phạm vi=${note.scope}；${note.directive}`),
            'Cách thực hiện phải tuân theo trạng thái thế giới có thẩm quyền hiện tại, thiết lập ổn định của nhân vật, ranh giới hiểu biết, tính liên tục của thời gian và ý chí tự chủ của người chơi. natural=có cơ hội thì thuận thế tiến gần; priority=lượt này ưu tiên thử rõ rệt; force=cố gắng thực hiện với điều kiện không vi phạm sự thật cứng và ý chí người chơi. Khi điều kiện chưa đủ có thể trải sẵn điều kiện tự nhiên trước, tuyệt đối không được vì thực hiện mong muốn mà dịch chuyển tức thời, viết lại sự thật có sẵn, khiến tính cách nhân vật đột biến hay quyết định hành động thay người chơi.',
            activeDirectorNotes.some(note => note.consumed)
                ? 'Những mảnh giấy này đã được cung cấp cho model tiền cảnh trước khi tạo chính văn của đợt này; ở đây chủ yếu là “đối chiếu kết quả”. Đừng vì muốn bù làm mảnh giấy mà tạo thêm sự kiện ngoài ống kính, chỉ đồng bộ những thay đổi đã xảy ra trong chính văn new, và duy trì nền theo nhân quả bình thường của thế giới.'
                : 'Nếu mảnh giấy chưa được cung cấp cho chính văn tiền cảnh, chỉ được thuận thế hỗ trợ khi nhân quả bình thường của thế giới vốn đã thành lập, không được vì hoàn thành mảnh giấy mà bịa ra sự kiện.',
            'Với mỗi mảnh giấy được cung cấp trong lượt này, hãy phán đoán trong director_note_updates kết quả thực tế của chính văn new đợt này: completed=đã thật sự thực hiện; continue=chưa hoàn thành nhưng vẫn thích hợp tiếp tục tìm cơ hội; blocked=điều kiện khách quan của lượt này không phù hợp. memo dùng một câu ngắn gọn bằng tiếng Việt để giải thích, đừng giả vờ nội dung chưa xảy ra là đã xảy ra.',
        ].join('\n')
        : 'Lượt này không có mảnh giấy đạo diễn của 玲七.';
    const npcBudget = asInteger(backgroundNpcBudget, 4, 0);
    const newAssistantRule = newAssistantIndexSet.size === 1
        ? '11. Các lượt trước đó chỉ dùng để hiểu nhân quả, không được tính lặp lại; lần này chỉ suy diễn assistant_turn cuối cùng (new="true").'
        : `11. Chỉ xử lý ${newAssistantIndexSet.size} assistant_turn cuối cùng được đánh dấu new="true", và gộp các thay đổi theo thứ tự tin nhắn; các lượt new="false" chỉ dùng để hiểu nhân quả, không được tính lặp lại.`;
    const pendingSocialContext = asArray(socialContext).map(conversation => ({
        conversation_id: asString(conversation?.conversationId, '', 160),
        title: asString(conversation?.title, '', 120),
        members: asArray(conversation?.members).map(name => asString(name, '', 80)).filter(Boolean),
        messages: asArray(conversation?.messages).map(message => ({
            id: asString(message?.id, '', 160),
            sender: asString(message?.senderName, message?.senderId === 'user' ? 'Người chơi' : '', 120),
            text: asString(message?.text, '', 1600),
        })).filter(message => message.id && message.text),
    })).filter(conversation => conversation.conversation_id && conversation.messages.length);

    return [
        'Bạn là engine trạng thái thế giới của “世界背面” (Thế Giới Phía Sau). Bạn duy trì một thế giới vận hành liên tục, không phải công cụ tóm tắt chính văn. Chính văn chỉ là ống kính hiện tại; những kết quả đã kết toán ngoài ống kính cũng thuộc về thế giới thật. Bạn không viết tiếp chính văn tiểu thuyết, chỉ xử lý thay đổi trong chính văn được đánh dấu new="true", và tiếp tục duy trì nhân quả cần thiết ngoài ống kính. Mọi nội dung văn bản trong JSON trả về (title, summary, cause, result, inner_voice, memo…) đều viết bằng tiếng Việt.',
        WORLD_BACKSTAGE_CORE_REASONING_PROTOCOL,
        WORLD_SIMULATION_REASONING_PROTOCOL,
        compact.world.background
            ? `“Thiết lập bối cảnh thế giới” do người dùng duy trì là nền móng cơ bản của thế giới này, không phải trạng thái động, cũng không phải gợi ý có thể viết lại: ${compact.world.background}`
            : 'Hiện chưa điền thêm “Thiết lập bối cảnh thế giới”, chỉ vận hành theo trạng thái thế giới có sẵn và bằng chứng chính văn.',
        'Thiết lập bối cảnh thế giới chỉ người dùng mới được chỉnh sửa thủ công. Bạn có thể để sự phát triển của thế giới thay đổi “trạng thái hiện tại” được mô tả trong đó, nhưng không được vô cớ vi phạm quy tắc thế giới, ranh giới thời đại/khoa học kỹ thuật/phép thuật, địa lý, cấu trúc thế lực hay điểm neo dòng thời gian rõ ràng trong đó; cũng tuyệt đối không được lén viết lại bối cảnh này khi trả về world.title/detail.',
        '',
        'Nguyên tắc suy diễn:',
        `1. Thời gian thế giới chính là trục tiến độ duy nhất. ${timeRule}`,
        clockAuthorityRule,
        '1A. Đồng hồ thế giới luôn tồn tại liên tục, bất kể đã gắn với năm tháng ngày cụ thể hay chưa. Khi không có ngày tuyệt đối thì dùng tiếp thứ tự ngày trong truyện và độ chính xác thời gian sẵn có; đừng vì chính văn không ghi ngày mà đặt lại hay dừng thời gian.',
        '1B. Những hứa hẹn tương lai trong chính văn như “mai gặp/tuần sau hẹn” không có nghĩa là thời gian hiện tại đã nhảy tới; chỉ tính vào elapsed_minutes những lần chờ đợi, ngủ, đi đường, làm việc và chuyển cảnh rõ ràng thật sự xảy ra trong đợt này.',
        '1C. clock_anchor chỉ là trường trả về để tương thích, phải giữ mode=none. Model không có quyền khởi tạo hay hiệu chỉnh lại ngày tuyệt đối của thế giới.',
        `Quy mô lần này: ${simulationRule}`,
        '2. Hành động của người chơi/người dùng chỉ được lấy từ nội dung đã xảy ra trong chính văn, không được thêm hành động thay người chơi.',
        `3. Trước tiên làm “điều phối sự thật tiền cảnh”: thời gian, vị trí/di chuyển của nhân vật, hành động, trạng thái cơ thể, thay đổi vật phẩm hoặc môi trường được chính văn new="true" viết rõ đều phải ghi ngược lại. Bước này không bị giới hạn bởi ngân sách NPC nền. Sau khi hoàn tất điều phối tiền cảnh, lần này cập nhật tối đa ${npcBudget} NPC ngoài ống kính.`,
        '3A. Trạng thái có thẩm quyền trước suy diễn không phải gợi ý tùy chọn. Nếu chính văn mới không mô tả sự chuyển tiếp như di chuyển/quay về/rời đi, mà lại đặt nhân vật ở nơi mâu thuẫn với vị trí có thẩm quyền, đừng âm thầm ghi đè trạng thái thế giới; hãy ghi nó vào consistency_conflicts và giữ nguyên sự thật thế giới ban đầu. Chỉ khi chính văn đã thiết lập rõ ràng sự chuyển tiếp mới hoặc sự thật mới đáng tin cậy, mới chấp nhận chính văn và cập nhật trạng thái.',
        '3B. Suy diễn nền cũng có thể hình thành sự thật thế giới thật sự. Một khi sự kiện đã resolved/cancelled/missed, hoặc hành động ngoài ống kính đã hoàn thành một cách khách quan, thì phải kết toán kết quả vào trạng thái nhân vật/sự kiện; kết quả ổn định không thể đưa vào trường hiện có thì ghi vào world_facts_upsert. Đừng đợi chính văn xác nhận lại mới coi là đã xảy ra. World fact phải phân biệt validity: current=hiện vẫn đúng, upcoming=chưa xảy ra nhưng đã xác định/đã định trước, historical=sự thật lịch sử đã kết thúc, persistent=hậu quả vẫn tiếp tục đúng sau khi sự kiện kết thúc. Bản thân result của sự kiện thường là historical; nếu “mưa bão đã tạnh nhưng đường vẫn ngập nước”, thì việc ngập nước phải được ghi riêng thành world fact current/persistent.',
        '3C. Nếu kết quả kết toán làm thay đổi các trường cấu trúc có sẵn như vị trí, hành động hiện tại, trạng thái cơ thể/tài nguyên của nhân vật, thì phải đồng bộ ghi vào people_upsert tương ứng; không được chỉ ghi “đã đến phòng ngủ” trong event.result, mà vẫn để vị trí có thẩm quyền của nhân vật dừng ở phòng làm việc. Kết quả sự kiện và trạng thái nhân vật/địa điểm phải nhất quán với nhau.',
        '3D. Sau khi hoàn tất điều phối sự thật tiền cảnh, phải làm thêm một lần “kiểm tra thế giới tự vận hành”. Chính văn mới nhất chỉ là một trong các đầu vào của thế giới, không phải tiền đề để sinh ra sự kiện mới. Kiểm tra: ① hậu quả do mạch ngầm có sẵn/sự kiện đã kết toán để lại có tự nhiên hình thành bước tiếp theo không; ② long_term_goal / intent của nhân vật ngoài ống kính đã đến lúc tự hành động chưa; ③ áp lực về thế lực, địa điểm, môi trường xã hội hay tài nguyên đã đủ để sinh ra thay đổi hợp lý mới chưa; ④ thời gian định trước hoặc điều kiện có sẵn có kích hoạt hành động chưa từng lộ ra trước đó không. Chỉ cần nhân quả đã thành lập, là có thể tạo mạch ngầm ngoài ống kính mới, dù chính văn hoàn toàn không nhắc tới.',
        '3E. “Sự kiện ngẫu nhiên” chỉ được lấy mẫu hợp lý từ thiết lập thế giới hiện tại, môi trường địa điểm, bối cảnh xã hội và áp lực có sẵn: có thể là tai nạn thường ngày, thời tiết, giao thông, động thái tổ chức, thay đổi công việc, biến động tài nguyên…; không được vô cớ tạo ra đại thảm họa, bước ngoặt gượng ép do trùng hợp, hay chuyên xảy ra xoay quanh người chơi. Ngẫu nhiên chỉ quyết định chuyện nào trong các ứng viên hợp lý xảy ra trước, không chịu trách nhiệm tạo ra nhân quả từ hư không.',
        '3F. Thế giới tự vận hành không có nghĩa là lượt nào cũng phải gượng ép tạo sự kiện. Nếu thời gian thế giới chính không thực sự trôi đi, điều kiện có sẵn không thay đổi, mục tiêu nhân vật cũng không có bước tiếp theo tự nhiên, thì có thể để events_create=[]. Nhưng không được vì “chính văn không nhắc tới” mà bỏ qua thay đổi thế giới vốn đã phải xảy ra.',
        `3G. ${pulseActivityRule}`,
        `3G-COVERAGE. ${coverageRule}`,
        `3G-LIFE. ${enhancedBackgroundRule}`,
        `3G-GROUP. ${groupLifeRule}`,
        '3H. world_pulse là sổ cái trạng thái vĩ mô ngoài ống kính, không phải danh sách tin tức. Nó ghi lại áp lực kéo dài một thời gian về môi trường, khu vực, tổ chức/thế lực, kinh tế tài nguyên, cơ sở hạ tầng, trị an, văn hóa/truyền thông hoặc cộng đồng. Chỉ khi trạng thái thật sự thay đổi mới ghi world_pulse_upsert; đừng lặp lại cùng một câu mỗi lượt. pressure=0 nghĩa là bình ổn, 1=nhẹ, 2=rõ rệt, 3=áp lực cao; trend chỉ mô tả áp lực đó đang tăng, giảm, dao động hay ổn định.',
        '3I. visibility và publicity là hai trục hoàn toàn khác nhau. visibility=hidden/trace/known/direct chỉ biểu thị sự kiện này đi vào chính văn hiện tại/tầm nhìn nhân vật như thế nào; nó tuyệt đối không đồng nghĩa với công khai trong xã hội. Phòng ngủ, chat riêng, hành động bí mật dù visibility=direct thì thường cũng phải publicity=private.',
        '3J. publicity=private nghĩa là xã hội không biết; publicity=trace nghĩa là bên ngoài chỉ có dấu hiệu chưa được kiểm chứng, có thể thành tin đồn trên diễn đàn nhưng không thể thành tin tức; publicity=public nghĩa là đã có thông báo, báo chí đưa tin, hiện tượng công chúng nhìn thấy được hoặc kênh lan truyền rộng rãi, có thể đưa vào tin tức.',
        '3K. Chỉ khi publicity=trace/public mới điền public_trace. Chỉ khi publicity=public mới điền public_headline và public_summary; hai trường này chỉ được chứa những sự thật mà công chúng đã có thể biết, không được sao chép nguyên nhân hậu trường, chi tiết riêng tư hay nội tâm nhân vật. public_summary biểu thị trạng thái hiện tại/lần gần nhất công chúng biết, không tự động đồng nghĩa với kết cục cuối cùng.',
        '3K-1. Khi sự kiện publicity=public chuyển sang resolved/cancelled/missed: nếu kết cục đã được công khai, phải điền public_result; nếu kết cục chưa công khai, để trống public_result. public_summary cũ chỉ được coi là bản tin lịch sử, tuyệt đối không được tiếp tục đóng vai trạng thái thế giới hiện tại.',
        '3L. world_pulse có thể sinh ra mạch ngầm mới hoàn toàn không liên quan đến tuyến chính hiện tại. Sự kiện thế giới công khai trước hết xảy ra thật trong thế giới, rồi mới qua các trường publicity/public_* chuyển cho module Dư luận; Dư luận tuyệt đối không được ngược lại tạo ra sự thật.',
        '3M. “Sự kiện thế giới công khai” không đồng nghĩa với “sự kiện lớn”. Thời tiết, giao thông, thương mại, thay đổi nhỏ về chính sách, động thái ngành, vụ án địa phương, sự cố cơ sở vật chất, hoạt động, tiêu dùng và điểm nóng trên mạng đều có thể thành lập. Tuyệt đại đa số thay đổi công cộng nên bình thường, mang tính địa phương, giải thích được; thiên tai lớn, chiến tranh, đảo chính, âm mưu khổng lồ thực sự… phải cực kỳ hiếm và có nhân quả mạnh.',
        'Thay đổi chung của số lượng lớn NPC cùng phe hoặc cùng địa điểm nên ưu tiên gộp thành sự kiện thế lực/địa điểm; khi tên xuất hiện lại, địa điểm đến gần, sự kiện liên quan đến hạn hoặc phục bút được kích hoạt thì mới đánh thức từng cá nhân.',
        '4. Không xuất phần trăm. Sự kiện duration/scheduled do plugin tính theo thời gian; sự kiện active chỉ điền worked_minutes thực tế đã làm trong lượt này; sự kiện condition chờ điều kiện.',
        '5. Sự kiện đến hạn phải đưa ra một trong resolved/cancelled/missed kèm result cụ thể, hoặc giữ rõ ràng ở ready; không được treo lâu ở 99%/100%.',
        '6. Độc thoại góc nhìn thứ nhất của NPC ghi vào inner_voice, phải là giọng của chính nhân vật đó, 20–80 chữ, viết bằng tiếng Việt, chỉ cập nhật khi hoàn cảnh, mục tiêu hoặc cảm xúc của nhân vật có thay đổi thực sự. Đừng để tất cả nhân vật độc thoại tập thể mỗi lượt.',
        'identity_anchor, personality_anchor, appearance_profile, background_profile, ability_profile, speaking_style và behavior_boundaries trong trạng thái nhân vật là thiết lập nhân vật ổn định do người dùng duy trì: phải tuân thủ, không được viết lại trong people_upsert. identity_anchor có thể bao gồm mọi giới tính/danh tính giới, cách xưng hô/đại từ, chủng loài, giai đoạn tuổi và danh tính xã hội; appearance_profile phụ trách ngoại hình và đặc điểm cơ thể; background_profile phụ trách bối cảnh, trải nghiệm và quan hệ; hiệu quả, phạm vi, điều kiện kích hoạt, cái giá và điểm yếu của năng lực trong ability_profile phải được tuân thủ đồng thời, đoạn trích tư liệu không có nghĩa là các điều kiện chưa được thể hiện đã mất hiệu lực. Không được suy ngược hay viết lại danh tính dựa vào ngoại hình, trang phục, cơ thể hay chủng loài. Khi không có điểm neo danh tính và chính văn cũng không rõ ràng thì dùng cách diễn đạt trung tính.',
        'Nhân vật author_managed=true nghĩa là do người dùng thêm thủ công hoặc nhập từ World Info: có thể cập nhật bình thường vị trí, hành động, ý định và trạng thái, nhưng tuyệt đối không được đưa vào people_remove. people_remove chỉ dùng để dọn các nhân vật nền tạm thời do plugin tự sinh ra và đã xác định không cần giữ lại nữa. Nhân vật của người dùng, nhân vật author_managed và nhân vật locked_profile đều không được bị routine simulation xóa.',
        `7. ${userVoiceRule} ${playerIdentityRule}`,
        '8. long_term_goal là phương hướng dài hạn tương đối ổn định của nhân vật; chỉ cập nhật khi mục tiêu thực sự được thiết lập, hoàn thành, từ bỏ hoặc chuyển hướng, không được lặp lại hành động của lượt này vào đó.',
        '9. inner_voice là thông tin quan sát hậu trường, không được coi là sự thật mà nhân vật chính đã biết, cũng không được ghi vào deliveries_confirmed.',
        '10. deliveries_confirmed chỉ biểu thị “chính văn có nhìn thấy kết quả hay không”, tuyệt đối không quyết định kết quả có tồn tại hay không. Sự thật thế giới đã kết toán dù chưa lộ ra vẫn có hiệu lực; chỉ khi chính văn mới của đợt này thật sự tiếp nối, cảm nhận hoặc để lại dấu vết nhìn thấy được mới điền ID sự kiện tương ứng.',
        '10A. Liên lạc đang chờ tiếp nối không phải sự thật thế giới. Chỉ khi chính văn new=true của đợt này nhắc tới, đáp lại, thực hiện, từ chối hoặc thay đổi rõ ràng nội dung của một cuộc liên lạc nào đó, mới ghi tin nhắn cuối cùng mà hội thoại đó đã được tiếp nối lần này vào social_messages_settled. evidence phải sao chép nguyên văn bằng chứng trực tiếp trong chính văn new=true; chỉ việc nhân vật xuất hiện, lấy điện thoại ra hay nói chuyện chung chung thì không tính là tiếp nối. Không có tiếp nối thì trả về mảng rỗng.',
        newAssistantRule,
        '12. Phục bút trong ký ức cũ liên quan chỉ có thể giúp giữ nhân quả liên tục; phục bút ẩn mà nhân vật không biết không được đột nhiên biến thành hiểu biết của nhân vật.',
        '12A. Nhận thức của NPC phải đi qua knowledge_updates; known_event_ids / known_fact_keys / known_fact_beliefs / known_clue_ids đều là sổ cái chỉ đọc, cấm ghi trực tiếp giá trị mới. Mỗi mục knowledge_updates phải có kind, ref, route, certainty, evidence; route chỉ được là witnessed / told / investigated / message / public_channel / inferred. Với việc biết được trong chính văn tiền cảnh, evidence phải sao chép câu ngắn trong chính văn new=true của đợt này có thể trực tiếp chứng minh “nhân vật này biết được bằng cách nào”; không có bằng chứng thì đừng gửi.',
        '12A-1. inferred chỉ được certainty=suspected, chỉ có thể hình thành “nghi ngờ/tin vào một phiên bản nào đó”, tuyệt đối không được trực tiếp nâng thành hiểu biết đã xác nhận. Nếu là event, belief/view chỉ ghi phiên bản bề mặt mà nhân vật thực sự biết; summary/cause/result thật của thế giới có thể chứa sự thật hậu trường, tuyệt đối không được sao chép nguyên đoạn cho nhân vật.',
        '12A-2. public_channel chỉ biểu thị nhân vật trong lượt này thật sự đã tiếp xúc với thông tin công khai qua tin tức/thông báo/kênh nghề nghiệp; bản thân việc “tin tức đã công khai” không có nghĩa là nhân vật nào cũng đã xem. Không có kênh tiếp xúc thực tế thì đừng gửi public_channel.',
        '12A-2a. Khi nhân vật ngoài ống kính có thêm hiểu biết confirmed, trừ inferred ra, phải điền source_event_id trỏ tới một “sự kiện quá trình biết được” của lượt này/đã có; title/summary/cause của sự kiện đó phải viết rõ nhân vật này đã nhìn thấy, được cho biết, nhận được tin nhắn hay điều tra mà biết như thế nào. Chỉ đơn thuần liệt kê nhân vật vào actors của sự kiện bí mật gốc không tính là bằng chứng biết được.',
        '12A-3. inner_voice chỉ được dựa trên nội dung nhân vật đó đã biết/đã nghi ngờ và trạng thái cơ thể, cảm xúc hiện tại. Nếu độc thoại dựa vào nhận thức cụ thể, hãy ghi event:ID / fact:KEY / clue:ID vào inner_voice_basis; không được nhét sự toàn tri của thế giới, bí mật của người dẫn truyện hay hành vi riêng tư của người chơi vào nội tâm nhân vật.',
        '12B. event.visibility chỉ biểu thị ranh giới hiển lộ với tiền cảnh/người chơi, không đại diện cho việc NPC có biết hay không. actors chỉ biểu thị tham gia/bị ảnh hưởng, cũng không đồng nghĩa với biết chuyện; event.known_by chỉ là bản phản chiếu để tương thích, plugin sẽ suy ngược từ sổ cái nhận thức nhân vật đã qua tường lửa, đừng dựa vào nó để mở hiểu biết cho nhân vật.',
        '12C. physical_state / emotional_state / resource_state là trạng thái hiện tại của nhân vật. Thay đổi trạng thái phải thực sự ảnh hưởng đến action, intent và năng lực thực hiện; bị thương, mệt mỏi, thiếu tài nguyên, thiếu quyền hạn hoặc áp lực cảm xúc không được biến mất vô cớ ở lượt sau. Không được bịa ra kỹ năng, trang bị, quyền hạn hay hiểu biết mà thẻ nhân vật, điểm neo danh tính, ký ức có sẵn không hỗ trợ. emotional_state của người chơi chỉ được cập nhật khi chính văn/người chơi thể hiện rõ ràng, không được đoán nội tâm thay người chơi.',
        '12D. Sự kiện mới phải ghi rõ cause. cause có thể đến từ: hành động/kết quả/hậu quả của sự kiện có sẵn, mục tiêu đã định và hành động chủ động của nhân vật, áp lực thế lực/địa điểm/môi trường, hoặc sự kiện môi trường hợp lý xảy ra tự nhiên trong điều kiện thế giới hiện tại. Nếu do sự kiện có sẵn tiếp tục lên men, phải điền ID sự kiện thượng nguồn vào caused_by; nếu không có sự kiện thượng nguồn, thì ghi rõ mục tiêu nhân vật hoặc điều kiện môi trường trong cause. actors chỉ liệt kê những người thực sự tham gia/trải qua sự kiện đó. Sau khi một sự kiện được giải quyết mà nảy sinh cục diện mới chưa giải quyết, nên tạo sự kiện tiếp theo mới và dùng caused_by xâu chuỗi lại, chứ không phải kéo dài vô hạn mạng sống của sự kiện cũ đã giải quyết.',
        '12D-1. Danh tính mạch ngầm phải ổn định. events trong trạng thái có thẩm quyền trước suy diễn là sự kiện chi tiết, event_index là chỉ mục mạch ngầm có sẵn vẫn đang chạy nhưng được lược bỏ chi tiết vì dung lượng lời gọi; ID trong cả hai đều là danh tính sự kiện thật và vẫn còn tồn tại. Chỉ cần cùng một sự kiện chưa kết thúc đang tiến triển, bị cản trở, chờ đợi, có manh mối mới, thay đổi trạng thái công khai hoặc sắp kết toán, thì phải dùng events_update cập nhật ID gốc, cấm đổi tiêu đề rồi events_create thêm một sự kiện gần nghĩa. Dù sự kiện đó chỉ xuất hiện trong event_index, không có summary đầy đủ, cũng không được vì thế mà sao chép tạo mới; khi thông tin không đủ, thà cập nhật thận trọng hoặc giữ nguyên. Chỉ khi xuất hiện đối tượng nhân quả mới thực sự độc lập, hoặc sự kiện cũ đã kết thúc rồi sinh ra hậu quả mới chưa giải quyết, mới được phép events_create.',
        '12D-LIFE. Nhân vật có life_tick_due_minutes>0 trong compact people thuộc diện “đến hạn kết toán đời sống”. Ưu tiên để tối đa backgroundNpcBudget người trong số đó tiếp tục sống từ trạng thái location/action/intent/long_term_goal/physical/emotional/resource của chính mình, chứ không phải xoay quanh chính văn mới nhất để tìm phản ứng. Dù khoảng thời gian này không có sự kiện kịch tính, cũng nên qua people_upsert đưa ra hành động/ý định hiện tại tự nhiên, nhờ đó hoàn tất kết toán đời sống; đừng vì làm cho có mà gượng ép tạo xung đột. Chỉ cần 3G-LIFE đưa ra danh sách mục tiêu rõ ràng, bất kể có bật suy diễn tăng cường nhân vật nền hay không, danh sách đó đều là hạng mục bắt buộc của lượt này, không được bỏ qua; trong đó manual-next là người dùng đã bấm “Ưu tiên lượt sau”, starvation-guard là hệ thống ngăn nhân vật bị bỏ đói lâu ngày.',
        '12D-GROUP. Trải nghiệm chung của nhiều người phải là cùng một sự thật thế giới, không được tách thành các tiểu kịch trường cá nhân mâu thuẫn nhau. Vị trí, động tác, trạng thái sự kiện và nội dung biết được của những người tham gia phải đối chiếu khớp nhau; khi một bên đã rời đi, từ chối hoặc chưa biết chuyện, bên kia không được giả vờ người đó vẫn có mặt, đã đồng ý hoặc đã biết.',
        '12D-1. Bản thân sự kiện đã giải quyết đừng vì “giữ lại cốt truyện” mà tiếp tục treo trong mạch ngầm; chỉ cần giữ lại world_facts / trạng thái nhân vật / hậu quả môi trường mà nó đã gây ra. Phần thực sự cần tiếp tục phát triển thì tạo thành sự kiện mới. Như vậy chuỗi sự kiện sẽ mọc tiến về phía trước, chứ không lặp đi lặp lại sự kiện cũ.',
        '12E. Khi event.visibility=trace, public_trace chỉ ghi “những dấu hiệu bề mặt mà người quan sát bên ngoài không biết nội tình thực sự có thể thấy/nghe/chú ý tới”, ví dụ chặn đường, dòng xe bất thường, hư hại nhìn thấy công khai, đột ngột ngừng kinh doanh…; tuyệt đối không được nhét nguyên nhân bị ẩn, hành động hậu trường, nội dung riêng tư của nhân vật hay kết luận chưa công khai vào public_trace. public_trace của sự kiện hidden phải để trống; known/direct có thể tùy nhu cầu đưa ra một manh mối công khai ngắn gọn.',
        '12F. visibility phải được chủ động chọn theo “bên ngoài thực tế có thể nhận ra điều gì”, chứ không phải theo thói quen điền hết hidden: chỉ khi sự kiện và ảnh hưởng của nó đều không thể bị người không biết chuyện nhận ra một cách hợp lý mới dùng hidden; nguyên nhân hậu trường vẫn giữ bí mật, nhưng đã xuất hiện bất thường bề mặt có thể thấy/nghe/được chú ý công khai thì phải dùng trace, và điền public_trace an toàn; sự thật đã lan truyền qua thông báo, truyền thông, kênh công khai thì dùng known; nội dung hiển lộ mà nhân vật/người chơi trong ống kính hiện tại đã trực tiếp cảm nhận có thể dùng direct. Tổ hợp nguyên nhân bí mật + dấu hiệu công khai phải là trace, không được vì sự thật được giữ bí mật mà tiếp tục ghi hidden.',
        '13. Chi tiết mới xuất hiện và có thể được nhắc lại ở phần sau thì ghi vào memory_update.clues_upsert; đừng ghi tràn lan động tác và không khí bình thường. Khi phục bút cũ bắt đầu tiến triển thì dùng ID gốc cập nhật thành developing, khi điều kiện then chốt đã thực sự được kích hoạt có thể cập nhật thành triggered; đã hoàn thành/hé lộ thì dùng clues_resolve(status=resolved), manh mối mà phần sau chứng minh không còn cần hoặc nhận định sai thì dùng clues_resolve(status=discarded) và giải thích lý do. Nếu phục bút liên quan rõ ràng đến nhân vật, địa điểm hoặc sự kiện thế giới, có thể lần lượt điền people / locations / events; đừng vì phân loại mà gượng ép gắn với một nhân vật.',
        '14. Chỉ khi chính văn mới của đợt này thiết lập hoặc thay đổi rõ ràng danh tính, quan hệ, lời hứa, hạn chế, quyền sở hữu vật phẩm hoặc sự thật đã hé lộ mà về sau vẫn còn hữu ích, mới ghi vào memory_update.facts_upsert. Vị trí, động tác tạm thời và phỏng đoán hậu trường do model tự suy diễn không được ghi thành sự thật lâu dài. Sự thật dài hạn phải được thay thế luân phiên: khi cùng một key ổn định xuất hiện giá trị mới thì gửi giá trị mới, để phiên bản cũ rời khỏi active; khi mất hiệu lực/bị phủ định rõ ràng thì ghi facts_invalidate. Đừng để sự thật đã hết hạn và sự thật mới cùng lúc đang hiệu lực.',
        '14A. Cập nhật tầng sự thật chỉ đại diện cho cập nhật sự thật/hồ sơ của thế giới, tuyệt đối không được vì thế mà tự động nhét giá trị mới vào known_fact_keys của mọi NPC; nhận thức của NPC vẫn chỉ thay đổi riêng rẽ theo bằng chứng biết chuyện ở mục 12A.',
        '14B. Với mỗi assistant_turn có new="true", tiện thể tạo một bản tóm tắt đơn lượt L0, ghi vào memory_update.turn_summaries. source_message_id phải bằng message_id của assistant_turn đó; summary bằng tiếng Việt, chỉ tóm tắt những thay đổi then chốt thực sự xảy ra trong lượt này, quan hệ/lời hứa/vật phẩm/vấn đề còn bỏ ngỏ, khoảng 60–160 chữ. Đừng để tác vụ ký ức độc lập phải gọi model lại một lần nữa cho cùng một lượt chính văn.',
        '14C. Sau khi kết toán xong thì điền next_turn_injection. required_refs chỉ liệt kê những tham chiếu mà lượt sau nếu không mang theo sẽ dễ gây lỗi liên tục, và vẫn còn đúng ở trạng thái cuối của chính văn; conditional_refs chỉ liệt kê những tham chiếu chỉ cần khi liên quan một cách tự nhiên; suppress_refs chỉ liệt kê lịch sử đã kết thúc, thông tin hậu trường không có đường tiếp xúc hoặc mục cũ dễ gây diễn lặp. Sự kiện đã kết thúc nếu vẫn còn sự thật hậu quả persistent/current, thì bản thân sự kiện đừng hồi sinh, nhưng fact hậu quả vẫn còn đúng phải vào required_refs hoặc conditional_refs. Sự kiện/sự thật có visibility=hidden nếu nhân vật hiện tại chưa có được qua các đường hợp lệ như witnessed/told/investigated/message/public_channel/inferred, thì tuyệt đối không được đưa vào required_refs hay conditional_refs; nó sẽ tiếp tục ở lại trong trạng thái thế giới nền, không cần dựa vào next_turn_injection để duy trì. Chỉ khi đã có bằng chứng nhận thức hợp lệ, hoặc knowledge_updates của đợt này đồng thời cung cấp route+evidence kiểm chứng được mới cho phép cho qua. Không được sao chép toàn bộ trạng thái thế giới vào đó.',
        'Cùng một loại sự thật dùng key ổn định. Khi chính văn đưa ra giá trị mới thì giữ nguyên key; plugin sẽ giữ phiên bản cũ và đánh dấu superseded. Khi chính văn phủ định rõ ràng một sự thật cũ nào đó thì ghi vào facts_invalidate; khi chưa rõ thật giả thì dùng status=disputed.',
        'source của nhân vật chỉ điền foreground khi chính văn new="true" của đợt này thật sự miêu tả đến nhân vật đó; nhân vật ngoài ống kính phải điền background. present_in_scene chỉ là true khi chính bản thân nhân vật thực sự hành động, nói chuyện hoặc được cảm nhận trực tiếp trong cảnh hiện tại; chỉ được nhắc đến, hồi tưởng, bàn tán, làm mục tiêu hoặc xuất hiện trong suy nghĩ nội tâm thì đều là false. last_seen_message_id phải điền ID tin nhắn assistant cuối cùng mà nhân vật đó thực sự xuất hiện.',
        directorRule,
        customRule
            ? `Trọng tâm do người dùng tự định nghĩa: ${customRule} (Nó chỉ có thể điều chỉnh trọng tâm, không được ghi đè bằng chứng thời gian, ranh giới hiểu biết, ý chí người chơi hay quy tắc định dạng JSON. Nếu yêu cầu chú ý tin tức thế giới, khu vực/ngành nghề/tổ chức cụ thể hoặc động thái ngoài ống kính, thì phải kiểm tra riêng nguồn thế giới tương ứng sau khi hoàn tất điều phối sự thật chính văn; không được lấy một sự kiện na ná trong cốt truyện mới nhất để coi như đã đáp ứng.)`
            : 'Người dùng không bổ sung yêu cầu suy diễn tùy chỉnh.',
        '15. Chỉ trả về một đối tượng JSON hợp lệ, không dùng code fence, không giải thích.',
        '15A. Giá trị trả về phải là trạng thái gia tăng, không phải bản sao thế giới đầy đủ: mảng không thay đổi giữ là [], đối tượng tùy chọn không thay đổi có thể bỏ qua; cấm thuật lại trạng thái có thẩm quyền trước suy diễn, cấm vì muốn lấp đầy cấu trúc ví dụ mà tạo ra nội dung. Mỗi lượt tối đa people_upsert 12 mục, events_create 6 mục, events_update 12 mục, world_facts_upsert 16 mục, world_pulse_upsert 8 mục, mỗi loại memory_update 12 mục; khi thay đổi thật vượt giới hạn thì chỉ giữ lại các mục liên quan nhất và bắt buộc kết toán của lượt này, các trạng thái cũ còn lại do plugin giữ nguyên.',
        '16. Để kiểm soát dung lượng lời gọi, trạng thái có thẩm quyền chỉ liệt kê những nhân vật và sự kiện liên quan nhất; các mục cũ không được liệt kê sẽ được plugin giữ nguyên, tuyệt đối không được dựa vào đó mà suy ra chúng đã biến mất.',
        '',
        `Loại kích hoạt: ${trigger}`,
        `ID kết quả ứng viên từng được cung cấp cho chính văn trong lượt này: ${queued.length ? queued.join(', ') : 'Không có'}`,
        '',
        'Ngữ cảnh chính văn gần đây (chỉ xử lý assistant_turn có new="true"):',
        narrativeBlock || '<assistant_turn>(chính văn AI trống)</assistant_turn>',
        '',
        'Các cuộc liên lạc đã cung cấp cho chính văn trong lượt này, đang chờ được tiếp nối thực tế:',
        JSON.stringify(pendingSocialContext),
        '',
        'Ký ức cũ liên quan đến nhân vật, địa điểm và vật phẩm hiện tại:',
        JSON.stringify(relevantMemory),
        '',
        'Trạng thái có thẩm quyền trước suy diễn:',
        JSON.stringify(compact),
        '',
        'Cấu trúc trả về:',
        JSON.stringify({
            time_resolution: {
                evidence_found: false,
                authority: 'none',
                scope: 'unknown',
                evidence: '',
                end_time_text: '',
                needs_elapsed_estimate: false,
                estimated_minutes: 0,
                confidence: 'low',
                reason: '',
            },
            elapsed_minutes: 0,
            time_reason: '',
            clock_anchor: {
                mode: 'none',
                calendar_name: '',
                year: null,
                month: null,
                day: null,
                hour: null,
                minute: null,
                precision: 'minute',
                confidence: 'low',
                source_excerpt: '',
                reason: '',
            },
            world: { title: '', detail: '' },
            people_upsert: [{
                id: '',
                name: '',
                is_user: false,
                location: '',
                action: '',
                intent: '',
                long_term_goal: '',
                trace: '',
                inner_voice: '',
                inner_voice_basis: ['event:ID sự kiện có sẵn | fact:key sự thật | clue:ID manh mối'],
                knowledge: 'hidden',
                cognition_ready: true,
                knowledge_updates: [{
                    kind: 'event | fact | clue',
                    ref: 'ID sự kiện / key sự thật / ID manh mối',
                    route: 'witnessed | told | investigated | message | public_channel | inferred',
                    certainty: 'confirmed | suspected',
                    evidence: 'Câu ngắn nguyên văn chứng minh nhân vật này biết được bằng cách nào; biết được ở tiền cảnh thì phải sao chép từ chính văn của đợt này',
                    belief: 'Phiên bản mà nhân vật này thực sự biết/tin; đặc biệt với event không được sao chép summary toàn tri hậu trường',
                    source_event_id: 'Nếu biết được qua sự kiện công khai/kênh thông báo, có thể điền ID sự kiện nguồn',
                }],
                physical_state: '',
                emotional_state: '',
                resource_state: '',
                relevance: 1,
                source: 'foreground',
                present_in_scene: false,
                last_seen_message_id: 0,
            }],
            people_remove: [],
            events_create: [{
                id: '',
                title: '',
                place: '',
                summary: '',
                consequence: '',
                expected_result: '',
                clock_mode: 'duration',
                duration_minutes: 0,
                scheduled_at: null,
                prerequisites: [],
                cause: '',
                actors: [],
                caused_by: [],
                publicity: 'private | trace | public',
                public_trace: '',
                public_headline: '',
                public_summary: '',
                public_result: '',
                visibility: 'hidden',
                delivery_route: '',
            }],
            events_update: [{
                id: '',
                status: 'active',
                worked_minutes: 0,
                result: '',
                summary: '',
                consequence: '',
                cause: '',
                actors: [],
                caused_by: [],
                publicity: 'private | trace | public',
                public_trace: '',
                public_headline: '',
                public_summary: '',
                public_result: '',
                visibility: 'hidden',
                delivery_route: '',
            }],
            deliveries_confirmed: [],
            social_messages_settled: [{
                conversation_id: '',
                through_message_id: '',
                evidence: 'Sao chép nguyên văn câu ngắn trong chính văn new=true của đợt này thực sự tiếp nối cuộc liên lạc này',
            }],
            director_note_updates: [{
                id: 'note_xxx',
                status: 'completed | continue | blocked',
                memo: 'Một câu giải thích ngắn gọn dựa trên kết quả thực tế của chính văn new đợt này',
            }],
            front_facts: [{
                text: '',
                affects: [],
                visibility: 'known',
            }],
            world_facts_upsert: [{
                key: 'person:ID_nhân_vật:location',
                subject_type: 'person | event | world | location | item | organization | other',
                subject_id: '',
                subject: '',
                field: 'location | state | result | owner | condition | other',
                value: '',
                source: 'simulation | foreground',
                validity: 'current | upcoming | historical | persistent',
                visibility: 'hidden | trace | known | direct',
                confidence: 'high',
                event_id: '',
            }],
            world_pulse_upsert: [{
                id: '',
                label: 'Ví dụ: logistics khu cảng / giao thông thành phố / chuỗi vốn của thương hội / thời tiết gió mùa',
                scope: 'Khu vực, ngành nghề, tổ chức hoặc phạm vi xã hội',
                kind: 'environment | government | economy | organization | infrastructure | security | culture | media | community | other',
                state: 'Trạng thái kéo dài hiện tại, không viết tiêu đề tin tức một lần',
                pressure: 1,
                trend: 'stable | rising | falling | volatile',
                visibility: 'hidden | trace | known',
                source: 'simulation',
                evidence: 'Được điều kiện có sẵn hay thiết lập thế giới nào chống đỡ',
            }],
            consistency_conflicts: [{
                subject: '',
                field: '',
                previous_value: '',
                narrative_value: '',
                resolution: 'keep-world | accept-narrative | transition',
                reason: '',
            }],
            next_turn_injection: {
                required_refs: [],
                conditional_refs: [],
                suppress_refs: [],
                reason: '',
            },
            memory_update: {
                turn_summaries: [{
                    source_message_id: 0,
                    title: '',
                    summary: '',
                }],
                facts_upsert: [{
                    id: '',
                    key: '',
                    subject: '',
                    predicate: '',
                    value: '',
                    source_message_id: 0,
                    source_swipe_id: 0,
                    source_excerpt: '',
                    people: [],
                    locations: [],
                    tags: [],
                    status: 'active',
                    confidence: 'high',
                    importance: 2,
                    visibility: 'known',
                }],
                facts_invalidate: [{
                    id: '',
                    key: '',
                    reason: '',
                }],
                clues_upsert: [{
                    id: '',
                    title: '',
                    text: '',
                    source_excerpt: '',
                    people: [],
                    locations: [],
                    events: [],
                    tags: [],
                    status: 'open | developing | triggered',
                    importance: 1,
                    visibility: 'hidden',
                }],
                clues_resolve: [{
                    id: '',
                    status: 'resolved | discarded',
                    resolution: '',
                    reason: '',
                }],
            },
        }),
    ].join('\n');
}

function escapeJsonControlCharacters(candidate) {
    let output = '';
    let inString = false;
    let escaped = false;
    for (const char of candidate) {
        if (!inString) {
            if (char === '"') inString = true;
            output += char;
            continue;
        }
        if (escaped) {
            output += char;
            escaped = false;
            continue;
        }
        if (char === '\\') {
            output += char;
            escaped = true;
            continue;
        }
        if (char === '"') {
            output += char;
            inString = false;
            continue;
        }
        if (char === '\n') {
            output += '\\n';
            continue;
        }
        if (char === '\r') {
            output += '\\r';
            continue;
        }
        if (char === '\t') {
            output += '\\t';
            continue;
        }
        const code = char.charCodeAt(0);
        output += code < 0x20
            ? `\\u${code.toString(16).padStart(4, '0')}`
            : char;
    }
    return output;
}

function removeJsonTrailingCommas(candidate) {
    let output = '';
    let inString = false;
    let escaped = false;
    for (let index = 0; index < candidate.length; index += 1) {
        const char = candidate[index];
        if (inString) {
            output += char;
            if (escaped) escaped = false;
            else if (char === '\\') escaped = true;
            else if (char === '"') inString = false;
            continue;
        }
        if (char === '"') {
            inString = true;
            output += char;
            continue;
        }
        if (char === ',') {
            let next = index + 1;
            while (next < candidate.length && /\s/.test(candidate[next])) next += 1;
            if (candidate[next] === '}' || candidate[next] === ']') continue;
        }
        output += char;
    }
    return output;
}

function parseJsonCandidate(candidate) {
    const repaired = removeJsonTrailingCommas(escapeJsonControlCharacters(candidate));
    for (const value of repaired === candidate ? [candidate] : [candidate, repaired]) {
        try {
            return JSON.parse(value);
        } catch {
            // Try the next conservative repair, if one exists.
        }
    }
    return null;
}

export function extractJsonObject(rawText) {
    const raw = asString(rawText, '', 200000)
        .replace(/^```(?:json)?\s*/i, '')
        .replace(/\s*```$/i, '')
        .trim();
    if (!raw) return null;

    const direct = parseJsonCandidate(raw);
    if (direct) return direct;

    let start = -1;
    let depth = 0;
    let inString = false;
    let escaped = false;

    for (let index = 0; index < raw.length; index += 1) {
        const char = raw[index];
        if (inString) {
            if (escaped) {
                escaped = false;
            } else if (char === '\\') {
                escaped = true;
            } else if (char === '"') {
                inString = false;
            }
            continue;
        }

        if (char === '"') {
            inString = true;
            continue;
        }
        if (char === '{') {
            if (depth === 0) start = index;
            depth += 1;
        } else if (char === '}') {
            depth -= 1;
            if (depth === 0 && start >= 0) {
                const parsed = parseJsonCandidate(raw.slice(start, index + 1));
                if (parsed) return parsed;
                start = -1;
            }
        }
    }
    return null;
}

export function createSnapshot(state, meta = {}) {
    return {
        schemaVersion: SCHEMA_VERSION,
        takenAt: nowIso(),
        meta: {
            messageId: meta.messageId ?? null,
            swipeId: meta.swipeId ?? null,
            sourceKey: asString(meta.sourceKey, '', 180),
            kind: asString(meta.kind, 'result', 30),
        },
        state: trimState(deepClone(state)),
    };
}

// Message/swipe snapshots used to copy the entire hierarchical memory pool into
// every turn. On very long chats that makes chat metadata grow roughly with
// "turns × accumulated memory". Compact snapshots keep the branch-specific
// world state plus only the summaries that end on the snapshot's own cutoff;
// older summaries are reconstructed from one chat-level archive on restore.
export function createCompactSnapshot(state, meta = {}) {
    const trimmed = trimState(deepClone(state));
    const summaries = asArray(trimmed.storyMemory?.summaries);
    const explicitCutoff = Number.parseInt(meta.memorySummaryCutoffMessageId ?? meta.messageId, 10);
    const inferredCutoff = summaries.reduce(
        (maximum, summary) => Math.max(maximum, Number(summary?.endMessageId ?? -1)),
        -1,
    );
    const cutoff = Number.isFinite(explicitCutoff) && explicitCutoff >= 0
        ? explicitCutoff
        : inferredCutoff;
    const localSummaries = cutoff >= 0
        ? summaries.filter(summary => Number(summary?.endMessageId ?? -1) === cutoff)
        : [];
    trimmed.storyMemory = {
        ...trimmed.storyMemory,
        summaries: deepClone(localSummaries),
    };
    return {
        schemaVersion: SCHEMA_VERSION,
        takenAt: nowIso(),
        meta: {
            messageId: meta.messageId ?? null,
            swipeId: meta.swipeId ?? null,
            sourceKey: asString(meta.sourceKey, '', 180),
            kind: asString(meta.kind, 'result', 30),
            compactMemory: true,
            memorySummaryCutoffMessageId: cutoff,
        },
        state: trimmed,
    };
}

export function restoreCompactSnapshot(snapshot, fallback = null, summaryPool = []) {
    const restored = restoreSnapshot(snapshot, fallback);
    if (!snapshot?.meta?.compactMemory) return restored;
    const cutoff = asInteger(snapshot?.meta?.memorySummaryCutoffMessageId, -1, -1);
    const localSummaries = asArray(snapshot?.state?.storyMemory?.summaries);
    const localIds = new Set(localSummaries.map(summary => String(summary?.id || '')).filter(Boolean));
    const archived = cutoff >= 0
        ? asArray(summaryPool).filter(summary => (
            Number(summary?.endMessageId ?? -1) < cutoff
            && !localIds.has(String(summary?.id || ''))
        ))
        : [];
    restored.storyMemory = {
        ...restored.storyMemory,
        summaries: [...archived, ...localSummaries],
    };
    return trimState(restored);
}

function normalizeRecoveryPoint(raw) {
    if (!raw || typeof raw !== 'object' || !raw.state || typeof raw.state !== 'object') return null;
    return {
        id: asString(raw.id, '', 120),
        createdAt: asString(raw.createdAt, '', 40),
        reason: asString(raw.reason, 'manual', 60),
        label: asString(raw.label, 'Điểm khôi phục thủ công', 120),
        schemaVersion: asInteger(raw.schemaVersion, 0, 0),
        worldName: asString(raw.worldName, raw.state?.world?.name || 'Thế giới chính', 80),
        worldMinute: asInteger(raw.worldMinute, raw.state?.clock?.absoluteMinute ?? 0, 0),
        revision: asInteger(raw.revision, raw.state?.revision ?? 0, 0),
        state: deepClone(raw.state),
    };
}

export function listRecoveryPoints(inputStore) {
    return asArray(inputStore?.recoveryPoints)
        .map(normalizeRecoveryPoint)
        .filter(point => point?.id)
        .sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)))
        .slice(-RECOVERY_LIMIT);
}

// Hot UI paths only need recovery-point metadata. Avoid cloning the full saved
// world state just to render a count/label; the full snapshot is normalized
// only when a recovery operation actually needs it.
export function listRecoveryPointHeaders(inputStore) {
    return asArray(inputStore?.recoveryPoints)
        .filter(raw => raw && typeof raw === 'object' && raw.state && typeof raw.state === 'object')
        .map(raw => ({
            id: asString(raw.id, '', 120),
            createdAt: asString(raw.createdAt, '', 40),
            reason: asString(raw.reason, 'manual', 60),
            label: asString(raw.label, 'Điểm khôi phục thủ công', 120),
            schemaVersion: asInteger(raw.schemaVersion, 0, 0),
            worldName: asString(raw.worldName, raw.state?.world?.name || 'Thế giới chính', 80),
            worldMinute: asInteger(raw.worldMinute, raw.state?.clock?.absoluteMinute ?? 0, 0),
            revision: asInteger(raw.revision, raw.state?.revision ?? 0, 0),
        }))
        .filter(point => point.id)
        .sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)))
        .slice(-RECOVERY_LIMIT);
}

export function addRecoveryPoint(inputStore, {
    reason = 'manual',
    label = 'Điểm khôi phục thủ công',
    createdAt = nowIso(),
    id = '',
} = {}) {
    const store = deepClone(inputStore || {});
    const state = store.currentState;
    if (!state || typeof state !== 'object') return store;
    const normalizedCreatedAt = asString(createdAt, nowIso(), 40);
    const signature = hashText(JSON.stringify({
        createdAt: normalizedCreatedAt,
        reason,
        revision: state.revision,
        worldMinute: state.clock?.absoluteMinute,
    }));
    const point = normalizeRecoveryPoint({
        id: asString(id, '', 120) || `recovery_${Date.parse(normalizedCreatedAt) || Date.now()}_${signature}`,
        createdAt: normalizedCreatedAt,
        reason,
        label,
        schemaVersion: inputStore?.schemaVersion ?? state.schemaVersion ?? 0,
        worldName: state.world?.name,
        worldMinute: state.clock?.absoluteMinute,
        revision: state.revision,
        state,
    });
    const points = listRecoveryPoints(store).filter(existing => existing.id !== point.id);
    store.recoveryPoints = [...points, point].slice(-RECOVERY_LIMIT);
    return store;
}

export function restoreRecoveryPoint(inputStore, recoveryId = '') {
    const store = deepClone(inputStore || {});
    const points = listRecoveryPoints(store);
    const target = recoveryId
        ? points.find(point => point.id === String(recoveryId))
        : points.at(-1);
    if (!target) return { store, point: null };
    store.currentState = trimState(target.state);
    store.recoveryPoints = points;
    store.updatedAt = nowIso();
    return { store, point: target };
}

export function restoreSnapshot(snapshot, fallback = null) {
    if (!snapshot || typeof snapshot !== 'object' || !snapshot.state) {
        return fallback ? trimState(deepClone(fallback)) : createInitialState();
    }
    return trimState(deepClone(snapshot.state));
}

export function markPendingSync(inputState, pending = true) {
    const state = deepClone(inputState);
    state.pendingSync = Boolean(pending);
    state.updatedAt = nowIso();
    return state;
}

export function hashText(text) {
    const value = String(text ?? '');
    let hash = 0x811c9dc5;
    for (let index = 0; index < value.length; index += 1) {
        hash ^= value.charCodeAt(index);
        hash = Math.imul(hash, 0x01000193);
    }
    return (hash >>> 0).toString(36);
}

function escapeRegExp(value) {
    return String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export const DEFAULT_TAG_FILTER_RULES = Object.freeze([
    Object.freeze({ open: '<options>', close: '</options>' }),
    Object.freeze({ open: '<thinking>', close: '</thinking>' }),
    Object.freeze({ open: '<think>', close: '</think>' }),
    Object.freeze({ open: '<UpdateVariable>', close: '</UpdateVariable>' }),
    Object.freeze({ open: '<updatevariable>', close: '</updatevariable>' }),
]);

export function normalizeTagFilterRules(rawRules) {
    const list = Array.isArray(rawRules) ? rawRules : [];
    const normalized = [];
    for (const item of list) {
        if (normalized.length >= 30) break;
        const open = String(item?.open ?? '').trim().slice(0, 80);
        const close = String(item?.close ?? '').trim().slice(0, 80);
        if (!open && !close) continue;
        normalized.push({ open, close });
    }
    return normalized;
}



export function extractTagFilterCandidates(texts, existingRules = []) {
    const sources = Array.isArray(texts) ? texts : [texts];
    const existing = new Set(
        normalizeTagFilterRules(existingRules)
            .map(rule => `${rule.open}\u0000${rule.close}`),
    );
    const byName = new Map();
    const broadNames = new Set([
        'div', 'span', 'p', 'a', 'section', 'article', 'main', 'header', 'footer',
        'details', 'summary', 'table', 'thead', 'tbody', 'tr', 'td', 'th', 'ul', 'ol', 'li',
        'style', 'script', 'content',
    ]);
    const recommendedNames = new Set([
        'think', 'thinking', 'analysis', 'options', 'updatevariable', 'jsonpatch', 'json_patch',
    ]);

    for (const source of sources) {
        const text = String(source ?? '');
        const opens = [];
        const openPattern = /<([^\s<>\/!]+)(?:\s[^<>]*?)?>/g;
        let match;
        while ((match = openPattern.exec(text))) {
            const token = match[0];
            if (/\/$/.test(token.slice(0, -1))) continue;
            const name = String(match[1] || '');
            if (!name) continue;
            opens.push({ name, token, index: match.index });
        }
        for (const item of opens) {
            const closePattern = new RegExp(`</${escapeRegExp(item.name)}\\s*>`, 'g');
            closePattern.lastIndex = item.index + item.token.length;
            const closeMatch = closePattern.exec(text);
            if (!closeMatch) continue;
            const key = item.name;
            const current = byName.get(key) || {
                name: key,
                open: item.token,
                close: closeMatch[0],
                count: 0,
                variants: new Set(),
            };
            current.count += 1;
            current.variants.add(item.token);
            byName.set(key, current);
        }
    }

    return [...byName.values()]
        .map(item => {
            const lower = item.name.toLocaleLowerCase();
            const open = item.variants.size > 1 && /\s/.test(item.open)
                ? item.open
                : item.open;
            const close = item.close;
            const alreadyAdded = existing.has(`${open}\u0000${close}`);
            const broad = broadNames.has(lower) || item.variants.size > 1;
            return {
                id: hashText(`${open}\u0000${close}`),
                tagName: item.name,
                open,
                close,
                count: item.count,
                broad,
                alreadyAdded,
                recommended: !alreadyAdded && recommendedNames.has(lower) && !broad,
            };
        })
        .sort((a, b) => Number(b.recommended) - Number(a.recommended) || b.count - a.count || a.tagName.localeCompare(b.tagName));
}

export function normalizeNarrativeRegexRules(rawRules) {
    const source = Array.isArray(rawRules)
        ? rawRules
        : String(rawRules ?? '').split(/\r?\n/);
    return source
        .map(item => String(item ?? '').trim())
        .filter(Boolean)
        .slice(0, 8)
        .map(item => item.slice(0, 260));
}

function extractIncludedNarrativeTag(text, tagName) {
    const normalized = String(tagName || '').trim();
    if (!/^[A-Za-z0-9_:-]{1,80}$/.test(normalized)) return String(text ?? '');
    const pattern = new RegExp(
        `<${escapeRegExp(normalized)}(?:\\s[^<>]*?)?>([\\s\\S]*?)<\\/${escapeRegExp(normalized)}\\s*>`,
        'gi',
    );
    const matches = [];
    let match;
    while ((match = pattern.exec(String(text ?? '')))) {
        matches.push(String(match[1] || ''));
        if (match[0] === '') pattern.lastIndex += 1;
    }
    // “只读取某标签”是便捷提取器：本条没有该标签时保留原文，
    // 避免不同预设/旧楼层因为格式不一致被整个吃空。
    return matches.length ? matches.join('\n') : String(text ?? '');
}

function compileNarrativeRegexRule(rawRule) {
    const raw = String(rawRule || '').trim();
    if (!raw) return null;
    let pattern = raw;
    let flags = 'g';
    const slash = raw.match(/^\/(.*)\/([dgimsuvy]*)$/);
    if (slash) {
        pattern = slash[1];
        flags = slash[2] || 'g';
    }
    // Replacement must scan the whole narrative. Sticky mode would only match
    // at lastIndex and is not useful for a cleanup rule.
    flags = [...new Set(`${flags.replaceAll('y', '')}g`)].join('');
    try {
        return new RegExp(pattern, flags);
    } catch {
        return null;
    }
}

export function filterNarrativeText(text, settings = {}) {
    let result = String(text ?? '');
    // Always strip well-formed HTML comments (non-greedy, dotAll).
    result = result.replace(/<!--[\s\S]*?-->/g, '');

    if (settings?.tagFilterEnabled === false) return result;

    // Optional positive extraction comes first. If a preset wraps the actual
    // prose in e.g. <narrative>...</narrative>, users can simply name the tag
    // instead of maintaining a long exclusion list.
    result = extractIncludedNarrativeTag(result, settings?.narrativeIncludeTag);

    const rules = normalizeTagFilterRules(settings?.tagFilterRules);
    for (const rule of rules) {
        const { open, close } = rule;
        if (open && close) {
            const pattern = new RegExp(
                `${escapeRegExp(open)}[\\s\\S]*?${escapeRegExp(close)}`,
                'g',
            );
            let previous;
            do {
                previous = result;
                result = result.replace(pattern, '');
            } while (result !== previous);
            continue;
        }
        if (!open && close) {
            let previous;
            do {
                previous = result;
                const index = result.indexOf(close);
                if (index === -1) break;
                result = result.slice(index + close.length);
            } while (result !== previous);
            continue;
        }
        if (open && !close) {
            const index = result.indexOf(open);
            if (index !== -1) result = result.slice(0, index);
        }
    }

    for (const rawRule of normalizeNarrativeRegexRules(settings?.narrativeRegexFilters)) {
        const pattern = compileNarrativeRegexRule(rawRule);
        if (!pattern) continue;
        result = result.replace(pattern, '');
    }
    return result;
}

/**
 * Last `count` usable assistant message ids ending at `messageId` (ascending).
 * Walks raw chat by index; does not consult narrativeContext (which drops empty-after-filter turns).
 */
export function selectPendingAssistantMessageIds(chat, messageId, count, isUsableAssistant) {
    const list = asArray(chat);
    const maxCount = Math.max(1, Number(count) || 1);
    const target = Number(messageId);
    const end = Number.isFinite(target)
        ? Math.min(Math.max(0, target), Math.max(0, list.length - 1))
        : list.length - 1;
    const usable = typeof isUsableAssistant === 'function'
        ? isUsableAssistant
        : (message) => Boolean(message && !message.is_user && !message.is_system);
    const ids = [];
    if (!list.length || end < 0) return ids;
    for (let index = end; index >= 0 && ids.length < maxCount; index -= 1) {
        if (!usable(list[index])) continue;
        ids.push(index);
    }
    return ids.reverse();
}

/** Count assistant narrative turns whose messageId is in the pending batch. */
export function countSurvivingNewAssistantTurns(narrativeTurns, pendingMessageIds) {
    const pending = new Set(asArray(pendingMessageIds).map(Number));
    return asArray(narrativeTurns).filter(
        turn => turn?.role === 'assistant' && pending.has(Number(turn.messageId)),
    ).length;
}

export function trimState(inputState) {
    const state = deepClone(inputState);
    const previousSchemaVersion = asInteger(state.schemaVersion, 0, 0);
    state.schemaVersion = SCHEMA_VERSION;
    state.lastTimeResolution = normalizeStoredTimeResolution(state.lastTimeResolution);
    state.nextTurnInjection = normalizeNextTurnInjection(state.nextTurnInjection);
    const absoluteMinute = asInteger(state.clock?.absoluteMinute, MINUTES_PER_DAY, 0);
    const absoluteDay = Math.floor(absoluteMinute / MINUTES_PER_DAY);
    // Keep the raw calendar long enough to decide whether an old save ever had
    // real calendar evidence. Normalization manufactures a harmless calculation
    // fallback, so using the normalized object for migration would make "missing"
    // data look like a genuine Gregorian date.
    const rawCalendar = state.world?.calendar;
    state.world = {
        name: asString(state.world?.name, 'Thế giới chưa đặt tên', 80),
        title: asString(state.world?.title, 'Thế giới vẫn tiếp diễn', 180),
        detail: asString(state.world?.detail, '', 640),
        // User-authored foundation. Routine simulation can read it but never rewrites it.
        background: asString(state.world?.background, '', LIMITS.worldBackground),
        calendar: normalizeWorldCalendar(rawCalendar, absoluteDay),
    };
    const hasCalendarCalibrationAudit = asArray(state.audit).some(entry => (
        ['calendar_calibrated', 'clock_anchor_initialized', 'clock_anchor_recalibrated']
            .includes(entry?.type)
    ));
    const rawAnchorYear = Number(rawCalendar?.anchor_year ?? rawCalendar?.anchorYear);
    const rawAnchorMonth = Number(rawCalendar?.anchor_month ?? rawCalendar?.anchorMonth);
    const rawAnchorDay = Number(rawCalendar?.anchor_day ?? rawCalendar?.anchorDay);
    const rawCalendarHasAnchor = Number.isFinite(rawAnchorYear)
        && Number.isFinite(rawAnchorMonth)
        && Number.isFinite(rawAnchorDay)
        && rawAnchorYear >= 1
        && rawAnchorMonth >= 1 && rawAnchorMonth <= 12
        && rawAnchorDay >= 1 && rawAnchorDay <= 31;
    const legacyCalendarLooksPlaceholder = previousSchemaVersion < 8
        && (!rawCalendar || (
            rawCalendar?.name === 'Lịch thế giới chính'
            && rawAnchorYear === 1
            && rawAnchorMonth === 1
            && rawAnchorDay === 1
        ))
        && !hasCalendarCalibrationAudit
        && ['initial', 'narrative', 'unknown'].includes(asString(state.clock?.source, 'initial', 40));
    const inferredAnchored = legacyCalendarLooksPlaceholder
        ? false
        : rawCalendarHasAnchor && asString(state.clock?.source, 'initial', 40) !== 'initial';
    state.clock = {
        absoluteMinute,
        lastCheckedAt: asInteger(
            state.clock?.lastCheckedAt,
            state.clock?.absoluteMinute ?? MINUTES_PER_DAY,
            0,
        ),
        source: asString(state.clock?.source, 'unknown', 40),
        reason: asString(state.clock?.reason, '', 240),
        anchored: legacyCalendarLooksPlaceholder
            ? false
            : (state.clock?.anchored === undefined
                ? inferredAnchored
                : Boolean(state.clock?.anchored)),
        precision: legacyCalendarLooksPlaceholder
            ? 'day'
            : (['minute', 'daypart', 'date', 'day'].includes(state.clock?.precision)
                ? state.clock.precision
                : ((state.clock?.anchored === undefined ? inferredAnchored : Boolean(state.clock?.anchored))
                    ? 'minute'
                    : 'day')),
        daypart: asString(state.clock?.daypart, '', 20),
    };

    // 人物 ID 是 UI 编辑、观测与删除操作的稳定定位键。
    // 旧状态或模型输出偶尔可能产生重复 ID；如果继续保留，点击 A 人物的操作
    // 会命中数组中更早出现的 B 人物。载入/提交状态时统一修复冲突，保留首个
    // ID，并为后续冲突项生成新的稳定 ID。
    const seenPersonIds = new Set();
    state.people = asArray(state.people)
        .map(person => normalizePerson(person, person, state.clock.absoluteMinute))
        .map(person => {
            if (!seenPersonIds.has(person.id)) {
                seenPersonIds.add(person.id);
                return person;
            }
            let nextId = makeId('person');
            while (seenPersonIds.has(nextId)) nextId = makeId('person');
            person.id = nextId;
            seenPersonIds.add(nextId);
            return person;
        });

    const events = asArray(state.events)
        .map(event => normalizeEvent(event, state.clock.absoluteMinute, event));
    const active = events.filter(event => !TERMINAL_EVENT_STATES.has(event.status));
    const terminal = events
        .filter(event => TERMINAL_EVENT_STATES.has(event.status))
        .sort((a, b) => Number(b.resolvedAt || b.updatedAt) - Number(a.resolvedAt || a.updatedAt));
    state.events = [
        ...active.slice(-LIMITS.events),
        ...terminal.slice(0, Math.max(0, LIMITS.events - active.length)),
    ];
    synchronizeCognitiveLedger(state);

    state.echoes = asArray(state.echoes).slice(0, LIMITS.echoes);
    state.archive = asArray(state.archive).slice(0, LIMITS.archive);
    state.foregroundFacts = asArray(state.foregroundFacts).slice(0, LIMITS.foregroundFacts);

    const normalizedWorldFacts = [];
    for (const rawFact of asArray(state.worldFacts).slice(0, LIMITS.worldFacts)) {
        const existing = normalizedWorldFacts.find(item => item.key === worldFactStableKey(rawFact));
        const fact = normalizeWorldFact(rawFact, existing, state.clock.absoluteMinute);
        if (!fact.value) continue;
        if (existing) Object.assign(existing, fact);
        else normalizedWorldFacts.push(fact);
    }
    state.worldFacts = normalizedWorldFacts;
    state.worldPulse = normalizeWorldPulse(state.worldPulse, state.clock.absoluteMinute);
    syncPublicEventRealityFacts(state, state.clock.absoluteMinute);
    state.publicImpactLedger = asArray(state.publicImpactLedger)
        .map(record => normalizePublicImpactRecord(record, state.clock.absoluteMinute))
        .filter(record => record.sourceEventId && record.fingerprint)
        .slice(0, LIMITS.publicImpactLedger);

    // Schema 14 introduces an explicit authoritative fact layer. Old person
    // locations may already lag behind the latest foreground, so migration does
    // not immediately promote them to hard facts. Terminal event results are safe
    // to retain; person state becomes authoritative after the first successful
    // 1.3 reconciliation pass.
    if (previousSchemaVersion < 14) {
        state.needsReconciliation = true;
        if (!state.worldFacts.length) {
            for (const event of state.events) settleEventResultFact(state, event, null);
        }
    } else {
        state.needsReconciliation = Boolean(state.needsReconciliation);
    }
    if (previousSchemaVersion < 15) {
        state.worldPulse.baselineEstablished = Boolean(state.worldPulse.domains.length);
        state.worldPulse.lastSweepAt = state.clock.absoluteMinute;
    }
    if (previousSchemaVersion < 16) {
        // publicity 在 normalizeEvent 中已按“明确公共传播证据”保守迁移。
        // 不允许把旧 known/direct 直接解释为社会公开。
        state.events = state.events.map(event => normalizeEvent(event, state.clock.absoluteMinute, event));
    }
    if (previousSchemaVersion < 17) {
        // 升级时把已有公共事件视为“此前世界已经包含其后果”，避免更新后
        // 把旧新闻全部重新冲击一遍人物/行业。只有之后新增或公共信息真正变化
        // 的事件才进入新的影响传播队列。
        recordProcessedPublicImpacts(
            state,
            state.events.filter(eventHasPublicPropagation),
            [],
            { reason: 'schema-17-baseline' },
        );
    }
    if (previousSchemaVersion < 18) {
        // 最新公开报道和真正公开的终局从此分开。旧终结事件不会把
        // publicSummary 自动猜成 publicResult，避免把“仍在下雨”之类旧报道
        // 升级后继续冒充当前结果。
        state.events = state.events.map(event => normalizeEvent(event, state.clock.absoluteMinute, event));
        // schema 18 的公共影响 fingerprint 只看真正公开的信息，不再看后台
        // status。升级时给现有公开事件建立新基线，避免把所有旧新闻重放一次。
        recordProcessedPublicImpacts(
            state,
            state.events.filter(eventHasPublicPropagation),
            [],
            { reason: 'schema-18-public-fingerprint-baseline' },
        );
    }
    if (previousSchemaVersion < 20) {
        // 旧认知账本曾受 actors / known_by / visibility 反向推断污染，无法可靠
        // 区分“角色真的知道”与“世界/模型知道”。升级时对 NPC 做保守清洗，
        // 之后只允许带获知路径和证据的 knowledge_updates 重新建立认知。
        state.people = state.people.map(person => {
            if (person.isUser) return person;
            return {
                ...person,
                cognitionReady: false,
                knownEventIds: [],
                knownEventViews: [],
                knownFactKeys: [],
                knownFactBeliefs: [],
                knownClueIds: [],
                innerVoice: '',
                innerVoiceAt: state.clock.absoluteMinute,
            };
        });
        state.events = state.events.map(event => ({
            ...event,
            knownBy: [],
        }));
        appendAudit(state, {
            type: 'cognition_schema_20_reset',
            text: 'Đã dọn sổ cái nhận thức NPC phiên bản cũ, chờ thiết lập lại theo đường biết được',
            reason: 'actors/known_by/visibility phiên bản cũ có thể làm rò rỉ sự toàn tri của thế giới cho nhân vật',
        });
    }
    if (previousSchemaVersion < 24) {
        // 首次升级不假装旧世界已经被完整巡查。coverage 保持“尚未检查”，
        // 让下一次正常世界推演或手动舆情刷新安全建立真实覆盖基线。
        state.worldPulse.coverage = normalizeWorldCoverage(
            state.worldPulse.coverage,
            state.clock.absoluteMinute,
        );
        appendAudit(state, {
            type: 'world_coverage_schema_24_ready',
            text: 'Sổ cái luân phiên thế giới công cộng ngoài ống kính đã sẵn sàng',
            reason: 'Lần tuần tra đầu tiên sẽ được thiết lập trong lần suy diễn thế giới đến hạn kế tiếp, không viết ngược lại thế giới cũ',
        });
    }

    state.consistencyConflicts = asArray(state.consistencyConflicts)
        .map(conflict => normalizeConsistencyConflict(
            conflict,
            state.clock.absoluteMinute,
            conflict?.messageId ?? null,
        ))
        .slice(0, LIMITS.consistencyConflicts);
    state.storyMemory = normalizeStoryMemory(state.storyMemory, state.clock.absoluteMinute);
    state.audit = asArray(state.audit).slice(0, LIMITS.audit);
    state.revision = asInteger(state.revision, 0, 0);
    state.pendingSync = Boolean(state.pendingSync);
    state.updatedAt = asString(state.updatedAt, nowIso(), 40);
    return state;
}

export function isTerminalEvent(event) {
    return TERMINAL_EVENT_STATES.has(event?.status);
}

export function isActiveEvent(event) {
    return ACTIVE_EVENT_STATES.has(event?.status);
}
