import {
    AUTO_HIDE_KEEP_RECENT_MESSAGES,
    AUTO_HIDE_KEEP_RECENT_MAX,
    AUTO_HIDE_KEEP_RECENT_MIN,
    markAutoHiddenMessages,
    normalizeAutoHideKeepRecentMessages,
    restoreAutoHiddenMessages,
    setAutoHideKeepRecentMessages,
} from './auto-hide.js';

const MODULE_ID = 'world_backstage';
const STATE_KEY = 'world_backstage_v1';
const SETTING_KEY = 'autoHideKeepRecentMessages';
const CONTROL_CLASS = 'wb-auto-hide-keep-setting';

function getContext() {
    return globalThis.SillyTavern?.getContext?.() || null;
}

function getModuleSettings({ create = false } = {}) {
    const context = getContext();
    if (!context?.extensionSettings) return null;
    if (create && (!context.extensionSettings[MODULE_ID] || typeof context.extensionSettings[MODULE_ID] !== 'object')) {
        context.extensionSettings[MODULE_ID] = {};
    }
    return context.extensionSettings[MODULE_ID] || null;
}

function currentKeepRecent() {
    const settings = getModuleSettings();
    const value = settings?.[SETTING_KEY] ?? AUTO_HIDE_KEEP_RECENT_MESSAGES;
    return setAutoHideKeepRecentMessages(value);
}

function setMessageHiddenDomState(messageId, hidden) {
    const node = globalThis.document?.querySelector?.(`.mes[mesid="${Number(messageId)}"]`);
    if (node) node.setAttribute('is_system', String(Boolean(hidden)));
}

function currentWorldState(context) {
    return context?.chatMetadata?.[STATE_KEY]?.currentState || null;
}

async function reconcileAutoHiddenFloors(keepRecent) {
    const context = getContext();
    const settings = getModuleSettings();
    if (
        !context
        || !Array.isArray(context.chat)
        || !settings?.enabled
        || !settings?.memorySystemEnabled
        || !settings?.injectionMemory
        || !settings?.autoHideArchivedFloors
    ) return;

    const state = currentWorldState(context);
    const memory = state?.storyMemory;
    const indexedThroughMessageId = Number(memory?.indexedThroughMessageId ?? -1);
    if (indexedThroughMessageId < 0) return;

    const restoredIds = restoreAutoHiddenMessages(context.chat);
    for (const messageId of restoredIds) setMessageHiddenDomState(messageId, false);

    const hiddenIds = markAutoHiddenMessages(context.chat, indexedThroughMessageId, {
        keepRecent,
        summaries: memory?.summaries || [],
    });
    for (const messageId of hiddenIds) setMessageHiddenDomState(messageId, true);

    if (restoredIds.length || hiddenIds.length) await context.saveChat?.();
}

function updateControlCopies(value) {
    for (const toggle of document.querySelectorAll('input[data-wb-setting="autoHideArchivedFloors"]')) {
        const row = toggle.closest('.wb-setting-toggle');
        const copy = row?.querySelector('div > span');
        if (copy) {
            const text = `Sau khi ký ức dài hạn được xác nhận đã lưu xong, tự động ẩn các tầng cũ hơn; hiện giữ lại ${value} tầng chính văn đã lưu trữ gần nhất cùng toàn bộ chính văn chưa lưu trữ. Cần bật chèn ký ức dài hạn; lịch sử trò chuyện sẽ không bị xóa.`;
            if (copy.textContent !== text) copy.textContent = text;
        }
    }
}

function syncControls(value = currentKeepRecent()) {
    for (const input of document.querySelectorAll('input[data-wb-auto-hide-keep="true"]')) {
        input.value = String(value);
    }
    updateControlCopies(value);
}

function enhanceControls() {
    const value = currentKeepRecent();
    for (const toggle of document.querySelectorAll('input[data-wb-setting="autoHideArchivedFloors"]')) {
        const row = toggle.closest('.wb-setting-toggle');
        if (!row || row.dataset.wbAutoHideCustomReady === 'true') continue;
        row.dataset.wbAutoHideCustomReady = 'true';

        const label = document.createElement('label');
        label.className = `wb-number-setting ${CONTROL_CLASS}`;
        label.innerHTML = `Giữ lại chính văn đã lưu trữ gần nhất (tầng)<input type="number" min="${AUTO_HIDE_KEEP_RECENT_MIN}" max="${AUTO_HIDE_KEEP_RECENT_MAX}" step="1" data-wb-auto-hide-keep="true" value="${value}">`;
        row.insertAdjacentElement('afterend', label);
    }
    syncControls(value);
}

async function persistKeepRecent(rawValue) {
    const value = normalizeAutoHideKeepRecentMessages(rawValue, currentKeepRecent());
    const settings = getModuleSettings({ create: true });
    const context = getContext();
    if (!settings || !context) return;

    settings[SETTING_KEY] = value;
    setAutoHideKeepRecentMessages(value);
    syncControls(value);
    context.saveSettingsDebounced?.();
    await reconcileAutoHiddenFloors(value);
}

function start() {
    currentKeepRecent();
    enhanceControls();

    document.addEventListener('change', event => {
        const input = event.target?.closest?.('input[data-wb-auto-hide-keep="true"]');
        if (!input) return;
        void persistKeepRecent(input.value).catch(error => {
            console.warn('[世界背面] Cập nhật số tầng giữ lại khi tự động ẩn thất bại', error);
        });
    }, true);

    const observer = new MutationObserver(() => enhanceControls());
    observer.observe(document.documentElement, { childList: true, subtree: true });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
} else {
    start();
}
